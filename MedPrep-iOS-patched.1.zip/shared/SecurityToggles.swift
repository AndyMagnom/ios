import Foundation

/// iOS twin of the macOS `AppConfig.MacSecurity` switches.
///
/// Every protection is ON in Release builds and CANNOT be turned off there.
/// In Debug builds you can flip any switch below so the app runs on the
/// MacInCloud VM, the iOS Simulator, or under the Xcode debugger.
///
/// HOW TO USE ON MACINCLOUD (Xcode 26.2):
/// 1. Build the Debug scheme and run on an iOS Simulator.
/// 2. Set the "EDIT HERE" values below (or change them later in the app's
///    UserDefaults - keys are printed next to each case; toggles are frozen
///    at launch, so restart the app after editing defaults or use
///    `SecurityToggles.restoreDefaults()` by relaunching after clearing).
/// 3. On the Moodle side, enable LockGuard's "macOS app" support
///    (auth_devicelock | macOS enabled = 1) so the simulator can enroll with
///    the existing macOS device-key protocol. No Apple credentials needed.
///
/// Release/TestFlight/App Store: every protection returns true and the
/// simulator/VM/mac enrollments are impossible (this file never returns a
/// non-default there).
enum SecurityToggles {
    enum Protection: String, CaseIterable {
        // ---- Platform gates -------------------------------------------------
        /// Block the iOS Simulator ("MedPrep requires a physical Apple device").
        case simulator = "Block the iOS Simulator"
        /// Block "Designed for iPad" apps running on Apple-silicon Macs.
        case iosOnMac = "Block iOS on Mac (Designed for iPad)"
        /// Block the Apple Vision Pro compatibility idiom.
        case vision = "Block Apple Vision Pro"
        /// Jailbreak file-system probes (Cydia, Sileo, /var/jb, substrate, sshd).
        case jailbreakPaths = "Jailbreak file-system probes"
        /// cydia:// / sileo:// URL-scheme probes.
        case jailbreakSchemes = "Jailbreak URL-scheme probes"
        /// Sandbox-escape write probe outside the app container.
        case sandboxProbe = "Sandbox-escape write probe"
        /// DYLD_INSERT_LIBRARIES environment check.
        case injectedEnvironment = "Block injected-library environment variables"
        /// Loaded-library scan for Frida/Substrate/Substitute/libhooker/ElleKit.
        case hookLibraries = "Block Frida and known hook libraries"
        /// Attached-debugger detection (P_TRACED). Turn OFF to run from Xcode
        /// with the debugger attached in Debug builds only.
        case debugger = "Block attached debuggers"
        /// Require >= 2 valid SPKI pins per host (turn OFF only when your VM
        /// sits behind a TLS-intercepting proxy for development).
        case pinnedTLS = "Verify current / backup server public-key pins"
        /// Apple App Attest + DeviceCheck hardware proof. Turn OFF only for
        /// Simulator/VM development: the app then enrolls through the server's
        /// existing macOS device-key protocol instead (no Apple proof).
        case appAttest = "Require Apple App Attest / DeviceCheck proof"

        // ---- Capture protection --------------------------------------------
        /// Secure-text-canvas layer exclusion (screenshots/screen recordings).
        /// Turn OFF only if the private canvas API misbehaves on your VM.
        case captureExclusion = "Exclude content pixels from capture"
        /// External-display / scene-capture-state monitoring and revocation.
        case captureDetection = "Detect screen recording, mirroring and external displays"
        /// Screenshot/recording telemetry plus bearer revocation on the server.
        case screenshotReports = "Report capture events to Moodle and revoke the session"
        /// Opaque cover over content and sheets while inactive or captured.
        case inactiveCover = "Hide content and stop playback when inactive"

        // ---- Content hardening ----------------------------------------------
        /// Injected CSS/JS: no selection/copy/print/share/fullscreen/downloads.
        case contentRestrictions = "Block selection, copy, print, share and downloads"
        /// Clear the system pasteboard on inactivity/disappearance/purge.
        case clipboardWipe = "Clear clipboard when the app becomes inactive"
        /// Deny websites camera/microphone permission prompts.
        case mediaPermissions = "Block website camera / microphone access"
        /// Disable AirPlay and picture-in-picture playback routes.
        case airPlay = "Block media AirPlay / external playback"
        /// Keep the WebKit inspector (Safari Web Inspector) disabled.
        case webInspection = "Block Web Inspector"

        // ---- Development features (default OFF, still OFF in Release) -------
        /// Present the native file picker for Moodle file inputs. The picker is
        /// native (outside the capture-excluded layer); enable per build if you
        /// need attachment uploads during testing.
        case fileUploads = "Allow native file uploads (file inputs)"
        /// Open user-tapped main-frame https links that point outside the
        /// trusted Moodle hosts in Safari. Disabled keeps all content inside
        /// the protected canvas.
        case externalLinks = "Open external https links in Safari"
    }

    /// EDIT HERE: true = protection/feature ON, false = OFF. Debug only.
    /// Any omitted option defaults to ON, except fileUploads/externalLinks.
    static let debugDefaults: [Protection: Bool] = [
        // ---- Platform gates (the ones to flip for MacInCloud/VM development)
        .simulator: false,          // <- required on the iOS Simulator
        .iosOnMac: false,           // <- required for "My Mac (Designed for iPad)" runs
        .vision: true,
        .jailbreakPaths: false,     // <- VM images often trip these heuristics
        .jailbreakSchemes: false,
        .sandboxProbe: false,
        .injectedEnvironment: false,
        .hookLibraries: false,
        .debugger: false,           // <- required to run with the Xcode debugger
        .pinnedTLS: true,           // <- flip to false only behind a TLS proxy
        .appAttest: false,          // <- false: enroll via the macOS device-key protocol

        // ---- Capture protection
        .captureExclusion: true,    // <- flip to false only if the canvas API fails on your VM
        .captureDetection: false,   // <- the simulator reports no capture state; harmless either way
        .screenshotReports: true,
        .inactiveCover: true,

        // ---- Content hardening
        .contentRestrictions: true,
        .clipboardWipe: true,
        .mediaPermissions: true,
        .airPlay: true,
        .webInspection: true,

        // ---- Development features
        .fileUploads: false,
        .externalLinks: false,
    ]

    private static func key(_ protection: Protection) -> String { "MedPrepDebugSecurity." + protection.rawValue }

    #if DEBUG
    /// Frozen at launch so a runtime UserDefaults change cannot disable a
    /// protection while content is on screen.
    private static let launched: [Protection: Bool] = Dictionary(uniqueKeysWithValues:
        Protection.allCases.map { ($0, saved($0)) })

    static func saved(_ protection: Protection) -> Bool {
        UserDefaults.standard.object(forKey: key(protection)) as? Bool ?? debugDefaults[protection] ?? true
    }
    static func save(_ enabled: Bool, for protection: Protection) {
        UserDefaults.standard.set(enabled, forKey: key(protection))
    }
    static func restoreDefaults() {
        for protection in Protection.allCases { UserDefaults.standard.removeObject(forKey: key(protection)) }
    }
    static func isReleaseLocked(_ protection: Protection) -> Bool {
        protection != .fileUploads && protection != .externalLinks
    }
    #endif

    static func enabled(_ protection: Protection) -> Bool {
        #if DEBUG
        return launched[protection] ?? debugDefaults[protection] ?? true
        #else
        // Release: every protection is forced ON. The two dev conveniences
        // stay at their coded defaults (OFF) unless changed in source.
        return protection != .fileUploads && protection != .externalLinks
            ? true : (debugDefaults[protection] ?? false)
        #endif
    }
}
