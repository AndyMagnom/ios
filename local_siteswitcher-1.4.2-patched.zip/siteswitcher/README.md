# Site switcher (local_siteswitcher)

Adds a dropdown button to the Moodle login page that links to your other Moodle sites.
The button uses the same `btn btn-primary` style as the "Log in" button.

## Install (Moodle 5.0 and 5.1)

1. Copy the `siteswitcher` folder to:
   - Moodle 5.1: `<moodle>/public/local/siteswitcher`
   - Moodle 5.0: `<moodle>/local/siteswitcher`
   Or upload the ZIP at Site administration > Plugins > Install plugins.
2. Visit Site administration > Notifications to finish the install.
3. Configure at Site administration > Plugins > Local plugins > Site switcher.

## Settings

- Enable site switcher: on/off.
- Button text: label of the dropdown button.
- Show current site on the button: use the current site's name as the button text (falls back to Button text if no site is marked current).
- Dropdown heading: optional heading inside the menu (empty = hidden).
- Open in a new tab: open links in a new tab.
- Show on all login-style pages: also show on sign-up and forgotten password pages.
- Show favicons: show each site's favicon next to its name. Icons are detected when you save the site list (the plugin reads the icon link in each site's page). The current site uses its own theme favicon. Enter an Icon URL on a row to override.
- Publish site list for the mobile app: serves host names of unlocked sites as JSON at /local/siteswitcher/sites.php for the MedPrep/AndyPrep Android app. Off by default.
- Sites: add, edit, reorder and remove entries (title + URL). No site is hard coded.
  - Current site: marks the site this Moodle runs on. Shown with a checkmark, not clickable. Only one can be current.
  - Locked: entry is grayed out with a lock icon and cannot be clicked.

If no sites are configured the button is not shown.

Note: icon detection uses Moodle's curl class, so Moodle's blocked hosts rules apply (sites on private IP addresses cannot be read; set an Icon URL by hand for those).
