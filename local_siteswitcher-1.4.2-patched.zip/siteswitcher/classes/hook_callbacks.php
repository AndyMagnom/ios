<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace local_siteswitcher;

use core\hook\output\before_footer_html_generation;

/**
 * Hook callbacks.
 *
 * @package    local_siteswitcher
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class hook_callbacks {
    /**
     * Add the site switcher dropdown to login pages.
     *
     * @param before_footer_html_generation $hook
     */
    public static function before_footer_html_generation(before_footer_html_generation $hook): void {
        global $PAGE;

        if (!get_config('local_siteswitcher', 'enabled')) {
            return;
        }
        if ($PAGE->pagelayout !== 'login') {
            return;
        }
        if (!get_config('local_siteswitcher', 'showonallloginpages') && $PAGE->pagetype !== 'login-index') {
            return;
        }

        $sites = helper::get_sites();
        if (empty($sites)) {
            return;
        }

        $label = trim((string) get_config('local_siteswitcher', 'buttonlabel'));
        if ($label === '') {
            $label = get_string('buttonlabel_default', 'local_siteswitcher');
        }
        if (get_config('local_siteswitcher', 'showcurrentonbutton')) {
            // Show the current site's name on the button. Falls back to the button text if none is marked.
            foreach ($sites as $site) {
                if ($site['current']) {
                    $label = $site['title'];
                    break;
                }
            }
        }
        $heading = trim((string) get_config('local_siteswitcher', 'menuheading'));

        $showfavicons = (bool) get_config('local_siteswitcher', 'showfavicons');

        $items = [];
        foreach ($sites as $site) {
            $favicon = '';
            if ($showfavicons) {
                if ($site['icon'] !== '') {
                    // Icon set by hand wins.
                    $favicon = $site['icon'];
                } else if ($site['current'] && method_exists($hook->renderer, 'favicon')) {
                    // This site: use its own theme favicon.
                    $favicon = (string) $hook->renderer->favicon();
                } else {
                    // Icon detected when the site list was saved.
                    $favicon = $site['autoicon'];
                }
            }
            $items[] = [
                'title' => $site['title'],
                'url' => $site['url'],
                'iscurrent' => $site['current'],
                'islocked' => !$site['current'] && $site['locked'],
                'hasfavicon' => $favicon !== '',
                'favicon' => $favicon,
            ];
        }

        $context = [
            'buttonlabel' => $label,
            'hasheading' => $heading !== '',
            'heading' => $heading,
            'newtab' => (bool) get_config('local_siteswitcher', 'opennewtab'),
            'sites' => $items,
        ];

        $hook->add_html($hook->renderer->render_from_template('local_siteswitcher/switcher', $context));
    }
}
