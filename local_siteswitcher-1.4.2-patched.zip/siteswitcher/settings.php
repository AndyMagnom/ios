<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Admin settings.
 *
 * @package    local_siteswitcher
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    $settings = new admin_settingpage(
        'local_siteswitcher',
        get_string('pluginname', 'local_siteswitcher')
    );
    $ADMIN->add('localplugins', $settings);

    if ($ADMIN->fulltree) {
        $settings->add(new admin_setting_configcheckbox(
            'local_siteswitcher/enabled',
            get_string('enabled', 'local_siteswitcher'),
            get_string('enabled_desc', 'local_siteswitcher'),
            1
        ));

        $settings->add(new admin_setting_configtext(
            'local_siteswitcher/buttonlabel',
            get_string('buttonlabel', 'local_siteswitcher'),
            get_string('buttonlabel_desc', 'local_siteswitcher'),
            get_string('buttonlabel_default', 'local_siteswitcher'),
            PARAM_TEXT
        ));

        $settings->add(new admin_setting_configcheckbox(
            'local_siteswitcher/showcurrentonbutton',
            get_string('showcurrentonbutton', 'local_siteswitcher'),
            get_string('showcurrentonbutton_desc', 'local_siteswitcher'),
            0
        ));

        $settings->add(new admin_setting_configtext(
            'local_siteswitcher/menuheading',
            get_string('menuheading', 'local_siteswitcher'),
            get_string('menuheading_desc', 'local_siteswitcher'),
            '',
            PARAM_TEXT
        ));

        $settings->add(new admin_setting_configcheckbox(
            'local_siteswitcher/opennewtab',
            get_string('opennewtab', 'local_siteswitcher'),
            get_string('opennewtab_desc', 'local_siteswitcher'),
            0
        ));

        $settings->add(new admin_setting_configcheckbox(
            'local_siteswitcher/showonallloginpages',
            get_string('showonallloginpages', 'local_siteswitcher'),
            get_string('showonallloginpages_desc', 'local_siteswitcher'),
            0
        ));

        $settings->add(new admin_setting_configcheckbox(
            'local_siteswitcher/showfavicons',
            get_string('showfavicons', 'local_siteswitcher'),
            get_string('showfavicons_desc', 'local_siteswitcher'),
            0
        ));

        $settings->add(new admin_setting_configcheckbox(
            'local_siteswitcher/appendpoint',
            get_string('appendpoint', 'local_siteswitcher'),
            get_string('appendpoint_desc', 'local_siteswitcher', (new moodle_url('/local/siteswitcher/sites.php'))->out(false)),
            0
        ));

        $settings->add(new \local_siteswitcher\admin_setting_sitelist(
            'local_siteswitcher/sites',
            get_string('sites', 'local_siteswitcher'),
            get_string('sites_desc', 'local_siteswitcher'),
            '[]'
        ));
    }
}
