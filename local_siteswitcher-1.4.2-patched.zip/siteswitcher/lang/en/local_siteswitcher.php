<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * English language strings.
 *
 * @package    local_siteswitcher
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['addsite'] = 'Add site';
$string['appendpoint'] = 'Publish site list for the mobile app';
$string['appendpoint_desc'] = 'Lets the mobile app read which sites to open inside the app, so you do not have to rebuild it when you add a site. Publishes the host names of all sites that are not locked as JSON at {$a}, readable by anyone (they are already visible on the login page). Leave off if you do not use the app.';
$string['buttonlabel'] = 'Button text';
$string['buttonlabel_default'] = 'Switch site';
$string['buttonlabel_desc'] = 'Text shown on the dropdown button.';
$string['currentsite_sr'] = 'Current site';
$string['enabled'] = 'Enable site switcher';
$string['enabled_desc'] = 'When disabled, the dropdown button is not shown anywhere.';
$string['error_badicon'] = 'Invalid icon URL "{$a}". Use a full address starting with http:// or https://, or leave it empty.';
$string['error_badurl'] = 'Invalid URL "{$a}". Use a full address starting with http:// or https://.';
$string['error_notitle'] = 'Every site needs a title.';
$string['lockedsite_sr'] = 'Locked';
$string['menuheading'] = 'Dropdown heading';
$string['menuheading_desc'] = 'Optional heading shown at the top of the dropdown menu. Leave empty for no heading.';
$string['movedown'] = 'Move down';
$string['moveup'] = 'Move up';
$string['opennewtab'] = 'Open in a new tab';
$string['opennewtab_desc'] = 'Open the selected site in a new browser tab instead of the current one.';
$string['pluginname'] = 'Site switcher';
$string['privacy:metadata'] = 'The Site switcher plugin does not store any personal data.';
$string['removesite'] = 'Remove site';
$string['showcurrentonbutton'] = 'Show current site on the button';
$string['showcurrentonbutton_desc'] = 'Use the name of the site marked "Current site" as the button text, so visitors see which site they are on without opening the menu. If no site is marked as current, the button text above is used.';
$string['showfavicons'] = 'Show favicons';
$string['showfavicons_desc'] = 'Show each website\'s favicon next to its name in the dropdown. Icons are detected automatically from each site when you save the site list. Enter an icon URL on a row to override it.';
$string['showonallloginpages'] = 'Show on all login-style pages';
$string['showonallloginpages_desc'] = 'By default the button only appears on the main login page. Enable this to also show it on the sign-up and forgotten password pages.';
$string['sitecurrent'] = 'Current site';
$string['sitecurrent_help'] = 'Mark the site this Moodle is running on. It gets a checkmark and cannot be clicked. Only one site can be current.';
$string['siteicon'] = 'Icon URL';
$string['siteicon_placeholder'] = 'Icon URL (optional, auto-detected)';
$string['sitelocked'] = 'Locked';
$string['sitelocked_help'] = 'Locked sites are grayed out with a lock icon and users cannot switch to them.';
$string['sites'] = 'Sites';
$string['sites_desc'] = 'Websites listed in the dropdown, in this order. Add, edit, reorder or remove entries at any time. Tick "Current site" on the entry that is this website (checkmark, not clickable). Tick "Locked" to gray an entry out with a lock icon so users cannot switch to it. Remember to save changes.';
$string['sitetitle'] = 'Title';
$string['sitetitle_placeholder'] = 'Site name';
$string['siteurl'] = 'URL';
$string['siteurl_placeholder'] = 'https://example.com/login/index.php';
