<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Helper functions for Lock Guard plugin
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

// v3.5.0: the persistent security-score engine lives in lib.php (it must be
// loadable without locallib), so make sure it is always available to the
// helpers below.
require_once(__DIR__ . '/lib.php');

// ============================================================
// Security-log rendering helpers (shared by every log view)
// ============================================================

/**
 * Resolve a log event action to [badge class, FA icon, human-readable label].
 *
 * Shared by auth_devicelock_action_badge() (styled badge for log tables)
 * and auth_devicelock_action_label() (plain label for tooltips, exports,
 * etc.), so every place that shows an action name stays in sync.
 *
 * Unknown/future actions fall back to a humanised label
 * (e.g. "some_new_event" -> "Some New Event") so nothing ever shows a
 * raw, underscored action name.
 *
 * @param string $action Raw action name from the logs table.
 * @return array         [Bootstrap badge class, FontAwesome icon, label].
 */
function auth_devicelock_action_info($action) {
    $action = trim((string)$action);
    if ($action === '') {
        return ['badge-secondary', 'fa-tag', 'Unknown'];
    }

    // [Bootstrap badge class, FontAwesome icon, human-readable label].
    $map = [
        // User activity events (v3.6.0) - light outlined badges keep the
        // high-volume navigation events visually distinct from security
        // events, which keep their solid colours.
        'activity_page'         => ['badge-light border text-dark', 'fa-eye', 'Page Viewed'],
        'activity_course'       => ['badge-light border text-dark', 'fa-book-open', 'Course Viewed'],
        'activity_section'      => ['badge-light border text-dark', 'fa-stream', 'Section Viewed'],
        'activity_module'       => ['badge-light border text-dark', 'fa-cubes', 'Activity Viewed'],
        'activity_dashboard'    => ['badge-light border text-dark', 'fa-home', 'Dashboard Viewed'],
        'activity_mycourses'    => ['badge-light border text-dark', 'fa-th-large', 'My Courses Viewed'],
        'activity_profile'      => ['badge-light border text-dark', 'fa-user-circle', 'Profile Viewed'],
        'activity_participants' => ['badge-light border text-dark', 'fa-users', 'Participants Viewed'],
        'activity_grades'       => ['badge-light border text-dark', 'fa-chart-bar', 'Grades Viewed'],
        'activity_catalog'      => ['badge-light border text-dark', 'fa-list-ul', 'Course Catalog Viewed'],
        'activity_download'     => ['badge-light border text-dark', 'fa-file-download', 'File Accessed'],
        'activity_link'         => ['badge-light border text-dark', 'fa-external-link', 'External Link Opened'],
        'activity_click'        => ['badge-light border text-dark', 'fa-hand-pointer', 'Button Clicked'],
        'activity_tour'         => ['badge-light border text-dark', 'fa-map-signs', 'User Tour'],
        // Logins & device events.
        'login_prevented'                => ['badge-danger', 'fa-ban', 'Blocked Login'],
        'blocked_device_login_attempt'   => ['badge-danger', 'fa-ban', 'Blocked Login'],
        'blocked_device_tried_to_login'  => ['badge-danger', 'fa-ban', 'Blocked Login'],
        'login_blocked_limit'            => ['badge-warning text-dark', 'fa-exclamation-triangle', 'Limit Blocked'],
        'device_limit_reached'           => ['badge-warning text-dark', 'fa-exclamation-triangle', 'Limit Blocked'],
        'unexpected_device_login'        => ['badge-warning text-dark', 'fa-warning', 'Unexpected Login'],
        'device_blocked'                 => ['badge-dark', 'fa-times', 'Device Blocked'],
        'device_status_blocked'          => ['badge-dark', 'fa-times', 'Device Blocked'],
        'device_status_active'           => ['badge-success', 'fa-check', 'Device Unblocked'],
        'new_browser_on_device'          => ['badge-info', 'fa-globe', 'New Browser'],
        'browser_login'                  => ['badge-light border', 'fa-desktop', 'Browser Login'],
        'device_registered'              => ['badge-primary', 'fa-plus-circle', 'Registered'],
        'device_login'                   => ['badge-light', 'fa-sign-in', 'Device Login'],
        'user_logout'                    => ['badge-dark', 'fa-sign-out', 'User Logout'],
        'browser_limit_reached'          => ['badge-warning text-dark', 'fa-ban', 'Browser Limit'],
        // Account / admin actions.
        'auth_method_migrated'           => ['badge-success', 'fa-random', 'Migrated'],
        'user_migrated'                  => ['badge-success', 'fa-random', 'Migrated'],
        'user_migrated_bulk'             => ['badge-success', 'fa-random', 'Migrated'],
        'auth_method_changed'            => ['badge-warning text-dark', 'fa-key', 'Auth Changed'],
        'auth_method_changed_bulk'       => ['badge-warning text-dark', 'fa-key', 'Auth Changed'],
        'reset_all_devices'              => ['badge-info', 'fa-refresh', 'Reset User Devices'],
        'reset_device_browsers'          => ['badge-info', 'fa-refresh', 'Browsers Reset'],
        'reset_user_browsers'            => ['badge-info', 'fa-globe', 'User Browsers Reset'],
        'reset_all_users_devices'        => ['badge-danger', 'fa-refresh', 'Reset All Users'],
        'save_user_limit'                => ['badge-secondary', 'fa-sliders', 'Limit Changed'],
        'send_custom_email'              => ['badge-info', 'fa-envelope', 'Email Sent'],
        'send_custom_email_bulk'         => ['badge-info', 'fa-envelope', 'Email Sent'],
        'send_reset_password'            => ['badge-warning text-dark', 'fa-unlock-alt', 'Pwd Reset Sent'],
        'generate_temporary_password'    => ['badge-info', 'fa-key', 'Temp Pwd Created'],
        'change_password_direct'         => ['badge-success', 'fa-key', 'Password Changed'],
        'password_changed'               => ['badge-success', 'fa-key', 'Password Changed'],
        'password_reset_completed'       => ['badge-success', 'fa-check-circle', 'Password Reset Completed'],
        'toggle_suspend'                 => ['badge-dark', 'fa-user-times', 'Suspend Toggled'],
        'confirm_user'                   => ['badge-success', 'fa-check-circle', 'User Confirmed'],
        'ban_user'                       => ['badge-danger', 'fa-ban', 'User Banned'],
        'unban_user'                     => ['badge-success', 'fa-check-circle', 'User Unbanned'],
        'bulk_ban_users'                 => ['badge-danger', 'fa-ban', 'Bulk Ban'],
        'bulk_unban_users'               => ['badge-success', 'fa-check-circle', 'Bulk Unban'],
        'copy_user_details'              => ['badge-secondary', 'fa-clipboard', 'Details Copied'],
        'bulk_copy_user_details'         => ['badge-secondary', 'fa-clipboard', 'Bulk Details Copied'],
        'delete_user_account'            => ['badge-danger', 'fa-trash', 'Account Deleted'],
        'bulk_delete_user_account'       => ['badge-danger', 'fa-trash', 'Bulk Deletion'],
        'clear_all_logs'                 => ['badge-secondary', 'fa-eraser', 'Logs Cleared'],
        'bulk_import_users'              => ['badge-info', 'fa-upload', 'Bulk User Import'],
        'quick_create_user'              => ['badge-success', 'fa-user-plus', 'Quick User Created'],
        'bulk_create_users'              => ['badge-success', 'fa-users', 'Bulk Users Created'],
        'change_course'                  => ['badge-info', 'fa-graduation-cap', 'Courses Changed'],
        'bulk_change_course'             => ['badge-info', 'fa-graduation-cap', 'Bulk Course Change'],
        'change_role'                    => ['badge-primary', 'fa-user-tag', 'Roles Changed'],
        'bulk_change_role'               => ['badge-primary', 'fa-user-tag', 'Bulk Role Change'],
        // App Guard events.
        'web_browser_sign_in_blocked'    => ['badge-danger', 'fa-mobile', 'App Guard: Sign-in Blocked'],
        'web_browser_session_terminated' => ['badge-danger', 'fa-mobile', 'App Guard: Session Terminated'],
        'emulator_detected'              => ['badge-dark', 'fa-desktop', 'App Guard: Emulator Detected'],
        'dev_options_detected'           => ['badge-warning text-dark', 'fa-wrench', 'App Guard: Dev Options'],
        'usb_debugging_detected'         => ['badge-warning text-dark', 'fa-usb', 'App Guard: USB Debugging'],
        'wireless_debugging_detected'    => ['badge-warning text-dark', 'fa-wifi', 'App Guard: Wireless Debugging'],
        'screenshot_attempt'             => ['badge-info', 'fa-camera', 'App Guard: Screenshot'],
        'screen_recording_detected'      => ['badge-info', 'fa-video-camera', 'App Guard: Screen Recording'],
        'audio_capture_detected'         => ['badge-info', 'fa-microphone', 'App Guard: Audio Capture'],
        'mic_guard_unavailable'          => ['badge-secondary', 'fa-microphone-slash', 'App Guard: Mic Guard Unavailable'],
        'mic_contended'                  => ['badge-secondary', 'fa-microphone-slash', 'App Guard: Mic Contended'],
        // Security score events (v3.5.0).
        'score_regained'                 => ['badge-success', 'fa-angle-up', 'Score Regained'],
        'score_changed'                  => ['badge-info', 'fa-sliders', 'Score Changed'],
        'bulk_score_reset'               => ['badge-success', 'fa-battery-full', 'Scores Reset (Bulk)'],
    ];

    if (isset($map[$action])) {
        return $map[$action];
    }

    // Windows App Guard family — grouped under one shield style with a
    // humanised suffix (e.g. "test_signing_detected" -> "Test Signing Detected").
    $appguardfamily = [
        'vm_detected', 'debugger_detected', 'dev_mode_detected', 'test_signing_detected',
        'remote_session_detected', 'virtual_display_detected', 'capture_tool_detected', 'recorder_suspected',
    ];
    if (in_array($action, $appguardfamily, true)) {
        return ['badge-dark', 'fa-shield', 'App Guard: ' . ucwords(str_replace('_', ' ', $action))];
    }

    // Generic fallback: humanised label so nothing ever looks raw/unstyled.
    return ['badge-secondary', 'fa-tag', ucwords(str_replace('_', ' ', $action))];
}

/**
 * The plain, human-readable label for a log event action (no HTML),
 * e.g. for icon tooltips and plain-text listings.
 *
 * @param string $action Raw action name from the logs table.
 * @return string        Human-readable label, escaped for HTML output.
 */
function auth_devicelock_action_label($action) {
    $info = auth_devicelock_action_info($action);
    return s($info[2]);
}

/**
 * Render a styled Bootstrap badge for a log event action.
 *
 * Every action the plugin can write to {auth_devicelock_logs} has an
 * explicit colour + icon + human-readable label here. Unknown/future
 * actions fall back to a generic badge with a humanised label
 * (e.g. "some_new_event" -> "Some New Event") so no log row ever
 * shows a raw, unstyled action name.
 *
 * @param string $action Raw action name from the logs table.
 * @return string        HTML for the badge (already escaped).
 */
function auth_devicelock_action_badge($action) {
    $m = auth_devicelock_action_info($action);
    return '<span class="badge ' . $m[0] . '"><i class="fa ' . $m[1] . '"></i> ' . s($m[2]) . '</span>';
}

/**
 * Human label for a log-details JSON key (v3.6.0).
 *
 * Fixes the acronyms that naive humanisation mangles ("device_id"
 * would become "Device Id") and gives known keys their proper full
 * labels ("pwlength" -> "Password Length"). Unknown keys fall back to
 * humanisation with acronym repair, so future keys still look right.
 *
 * @param string $key Raw JSON key.
 * @return string     Human-readable label.
 */
function auth_devicelock_detail_key_label($key) {
    $key = trim((string)$key);

    // Keys with a canonical label that plain humanisation gets wrong.
    $canonical = [
        'ip'                       => 'IP',
        'gpu'                      => 'GPU',
        'cpu'                      => 'CPU',
        'cpu_cores'                => 'CPU Cores',
        'device_id'                => 'Device ID',
        'pwlength'                 => 'Password Length',
        'ua'                       => 'User Agent',
        'useragent'                => 'User Agent',
        'os'                       => 'OS',
        'url'                      => 'URL',
        'browser_lang'             => 'Browser Language',
        'total_browsers_on_device' => 'Browsers on Device',
        'users'                    => 'Affected Users',
        'affected_users'           => 'Affected Users',
        'deleted_users'            => 'Deleted Users',
        'admin_user'               => 'Admin User ID',
        'admin_username'           => 'Admin Username',
        'courses_enrolled'         => 'Enrolled Courses',
        'courses_unenrolled'       => 'Un-enrolled Courses',
        'roles_added'              => 'Roles Added',
        'roles_removed'            => 'Roles Removed',
        'profile_user'             => 'Profile User',
        'tour_name'                => 'Tour',
        'phase'                    => 'Phase',
        'view_name'                => 'View',
        'from_page'                => 'From Page',
        'button'                   => 'Button',
        'button_type'              => 'Button Type',
        'form_action'              => 'Form Action',
        'section_number'           => 'Section Number',
        'section_name'             => 'Section Name',
        'fullname'                 => 'Full Name',
    ];
    if (isset($canonical[$key])) {
        return $canonical[$key];
    }

    $label = ucwords(str_replace('_', ' ', $key));

    // Repair acronyms: "Device Id" -> "Device ID", "My Gpu" -> "My GPU".
    $label = preg_replace_callback('/\b(Id|Ip|Gpu|Cpu|Os|Url|Api|Http|Https|Ram|Uri|Ssl)\b/',
        function ($m) {
            return strtoupper($m[1]);
        }, $label);

    return ($label === null) ? $key : $label;
}

/**
 * Render a device fingerprint for a table cell (v3.6.0).
 *
 * Shows the COMPLETE fingerprint - never a truncated copy - in a
 * small monospace span that wraps instead of being cut off. The full
 * value is also kept in the tooltip for easy copying.
 *
 * @param string|null $fingerprint Raw value from the logs/devices table.
 * @return string                   Escaped HTML.
 */
function auth_devicelock_fingerprint_span($fingerprint) {
    $fp = trim((string)$fingerprint);
    if ($fp === '') {
        return '<span class="lg-dimtext">&mdash;</span>';
    }
    if ($fp === 'system') {
        return '<span class="lg-dimtext"><i class="fa fa-gears" aria-hidden="true"></i> system</span>';
    }
    return '<span class="lg-fp" title="' . s($fp) . '">' . s($fp) . '</span>';
}

/**
 * Render the "Details" column of a log row as neat, styled chips.
 *
 * Replaces the old raw "key: value | key: value" text dump with:
 *  - a highlighted admin badge when an admin performed the action
 *    (admin_email / admin_name / admin_user keys),
 *  - one bordered chip per remaining key/value pair with a humanised
 *    key label, Yes/No for is_* flags, and long values truncated,
 *  - redundant keys (timestamp, ip) hidden — they already have their
 *    own dedicated table columns.
 *
 * v3.4.4: every event with metadata is now EXPANDABLE — the condensed
 * chips are followed by a "Show all" toggle and a hidden full-details
 * block that lists EVERY key with its COMPLETE, untruncated value.
 * Clicking the event row (or the toggle) swaps between the two views;
 * see auth_devicelock_print_log_expand_js() for the behaviour.
 *
 * v3.8.0: LIST values (sequential numeric arrays of strings, e.g. the
 * affected-user lists logged by the bulk handlers) render as a single
 * count chip in the condensed view and a scrollable one-row-per-item
 * block in the expanded view instead of a raw json_encode blob.
 *
 * @param string|null $detailsjson Raw JSON string from the logs table.
 * @return string                   HTML for the details cell (already escaped).
 */
function auth_devicelock_log_details_cell($detailsjson) {
    $raw = trim((string)$detailsjson);
    if ($raw === '') {
        return '';
    }

    $details = @json_decode($raw, true);
    if (!is_array($details) || empty($details)) {
        // Not a JSON object (or empty) — show the raw text muted.
        return '<small class="text-muted">' . s($raw) . '</small>';
    }

    $parts = [];     // Condensed chips (what the row shows by default).
    $fullitems = []; // Complete, untruncated items for the expanded view.

    // Admin badge — rendered prominently above the chips.
    $adminid = '';
    if (!empty($details['admin_email'])) {
        $adminid = $details['admin_email'];
    } else if (!empty($details['admin_name'])) {
        $adminid = $details['admin_name'];
    } else if (!empty($details['admin_user'])) {
        $adminid = $details['admin_user'];
    }
    if ($adminid !== '') {
        $parts[] = '<span class="badge badge-warning text-dark" style="font-size:85%;">'
            . '<i class="fa fa-user-shield"></i> Admin: <strong>' . s($adminid) . '</strong></span>';
    }

    foreach ($details as $key => $val) {
        $keylabel = auth_devicelock_detail_key_label($key);

        // v3.8.0: LIST values (sequential numeric arrays of strings, e.g.
        // the affected-user lists logged by the bulk handlers) are rendered
        // as a real list instead of an ugly json_encode blob: the condensed
        // view shows a single "LABEL: N" count chip, the expanded view one
        // row per item inside a scrollable block. Non-sequential arrays,
        // arrays of arrays and objects keep the classic json fallback.
        $listitems = null;
        if (is_array($val)) {
            $listitems = [];
            $expectedidx = 0;
            foreach ($val as $listkey => $listitem) {
                if ($listkey !== $expectedidx++ || !is_string($listitem)) {
                    $listitems = null;
                    break;
                }
                // v3.9.0 FIX: the validation loop used to only CHECK the
                // items without ever collecting them, so $listitems stayed
                // [] and every list (affected users, enrolled courses,
                // roles added/removed) rendered EMPTY even though the data
                // was correctly stored in the log row. Collect each valid
                // item so it can actually be rendered below.
                $listitems[] = $listitem;
            }
        }
        if ($listitems !== null) {
            // Expanded view: dedicated scrollable block, one row per item.
            $listrows = '';
            foreach ($listitems as $listitem) {
                $listrows .= '<div class="lg-log-list-row">' . s($listitem) . '</div>';
            }
            $fullitems[] = '<div class="lg-log-full-item lg-log-full-list"><span class="lg-log-full-key">' . s($keylabel)
                . ':</span><span class="lg-log-full-val"><div class="lg-log-list-block" style="max-height:260px; overflow-y:auto; min-width:280px;">'
                . $listrows . '</div></span></div>';
            // Condensed view: a single count chip in the usual badge style.
            if (!in_array($key, ['admin_email', 'admin_user', 'admin_name', 'timestamp', 'ip'], true)) {
                $parts[] = '<span class="badge badge-light border text-dark font-weight-normal mr-1 mb-1" style="font-size:85%;"'
                    . ' title="' . s($key) . ': ' . count($listitems) . '">'
                    . '<span class="lg-detail-key">' . s($keylabel) . ':</span> ' . count($listitems) . '</span>';
            }
            continue;
        }
        if (is_array($val) || is_object($val)) {
            $val = json_encode($val);
        }
        $val = (string)$val;
        $display = $val;
        // Boolean-looking flags read better as Yes/No.
        $boolish = str_starts_with($key, 'is_')
            || in_array($key, ['suspended', 'blocked', 'enabled', 'active', 'deleted', 'confirmed'], true);
        if ($boolish && ($val === '0' || $val === '1')) {
            $display = ((int)$val === 1) ? 'Yes' : 'No';
        }
        // Raw epoch timestamps read better as a human date (GMT+2,
        // matching the Time column everywhere else in the plugin).
        if ($key === 'timestamp' && ctype_digit((string)$val) && (int)$val > 1000000) {
            $display = date('d M Y, H:i:s', (int)$val + (2 * 3600)) . ' (GMT+2)';
        }

        // The expanded view shows EVERY key with the FULL value — nothing
        // truncated, nothing hidden (not even the keys that have their own
        // table columns or are condensed into the admin badge).
        $fullitems[] = '<div class="lg-log-full-item"><span class="lg-log-full-key">' . s($keylabel) . ':</span>'
            . '<span class="lg-log-full-val">' . s($display) . '</span></div>';

        // Skip keys rendered elsewhere (admin badge, dedicated columns).
        if (in_array($key, ['admin_email', 'admin_user', 'admin_name', 'timestamp', 'ip'], true)) {
            continue;
        }
        // Truncate long values (e.g. user agents) in the condensed view —
        // the full text is one click away in the expanded view.
        if (\core_text::strlen($display) > 64) {
            $display = rtrim(\core_text::substr($display, 0, 61)) . '…';
        }
        $parts[] = '<span class="badge badge-light border text-dark font-weight-normal mr-1 mb-1" style="font-size:85%;"'
            . ' title="' . s($key) . ': ' . s($val) . '">'
            . '<span class="lg-detail-key">' . s($keylabel) . ':</span> ' . s($display) . '</span>';
    }

    if (empty($parts) && empty($fullitems)) {
        return '';
    }

    $condensed = '<div class="lg-log-condensed d-flex flex-wrap align-items-center">' . implode('', $parts) . '</div>';
    $toggle = '<a href="#" class="lg-log-toggle" role="button" aria-expanded="false">'
        . '<span class="lg-t-more"><i class="fa fa-chevron-down" aria-hidden="true"></i> ' . s(get_string('log_show_full', 'auth_devicelock')) . '</span>'
        . '<span class="lg-t-less" style="display:none;"><i class="fa fa-chevron-up" aria-hidden="true"></i> ' . s(get_string('log_show_less', 'auth_devicelock')) . '</span>'
        . '</a>';
    $full = '<div class="lg-log-full" style="display:none;">'
        . '<div class="lg-log-full-head"><i class="fa fa-file-alt" aria-hidden="true"></i> ' . s(get_string('log_full_details', 'auth_devicelock')) . '</div>'
        . '<div class="lg-log-full-grid">' . implode('', $fullitems) . '</div>'
        . '</div>';

    return $condensed . $toggle . $full;
}

/**
 * Print the shared JS that makes log event rows expandable.
 *
 * Clicking a row (or its "Show all" link) swaps the condensed chips for
 * the complete, untruncated details block and vice versa. Emitted at
 * most once per request (static guard), so it is safe to call after
 * every log table render.
 */
function auth_devicelock_print_log_expand_js() {
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    echo '<script>
(function() {
    if (document.body.getAttribute("data-lg-logexpand")) { return; }
    document.body.setAttribute("data-lg-logexpand", "1");
    function markRows() {
        var toggles = document.querySelectorAll(".lg-log-toggle");
        for (var k = 0; k < toggles.length; k++) {
            var tr = toggles[k].closest ? toggles[k].closest("tr") : null;
            if (tr) { tr.classList.add("lg-log-row"); }
        }
    }
    markRows();
    function toggleRow(tr) {
        if (!tr) { return; }
        var full = tr.querySelector(".lg-log-full");
        var cond = tr.querySelector(".lg-log-condensed");
        var toggle = tr.querySelector(".lg-log-toggle");
        if (!full || !cond || !toggle) { return; }
        var more = toggle.querySelector(".lg-t-more");
        var less = toggle.querySelector(".lg-t-less");
        var open = (full.style.display !== "none");
        if (open) {
            full.style.display = "none";
            cond.style.display = "";
            toggle.setAttribute("aria-expanded", "false");
            if (more) { more.style.display = ""; }
            if (less) { less.style.display = "none"; }
            tr.classList.remove("lg-log-open");
        } else {
            full.style.display = "";
            cond.style.display = "none";
            toggle.setAttribute("aria-expanded", "true");
            if (more) { more.style.display = "none"; }
            if (less) { less.style.display = ""; }
            tr.classList.add("lg-log-open");
        }
    }
    document.addEventListener("click", function(ev) {
        var t = ev.target;
        if (!t || !t.closest) { return; }
        var toggle = t.closest(".lg-log-toggle");
        if (toggle) {
            ev.preventDefault();
            toggleRow(toggle.closest("tr"));
            return;
        }
        // Clicking anywhere else on the event row expands it too — unless
        // the click landed on an interactive element inside the row.
        if (t.closest("a, button, input, select, textarea, label")) { return; }
        var tr = t.closest("tr");
        if (tr && tr.classList.contains("lg-log-row")) {
            toggleRow(tr);
        }
    });
})();
</script>';
}

/**
 * Random realistic first name for auto-generated accounts (v3.4.4).
 *
 * Used by the Quick Create / Bulk Create "Auto-generate" checkbox for
 * names. International mix, no commas (CSV-safe).
 *
 * @return string A random first name.
 */
function auth_devicelock_random_firstname() {
    static $pool = [
        'Adam', 'Ahmed', 'Alan', 'Albert', 'Amina', 'Anna', 'Anthony', 'Aya',
        'Bilal', 'Carlos', 'Chris', 'David', 'Dina', 'Elena', 'Emily', 'Faris',
        'Hana', 'Hassan', 'Ikram', 'Ivan', 'James', 'John', 'Julia', 'Karen',
        'Khalid', 'Laila', 'Liam', 'Lina', 'Marco', 'Maria', 'Maya', 'Michael',
        'Mona', 'Nadia', 'Noah', 'Omar', 'Oscar', 'Patrick', 'Rana', 'Sara',
        'Sean', 'Tarek', 'Yara', 'Youssef', 'Zainab',
    ];
    return $pool[random_int(0, count($pool) - 1)];
}

/**
 * Random realistic last name for auto-generated accounts (v3.4.4).
 *
 * @return string A random last name.
 */
function auth_devicelock_random_lastname() {
    static $pool = [
        'Adams', 'Ali', 'Baker', 'Brown', 'Chen', 'Clark', 'Davis', 'Diaz',
        'Evans', 'Fisher', 'Garcia', 'Green', 'Hall', 'Hassan', 'Hill', 'Ibrahim',
        'Jones', 'Kaur', 'Khan', 'King', 'Kumar', 'Lee', 'Lewis', 'Lopez',
        'Martin', 'Martinez', 'Miller', 'Mitchell', 'Moreno', 'Nasser', 'Nelson',
        'Novak', 'Ortiz', 'Patel', 'Perez', 'Reyes', 'Ross', 'Saleh', 'Silva',
        'Smith', 'Turner', 'Walker', 'Wang', 'White', 'Young', 'Zhang',
    ];
    return $pool[random_int(0, count($pool) - 1)];
}

// ============================================================
// Feature 3: Per-User Device Limit Helpers
// ============================================================

/**
 * Get the effective maximum device limit for a specific user.
 *
 * Checks for a per-user preference first, then falls back to
 * the global plugin setting. This is the SINGLE place all
 * device-limit logic should read from.
 *
 * @param int $userid  The user ID to resolve a limit for.
 * @return int         The effective device limit. 0 is a valid, deliberate
 *                      value meaning "no devices allowed" - it is NOT
 *                      floored to 1. Only a setting that was never saved
 *                      at all falls back to the documented default of 1.
 */
function auth_devicelock_get_user_device_limit($userid) {
    // Per-user preference stored via Moodle's user_preferences API.
    $userlimit = get_user_preferences('auth_devicelock_userlimit', null, $userid);

    if ($userlimit !== null && is_numeric($userlimit) && (int)$userlimit > 0) {
        return (int)$userlimit;
    }

    // Fall back to global plugin setting. get_config() returns the literal
    // string '0' when the admin has deliberately saved 0 - that must NOT be
    // treated the same as an unset setting (false/''), which is what the
    // old "?: 1" did (0 is falsy in PHP, so it silently became 1).
    $rawconfig = get_config('auth_devicelock', 'maxdevices');
    if ($rawconfig === false || $rawconfig === '') {
        return 1;
    }
    return max(0, (int)$rawconfig);
}

/**
 * Set a custom device limit for a specific user.
 *
 * Pass null or 0 to remove the per-user override and revert
 * to the global limit.
 *
 * @param int      $userid The user to configure.
 * @param int|null $limit  The custom limit, or null/0 to clear.
 * @return bool            True on success.
 */
function auth_devicelock_set_user_device_limit($userid, $limit) {
    if (empty($limit) || (int)$limit <= 0) {
        // Remove the per-user override.
        unset_user_preference('auth_devicelock_userlimit', $userid);
        return true;
    }
    set_user_preference('auth_devicelock_userlimit', (int)$limit, $userid);
    return true;
}

/**
 * Get the effective maximum browser limit per device for a specific user.
 *
 * Checks for a per-user preference first, then falls back to
 * the global plugin setting (0 = unlimited).
 *
 * @param int $userid  The user ID to resolve a limit for.
 * @return int         The effective browser limit (0 = unlimited).
 */
function auth_devicelock_get_user_browser_limit($userid) {
    $browserlimit = get_user_preferences('auth_devicelock_browserlimit', null, $userid);

    if ($browserlimit !== null && is_numeric($browserlimit) && (int)$browserlimit >= 0) {
        return (int)$browserlimit;
    }

    $globallimit = (int)(get_config('auth_devicelock', 'maxbrowsers') ?: 0);
    return max(0, $globallimit);
}

/**
 * Set a custom browser limit per device for a specific user.
 *
 * Pass null or empty string to remove the per-user override and revert
 * to the global limit. Pass 0 for unlimited browsers.
 *
 * @param int      $userid The user to configure.
 * @param int|null $limit  The custom browser limit, or null to clear.
 * @return bool            True on success.
 */
function auth_devicelock_set_user_browser_limit($userid, $limit) {
    if ($limit === null || $limit === '' || (int)$limit < 0) {
        // Remove the per-user override.
        unset_user_preference('auth_devicelock_browserlimit', $userid);
        return true;
    }
    set_user_preference('auth_devicelock_browserlimit', (int)$limit, $userid);
    return true;
}

// ============================================================
// Feature 1: Customizable Email Template Engine
// ============================================================

/**
 * Send a templated device-event email to a user.
 *
 * Fetches the subject and body templates from the admin settings,
 * replaces all supported placeholders, and dispatches via
 * Moodle's email_to_user().
 *
 * Supported placeholder tokens:
 *   {firstname}   – User's first name
 *   {fullname}    – User's full name
 *   {username}    – User's username
 *   {email}       – User's email address
 *   {sitename}    – Site full name
 *   {siteurl}     – Site URL
 *   {devicename}  – Formatted device description (OS + Screen)
 *   {ip}          – IP address of the device action
 *   {datetime}    – Formatted date/time in GMT+2
 *   {maxdevices}  – Effective device limit for the user
 *   {devicecount} – Current active device count for the user
 *
 * @param int    $userid     The recipient's user ID.
 * @param string $event      One of: 'newdevice', 'blocked', 'reset'.
 * @param array  $extra      Optional extra data: 'ip', 'devicename'.
 * @return bool              True on success, false on failure.
 */
function auth_devicelock_send_template_email($userid, $event, array $extra = []) {
    global $DB, $CFG;

    // Bail early if notifications are globally disabled.
    if (!get_config('auth_devicelock', 'sendnotifications')) {
        return false;
    }

    $user = $DB->get_record('user', ['id' => $userid]);
    if (!$user) {
        return false;
    }

    // Map event key to the config setting names.
    $eventmap = [
        'newdevice' => ['subject' => 'email_newdevice_subject', 'body' => 'email_newdevice_body'],
        'blocked'   => ['subject' => 'email_blocked_subject',   'body' => 'email_blocked_body'],
        'reset'     => ['subject' => 'email_reset_subject',     'body' => 'email_reset_body'],
    ];

    if (!isset($eventmap[$event])) {
        return false; // Unknown event.
    }

    $keys = $eventmap[$event];

    // Fetch from settings; fall back to language-string defaults.
    $subject = get_config('auth_devicelock', $keys['subject']);
    if (empty($subject)) {
        $subject = get_string($keys['subject'] . '_default', 'auth_devicelock');
    }

    $body = get_config('auth_devicelock', $keys['body']);
    if (empty($body)) {
        $body = get_string($keys['body'] . '_default', 'auth_devicelock');
    }

    // Build the replacement map.
    $site        = get_site();
    $devicecount = $DB->count_records('auth_devicelock_devices', ['userid' => $userid, 'status' => 'active']);
    $maxdevices  = auth_devicelock_get_user_device_limit($userid);
    $datetime    = device_manager::format_gmt2_date(time(), 'd M Y, H:i:s');

    $c_info = auth_devicelock_get_custom_profile_identifiers($userid, $user);

    $placeholders = [
        '{firstname}'   => $user->firstname,
        '{fullname}'    => fullname($user),
        '{username}'    => $user->username,
        '{email}'       => $user->email,
        '{phone}'       => $c_info['phone'] ?? '',
        '{uni_id}'      => $c_info['uni_id'] ?? '',
        '{sitename}'    => $site->fullname,
        '{siteurl}'     => $CFG->wwwroot,
        '{devicename}'  => $extra['devicename'] ?? get_string('unknown', 'auth_devicelock'),
        '{ip}'          => $extra['ip'] ?? getremoteaddr(),
        '{datetime}'    => $datetime,
        '{maxdevices}'  => $maxdevices,
        '{devicecount}' => $devicecount,
    ];

    $subject = str_replace(array_keys($placeholders), array_values($placeholders), $subject);
    $body    = str_replace(array_keys($placeholders), array_values($placeholders), $body);
    $htmlbody = nl2br(htmlspecialchars($body, ENT_QUOTES));

    // Send from site support address.
    $supportuser = core_user::get_support_user();
    return email_to_user($user, $supportuser, $subject, $body, $htmlbody);
}

/**
 * Feature 2: Send a fully custom admin-composed email to a user.
 *
 * @param int    $userid   Recipient user ID.
 * @param string $subject  Email subject line.
 * @param string $body     Plain-text email body.
 * @return bool            True on success.
 */
function auth_devicelock_send_custom_email($userid, $subject, $body) {
    global $DB;

    $user = $DB->get_record('user', ['id' => $userid]);
    if (!$user) {
        return false;
    }

    $subject  = clean_param($subject, PARAM_TEXT);
    $body     = clean_param($body,    PARAM_CLEANHTML);
    $htmlbody = nl2br(htmlspecialchars($body, ENT_QUOTES));

    $supportuser = core_user::get_support_user();
    return email_to_user($user, $supportuser, $subject, $body, $htmlbody);
}

/**
 * Helper to fetch custom profile identifiers (Uni_ID and Phone_Number) for a user or multiple users.
 * 
 * Specifically retrieves custom user profile fields:
 * - "Your University ID" (short name: Uni_ID)
 * - "Phone Number" (short name: Phone_Number)
 *
 * Case-insensitive lookup on shortname (Uni_ID, Phone_Number)
 * with graceful fallback to standard user fields ($user->idnumber, $user->phone1, $user->phone2).
 *
 * @param int|array $userids User ID or array of user IDs
 * @param stdClass|null $userrecord Optional single user object to populate fallbacks from
 * @return array Single array ['uni_id' => ..., 'phone' => ...] if single ID passed,
 *               or array of [userid => ['uni_id' => ..., 'phone' => ...]] if array of IDs passed.
 */
function auth_devicelock_get_custom_profile_identifiers($userids, $userrecord = null) {
    global $DB;

    $is_single = !is_array($userids);
    $raw_ids = $is_single ? [$userids] : $userids;
    $uids = [];
    foreach ($raw_ids as $id) {
        $id = (int)$id;
        if ($id > 0) {
            $uids[$id] = $id;
        }
    }

    $result = [];
    foreach ($uids as $uid) {
        $result[$uid] = [
            'uni_id' => '',
            'phone' => '',
        ];
    }

    // Populate fallbacks from $userrecord if provided for single user
    if ($is_single && !empty($userrecord) && is_object($userrecord)) {
        $uid = (int)($userrecord->id ?? 0);
        if ($uid > 0 && isset($result[$uid])) {
            if (!empty($userrecord->idnumber)) {
                $result[$uid]['uni_id'] = trim((string)$userrecord->idnumber);
            }
            if (!empty($userrecord->phone1)) {
                $result[$uid]['phone'] = trim((string)$userrecord->phone1);
            } else if (!empty($userrecord->phone2)) {
                $result[$uid]['phone'] = trim((string)$userrecord->phone2);
            }
        }
    }

    if (empty($uids)) {
        return $is_single ? ['uni_id' => '', 'phone' => ''] : $result;
    }

    try {
        if ($DB->get_manager()->table_exists('user_info_data') && $DB->get_manager()->table_exists('user_info_field')) {
            list($insql, $inparams) = $DB->get_in_or_equal(array_values($uids), SQL_PARAMS_NAMED, 'uid_');

            $sql = "SELECT d.id, d.userid, d.data, LOWER(f.shortname) AS shortname, f.name
                      FROM {user_info_data} d
                      JOIN {user_info_field} f ON d.fieldid = f.id
                     WHERE d.userid $insql
                       AND (
                           LOWER(f.shortname) IN ('uni_id', 'phone_number')
                           OR f.name IN ('Your University ID', 'Phone Number')
                       )";

            $records = $DB->get_records_sql($sql, $inparams);
            if (!empty($records)) {
                foreach ($records as $r) {
                    $val = trim((string)$r->data);
                    if ($val === '') {
                        continue;
                    }
                    $sname = strtolower(trim((string)$r->shortname));
                    $fname = trim((string)$r->name);

                    if ($sname === 'uni_id' || $fname === 'Your University ID') {
                        $result[$r->userid]['uni_id'] = $val;
                    } else if ($sname === 'phone_number' || $fname === 'Phone Number') {
                        $result[$r->userid]['phone'] = $val;
                    }
                }
            }
        }
    } catch (\Exception $e) {
        // Fallback gracefully without breaking page execution
    }

    return $is_single ? ($result[reset($uids)] ?? ['uni_id' => '', 'phone' => '']) : $result;
}

// ============================================================
// Feature: Per-User Security Score (persistent, v3.5.0)
// ============================================================

/**
 * Read one user's persistent security score (0-100).
 *
 * v3.5.0: the score is STORED, not computed - it starts at 100 when the
 * account is created, each violation lowers it (see
 * auth_devicelock_score_violation_deductions() in lib.php for the exact
 * list), and it slowly regains points over time once the user stops
 * violating. A new violation before the regain timer expires restarts the
 * timer. Returns:
 *  [
 *    'score'       => int,
 *    'band'        => 'high'|'good'|'fair'|'poor'|'critical',
 *    'label'       => string,  // localized band label
 *    'breakdown'   => ['violations' => n, 'last_violation' => ts, ...],
 *  ]
 *
 * @param int $userid
 * @return array
 */
function auth_devicelock_compute_security_score($userid) {
    $batch = auth_devicelock_compute_security_scores_batch([(int)$userid]);
    return $batch[(int)$userid] ?? [
        'score'     => 100,
        'band'      => 'high',
        'label'     => get_string('security_score_high', 'auth_devicelock'),
        'breakdown' => [],
    ];
}

/**
 * Batched read of the persistent security scores for a set of users.
 *
 * PERFORMANCE: the directory page calls this - it resolves every user's
 * score row in ONE query (creating missing rows at 100% in bulk), then
 * applies any regain that is already due (silently, without log rows) so
 * the displayed value is always current. The score itself is maintained
 * by the log hooks + the every-minute scheduled task in lib.php.
 *
 * @param array $userids  List of user IDs to read scores for.
 * @return array          [userid => ['score'=>int,'band'=>string,'label'=>string,'breakdown'=>array]]
 */
function auth_devicelock_compute_security_scores_batch(array $userids) {
    $rows = auth_devicelock_score_ensure_rows_batch($userids);

    $result = [];
    foreach ($userids as $uid) {
        $uid = (int)$uid;
        $row = $rows[$uid] ?? null;
        if ($row && !empty($row->id)) {
            // Apply a due regain silently so the shown score is current.
            list($row) = auth_devicelock_score_apply_regain($row, time(), false);
            $score = (int)$row->score;
            $breakdown = [
                'violations'     => (int)$row->violation_count,
                'last_violation' => (int)$row->last_violation,
                'last_regain'    => (int)$row->last_regain,
                'custom_regain'  => (int)$row->custom_regain,
            ];
        } else {
            $score = 100;
            $breakdown = [];
        }
        $bl = auth_devicelock_security_score_band($score);
        $result[$uid] = [
            'score'     => $score,
            'band'      => $bl['band'],
            'label'     => $bl['label'],
            'breakdown' => $breakdown,
        ];
    }
    return $result;
}

/**
 * Render a compact HTML badge for a user's security score.
 *
 * @param array $scoredata  Result of auth_devicelock_compute_security_score().
 * @return string  HTML.
 */
function auth_devicelock_render_security_score_badge(array $scoredata) {
    $score = (int)($scoredata['score'] ?? 100);
    $band  = $scoredata['band'] ?? 'high';
    $label = $scoredata['label'] ?? '';
    $tip   = get_string('security_score_tooltip', 'auth_devicelock');

    // Color mapping per band.
    $colormap = [
        'high'     => 'badge-success',
        'good'     => 'badge-primary',
        'fair'     => 'badge-warning',
        'poor'     => 'badge-danger',
        'critical'=> 'badge-dark',
    ];
    $cls = $colormap[$band] ?? 'badge-secondary';

    return '<span class="badge ' . $cls . ' px-2 py-1" title="' . s($tip) . '" '
        . 'style="font-size:0.85rem; min-width:42px; text-align:center;" '
        . 'data-toggle="tooltip">'
        . '<i class="fa fa-shield"></i> ' . $score . '% &middot; ' . s($label)
        . '</span>';
}

/**
 * Invalidate the cached security score for one user (or a list of users).
 *
 * Call this whenever a user's suspended/confirmed state changes or a new
 * log row is written for them, so the next read recomputes from scratch
 * instead of serving a stale snapshot.
 *
 * @param int|array $userids  One userid or an array of userids.
 * @return void
 */
function auth_devicelock_invalidate_security_score_cache($userids) {
    global $DB;

    if (empty($userids)) {
        return;
    }
    if (!is_array($userids)) {
        $userids = [$userids];
    }
    $uids = [];
    foreach ($userids as $uid) {
        $uid = (int)$uid;
        if ($uid > 0) {
            $uids[$uid] = $uid;
        }
    }
    if (empty($uids)) {
        return;
    }
    if (!$DB->get_manager()->table_exists('user_preferences')) {
        return;
    }
    $prefname = 'auth_devicelock_secscore_cache';
    list($insql, $inparams) = $DB->get_in_or_equal(array_values($uids), SQL_PARAMS_NAMED, 'inv_uid_');
    $inparams['inv_name'] = $prefname;
    $DB->delete_records_select(
        'user_preferences',
        "name = :inv_name AND userid $insql",
        $inparams
    );
}

/**
 * Backfill + refresh every user's persistent security score.
 *
 * v3.5.0: creates the score row (100%) for any user still missing one and
 * applies every regain that is due site-wide. Used by the "Recalculate All
 * Scores" admin action. Returns a count of users processed.
 *
 * @return int  Number of users processed.
 */
function auth_devicelock_recalculate_all_security_scores() {
    global $DB;

    if (!$DB->get_manager()->table_exists('auth_devicelock_user_scores')) {
        return 0;
    }

    // Every real user gets a row (missing rows are created at 100%).
    $alluserids = $DB->get_fieldset_sql(
        "SELECT id FROM {user} WHERE deleted = 0 AND id > 2",
        []
    );
    if (empty($alluserids)) {
        return 0;
    }
    $byuser = auth_devicelock_score_ensure_rows_batch($alluserids);

    // Apply every regain that is already due (silently - this is a
    // maintenance action, not a cron report).
    $now = time();
    $processed = 0;
    foreach ($byuser as $row) {
        if ((int)$row->score < 100) {
            auth_devicelock_score_apply_regain($row, $now, false);
        }
        $processed++;
    }
    return $processed;
}

/**
 * Build the security-snapshot data structure used by BOTH the weekly
 * scheduled email task AND the in-browser "Security Snapshot" admin page.
 *
 * This is the SINGLE source of truth for snapshot data — the task, the page,
 * and the send-test-email action all call this helper so the logic is never
 * duplicated. Runs 2-3 cheap SELECTs on the logs + user_preferences tables.
 *
 * @param int $days  Trend window in days (default 7).
 * @return array {
 *     'trend'      => ['blocked'=>int, 'regs'=>int, 'deletions'=>int],
 *     'dist'       => ['high'=>int, 'good'=>int, 'fair'=>int, 'poor'=>int, 'critical'=>int],
 *     'dist_total' => int,
 *     'toprisk'    => [['fullname'=>str, 'username'=>str, 'email'=>str, 'score'=>int], ...],
 * }
 */
function auth_devicelock_build_snapshot_data($days = 7) {
    global $DB;

    $mgr = $DB->get_manager();
    $since = time() - ((int)$days * 86400);

    // 1. Trend counts (last N days).
    $trend = ['blocked' => 0, 'regs' => 0, 'deletions' => 0];
    if ($mgr->table_exists('auth_devicelock_logs')) {
        $trendmap = [
            'blocked'    => ['login_prevented', 'device_status_blocked', 'toggle_suspend'],
            'regs'       => ['device_registered'],
            'deletions'  => ['delete_user_account', 'bulk_delete_user_account'],
        ];
        $sql = "SELECT action, COUNT(*) AS c
                  FROM {auth_devicelock_logs}
                 WHERE timestamp >= :since
              GROUP BY action";
        $rows = $DB->get_records_sql($sql, ['since' => $since]);
        foreach ($rows as $r) {
            foreach ($trendmap as $metric => $acts) {
                if (in_array($r->action, $acts, true)) {
                    $trend[$metric] += (int)$r->c;
                }
            }
        }
    }

    // 2. Score distribution (from the persistent score table, v3.5.0).
    $dist = ['high' => 0, 'good' => 0, 'fair' => 0, 'poor' => 0, 'critical' => 0];
    $dist_total = 0;
    $scored = []; // [userid => score] reused for toprisk below.
    if ($mgr->table_exists('auth_devicelock_user_scores')) {
        $srows = $DB->get_records('auth_devicelock_user_scores', null, '', 'userid, score');
        foreach ($srows as $sr) {
            $sc = (int)$sr->score;
            $scored[(int)$sr->userid] = $sc;
            $bl = auth_devicelock_security_score_band($sc);
            $dist[$bl['band']] = ($dist[$bl['band']] ?? 0) + 1;
            $dist_total++;
        }
    }

    // 3. Top-5 at-risk users (lowest cached scores, resolved to identities).
    $toprisk = [];
    if (!empty($scored)) {
        asort($scored); // ascending — lowest scores first.
        $topids = array_slice(array_keys($scored), 0, 5, true);
        if (!empty($topids)) {
            list($uinsql, $uinparams) = $DB->get_in_or_equal($topids, SQL_PARAMS_NAMED, 'risku_');
            $urecs = $DB->get_records_select('user', "id $uinsql AND deleted = 0", $uinparams, '', 'id, firstname, lastname, username, email');
            foreach ($topids as $tid) {
                if (isset($urecs[$tid])) {
                    $u = $urecs[$tid];
                    $toprisk[] = [
                        'fullname' => fullname($u),
                        'username' => $u->username,
                        'email'    => $u->email,
                        'score'    => $scored[$tid],
                    ];
                }
            }
        }
    }

    return [
        'trend'      => $trend,
        'dist'       => $dist,
        'dist_total' => $dist_total,
        'toprisk'    => $toprisk,
    ];
}

/**
 * Render the snapshot data as a plain-text email body.
 *
 * @param array $data   Result of auth_devicelock_build_snapshot_data().
 * @param string $sitename  The site fullname.
 * @return string  Plain-text body.
 */
function auth_devicelock_render_snapshot_text(array $data, $sitename) {
    $trend = $data['trend'];
    $dist = $data['dist'];
    $dist_total = $data['dist_total'];
    $toprisk = $data['toprisk'];

    $body = get_string('snapshot_intro', 'auth_devicelock', $sitename) . "\n\n";
    $body .= "=== " . get_string('snapshot_section_trends', 'auth_devicelock') . " ===\n";
    $body .= "  Blocked logins:       {$trend['blocked']}\n";
    $body .= "  Device registrations: {$trend['regs']}\n";
    $body .= "  Account deletions:    {$trend['deletions']}\n";
    $body .= "=== " . get_string('snapshot_section_distribution', 'auth_devicelock') . " ({$dist_total} users scored) ===\n";
    $body .= "  Excellent: {$dist['high']}\n";
    $body .= "  Good:      {$dist['good']}\n";
    $body .= "  Fair:      {$dist['fair']}\n";
    $body .= "  At Risk:   {$dist['poor']}\n";
    $body .= "  Critical:  {$dist['critical']}\n\n";
    if (!empty($toprisk)) {
        $body .= "=== " . get_string('snapshot_section_toprisk', 'auth_devicelock') . " ===\n";
        $i = 0;
        foreach ($toprisk as $tr) {
            $i++;
            $body .= "  {$i}. {$tr['fullname']} (@{$tr['username']}) — score {$tr['score']} — {$tr['email']}\n";
        }
    } else {
        $body .= get_string('snapshot_no_data', 'auth_devicelock') . "\n";
    }
    return $body;
}

/**
 * Render the snapshot data as an HTML email body.
 *
 * @param array $data   Result of auth_devicelock_build_snapshot_data().
 * @param string $sitename  The site fullname.
 * @param string $siteurl  The site wwwroot (for the footer).
 * @return string  HTML body.
 */
function auth_devicelock_render_snapshot_html(array $data, $sitename, $siteurl) {
    $trend = $data['trend'];
    $dist = $data['dist'];
    $dist_total = $data['dist_total'];
    $toprisk = $data['toprisk'];

    $html = '<div style="font-family: Arial, sans-serif; color: #333;">';
    $html .= '<h3>' . s(get_string('snapshot_intro', 'auth_devicelock', $sitename)) . '</h3>';

    $html .= '<h4>' . s(get_string('snapshot_section_trends', 'auth_devicelock')) . '</h4>';
    $html .= '<table cellpadding="4" style="border-collapse:collapse;">';
    foreach ([
        'Blocked logins'       => $trend['blocked'],
        'Device registrations' => $trend['regs'],
        'Account deletions'    => $trend['deletions'],
    ] as $label => $val) {
        $html .= '<tr><td style="border-bottom:1px solid #eee;">' . s($label) . '</td><td style="border-bottom:1px solid #eee; font-weight:bold; text-align:right;">' . (int)$val . '</td></tr>';
    }
    $html .= '</table>';

    $html .= '<h4>' . s(get_string('snapshot_section_distribution', 'auth_devicelock')) . ' (' . $dist_total . ' users scored)</h4>';
    $html .= '<table cellpadding="4" style="border-collapse:collapse;">';
    $bandcolours = ['high' => '#16a34a', 'good' => '#2563eb', 'fair' => '#f59e0b', 'poor' => '#dc2626', 'critical' => '#1f2937'];
    $bandlabels = [
        'high' => get_string('security_score_high', 'auth_devicelock'),
        'good' => get_string('security_score_good', 'auth_devicelock'),
        'fair' => get_string('security_score_fair', 'auth_devicelock'),
        'poor' => get_string('security_score_poor', 'auth_devicelock'),
        'critical' => get_string('security_score_critical', 'auth_devicelock'),
    ];
    foreach ($bandcolours as $band => $colour) {
        $html .= '<tr><td style="border-bottom:1px solid #eee;"><span style="color:' . $colour . '; font-weight:bold;">&#9632;</span> ' . s($bandlabels[$band]) . '</td><td style="border-bottom:1px solid #eee; text-align:right;">' . (int)$dist[$band] . '</td></tr>';
    }
    $html .= '</table>';

    if (!empty($toprisk)) {
        $html .= '<h4>' . s(get_string('snapshot_section_toprisk', 'auth_devicelock')) . '</h4>';
        $html .= '<ol>';
        foreach ($toprisk as $tr) {
            $html .= '<li><strong>' . s($tr['fullname']) . '</strong> (@' . s($tr['username']) . ') — score <strong>' . (int)$tr['score'] . '</strong> — ' . s($tr['email']) . '</li>';
        }
        $html .= '</ol>';
    } else {
        $html .= '<p><em>' . s(get_string('snapshot_no_data', 'auth_devicelock')) . '</em></p>';
    }
    $html .= '<hr><p style="font-size:12px; color:#888;">' . s($siteurl) . '</p>';
    $html .= '</div>';
    return $html;
}
/**
 * Fetch the score-history rows for a single user (newest-first).
 *
 * @param int $userid
 * @param int $limit  Max rows to return (default 30).
 * @return array  [['score'=>int, 'band'=>string, 'timestamp'=>int], ...]
 */
function auth_devicelock_get_score_history($userid, $limit = 30) {
    global $DB;
    $userid = (int)$userid;
    if (!$DB->get_manager()->table_exists('auth_devicelock_score_history') || $userid <= 0) {
        return [];
    }
    $rows = $DB->get_records('auth_devicelock_score_history', ['userid' => $userid], 'timestamp DESC', 'id, score, band, timestamp', 0, (int)$limit);
    $out = [];
    foreach ($rows as $r) {
        $out[] = ['score' => (int)$r->score, 'band' => $r->band, 'timestamp' => (int)$r->timestamp];
    }
    return $out;
}

/**
 * Render a pure-CSS sparkline of a user's score history.
 *
 * Each datapoint is a vertical bar; height scaled to 0-100. Colour-coded
 * by band (green/blue/amber/red/dark). Returns an empty string if there
 * are fewer than 2 datapoints (a single point is not a trend).
 *
 * @param array $history  Result of auth_devicelock_get_score_history() (newest-first).
 * @return string  HTML.
 */
function auth_devicelock_render_score_sparkline(array $history) {
    if (count($history) < 2) {
        return ''; // not enough data for a trend
    }
    // Reverse to oldest-first for left-to-right rendering.
    $history = array_reverse($history);
    $bandcolours = [
        'high'     => '#16a34a',
        'good'     => '#2563eb',
        'fair'     => '#f59e0b',
        'poor'     => '#dc2626',
        'critical' => '#1f2937',
    ];
    $html = '<div class="d-flex align-items-end" style="height:48px; gap:2px;">';
    foreach ($history as $pt) {
        $h = max(4, (int)round(($pt['score'] / 100) * 48));
        $colour = $bandcolours[$pt['band']] ?? '#6b7280';
        $tip = userdate($pt['timestamp'], get_string('strftimedatetimeshort', 'langconfig')) . ' — ' . $pt['score'];
        $html .= '<div title="' . s($tip) . '" style="flex:1; min-width:4px; height:' . $h . 'px; background:' . $colour . '; border-radius:2px 2px 0 0; opacity:0.85;"></div>';
    }
    $html .= '</div>';
    return $html;
}

// ============================================================
// COURSE ENROLMENT for Quick Create / Bulk Create users
// ============================================================

/**
 * Resolve (or create) the "manual" enrolment plugin instance for a course.
 *
 * Results are memoised in $instancecache so bulk creation does not repeat
 * the lookups for every single user.
 *
 * @param int $courseid Course id (the site/frontpage course id 1 is not enrolable).
 * @param enrol_plugin $enrolplugin The manual enrolment plugin instance.
 * @param array $instancecache Map of courseid => enrol instance record (by reference).
 * @param array $errors Collected human-readable error messages (by reference).
 * @return stdClass|null The enrol instance record, or null when unavailable.
 */
function auth_devicelock_resolve_manual_enrol_instance($courseid, $enrolplugin, &$instancecache, &$errors) {
    global $DB;

    $courseid = (int)$courseid;
    if ($courseid <= 1) {
        return null; // enrol_user() refuses enrolments into the frontpage course.
    }
    if (isset($instancecache[$courseid])) {
        return $instancecache[$courseid];
    }

    $instance = null;
    // Prefer an already-enabled manual instance.
    foreach (enrol_get_instances($courseid, true) as $inst) {
        if ($inst->enrol === 'manual') {
            $instance = $inst;
            break;
        }
    }
    // Fall back to a disabled manual instance and re-enable it.
    if (!$instance) {
        foreach (enrol_get_instances($courseid, false) as $inst) {
            if ($inst->enrol === 'manual') {
                $instance = $inst;
                break;
            }
        }
        if ($instance && (int)$instance->status !== ENROL_INSTANCE_ENABLED) {
            $enrolplugin->update_status($instance, ENROL_INSTANCE_ENABLED);
            $instance->status = ENROL_INSTANCE_ENABLED;
        }
    }
    // Last resort: add a brand-new manual instance to the course.
    if (!$instance) {
        $course = $DB->get_record('course', ['id' => $courseid], '*', MUST_EXIST);
        $instanceid = $enrolplugin->add_instance($course, ['status' => ENROL_INSTANCE_ENABLED]);
        $instance = $DB->get_record('enrol', ['id' => $instanceid], '*', MUST_EXIST);
    }

    $instancecache[$courseid] = $instance;
    return $instance;
}

/**
 * Enrol a user into a list of existing courses using the manual enrolment
 * plugin. Used by the Quick Create and Bulk Create user tools.
 *
 * @param int $userid Id of the already-created user.
 * @param array $courseids Course ids to enrol the user into.
 * @param int $roleid Course role to assign (0 or invalid falls back to Student).
 * @param int $durationdays Enrolment duration in days (0 = unlimited).
 * @param array $errors Collected human-readable error messages (by reference).
 * @param array $instancecache Shared enrol-instance cache between calls (by reference).
 * @return int Number of courses the user is now enrolled in.
 */
function auth_devicelock_enrol_user_in_courses($userid, $courseids, $roleid = 0, $durationdays = 0, &$errors = [], &$instancecache = []) {
    global $CFG, $DB;
    require_once($CFG->libdir . '/enrollib.php');

    $userid = (int)$userid;
    $durationdays = max(0, (int)$durationdays);
    if ($userid <= 0 || empty($courseids) || !is_array($courseids)) {
        return 0;
    }

    $enrolplugin = enrol_get_plugin('manual');
    if (!$enrolplugin) {
        $errors[] = get_string('enrol_manual_disabled', 'auth_devicelock');
        return 0;
    }

    // Default (or invalid) role falls back to Student.
    $roleid = (int)$roleid;
    if ($roleid <= 0 || !$DB->record_exists('role', ['id' => $roleid])) {
        $studentrole = $DB->get_record('role', ['shortname' => 'student'], 'id', IGNORE_MISSING);
        $roleid = $studentrole ? (int)$studentrole->id : 0;
    }

    $enrolled = 0;
    foreach ($courseids as $cid) {
        $cid = (int)$cid;
        if ($cid <= 1) {
            continue; // Never enrol into the site frontpage course.
        }
        try {
            $instance = auth_devicelock_resolve_manual_enrol_instance($cid, $enrolplugin, $instancecache, $errors);
            if (!$instance) {
                continue;
            }
            // Already enrolled in this course through any plugin? Treat as done.
            $already = $DB->record_exists_sql(
                'SELECT 1
                   FROM {user_enrolments} ue
                   JOIN {enrol} e ON e.id = ue.enrolid
                  WHERE ue.userid = ? AND e.courseid = ?',
                [$userid, $cid]
            );
            if ($already) {
                $enrolled++;
                continue;
            }
            $timestart = time();
            $timeend = 0;
            if ($durationdays > 0) {
                $timeend = $timestart + ($durationdays * DAYSECS);
            }
            $enrolplugin->enrol_user($instance, $userid, $roleid, $timestart, $timeend, ENROL_USER_ACTIVE);
            $enrolled++;
        } catch (\Exception $e) {
            $coursename = $DB->get_field('course', 'fullname', ['id' => $cid]);
            $errors[] = get_string('enrol_failed_course', 'auth_devicelock', [
                'course' => ($coursename !== false && $coursename !== null) ? $coursename : ('#' . $cid),
                'error'  => $e->getMessage(),
            ]);
        }
    }
    return $enrolled;
}


/**
 * Fetch every course enrolment a user currently holds, across ALL enrol
 * plugins (v3.8.0 - Change Course tool).
 *
 * Used to pre-check the courses the user is already enrolled in on the
 * Change Course form and to prefill each enrolment's duration.
 *
 * @param int $userid User id.
 * @return array Map of courseid => stdClass{courseid, timestart, timeend, enrolid, plugin, status}.
 */
function auth_devicelock_get_user_course_enrolments($userid) {
    global $DB;

    $userid = (int)$userid;
    if ($userid <= 0) {
        return [];
    }

    $rows = $DB->get_records_sql("
        SELECT e.courseid, ue.timestart, ue.timeend, ue.enrolid, e.enrol AS plugin, ue.status
          FROM {user_enrolments} ue
          JOIN {enrol} e ON e.id = ue.enrolid
         WHERE ue.userid = ?
      ORDER BY e.courseid", [$userid]);

    // Key by course id (a rare double enrolment in one course collapses to
    // the last row - the form still lists the course exactly once).
    $enrolments = [];
    foreach ($rows as $row) {
        $row->courseid = (int)$row->courseid;
        $enrolments[$row->courseid] = $row;
    }
    return $enrolments;
}

/**
 * Enrol (or update) a user's enrolment in ONE course via the manual plugin
 * (v3.8.0 - Change Course tool).
 *
 * Unlike auth_devicelock_enrol_user_in_courses() - which treats an existing
 * enrolment as "already done" - this helper ALWAYS calls the manual plugin's
 * enrol_user(): the core enrol_plugin::enrol_user() implementation INSERTS a
 * new {user_enrolments} row or UPDATES the existing one (timestart / timeend
 * / status) and assigns the requested course-level role, so one call gives
 * the Change Course form its enrol-or-update semantics.
 *
 * @param int   $userid        User to enrol.
 * @param int   $courseid      Course to enrol into (frontpage id 1 is refused).
 * @param int   $roleid        Course role to assign (0 or invalid falls back to Student).
 * @param int   $durationdays  Enrolment duration in days (0 = unlimited).
 * @param array $errors        Collected human-readable error messages (by reference).
 * @param array $instancecache Shared enrol-instance cache between calls (by reference).
 * @return bool True when the enrolment was created or updated.
 */
function auth_devicelock_set_course_enrolment($userid, $courseid, $roleid = 0, $durationdays = 0, &$errors = [], &$instancecache = []) {
    global $CFG, $DB;
    require_once($CFG->libdir . '/enrollib.php');

    $userid = (int)$userid;
    $courseid = (int)$courseid;
    $durationdays = max(0, (int)$durationdays);
    if ($userid <= 0 || $courseid <= 1) {
        return false; // Never enrol into the site frontpage course.
    }

    $enrolplugin = enrol_get_plugin('manual');
    if (!$enrolplugin) {
        $errors[] = get_string('enrol_manual_disabled', 'auth_devicelock');
        return false;
    }

    // Default (or invalid) role falls back to Student.
    $roleid = (int)$roleid;
    if ($roleid <= 0 || !$DB->record_exists('role', ['id' => $roleid])) {
        $studentrole = $DB->get_record('role', ['shortname' => 'student'], 'id', IGNORE_MISSING);
        $roleid = $studentrole ? (int)$studentrole->id : 0;
    }

    try {
        $instance = auth_devicelock_resolve_manual_enrol_instance($courseid, $enrolplugin, $instancecache, $errors);
        if (!$instance) {
            return false;
        }
        $timestart = time();
        $timeend = ($durationdays > 0) ? $timestart + ($durationdays * DAYSECS) : 0;
        // enrol_user() inserts OR updates the enrolment (dates, status +
        // course-level role), so this single call implements both "enrol
        // into a new course" and "re-duration / re-role an existing one".
        $enrolplugin->enrol_user($instance, $userid, $roleid, $timestart, $timeend, ENROL_USER_ACTIVE);
        return true;
    } catch (\Exception $e) {
        $coursename = $DB->get_field('course', 'fullname', ['id' => $courseid]);
        $errors[] = get_string('enrol_failed_course', 'auth_devicelock', [
            'course' => ($coursename !== false && $coursename !== null) ? $coursename : ('#' . $courseid),
            'error'  => $e->getMessage(),
        ]);
        return false;
    }
}

/**
 * Un-enrol a user from ONE course through every enrol plugin that allows it
 * (v3.8.0 - Change Course tool).
 *
 * @param int $userid   User to un-enrol.
 * @param int $courseid Course to remove the user from (frontpage id 1 is never touched).
 * @return bool True when at least one enrolment was removed.
 */
function auth_devicelock_unenrol_user_from_course($userid, $courseid) {
    global $CFG, $DB;
    require_once($CFG->libdir . '/enrollib.php');

    $userid = (int)$userid;
    $courseid = (int)$courseid;
    if ($userid <= 0 || $courseid <= 1) {
        return false; // Never un-enrol from the site frontpage course.
    }

    // The user's enrolment rows for this course, joined with their enrol
    // instances so each owning plugin can be asked for permission.
    $instances = $DB->get_records_sql("
        SELECT ue.id AS ueid, e.id, e.enrol, e.courseid, e.status
          FROM {user_enrolments} ue
          JOIN {enrol} e ON e.id = ue.enrolid
         WHERE ue.userid = ? AND e.courseid = ?", [$userid, $courseid]);

    $removed = false;
    foreach ($instances as $instance) {
        try {
            $plugin = enrol_get_plugin($instance->enrol);
            if ($plugin && $plugin->allow_unenrol($instance)) {
                $plugin->unenrol_user($instance, $userid);
                $removed = true;
            }
        } catch (\Exception $e) {
            debugging('auth_devicelock_unenrol_user_from_course: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }
    }
    return $removed;
}
