<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Login restriction handling
 *
 * @package    auth_devicelock
        * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/lib.php');
require_once(__DIR__ . '/auth.php');
require_once(__DIR__ . '/device_manager.php');

/**
 * Handle user login event
 *
 * @param stdClass $user User object
 * @return bool True if login should proceed
 */
function auth_devicelock_handle_user_login($user) {
    global $SESSION;
    
    // Check if user should be restricted
    if (!auth_plugin_devicelock::should_restrict_user_static($user)) {
        return true;
    }
    
    // Generate device fingerprint
    $fingerprint = auth_devicelock_get_current_fingerprint();
    
    // Check if device is allowed
    $device = auth_devicelock_find_device_for_user($user->id);
    if ($device && !empty($device->browser_limit_exceeded)) {
        require_logout();
        return false;
    }
    if ($device && $device->status === 'active') {
        return true;
    }
    
    // If device is explicitly blocked
    if ($device && $device->status === 'blocked') {
        require_logout();
        $SESSION->auth_devicelock_device_blocked = true;
        $SESSION->loginerrormsg = get_string('deviceblockedmessage', 'auth_devicelock');
        auth_devicelock_log_action($user->id, $fingerprint, 'login_prevented', [
            'reason' => 'device_blocked',
            'device_id' => $device->id
        ]);
        return false;
    }
    
    $currentcount = device_manager::get_active_device_count($user->id);
    if ($currentcount == 0) {
        return true;
    }
    
    // Log the user out immediately
    require_logout();
    
    // Set error message
    $SESSION->loginerrormsg = get_string('devicenotallowed', 'auth_devicelock');
    
    // Log the blocked attempt
    auth_devicelock_log_action($user->id, $fingerprint, 'login_prevented', [
        'reason' => 'device_not_allowed'
    ]);
    
    return false;
}

/**
 * Hook into login process
 *
 * @param object $user User object
 * @param object $user2 Second user object
 * @param string $username Username
 * @param string $password Password
 * @return bool True if login should proceed
 */
function auth_devicelock_user_login_hook($user, $user2, $username, $password) {
    return auth_devicelock_handle_user_login($user);
}