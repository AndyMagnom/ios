<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Installation script for Lock Guard plugin
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

function xmldb_auth_devicelock_install() {
    global $DB, $CFG;
    
    // Set default configuration
    $defaults = [
        'enabled' => 0,
        'maxdevices' => 1,
        'autoregister' => 1,
        'sendnotifications' => 0
    ];
    
    foreach ($defaults as $name => $value) {
        set_config($name, $value, 'auth_devicelock');
    }
    
    // v3.8.0: seed the excluded-roles list with the same default the
    // settings page shows - site administrators plus the teacher /
    // editing teacher / manager roles (fresh installs never run
    // db/upgrade.php, so the migration step there does not apply).
    $excludeddefaults = ['admin'];
    $teacherish = $DB->get_records_list('role', 'shortname',
        ['teacher', 'editingteacher', 'manager'], 'sortorder ASC', 'id');
    foreach ($teacherish as $tr) {
        $excludeddefaults[] = (string)(int)$tr->id;
    }
    set_config('excludedroles', implode(',', $excludeddefaults), 'auth_devicelock');
    
    // Ensure plugin is in Moodle's enabled auth plugins list
    require_once(__DIR__ . '/lib.php');
    if (function_exists('auth_devicelock_ensure_enabled')) {
        auth_devicelock_ensure_enabled();
    }
    
    return true;
}