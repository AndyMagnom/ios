<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * AJAX handler for Lock Guard plugin
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define('AJAX_SCRIPT', true);

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/filelib.php');

$action = optional_param('action', 'setsession', PARAM_ALPHA);
$sesskey = optional_param('sesskey', '', PARAM_RAW);

// SECURITY FIX: sesskey is now mandatory, not optional. Moodle issues a
// sesskey for anonymous sessions too (M.cfg.sesskey is available on the
// login page before authentication), so there is no legitimate case where
// it should be skippable. The old "if provided" check let anyone POST
// here with no sesskey at all and silently write session state.
if (!confirm_sesskey($sesskey)) {
    header('HTTP/1.1 403 Forbidden');
    echo json_encode(['error' => 'Invalid session key']);
    die();
}

// v3.6.0: external-link click beacon (navigator.sendBeacon from the
// page footer). A valid sesskey alone does not prove a login, so the
// normal activity gating (master switch, logged-in non-guest user,
// admin policy) is applied by the shared helper before anything is
// written.
if ($action === 'activitylink') {
    require_once(__DIR__ . '/lib.php');
    require_once(__DIR__ . '/device_manager.php');
    if (auth_devicelock_activity_tracking_active()) {
        $linkurl = required_param('url', PARAM_URL);
        if (\core_text::strlen($linkurl) > 512) {
            $linkurl = \core_text::substr($linkurl, 0, 512);
        }
        $linkdetails = ['url' => $linkurl];
        $linkref = clean_param($_SERVER['HTTP_REFERER'] ?? '', PARAM_URL);
        if ($linkref !== '') {
            $linkdetails['from_page'] = $linkref;
        }
        $linkfp = auth_devicelock_get_current_fingerprint();
        device_manager::log_action((int)$USER->id, $linkfp, 'activity_link', $linkdetails);
    }
    echo json_encode(['success' => true]);
    die();
}

// v3.10.0: button-click beacon (navigator.sendBeacon from the page
// footer). Mirrors activitylink above: a valid sesskey alone does not
// prove a login, so the shared activity gating decides who is tracked,
// and every payload field is cleaned and length-capped.
if ($action === 'activityclick') {
    require_once(__DIR__ . '/lib.php');
    require_once(__DIR__ . '/device_manager.php');
    if (auth_devicelock_activity_tracking_active()) {
        $btntext = optional_param('button', '', PARAM_TEXT);
        if (\core_text::strlen($btntext) > 120) {
            $btntext = \core_text::substr($btntext, 0, 120);
        }
        $btntype = optional_param('type', '', PARAM_TEXT);
        if (\core_text::strlen($btntype) > 40) {
            $btntype = \core_text::substr($btntype, 0, 40);
        }
        $clickdetails = [
            'button' => $btntext,
            'button_type' => $btntype,
        ];
        $formaction = optional_param('form', '', PARAM_URL);
        if (\core_text::strlen($formaction) > 512) {
            $formaction = \core_text::substr($formaction, 0, 512);
        }
        if ($formaction !== '') {
            $clickdetails['form_action'] = $formaction;
        }
        $clickref = clean_param($_SERVER['HTTP_REFERER'] ?? '', PARAM_URL);
        if ($clickref !== '') {
            $clickdetails['from_page'] = $clickref;
        }
        $clickfp = auth_devicelock_get_current_fingerprint();
        device_manager::log_action((int)$USER->id, $clickfp, 'activity_click', $clickdetails);
    }
    echo json_encode(['success' => true]);
    die();
}

global $SESSION;

require_once(__DIR__ . '/classes/local/ios_identity.php');
if (\auth_devicelock\local\ios_identity::is_request()) {
    // Activity actions above remain intact. Browser fingerprint mutation is not
    // part of native Apple identity and cannot override its server proof.
    header('Content-Type: application/json');
    if (!\auth_devicelock\local\ios_identity::session()) {
        http_response_code(403);
        echo json_encode(['error' => 'Verified Apple device required']);
    } else {
        echo json_encode(['success' => true, 'native_identity' => true]);
    }
    die();
}


if ($action === 'setfingerprint') {
    // Bundled fingerprint payload
    $rawdata = optional_param('data', '', PARAM_RAW);
    $data = [];
    if (!empty($rawdata)) {
        $decoded = @json_decode($rawdata, true);
        if (is_array($decoded)) {
            $data = $decoded;
        }
    }
    
    $allowed_keys = [
        'auth_devicelock_token',
        'auth_devicelock_screen',
        'auth_devicelock_avail_screen',
        'auth_devicelock_colordepth',
        'auth_devicelock_timezone',
        'auth_devicelock_tzname',
        'auth_devicelock_pixelratio',
        'auth_devicelock_language',
        'auth_devicelock_platform',
        'auth_devicelock_gpu',
        'auth_devicelock_gpu_vendor',
        'auth_devicelock_canvas',
        'auth_devicelock_audio',
        'auth_devicelock_brands',
        'auth_devicelock_concurrency',
        'auth_devicelock_memory',
        'auth_devicelock_touch',
        'auth_devicelock_cookies',
        'auth_devicelock_dnt',
        'auth_devicelock_online'
    ];
    
    foreach ($allowed_keys as $k) {
        if (isset($data[$k])) {
            $SESSION->{$k} = clean_param($data[$k], PARAM_RAW);
        } else {
            $val = optional_param($k, null, PARAM_RAW);
            if ($val !== null) {
                $SESSION->{$k} = $val;
            }
        }
    }
    
    // Check if the current browser token has been revoked in a reset action
    require_once(__DIR__ . '/device_manager.php');
    $token = $SESSION->auth_devicelock_token ?? '';
    $should_wipe = false;
    if (!empty($token) && device_manager::is_token_revoked($token)) {
        $should_wipe = true;
    }
    if (!empty($USER->id) && device_manager::has_browser_wipe_flag($USER->id, $token)) {
        $should_wipe = true;
        device_manager::clear_browser_wipe_flag($USER->id, $token);
    }
    
    if ($should_wipe) {
        if (!headers_sent()) {
            setcookie('auth_devicelock_token', '', time() - 3600, '/');
            setcookie('auth_devicelock_hw', '', time() - 3600, '/');
            setcookie('auth_devicelock_fallback', '', time() - 3600, '/');
        }
        unset($SESSION->auth_devicelock_token);
        echo json_encode(['success' => true, 'wipe' => true]);
        die();
    }
    
    echo json_encode(['success' => true]);
    die();
} else if ($action === 'setsession') {
    $key = optional_param('key', '', PARAM_ALPHAEXT);
    $value = optional_param('value', '', PARAM_RAW);
    if (!empty($key) && strpos($key, 'auth_devicelock_') === 0) {
        $SESSION->{$key} = clean_param($value, PARAM_RAW);
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['error' => 'Invalid or unauthorized session key']);
    }
    die();

} else {
    echo json_encode(['error' => 'Invalid action']);
    die();
}