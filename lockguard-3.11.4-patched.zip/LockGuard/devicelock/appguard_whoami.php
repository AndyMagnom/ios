<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * App Guard "who am I" endpoint - gives the custom app (Windows, ...) the
 * signed-in user's display name and id so it can draw a per-student
 * watermark over course content.
 *
 * GET /auth/devicelock/appguard_whoami.php
 *   -> {"ok":true,"id":123,"name":"Full Name","username":"jdoe"}
 *
 * Authentication: the user's own Moodle session (the app is a WebView and
 * the user is logged in). Returns ONLY the calling user's own data.
 * When App Guard is enabled the request must also look like it comes from
 * the app (User-Agent marker or App key header).
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define('AJAX_SCRIPT', true);

require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, private');
header('Pragma: no-cache');

function auth_devicelock_whoami_respond(int $code, array $body): void {
    http_response_code($code);
    echo json_encode($body);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
    auth_devicelock_whoami_respond(405, ['ok' => false, 'error' => 'GET only']);
}

if (auth_devicelock_appguard_enabled() && !auth_devicelock_appguard_is_app_request()) {
    auth_devicelock_whoami_respond(403, ['ok' => false, 'error' => 'App requests only']);
}

if (!isloggedin() || isguestuser()) {
    auth_devicelock_whoami_respond(401, ['ok' => false, 'error' => 'Not signed in']);
}

auth_devicelock_whoami_respond(200, [
    'ok' => true,
    'id' => (int)$USER->id,
    'name' => fullname($USER),
    'username' => (string)$USER->username,
]);
