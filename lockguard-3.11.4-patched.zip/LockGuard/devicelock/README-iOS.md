# LockGuard Apple identity extension

`LockGuard_v3_10_0.zip` is the original supplied archive. The revised, reviewable
source is `source/devicelock`; the installable package is
`LockGuard_v3_11_3_apple.zip`. Configuration, security limits and validation steps
are documented in the workspace `ios/README.md` and `ios/SECURITY-REPORT.md`.

The new endpoint is `/auth/devicelock/ios_identity.php`:

- `POST {"action":"challenge","keyID":"<Apple base64 key ID>"}` returns
  `id`, `nonce` (32 random bytes, base64) and `requiresAttestation`.
- `POST {"action":"verify","challengeID":"<id>","clientData":"<base64 JSON bytes>",
  "attestation":"<base64 CBOR>"}` enrolls an unknown key. Known keys send
  `assertion` instead of `attestation`.
- `clientData` decodes to `{challengeID, nonce, origin, signals}`. Signals contain
  `appAttestKeyID`, `keychainUUID`, optional `idfv`, exact `osVersion`, integer `build`, and a fresh
  `deviceCheckToken`. The server hashes the **exact decoded bytes**, validates
  the claims against its stored challenge and the configured HTTPS Moodle origin, then checks the Apple proof and
  DeviceCheck token. Client JSON key ordering is not a server trust assumption.
- Successful verification returns `sessionToken`: random 256-bit bearer secret,
  valid for five minutes. WKWebView receives it as a Secure, HttpOnly, host-only
  `MedPrepIOS` cookie with SameSite=Lax. Native reports send Authorization:
  Bearer. Only SHA-256 token digests are stored.

Challenges are single-use, expire after two minutes and are bound to one key.
Challenge creation is rate-limited to 120 per IP per minute across sessions.
Moodle locks serialize each key's challenge consumption, verification and
counter update. Fresh verification retires prior bearer sessions for that key. Failed verification consumes its challenge and yields no native
session. Apple API failures fail closed. DeviceCheck bit state is read-only;
existing vendor-wide bit conventions are preserved.

No shared Apple private key or client secret ships in the iOS app. Each Moodle
origin needs this extension and its own server configuration. No changes have
been deployed to a running Moodle instance.


Capture policy is mandatory and denies by default. Set
`$CFG->auth_devicelock_ios_capture` with Boolean `enabled`, exact
`reviewed_os_versions` strings (`major.minor.patch`) and integer `minimum_build`.
`POST {"action":"policy"}` exposes only this public policy. Verification rejects
unapproved OS/build claims; existing sessions are rechecked against current policy.
The `after_config` hook checks native sessions for Moodle PHP/AJAX/file requests,
and enforces no-store headers before response transmission. Static files,
external/CDN deliveries and alternate legacy clients require separate controls.
The current session-based WebKit implementation does not generate an App Attest
assertion for every subresource request. See the security report for that limit.


Authenticated native `screenshot_attempt` reports, and
`screen_recording_detected` reports with the exact Boolean `capture_active: true`,
revoke only their own bearer session before telemetry rate limiting or logging.
The response includes `native_session_revoked`. Account/device registrations and
replacement bearers are preserved. Recording-stop events do not revoke sessions.
When available, the bearer-bound Moodle user determines audit attribution even
if client cookie data has already been purged. Local capture enforcement does
not depend on report delivery; failed delivery leaves the server bearer valid
until its existing expiry and must not be reported as successful revocation.

Native macOS configuration and automatic device-key enrollment are documented in `README-macOS.md`.
