<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Session Manager for Lock Guard plugin
 * Tracks which session belongs to which device for precise logout
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace auth_devicelock;

defined('MOODLE_INTERNAL') || die();

/**
 * Session Manager class
 * 
 * This class tracks the relationship between Moodle sessions and device fingerprints
 * to enable logging out specific devices without affecting others.
 */
class session_manager {

    /**
     * Track the current session for a device
     * 
     * @param int $userid User ID
     * @param string $fingerprint Device fingerprint
     * @return bool Success
     */
    public static function track_current_session($userid, $fingerprint) {
        global $DB;
        
        $sessionid = session_id();
        if (empty($sessionid)) {
            return false;
        }
        
        // Get current IP and user agent
        $ipaddress = getremoteaddr();
        $useragent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $now = time();
        
        // Check if tracking already exists
        $existing = $DB->get_record('auth_devicelock_session_tracking', [
            'userid' => $userid,
            'device_fingerprint' => $fingerprint
        ]);
        
        if ($existing) {
            // Update existing tracking
            $existing->session_id = $sessionid;
            $existing->ip_address = $ipaddress;
            $existing->user_agent = $useragent;
            $existing->last_access = $now;
            return $DB->update_record('auth_devicelock_session_tracking', $existing);
        } else {
            // Create new tracking
            $tracking = new \stdClass();
            $tracking->userid = $userid;
            $tracking->device_fingerprint = $fingerprint;
            $tracking->session_id = $sessionid;
            $tracking->created_at = $now;
            $tracking->ip_address = $ipaddress;
            $tracking->user_agent = $useragent;
            $tracking->last_access = $now;
            
            try {
                return $DB->insert_record('auth_devicelock_session_tracking', $tracking);
            } catch (\dml_write_exception $e) {
                $existing = $DB->get_record('auth_devicelock_session_tracking', [
                    'userid' => $userid,
                    'device_fingerprint' => $fingerprint
                ]);
                if ($existing) {
                    $existing->session_id = $sessionid;
                    $existing->ip_address = $ipaddress;
                    $existing->user_agent = $useragent;
                    $existing->last_access = $now;
                    return $DB->update_record('auth_devicelock_session_tracking', $existing);
                }
                return false;
            }
        }
    }

    
    /**
     * Get session ID for a specific device
     * 
     * @param int $userid User ID
     * @param string $fingerprint Device fingerprint
     * @return string|bool Session ID or false if not found
     */
    public static function get_session_for_device($userid, $fingerprint) {
        global $DB;
        
        $tracking = $DB->get_record('auth_devicelock_session_tracking', [
            'userid' => $userid,
            'device_fingerprint' => $fingerprint
        ]);
        
        return $tracking ? $tracking->session_id : false;
    }
    
    /**
     * Check if a device has an active session
     * 
     * @param int $userid User ID
     * @param string $fingerprint Device fingerprint
     * @return bool
     */
    public static function device_has_active_session($userid, $fingerprint) {
        global $DB;
        
        $tracking = $DB->get_record('auth_devicelock_session_tracking', [
            'userid' => $userid,
            'device_fingerprint' => $fingerprint
        ]);
        
        if (!$tracking) {
            return false;
        }
        
        // Check if the session still exists in Moodle sessions table
        $session = $DB->get_record('sessions', [
            'userid' => $userid,
            'sid' => $tracking->session_id
        ]);
        
        return !empty($session);
    }
    
    /**
     * Get all sessions for a user with their device info
     * 
     * @param int $userid User ID
     * @return array Array of session tracking records
     */
    public static function get_user_sessions($userid) {
        global $DB;
        
        return $DB->get_records('auth_devicelock_session_tracking', ['userid' => $userid]);
    }
    
    /**
     * Logout a specific device by deleting its session ONLY
     * 
     * @param int $userid User ID
     * @param string $fingerprint Device fingerprint
     * @return bool Success
     */
    public static function logout_specific_device($userid, $fingerprint) {
        global $DB;
        
        // Get the session ID for this device
        $tracking = $DB->get_record('auth_devicelock_session_tracking', [
            'userid' => $userid,
            'device_fingerprint' => $fingerprint
        ]);
        
        if (!$tracking) {
            return false;
        }
        
        $sessionid = $tracking->session_id;
        
        // 1. Remove from tracking
        $DB->delete_records('auth_devicelock_session_tracking', [
            'userid' => $userid,
            'device_fingerprint' => $fingerprint
        ]);
        
        // 2. Safely terminate session using Moodle core session manager API
        \core\session\manager::kill_session($sessionid);
        
        return true;
    }
    
    /**
     * Clean up old session tracking records (call from cron)
     */
    public static function cleanup_old_tracking() {
        global $DB;
        
        // Delete tracking older than 24 hours (sessions should be expired anyway)
        $oldtime = time() - (24 * 3600);
        $DB->delete_records_select('auth_devicelock_session_tracking', 'created_at < ?', [$oldtime]);
        
        return true;
    }
    
    /**
     * Remove tracking for current session (call on logout)
     * 
     * @param int $userid User ID
     * @return bool Success
     */
    public static function remove_current_tracking($userid) {
        global $DB;
        
        $sessionid = session_id();
        if (empty($sessionid)) {
            return false;
        }
        
        return $DB->delete_records('auth_devicelock_session_tracking', [
            'userid' => $userid,
            'session_id' => $sessionid
        ]);
    }
}