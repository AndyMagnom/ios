<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Privacy provider implementation for Lock Guard plugin
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace auth_devicelock\privacy;

defined('MOODLE_INTERNAL') || die();

use core_privacy\local\metadata\collection;
use core_privacy\local\request\contextlist;
use core_privacy\local\request\approved_contextlist;
use core_privacy\local\request\transform;
use core_privacy\local\request\writer;
use core_privacy\local\request\userlist;
use core_privacy\local\request\approved_userlist;

/**
 * Privacy provider class
 */
class provider implements 
    \core_privacy\local\metadata\provider,
    \core_privacy\local\request\plugin\provider,
    \core_privacy\local\request\core_userlist_provider {

    /**
     * Returns metadata about this plugin
     *
     * @param collection $collection The initialised collection to add items to
     * @return collection A listing of user data stored through the system
     */
    public static function get_metadata(collection $collection) : collection {
        
        $collection->add_database_table('auth_devicelock_devices', [
            'userid' => 'privacy:metadata:auth_devicelock_devices:userid',
            'device_fingerprint' => 'privacy:metadata:auth_devicelock_devices:device_fingerprint',
            'device_info' => 'privacy:metadata:auth_devicelock_devices:device_info',
            'status' => 'privacy:metadata:auth_devicelock_devices:status',
            'last_login' => 'privacy:metadata:auth_devicelock_devices:last_login',
            'user_agent' => 'privacy:metadata:auth_devicelock_devices:user_agent',
            'screen_resolution' => 'privacy:metadata:auth_devicelock_devices:screen_resolution',
            'ip_address' => 'privacy:metadata:auth_devicelock_devices:ip_address',
        ], 'privacy:metadata:auth_devicelock_devices');
        
        $collection->add_database_table('auth_devicelock_logs', [
            'userid' => 'privacy:metadata:auth_devicelock_logs:userid',
            'device_fingerprint' => 'privacy:metadata:auth_devicelock_logs:device_fingerprint',
            'action' => 'privacy:metadata:auth_devicelock_logs:action',
            'ip_address' => 'privacy:metadata:auth_devicelock_logs:ip_address',
            'user_agent' => 'privacy:metadata:auth_devicelock_logs:user_agent',
            'timestamp' => 'privacy:metadata:auth_devicelock_logs:timestamp',
            'details' => 'privacy:metadata:auth_devicelock_logs:details',
        ], 'privacy:metadata:auth_devicelock_logs');
        
        $collection->add_database_table('auth_devicelock_user_scores', [
            'userid' => 'privacy:metadata:auth_devicelock_user_scores:userid',
            'score' => 'privacy:metadata:auth_devicelock_user_scores:score',
            'violation_count' => 'privacy:metadata:auth_devicelock_user_scores:violation_count',
            'last_violation' => 'privacy:metadata:auth_devicelock_user_scores:last_violation',
            'last_regain' => 'privacy:metadata:auth_devicelock_user_scores:last_regain',
            'custom_regain' => 'privacy:metadata:auth_devicelock_user_scores:custom_regain',
            'regain_amount' => 'privacy:metadata:auth_devicelock_user_scores:regain_amount',
            'regain_interval' => 'privacy:metadata:auth_devicelock_user_scores:regain_interval',
            'updated_at' => 'privacy:metadata:auth_devicelock_user_scores:updated_at',
        ], 'privacy:metadata:auth_devicelock_user_scores');
        
        $collection->add_database_table('auth_devicelock_ios_state', [
            'fingerprint' => 'privacy:metadata:ios:fingerprint',
            'payload' => 'privacy:metadata:ios:payload',
            'created' => 'privacy:metadata:ios:created',
            'expires' => 'privacy:metadata:ios:expires',
        ], 'privacy:metadata:ios');
        $collection->add_external_location_link('apple_devicecheck', [
            'device_token' => 'privacy:metadata:ios:devicecheck',
        ], 'privacy:metadata:ios:apple');

        return $collection;
    }
    
    /**
     * Get the list of contexts that contain user information for the specified user
     *
     * @param int $userid The user to search
     * @return contextlist $contextlist The contextlist containing the list of contexts used in this plugin
     */
    public static function get_contexts_for_userid(int $userid) : contextlist {
        $contextlist = new contextlist();
        
        // Add system context
        $contextlist->add_system_context();
        
        return $contextlist;
    }
    
    /**
     * Export all user data for the specified user, in the specified contexts
     *
     * @param approved_contextlist $contextlist The approved contexts to export information for
     */
    public static function export_user_data(approved_contextlist $contextlist) {
        global $DB;
        
        $userid = $contextlist->get_user()->id;
        
        // Export device data
        $devices = $DB->get_records('auth_devicelock_devices', ['userid' => $userid]);
        foreach ($devices as $device) {
            $data = (object) [
                'device_fingerprint' => auth_devicelock_mask_fingerprint($device->device_fingerprint),
                'status' => $device->status,
                'last_login' => transform::datetime($device->last_login),
                'created_at' => transform::datetime($device->created_at),
                'user_agent' => $device->user_agent,
                'screen_resolution' => $device->screen_resolution,
                'ip_address' => $device->ip_address
            ];
            
            writer::with_context(\context_system::instance())->export_data([
                get_string('pluginname', 'auth_devicelock'),
                'Device ' . $device->id
            ], $data);
        }
        
        $apple = $DB->get_records_sql('SELECT s.* FROM {auth_devicelock_ios_state} s
            WHERE s.kind = :kind AND s.fingerprint IN (
                SELECT device_fingerprint FROM {auth_devicelock_devices} WHERE userid = :deviceuser
                UNION SELECT device_fingerprint FROM {auth_devicelock_logs} WHERE userid = :loguser
            )', ['kind' => 'key', 'deviceuser' => $userid, 'loguser' => $userid]);
        foreach ($apple as $record) {
            writer::with_context(\context_system::instance())->export_data([
                get_string('pluginname', 'auth_devicelock'), 'Apple identity ' . $record->id
            ], (object)json_decode($record->payload, true));
        }

        // Export the persistent security score row
        $scorerow = $DB->get_record('auth_devicelock_user_scores', ['userid' => $userid]);
        if ($scorerow) {
            $scoredata = (object) [
                'score' => $scorerow->score,
                'violation_count' => $scorerow->violation_count,
                'last_violation' => transform::datetime($scorerow->last_violation),
                'last_regain' => transform::datetime($scorerow->last_regain),
                'custom_regain' => $scorerow->custom_regain,
                'regain_amount' => $scorerow->regain_amount,
                'regain_interval' => $scorerow->regain_interval,
                'updated_at' => transform::datetime($scorerow->updated_at)
            ];
            writer::with_context(\context_system::instance())->export_data([
                get_string('pluginname', 'auth_devicelock'),
                'Security score'
            ], $scoredata);
        }
        
        // Export logs
        $logs = $DB->get_records('auth_devicelock_logs', ['userid' => $userid]);
        foreach ($logs as $log) {
            $data = (object) [
                'action' => $log->action,
                'device_fingerprint' => auth_devicelock_mask_fingerprint($log->device_fingerprint),
                'timestamp' => transform::datetime($log->timestamp),
                'ip_address' => $log->ip_address,
                'user_agent' => $log->user_agent,
                'details' => $log->details
            ];
            
            writer::with_context(\context_system::instance())->export_data([
                get_string('pluginname', 'auth_devicelock'),
                'Log ' . $log->id
            ], $data);
        }
    }
    
    /**
     * Delete all data for all users in the specified context
     *
     * @param \context $context The specific context to delete data for
     */
    public static function delete_data_for_all_users_in_context(\context $context) {
        global $DB;
        
        if ($context->contextlevel == CONTEXT_SYSTEM) {
            $DB->delete_records('auth_devicelock_ios_state');
            $DB->delete_records('auth_devicelock_devices');
            $DB->delete_records('auth_devicelock_logs');
            $DB->delete_records('auth_devicelock_user_scores');
        }
    }
    
    /**
     * Delete all user data for the specified user, in the specified contexts
     *
     * @param approved_contextlist $contextlist The approved contexts and user information to delete information for
     */
    public static function delete_data_for_user(approved_contextlist $contextlist) {
        global $DB;
        
        $userid = $contextlist->get_user()->id;
        
        foreach ($contextlist->get_contexts() as $context) {
            if ($context->contextlevel == CONTEXT_SYSTEM) {
                self::delete_apple_identities([$userid]);
                $DB->delete_records('auth_devicelock_devices', ['userid' => $userid]);
                $DB->delete_records('auth_devicelock_logs', ['userid' => $userid]);
                $DB->delete_records('auth_devicelock_user_scores', ['userid' => $userid]);
            }
        }
    }
    
    /**
     * Get the list of users who have data within a context
     *
     * @param userlist $userlist The userlist containing the list of users who have data in this context/plugin combination
     */
    public static function get_users_in_context(userlist $userlist) {
        $context = $userlist->get_context();
        
        if ($context->contextlevel != CONTEXT_SYSTEM) {
            return;
        }
        
        // Add users from devices table
        $sql = "SELECT userid FROM {auth_devicelock_devices}";
        $userlist->add_from_sql('userid', $sql, []);
        
        // Add users from logs table
        $sql = "SELECT userid FROM {auth_devicelock_logs}";
        $userlist->add_from_sql('userid', $sql, []);
        
        // Add users from the security-score table
        $sql = "SELECT userid FROM {auth_devicelock_user_scores}";
        $userlist->add_from_sql('userid', $sql, []);
    }
    
    /**
     * Delete multiple users within a single context
     *
     * @param approved_userlist $userlist The approved context and user information to delete information for
     */
    public static function delete_data_for_users(approved_userlist $userlist) {
        global $DB;
        
        $context = $userlist->get_context();
        
        if ($context->contextlevel != CONTEXT_SYSTEM) {
            return;
        }
        
        $userids = $userlist->get_userids();
        
        if (empty($userids)) {
            return;
        }
        
        list($insql, $inparams) = $DB->get_in_or_equal($userids, SQL_PARAMS_NAMED);
        
        self::delete_apple_identities($userids);
        $DB->delete_records_select('auth_devicelock_devices', "userid $insql", $inparams);
        $DB->delete_records_select('auth_devicelock_logs', "userid $insql", $inparams);
        $DB->delete_records_select('auth_devicelock_user_scores', "userid $insql", $inparams);
    }
    /** Shared Apple keys remain only while another account still references them. */
    private static function delete_apple_identities(array $userids): void {
        global $DB;
        [$devicesql, $deviceparams] = $DB->get_in_or_equal($userids, SQL_PARAMS_NAMED, 'iosd');
        [$logsql, $logparams] = $DB->get_in_or_equal($userids, SQL_PARAMS_NAMED, 'iosl');
        $fingerprints = $DB->get_fieldset_sql("SELECT device_fingerprint FROM {auth_devicelock_devices}
            WHERE userid $devicesql UNION SELECT device_fingerprint FROM {auth_devicelock_logs}
            WHERE userid $logsql", array_merge($deviceparams, $logparams));
        [$othersql, $otherparams] = $DB->get_in_or_equal($userids, SQL_PARAMS_NAMED, 'ioso', false);
        foreach ($fingerprints as $fingerprint) {
            if (!preg_match('/^(?:ios|mac)_/', $fingerprint)) { continue; }
            $params = array_merge($otherparams, ['iosfp' => $fingerprint]);
            $where = "device_fingerprint = :iosfp AND userid > 0 AND userid $othersql";
            $others = $DB->count_records_select('auth_devicelock_devices', $where, $params) +
                $DB->count_records_select('auth_devicelock_logs', $where, $params);
            if (!$others) {
                $DB->delete_records('auth_devicelock_ios_state', ['fingerprint' => $fingerprint]);
            }
        }
    }
}
