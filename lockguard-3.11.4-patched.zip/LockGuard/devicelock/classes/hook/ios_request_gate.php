<?php
namespace auth_devicelock\hook;
defined('MOODLE_INTERNAL') || die();
require_once(__DIR__ . '/../local/ios_identity.php');

/** Runs for Moodle PHP/AJAX/file requests, not just rendered pages. */
final class ios_request_gate {
    public static function execute(\core\hook\after_config $hook): void {
        global $CFG, $USER, $DB;
        if ((defined('CLI_SCRIPT') && CLI_SCRIPT) || (defined('BEHAT_SITE') && BEHAT_SITE) ||
            !\auth_devicelock\local\ios_identity::is_request()) { return; }
        $script = (string)($_SERVER['SCRIPT_NAME'] ?? '');
        $prefix = (string)(parse_url($CFG->wwwroot, PHP_URL_PATH) ?: '');
        if ($prefix !== '' && $prefix !== '/' && str_starts_with($script, $prefix . '/')) {
            $script = substr($script, strlen($prefix));
        }
        // Public bootstrap contains host names/policy only, never course content.
        if (in_array($script, ['/auth/devicelock/ios_identity.php',
            '/auth/devicelock/appguard_rest.php', '/auth/devicelock/appguard_blocked.php',
            '/local/siteswitcher/sites.php'], true)) { return; }
        $allowed = false;
        try {
            $session = \auth_devicelock\local\ios_identity::session();
            $allowed = $session !== null;
            if ($allowed && !empty($USER->id) && !isguestuser()) {
                require_once(__DIR__ . '/../../auth.php');
                $restricted = \auth_plugin_devicelock::should_restrict_user_static($USER);
                if ($restricted) {
                    $device = $DB->get_record('auth_devicelock_devices',
                        ['userid' => $USER->id, 'device_fingerprint' => $session['fingerprint']]);
                    $allowed = $device && $device->status === 'active' && empty($device->browser_limit_exceeded);
                }
                $allowed = $allowed && empty($USER->suspended) && empty($USER->deleted);
                if ($allowed) { $allowed = \auth_devicelock\local\ios_identity::bind_user((int)$USER->id, $restricted); }
            }
        } catch (\Throwable $error) { $allowed = false; }
        // Moodle file endpoints can overwrite early headers; restore these just
        // before PHP sends them. Static/CDN/X-Sendfile paths need edge rules too.
        $nocache = static function(): void {
            header('Cache-Control: no-store, private, max-age=0');
            header('Pragma: no-cache'); header('Expires: 0');
        };
        $nocache(); header_register_callback($nocache);
        if (!$allowed) { http_response_code(403); exit('Protected content unavailable.'); }
    }
}
