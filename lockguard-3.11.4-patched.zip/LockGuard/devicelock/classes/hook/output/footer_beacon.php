<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Footer beacon hook (v3.6.0): appends a tiny script to the page
 * footer that reports clicks on EXTERNAL links back to the plugin
 * (navigator.sendBeacon to ajax.php?action=activitylink), so "the
 * user clicked this link" is recorded even though the browser
 * immediately navigates away. Internal links are skipped - the
 * destination page logs its own page-view event.
 *
 * All gating lives in lib.php (auth_devicelock_activity_beacon_html()).
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace auth_devicelock\hook\output;

defined('MOODLE_INTERNAL') || die();

require_once(dirname(__DIR__, 3) . '/lib.php');

class footer_beacon {

    public static function execute(\core\hook\output\before_footer_html_generation $hook): void {
        // v3.10.0: write the deferred page-view row FIRST (footer time is
        // after every core event of the request has fired, so the
        // per-request dedupe flag is final - see
        // auth_devicelock_activity_log_current_page_flush() in lib.php).
        auth_devicelock_activity_log_current_page_flush();

        $html = auth_devicelock_activity_beacon_html();
        if ($html !== '') {
            $hook->add_html($html);
        }
    }
}
