<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * App Guard hook: runs before any page's headers are sent, on every
 * request, for any logged-in user regardless of their auth method.
 * Terminates browser sessions of restricted users browsing outside the
 * app (catches sessions that existed before the restriction was enabled,
 * or before a user was migrated to devicelock auth).
 *
 * All the actual logic lives in lib.php
 * (auth_devicelock_appguard_enforce_page_view()) so this hook and the
 * legacy lib.php callback (auth_devicelock_before_http_headers(), used on
 * Moodle versions without the hooks API) share one implementation.
 *
 * IMPORTANT: this class deliberately does NOT "implement"
 * \core\hook\output\before_http_headers - Moodle's core hook classes are
 * declared as plain classes, not interfaces, so a PHP class cannot
 * "implement" one. The hook manager only requires a public static method
 * named in db/hooks.php - no interface needed.
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace auth_devicelock\hook\output;

defined('MOODLE_INTERNAL') || die();

// Autoloading only loads THIS class - the shared enforcement function it
// calls lives in the plugin's lib.php, which Moodle does not load
// automatically for an auth plugin's hook classes.
require_once(dirname(__DIR__, 3) . '/lib.php');

class before_http_headers {

    public static function execute(\core\hook\output\before_http_headers $hook): void {
        auth_devicelock_appguard_enforce_page_view();
        auth_devicelock_adminnav_tweaks();
    }
}
