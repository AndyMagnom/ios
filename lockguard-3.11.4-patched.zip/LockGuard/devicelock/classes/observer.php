<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Event observer for Lock Guard plugin
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace auth_devicelock;

defined('MOODLE_INTERNAL') || die();

/**
 * Event observer class
 */
class observer {

    /**
     * Handle user loggedin event
     *
     * @param \core\event\user_loggedin $event
     * @return void
     */
    public static function user_loggedin(\core\event\user_loggedin $event) {
        global $DB, $SESSION;
        
        try {
            $userid = $event->userid;
            
            // Check if plugin is enabled
            if (!get_config('auth_devicelock', 'enabled')) {
                return;
            }
            
            // Get user
            $user = $DB->get_record('user', ['id' => $userid]);
            if (!$user) {
                return;
            }
            
            // Skip if user account is not confirmed yet (standard email registration)
            if (empty($user->confirmed)) {
                return;
            }

            // Never register devices during signup or email confirmation
            $req_uri = $_SERVER['REQUEST_URI'] ?? '';
            if (strpos($req_uri, 'confirm.php') !== false || strpos($req_uri, 'signup.php') !== false) {
                return;
            }

            // Skip if user is excluded or should not be restricted
            require_once(__DIR__ . '/../auth.php');
            if (!\auth_plugin_devicelock::should_restrict_user_static($user)) {
                return;
            }

            // ================================================
            // APP GUARD: catches logins via ANY auth method (not just
            // devicelock - e.g. a restricted user not migrated yet). A
            // devicelock-auth user is normally already stopped earlier, in
            // auth.php::user_login(), before a session is even created;
            // this is the safety net for everyone else.
            // ================================================
            require_once(__DIR__ . '/../lib.php');
            if (auth_devicelock_appguard_check_login($userid)) {
                return;
            }

            // Auto-migrate user to devicelock on first login after email confirmation
            // AND once they actually hold the student role (not just confirmed email -
            // enrolment/role assignment can happen after confirmation, and migrating
            // before that was causing issues for accounts still in that in-between state)
            if (!empty(get_config('auth_devicelock', 'automigrate')) && $user->auth !== 'devicelock'
                    && \auth_plugin_devicelock::user_has_student_role_static($userid)) {
                $authplugin = new \auth_plugin_devicelock();
                if ($authplugin->can_migrate_user($userid)) {
                    $authplugin->migrate_user_to_devicelock($userid, false);
                    $user->auth = 'devicelock';
                    global $USER;
                    if (!empty($USER) && $USER->id == $userid) {
                        $USER->auth = 'devicelock';
                    }
                }
            }
            
            // Generate fingerprint using our function
            require_once(__DIR__ . '/../lib.php');
            $fingerprint = auth_devicelock_get_current_fingerprint();
            
            // Check if device is registered using centralized finding logic (login event)
            $device = auth_devicelock_find_device_for_user($userid, true);
            
            if ($device && !empty($device->browser_limit_exceeded)) {
                require_logout();
                return;
            }
            
            if ($device) {
                // Device exists - update last login
                $device->last_login = time();
                $device->ip_address = getremoteaddr();
                $device->user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
                $DB->update_record('auth_devicelock_devices', $device);
                
                // Record browser used on this authorized device (login event)
                auth_devicelock_record_device_browser($device, $device->user_agent, true);
                
                // Track the stabilized session for this device
                if (class_exists('\\auth_devicelock\\session_manager')) {
                    \auth_devicelock\session_manager::track_current_session($userid, $device->device_fingerprint);
                }
            } else {
                // If user has 0 active devices, ensure this initial login establishes the active device
                $count = device_manager::get_active_device_count($userid);
                if ($count == 0) {
                    $deviceinfo = auth_devicelock_get_device_info();
                    $devid = device_manager::register_device($userid, $fingerprint, $deviceinfo);
                    if ($devid) {
                        $newdev = $DB->get_record('auth_devicelock_devices', ['id' => $devid]);
                        if ($newdev) {
                            auth_devicelock_record_device_browser($newdev, $_SERVER['HTTP_USER_AGENT'] ?? '', true);
                        }

                        if (class_exists('\\auth_devicelock\\session_manager')) {
                            \auth_devicelock\session_manager::track_current_session($userid, $fingerprint);
                        }
                    }
                } else {
                    // Log unexpected device login (should have been blocked by auth.php)
                    auth_devicelock_log_action($userid, $fingerprint, 'unexpected_device_login', [
                        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
                        'ip' => getremoteaddr()
                    ]);
                }
            }
            
        } catch (\Exception $e) {
            // Don't break login on errors
            debugging('Device login plugin error: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }
    }

    /**
     * Handle user created event - seed the persistent security score.
     *
     * v3.5.0: every account starts with a clean 100% security score. The
     * rows are also created lazily on first read, so a missed event can
     * never leave a user without a score.
     *
     * @param \core\event\user_created $event
     * @return void
     */
    public static function user_created(\core\event\user_created $event) {
        try {
            require_once(__DIR__ . '/../lib.php');
            auth_devicelock_score_ensure_row((int)$event->userid);
        } catch (\Exception $e) {
            // Never break account creation because of the score seed.
            debugging('Device lock plugin (score seed) error: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }
    }


    /**
     * v3.8.0: course viewed (also fires for the site front page, id 1).
     *
     * @param \core\event\course_viewed $event
     * @return void
     */
    public static function activity_course_viewed(\core\event\course_viewed $event) {
        try {
            require_once(__DIR__ . '/../lib.php');
            global $DB, $SITE;

            $courseid = (int)$event->courseid;
            if ($courseid == SITEID) {
                // The site front page (/index.php).
                $action = 'activity_page';
                $details = ['url' => '/'];
                if (!empty($SITE->fullname)) {
                    $details['course'] = trim((string)$SITE->fullname);
                }
            } else {
                $action = 'activity_course';
                $details = ['url' => '/course/view.php?id=' . $courseid];
                $coursename = $DB->get_field('course', 'fullname', ['id' => $courseid]);
                if ($coursename !== false && $coursename !== null) {
                    $details['course'] = trim((string)$coursename);
                }
            }

            $section = (int)($event->other['coursesectionnumber'] ?? 0);
            if ($section > 0) {
                $details['section'] = $section;
            }

            auth_devicelock_activity_log_event($event, $action, $details);
        } catch (\Exception $e) {
            debugging('Device lock plugin (course viewed) error: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }
    }

    /**
     * v3.8.0: activity or resource module viewed (page, assign, quiz...).
     *
     * The base event is abstract - the observer also catches every
     * module-specific subclass that fires it.
     *
     * @param \core\event\course_module_viewed $event
     * @return void
     */
    public static function activity_course_module_viewed(\core\event\course_module_viewed $event) {
        try {
            require_once(__DIR__ . '/../lib.php');
            global $DB;

            $details = [];

            // Activity name from the event's record snapshot; some
            // modules have no name column (label) and snapshots may be
            // missing, so fall back to the course_modules record.
            $modulename = '';
            try {
                $snapshot = $event->get_record_snapshot($event->objecttable, $event->objectid);
                if ($snapshot && isset($snapshot->name)) {
                    $modulename = trim((string)$snapshot->name);
                }
            } catch (\Exception $snapshote) {
                $modulename = '';
            }
            if ($modulename === '' && function_exists('get_coursemodule_from_id')) {
                $cm = get_coursemodule_from_id($event->objecttable, (int)$event->objectid);
                if ($cm && !empty($cm->name)) {
                    $modulename = trim((string)$cm->name);
                }
            }
            if ($modulename !== '') {
                $details['activity'] = $modulename;
            }

            $details['module'] = (string)$event->objecttable;

            $coursename = $DB->get_field('course', 'fullname', ['id' => (int)$event->courseid]);
            if ($coursename !== false && $coursename !== null) {
                $details['course'] = trim((string)$coursename);
            }

            $details['url'] = '/mod/' . (string)$event->objecttable . '/view.php?id=' . (int)$event->objectid;

            auth_devicelock_activity_log_event($event, 'activity_module', $details);
        } catch (\Exception $e) {
            debugging('Device lock plugin (module viewed) error: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }
    }

    /**
     * v3.8.0: user profile viewed.
     *
     * @param \core\event\user_profile_viewed $event
     * @return void
     */
    public static function activity_profile_viewed(\core\event\user_profile_viewed $event) {
        try {
            require_once(__DIR__ . '/../lib.php');
            global $DB;

            $profileid = (int)$event->objectid;
            $url = '/user/view.php?id=' . $profileid;
            if ((int)$event->courseid > 1) {
                $url .= '&course=' . (int)$event->courseid;
            }

            $details = ['url' => $url];

            $profileuser = $DB->get_record('user', ['id' => $profileid], 'firstname,lastname', IGNORE_MISSING);
            if ($profileuser) {
                $details['profile_user'] = fullname($profileuser);
            }

            auth_devicelock_activity_log_event($event, 'activity_profile', $details);
        } catch (\Exception $e) {
            debugging('Device lock plugin (profile viewed) error: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }
    }

    /**
     * v3.8.0: course participants page viewed.
     *
     * @param \core\event\user_list_viewed $event
     * @return void
     */
    public static function activity_participants_viewed(\core\event\user_list_viewed $event) {
        try {
            require_once(__DIR__ . '/../lib.php');
            global $DB;

            $courseid = (int)$event->courseid;
            if ($courseid < 1) {
                $context = $event->get_context();
                if ($context && (int)$context->contextlevel == CONTEXT_COURSE) {
                    $courseid = (int)$context->instanceid;
                }
            }

            $details = ['url' => '/user/index.php?id=' . $courseid];

            if ($courseid > 0) {
                $coursename = $DB->get_field('course', 'fullname', ['id' => $courseid]);
                if ($coursename !== false && $coursename !== null) {
                    $details['course'] = trim((string)$coursename);
                }
            }

            auth_devicelock_activity_log_event($event, 'activity_participants', $details);
        } catch (\Exception $e) {
            debugging('Device lock plugin (participants viewed) error: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }
    }

    /**
     * v3.8.0: course category (course catalog) viewed.
     *
     * @param \core\event\course_category_viewed $event
     * @return void
     */
    public static function activity_category_viewed(\core\event\course_category_viewed $event) {
        try {
            require_once(__DIR__ . '/../lib.php');

            $details = ['url' => '/course/index.php?categoryid=' . (int)$event->objectid];

            auth_devicelock_activity_log_event($event, 'activity_catalog', $details);
        } catch (\Exception $e) {
            debugging('Device lock plugin (category viewed) error: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }
    }

    /**
     * v3.8.0: grade report viewed.
     *
     * @param \core\event\grade_report_viewed $event
     * @return void
     */
    public static function activity_grades_viewed(\core\event\grade_report_viewed $event) {
        try {
            require_once(__DIR__ . '/../lib.php');
            global $DB;

            $courseid = (int)$event->courseid;
            $details = ['url' => '/grade/report/index.php?id=' . $courseid];

            $coursename = $DB->get_field('course', 'fullname', ['id' => $courseid]);
            if ($coursename !== false && $coursename !== null) {
                $details['course'] = trim((string)$coursename);
            }

            auth_devicelock_activity_log_event($event, 'activity_grades', $details);
        } catch (\Exception $e) {
            debugging('Device lock plugin (grades viewed) error: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }
    }

    /**
     * v3.8.0: user tour started (arrives via an AJAX web-service
     * request from the admin tool usertours).
     *
     * @param \tool_usertours\event\tour_started $event
     * @return void
     */
    public static function activity_tour_started(\tool_usertours\event\tour_started $event) {
        try {
            require_once(__DIR__ . '/../lib.php');
            global $DB;

            $details = [
                'phase' => 'Started',
                'url' => (string)($event->other['pageurl'] ?? ''),
            ];

            // The admin tool's tables may be gone if it was uninstalled.
            if ($DB->get_manager()->table_exists('tool_usertours_tours')) {
                $tourname = $DB->get_field('tool_usertours_tours', 'name', ['id' => (int)$event->objectid]);
                if ($tourname !== false && $tourname !== null) {
                    $details['tour_name'] = (string)$tourname;
                }
            }

            auth_devicelock_activity_log_event($event, 'activity_tour', $details);
        } catch (\Exception $e) {
            debugging('Device lock plugin (tour started) error: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }
    }

    /**
     * v3.8.0: user tour ended (arrives via an AJAX web-service request
     * from the admin tool usertours).
     *
     * @param \tool_usertours\event\tour_ended $event
     * @return void
     */
    public static function activity_tour_ended(\tool_usertours\event\tour_ended $event) {
        try {
            require_once(__DIR__ . '/../lib.php');
            global $DB;

            $details = [
                'phase' => 'Ended',
                'url' => (string)($event->other['pageurl'] ?? ''),
            ];

            // The admin tool's tables may be gone if it was uninstalled.
            if ($DB->get_manager()->table_exists('tool_usertours_tours')) {
                $tourname = $DB->get_field('tool_usertours_tours', 'name', ['id' => (int)$event->objectid]);
                if ($tourname !== false && $tourname !== null) {
                    $details['tour_name'] = (string)$tourname;
                }
            }

            auth_devicelock_activity_log_event($event, 'activity_tour', $details);
        } catch (\Exception $e) {
            debugging('Device lock plugin (tour ended) error: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }
    }

    /**
     * v3.10.0: user logged OUT - the missing counterpart of the login
     * tracking. Moodle fires \core\event\user_loggedout for manual
     * logouts, session expirations on the next request and admin-forced
     * logouts alike, so "when did this user leave" is now answered.
     *
     * @param \core\event\user_loggedout $event
     * @return void
     */
    public static function user_loggedout(\core\event\user_loggedout $event) {
        try {
            require_once(__DIR__ . '/../lib.php');
            global $DB;

            $userid = (int)$event->userid;
            if ($userid < 2) {
                $userid = (int)$event->objectid;
            }

            $details = [];
            $user = $DB->get_record('user', ['id' => $userid], 'username,firstname,lastname', IGNORE_MISSING);
            if ($user) {
                $details['username'] = $user->username;
                $details['fullname'] = fullname($user);
            }

            auth_devicelock_activity_log_event($event, 'user_logout', $details);
        } catch (\Exception $e) {
            debugging('Device lock plugin (user logged out) error: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }
    }

    /**
     * v3.10.0: Dashboard viewed (/my). Moodle logs the same event in its
     * standard Logs report; the plugin's log now mirrors it.
     *
     * @param \core\event\dashboard_viewed $event
     * @return void
     */
    public static function activity_dashboard_viewed(\core\event\dashboard_viewed $event) {
        try {
            require_once(__DIR__ . '/../lib.php');

            auth_devicelock_activity_log_event($event, 'activity_dashboard', ['url' => '/my/index.php']);
        } catch (\Exception $e) {
            debugging('Device lock plugin (dashboard viewed) error: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }
    }

    /**
     * v3.10.0: My courses page viewed (/my/courses.php).
     *
     * @param \core\event\mycourses_viewed $event
     * @return void
     */
    public static function activity_mycourses_viewed(\core\event\mycourses_viewed $event) {
        try {
            require_once(__DIR__ . '/../lib.php');

            auth_devicelock_activity_log_event($event, 'activity_mycourses', ['url' => '/my/courses.php']);
        } catch (\Exception $e) {
            debugging('Device lock plugin (my courses viewed) error: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }
    }

    /**
     * v3.10.0: course SECTION viewed (/course/section.php - the single
     * section page). Moodle's standard Logs show "Section viewed" for
     * these; the plugin now records the course, the section number and
     * the section title when one is set.
     *
     * @param \core\event\section_viewed $event
     * @return void
     */
    public static function activity_section_viewed(\core\event\section_viewed $event) {
        try {
            require_once(__DIR__ . '/../lib.php');
            global $DB;

            // URL comes from the event itself (course_get_url), filled in
            // automatically by the shared pipeline when omitted here.
            $details = [];

            $sectionid = (int)$event->objectid;
            if ($sectionid > 0) {
                $section = $DB->get_record('course_sections', ['id' => $sectionid], 'section,name', IGNORE_MISSING);
                if ($section) {
                    $details['section_number'] = (int)$section->section;
                    $sectionname = trim((string)$section->name);
                    if ($sectionname !== '') {
                        $details['section_name'] = $sectionname;
                    }
                }
            }

            $coursename = $DB->get_field('course', 'fullname', ['id' => (int)$event->courseid]);
            if ($coursename !== false && $coursename !== null) {
                $details['course'] = trim((string)$coursename);
            }

            auth_devicelock_activity_log_event($event, 'activity_section', $details);
        } catch (\Exception $e) {
            debugging('Device lock plugin (section viewed) error: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }
    }

    /**
     * v3.10.0: catch-all for every OTHER "...\event\something_viewed"
     * event from ANY component - calendar views, blog entries, messages,
     * notifications, search results, badges, glossary entries, book
     * chapters, wiki pages, lesson pages, question banks, competencies,
     * content bank, recent activity, course information pages ... all
     * the "pages with an event" the dedicated observers above do not
     * cover, so the admin's "track everything" requirement holds even
     * on pages the generic footer page-logger cannot reach.
     *
     * Registered in db/events.php with eventname '*' which Moodle maps
     * to \core\event\base - the parent of EVERY event - so this runs
     * for all of them and must stay CHEAP for the 95% it ignores.
     *
     * @param \core\event\base $event
     * @return void
     */
    public static function activity_wildcard_viewed(\core\event\base $event) {
        // Cheap rejection first: no requires, no DB, just the class name.
        $classname = get_class($event);
        $pos = strrpos($classname, '\\');
        $basename = ($pos === false) ? $classname : substr($classname, $pos + 1);
        if (substr($basename, -7) !== '_viewed') {
            return;
        }

        // Skip everything a dedicated observer already records (otherwise
        // those pages would appear twice per visit).
        if ($event instanceof \core\event\course_viewed
                || $event instanceof \core\event\course_module_viewed
                || $event instanceof \core\event\user_profile_viewed
                || $event instanceof \core\event\user_list_viewed
                || $event instanceof \core\event\course_category_viewed
                || $event instanceof \core\event\grade_report_viewed
                || $event instanceof \core\event\dashboard_viewed
                || $event instanceof \core\event\mycourses_viewed
                || $event instanceof \core\event\section_viewed) {
            return;
        }

        try {
            require_once(__DIR__ . '/../lib.php');

            $details = [];
            try {
                $eventname = $event->get_name();
                if (is_string($eventname) && trim($eventname) !== '') {
                    // e.g. "Discussion viewed", "Calendar viewed" - tells the
                    // admin WHICH kind of page the row refers to.
                    $details['view_name'] = trim($eventname);
                }
            } catch (\Exception $namee) {
                // No localised name - the URL alone still identifies the page.
            }

            auth_devicelock_activity_log_event($event, 'activity_page', $details);
        } catch (\Exception $e) {
            debugging('Device lock plugin (wildcard viewed) error: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }
    }
}