<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Scheduled task: weekly security-snapshot email digest to site administrators.
 *
 * Sends a plain-text + HTML email summarising the last 7 days of Lock Guard
 * activity: trend counts (blocked logins / device registrations / account
 * deletions / details-copied), the cached security-score distribution, and the
 * top-5 at-risk users (lowest cached scores). Delivered to every site admin
 * with a valid email address.
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace auth_devicelock\task;

defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/../../locallib.php');

/**
 * Weekly security-snapshot scheduled task.
 */
class weekly_snapshot_task extends \core\task\scheduled_task {

    /**
     * Get task name.
     *
     * @return string
     */
    public function get_name() {
        return get_string('task_weekly_snapshot', 'auth_devicelock');
    }

    /**
     * Execute the task.
     */
    public function execute() {
        global $CFG, $SITE;

        // Respect the per-site settings toggle (default: disabled).
        if (!get_config('auth_devicelock', 'snapshot_enabled')) {
            mtrace('auth_devicelock: weekly snapshot email is disabled — skipping.');
            return;
        }

        // ---- 1. Build the snapshot data (shared helper — single source of truth) ----
        $data = \auth_devicelock_build_snapshot_data(7);

        // ---- 2. Build the email bodies (shared render helpers) ----
        $sitename = format_string($SITE->fullname);
        $subject = get_string('snapshot_subject', 'auth_devicelock', $sitename);
        $textbody = \auth_devicelock_render_snapshot_text($data, $sitename);
        $htmlbody = \auth_devicelock_render_snapshot_html($data, $sitename, $CFG->wwwroot);

        // ---- 3. Resolve recipient admins + send ----
        $admins = get_admins();
        $sent = 0;
        $supportuser = \core_user::get_support_user();
        foreach ($admins as $admin) {
            if (empty($admin->email) || !validate_email($admin->email)) {
                continue;
            }
            // Use a clone so email_to_user doesn't mutate the global admin record.
            $recipient = clone $admin;
            $recipient->mailformat = 1; // HTML-capable.
            if (email_to_user($recipient, $supportuser, $subject, $textbody, $htmlbody)) {
                $sent++;
            }
        }

        // ---- 4. Record the last-sent timestamp (shown on the snapshot page) ----
        if ($sent > 0) {
            set_config('snapshot_last_sent', time(), 'auth_devicelock');
            mtrace(get_string('snapshot_sent', 'auth_devicelock', $sent));
        } else {
            mtrace(get_string('snapshot_no_admins', 'auth_devicelock'));
        }
    }
}
