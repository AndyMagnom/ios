<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Persistent security-score regain task (v3.5.0).
 *
 * Runs every minute: applies every due score regain and writes a
 * "Score Regained" log row for each user that regained points, so the
 * recovery is visible in the Security & Error Logs.
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace auth_devicelock\task;

defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/../../lib.php');

/**
 * The score_regain scheduled task.
 */
class score_regain_task extends \core\task\scheduled_task {

    /**
     * Task name shown in the scheduled-task admin page.
     *
     * @return string
     */
    public function get_name() {
        return get_string('task_score_regain', 'auth_devicelock');
    }

    /**
     * Apply every due score regain.
     *
     * @return bool Always true.
     */
    public function execute() {
        $count = auth_devicelock_score_process_regains_all();
        if ($count > 0) {
            mtrace('Lock Guard: security-score regain applied for ' . $count . ' user(s).');
        }
        return true;
    }
}
