<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * App Guard scheduled task: revoke web-service tokens of restricted users.
 *
 * The login observer and the auth.php sign-in check cannot delete a token
 * that /login/token.php creates AFTER a successful credential check (the
 * official Moodle mobile app's flow, and any other web-service client), so
 * this task sweeps every minute: while the restriction is enabled, a
 * restricted user keeps no valid web-service token for longer than the
 * cron interval.
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace auth_devicelock\task;

defined('MOODLE_INTERNAL') || die();

require_once(dirname(__DIR__, 2) . '/lib.php');

class revoke_appguard_tokens extends \core\task\scheduled_task {

    public function get_name(): string {
        return 'App Guard: revoke web-service tokens of restricted users';
    }

    public function get_minute(): string {
        return '*';
    }

    public function get_hour(): string {
        return '*';
    }

    public function execute(): bool {
        global $DB;

        if (!auth_devicelock_appguard_enabled()) {
            return true;
        }

        $userids = auth_devicelock_appguard_restricted_userids();
        foreach ($userids as $userid) {
            try {
                $DB->delete_records('external_tokens', ['userid' => $userid]);
            } catch (\Throwable $t) {
                mtrace('auth_devicelock appguard: could not revoke tokens of user ' . $userid . ': ' . $t->getMessage());
            }
        }

        return true;
    }
}
