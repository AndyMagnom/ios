<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Scheduled task: prune orphaned Lock Guard device + session-tracking rows
 * whose owning user no longer exists (or is marked deleted) in mdl_user.
 *
 * The per-user delete flow (action=deleteuser / bulkdeleteusers) already wipes
 * plugin data for the users it removes, but a user can also be deleted via
 * Moodle's own user-management UI or via a DB restore that drops the user
 * without running the plugin's hook. This task catches those stragglers so
 * the device/session-tracking tables don't accumulate orphaned rows forever.
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace auth_devicelock\task;

defined('MOODLE_INTERNAL') || die();

/**
 * Scheduled task class for pruning orphaned device/session-tracking rows.
 */
class prune_orphans_task extends \core\task\scheduled_task {

    /**
     * Get task name.
     *
     * @return string
     */
    public function get_name() {
        return get_string('task_prune_orphans', 'auth_devicelock');
    }

    /**
     * Execute the task.
     *
     * Deletes rows from auth_devicelock_devices and auth_devicelock_session_tracking
     * whose userid has no matching (non-deleted) row in mdl_user. Logs are NOT
     * pruned here — they are audit records and are handled by the existing
     * 3-week cleanup_logs_task.
     */
    public function execute() {
        global $DB;

        $pruned_devices  = 0;
        $pruned_sessions = 0;

        $mgr = $DB->get_manager();

        // Prune orphaned device rows.
        if ($mgr->table_exists('auth_devicelock_devices')) {
            // Build a list of plugin userids that have no live counterpart in
            // mdl_user (either the row is gone or deleted=1). We resolve via a
            // LEFT JOIN on a sub-query so this works on MySQL/MariaDB/Postgres.
            $sql = "SELECT d.id
                      FROM {auth_devicelock_devices} d
                 LEFT JOIN {user} u ON u.id = d.userid
                     WHERE u.id IS NULL OR u.deleted = 1";
            // get_fieldset_sql() returns strings; cast to int so get_in_or_equal
            // produces correctly-typed bound params (avoids Postgres type errors).
            $orphan_ids = array_map('intval', $DB->get_fieldset_sql($sql, []));
            $orphan_ids = array_filter($orphan_ids, function ($x) { return $x > 0; });
            if (!empty($orphan_ids)) {
                // Delete in chunks of 500 to stay within bound-param limits.
                foreach (array_chunk($orphan_ids, 500) as $chunk) {
                    list($insql, $inparams) = $DB->get_in_or_equal($chunk);
                    $DB->delete_records_select('auth_devicelock_devices', "id $insql", $inparams);
                    $pruned_devices += count($chunk);
                    mtrace("auth_devicelock prune: deleted " . count($chunk) . " orphaned device row(s).");
                }
            }
        }

        // Prune orphaned session-tracking rows.
        if ($mgr->table_exists('auth_devicelock_session_tracking')) {
            $sql = "SELECT s.id
                      FROM {auth_devicelock_session_tracking} s
                 LEFT JOIN {user} u ON u.id = s.userid
                     WHERE u.id IS NULL OR u.deleted = 1";
            $orphan_ids = array_map('intval', $DB->get_fieldset_sql($sql, []));
            $orphan_ids = array_filter($orphan_ids, function ($x) { return $x > 0; });
            if (!empty($orphan_ids)) {
                foreach (array_chunk($orphan_ids, 500) as $chunk) {
                    list($insql, $inparams) = $DB->get_in_or_equal($chunk);
                    $DB->delete_records_select('auth_devicelock_session_tracking', "id $insql", $inparams);
                    $pruned_sessions += count($chunk);
                    mtrace("auth_devicelock prune: deleted " . count($chunk) . " orphaned session-tracking row(s).");
                }
            }
        }

        if ($pruned_devices > 0 || $pruned_sessions > 0) {
            mtrace(get_string('task_prune_orphans_done', 'auth_devicelock',
                ['devices' => $pruned_devices, 'sessions' => $pruned_sessions]));
        } else {
            mtrace('auth_devicelock: prune_orphans_task — no orphaned rows found.');
        }

        // Opportunistic cleanup of stale security-score cache preferences.
        // The cache (auth_devicelock_secscore_cache) stores a JSON blob with a
        // 'ts' field; entries older than 24h are unlikely to be re-read before
        // their 1h TTL would re-trigger a recompute anyway, so drop them to
        // prevent user_preferences bloat. The value field is TEXT so we filter
        // by name + do a PHP-side age check to avoid DB-side JSON ops.
        $pruned_scores = 0;
        $prefname = 'auth_devicelock_secscore_cache';
        $cutoff = time() - (24 * 3600);
        $stale = $DB->get_records_select('user_preferences', "name = ?", [$prefname], '', 'id, userid, value');
        foreach ($stale as $sp) {
            $decoded = @json_decode($sp->value, true);
            if (is_array($decoded) && isset($decoded['ts']) && (int)$decoded['ts'] < $cutoff) {
                $DB->delete_records('user_preferences', ['id' => $sp->id]);
                $pruned_scores++;
            }
        }
        if ($pruned_scores > 0) {
            mtrace("auth_devicelock prune: removed {$pruned_scores} stale security-score cache preference(s).");
        }
    }
}
