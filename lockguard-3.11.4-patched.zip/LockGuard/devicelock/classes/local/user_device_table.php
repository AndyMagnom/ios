<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * User device table class
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace auth_devicelock\local;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/tablelib.php');

/**
 * User device table class
 */
class user_device_table extends \table_sql {

    /**
     * Constructor
     *
     * @param string $uniqueid Unique identifier for the table
     * @param int $userid User ID to show devices for
     */
    public function __construct($uniqueid, $userid = 0) {
        parent::__construct($uniqueid);
        
        $this->userid = $userid;
        
        // Define columns
        $columns = ['device_fingerprint', 'device_info', 'status', 'last_login', 'created_at', 'ip_address', 'user_agent', 'actions'];
        $headers = [
            get_string('devicefingerprint', 'auth_devicelock'),
            get_string('deviceinfo', 'auth_devicelock'),
            get_string('status', 'auth_devicelock'),
            get_string('lastlogin', 'auth_devicelock'),
            get_string('registeredon', 'auth_devicelock'),
            get_string('ipaddress', 'auth_devicelock'),
            get_string('useragent', 'auth_devicelock'),
            get_string('actions', 'auth_devicelock')
        ];
        
        $this->define_columns($columns);
        $this->define_headers($headers);
        
        // Setup table properties
        $this->sortable(false);
        $this->collapsible(false);
        $this->pageable(true);
        $this->is_downloadable(false);
        
        // Set SQL
        $this->set_sql(
            '*',
            '{auth_devicelock_devices}',
            'userid = ?',
            [$userid]
        );
        
        $this->set_count_sql(
            'SELECT COUNT(*) FROM {auth_devicelock_devices} WHERE userid = ?',
            [$userid]
        );
    }
    
    /**
     * Format device fingerprint column
     *
     * @param stdClass $row Table row
     * @return string Formatted fingerprint
     */
    protected function col_device_fingerprint($row) {
        return \auth_devicelock_mask_fingerprint($row->device_fingerprint);
    }
    
    /**
     * Format device info column
     *
     * @param stdClass $row Table row
     * @return string Formatted device info
     */
    protected function col_device_info($row) {
        return \auth_devicelock_format_device_info($row);
    }
    
    /**
     * Format status column
     *
     * @param stdClass $row Table row
     * @return string Formatted status
     */
    protected function col_status($row) {
        return \auth_devicelock_get_status_badge($row->status);
    }
    
    /**
     * Format last login column
     *
     * @param stdClass $row Table row
     * @return string Formatted date
     */
    protected function col_last_login($row) {
        return $row->last_login ? userdate($row->last_login) : '-';
    }
    
    /**
     * Format created at column
     *
     * @param stdClass $row Table row
     * @return string Formatted date
     */
    protected function col_created_at($row) {
        return userdate($row->created_at);
    }
    
    /**
     * Format IP address column
     *
     * @param stdClass $row Table row
     * @return string IP address
     */
    protected function col_ip_address($row) {
        return $row->ip_address;
    }
    
    /**
     * Format user agent column
     *
     * @param stdClass $row Table row
     * @return string User agent
     */
    protected function col_user_agent($row) {
        return shorten_text($row->user_agent, 50);
    }
    
    /**
     * Format actions column
     *
     * @param stdClass $row Table row
     * @return string Action buttons
     */
    protected function col_actions($row) {
        global $OUTPUT, $PAGE;
        
        $url = $PAGE->url;
        $url->param('deviceid', $row->id);
        $url->param('userid', $this->userid);
        
        if ($row->status == 'active') {
            $url->param('action', 'blockdevice');
            $icon = 't/block';
            $text = get_string('blockdevice', 'auth_devicelock');
            $class = 'text-danger';
        } else {
            $url->param('action', 'unblockdevice');
            $icon = 't/unblock';
            $text = get_string('unblockdevice', 'auth_devicelock');
            $class = 'text-success';
        }
        
        $url->param('sesskey', sesskey());
        
        return $OUTPUT->action_link($url, $text, null, ['class' => $class]);
    }
}