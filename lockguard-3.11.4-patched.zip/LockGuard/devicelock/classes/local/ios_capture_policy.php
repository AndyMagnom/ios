<?php
namespace auth_devicelock\local;
defined('MOODLE_INTERNAL') || die();
require_once(__DIR__ . '/macos_testing.php');

/** Exact, operator-reviewed OS versions. Missing policy always denies content. */
final class ios_capture_policy {
    public static function current(string $platform = 'ios'): array {
        global $CFG;
        if ($platform === 'macos') {
            $enabled = function_exists('get_config') ? get_config('auth_devicelock', 'macos_enabled') : false;
            $minimum = function_exists('get_config') ? get_config('auth_devicelock', 'macos_minimum_build') : false;
            // Saved UI settings take precedence over historical config.php values.
            if ($enabled === false) { $enabled = ($CFG->auth_devicelock_macos_capture['enabled'] ?? false) === true ? '1' : '0'; }
            if ($minimum === false) { $minimum = $CFG->auth_devicelock_macos_capture['minimum_build'] ?? 2; }
            if (macos_testing::disabled('minimum_build')) { $minimum = 1; }
            $validminimum = (is_int($minimum) || is_string($minimum)) && preg_match('/^[1-9][0-9]*$/D', (string)$minimum);
            return ['enabled' => (string)$enabled === '1' && $validminimum,
                'reviewedOSVersions' => [], 'requiresReviewedOS' => false,
                'minimumBuild' => $validminimum ? (int)$minimum : 1];
        }
        $policy = ($platform === 'macos' ? ($CFG->auth_devicelock_macos_capture ?? []) :
            ($platform === 'ios' ? ($CFG->auth_devicelock_ios_capture ?? []) : []));
        $versions = $policy['reviewed_os_versions'] ?? [];
        $minimum = $policy['minimum_build'] ?? null;
        if (!is_array($versions) || !is_int($minimum) || $minimum < 1) {
            return ['enabled' => false, 'reviewedOSVersions' => [], 'minimumBuild' => 1];
        }
        foreach ($versions as $version) {
            if (!is_string($version) || !preg_match('/^[0-9]{1,2}\.[0-9]{1,2}\.[0-9]{1,3}$/D', $version)) {
                return ['enabled' => false, 'reviewedOSVersions' => [], 'minimumBuild' => 1];
            }
        }
        return ['enabled' => ($policy['enabled'] ?? false) === true,
            'reviewedOSVersions' => array_values(array_unique($versions)), 'minimumBuild' => $minimum];
    }
    public static function allows($version, $build, string $platform = 'ios'): bool {
        $policy = self::current($platform);
        return $policy['enabled'] && is_string($version) && is_int($build) &&
            $build >= $policy['minimumBuild'] &&
            preg_match('/^[0-9]{1,2}\.[0-9]{1,2}\.[0-9]{1,3}$/D', $version) &&
            (($policy['requiresReviewedOS'] ?? true) === false || in_array($version, $policy['reviewedOSVersions'], true));
    }
    public static function require_allowed($version, $build, string $platform = 'ios'): void {
        if (!self::allows($version, $build, $platform)) { throw new \RuntimeException('Capture policy denies this OS/app build'); }
    }
}
