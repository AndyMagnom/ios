<?php
namespace auth_devicelock\local;

/** Strict, bounded decoding of the CBOR subset used by Apple App Attest. */
final class apple_cbor {
    private string $data;
    private int $offset = 0;
    private int $items = 0;
    public static function decode(string $data): mixed {
        $consumed = 0;
        $value = self::decode_prefix($data, $consumed);
        if ($consumed !== strlen($data)) { throw new \RuntimeException('Trailing CBOR bytes'); }
        return $value;
    }
    public static function decode_prefix(string $data, int &$consumed): mixed {
        if (strlen($data) > 32768) { throw new \RuntimeException('CBOR too large'); }
        $decoder = new self(); $decoder->data = $data;
        $value = $decoder->item(0); $consumed = $decoder->offset;
        return $value;
    }
    private function take(int $length): string {
        if ($length < 0 || $length > strlen($this->data) - $this->offset) {
            throw new \RuntimeException('Truncated CBOR');
        }
        $value = substr($this->data, $this->offset, $length);
        $this->offset += $length;
        return $value;
    }
    private function item(int $depth): mixed {
        if ($depth > 10 || ++$this->items > 512) {
            throw new \RuntimeException('CBOR limits exceeded');
        }
        $byte = ord($this->take(1));
        $major = $byte >> 5;
        $length = $byte & 31;
        if ($length >= 24) {
            $length = match ($length) {
                24 => ord($this->take(1)),
                25 => unpack('n', $this->take(2))[1],
                26 => unpack('N', $this->take(4))[1],
                default => throw new \RuntimeException('Unsupported CBOR length'),
            };
        }
        if ($major === 0) { return $length; }
        if ($major === 1) { return -1 - $length; }
        if ($major === 2 || $major === 3) { return $this->take($length); }
        if ($length > 128) { throw new \RuntimeException('CBOR collection too large'); }
        if ($major === 4) {
            $result = [];
            for ($i = 0; $i < $length; $i++) { $result[] = $this->item($depth + 1); }
            return $result;
        }
        if ($major === 5) {
            $result = [];
            for ($i = 0; $i < $length; $i++) {
                $key = $this->item($depth + 1);
                if ((!is_int($key) && !is_string($key)) || array_key_exists($key, $result)) {
                    throw new \RuntimeException('Invalid or duplicate CBOR map key');
                }
                $result[$key] = $this->item($depth + 1);
            }
            return $result;
        }
        throw new \RuntimeException('Unsupported CBOR type');
    }
}

