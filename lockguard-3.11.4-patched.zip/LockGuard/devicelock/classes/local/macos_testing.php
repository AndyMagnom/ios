<?php
namespace auth_devicelock\local;
defined('MOODLE_INTERNAL') || die();

/** Server-owned, one-hour staging overrides. Never enabled by client claims. */
final class macos_testing {
    public const PROTECTIONS = ['minimum_build', 'device_signature', 'device_rules',
        'challenge_rate', 'challenge_expiry', 'session_expiry', 'capture_revocation'];
    public static function active(): bool {
        if (!function_exists('get_config') || (string)get_config('auth_devicelock', 'macos_testing') !== '1') { return false; }
        $started = get_config('auth_devicelock', 'macos_testing_started');
        if (!is_scalar($started) || !preg_match('/^[1-9][0-9]*$/D', (string)$started)) { return false; }
        $age = time() - (int)$started;
        return $age >= 0 && $age < 3600;
    }
    public static function disabled(string $protection): bool {
        return in_array($protection, self::PROTECTIONS, true) && self::active() &&
            (string)get_config('auth_devicelock', 'macos_test_' . $protection) === '0';
    }
    /** Changing any override or ending the test window invalidates test bearers/challenges. */
    public static function stamp(): string {
        if (!self::active()) { return ''; }
        $values = [(string)get_config('auth_devicelock', 'macos_testing_started')];
        foreach (self::PROTECTIONS as $protection) { $values[] = self::disabled($protection); }
        return hash('sha256', json_encode($values, JSON_THROW_ON_ERROR));
    }
}
