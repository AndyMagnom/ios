<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Public password reset page for Lock Guard plugin.
 *
 * @package    auth_devicelock
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/moodlelib.php');

global $DB, $PAGE, $OUTPUT, $CFG;

// Page setup
$PAGE->set_context(context_system::instance());
$PAGE->set_url(new moodle_url('/auth/devicelock/reset_password.php'));
$PAGE->set_pagelayout('login');
$PAGE->set_title(get_string('pluginname', 'auth_devicelock') . ' - Reset Password');
$PAGE->set_heading(get_string('pluginname', 'auth_devicelock') . ' - Reset Password');

$token  = optional_param('token', '', PARAM_ALPHANUM);
$userid = optional_param('userid', 0, PARAM_INT);

$user = null;
$error = '';
$success = false;

if ($userid) {
    $user = $DB->get_record('user', ['id' => $userid, 'deleted' => 0]);
}

if (!$user) {
    $error = 'Invalid user ID or user does not exist.';
} else {
    // Validate token and expiry
    $saved_token = get_user_preferences('auth_devicelock_pwdreset_token', '', $userid);
    $expiry      = get_user_preferences('auth_devicelock_pwdreset_expiry', 0, $userid);
    
    if (empty($token) || empty($saved_token) || !hash_equals((string)$saved_token, (string)$token)) {
        $error = 'The password reset link is invalid or has already been used.';
    } else if (time() > $expiry) {
        $error = 'This password reset link has expired (valid for 24 hours).';
    }
}

require_once(__DIR__ . '/lib.php');

// Ensure devicelock plugin is enabled in Moodle
auth_devicelock_ensure_enabled();

$validation_errors = [];

// Handle POST request
if (empty($error) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = optional_param('password', '', PARAM_RAW);
    $confirmpassword = optional_param('confirmpassword', '', PARAM_RAW);
    
    if (empty($password)) {
        $validation_errors[] = 'Password cannot be empty.';
    } else if ($password !== $confirmpassword) {
        $validation_errors[] = 'Passwords do not match.';
    } else {
        // Enforce Moodle password policy
        $errmsg = '';
        if (!check_password_policy($password, $errmsg, $user)) {
            $validation_errors[] = $errmsg;
        }
    }
    
    if (empty($validation_errors)) {
        // Update password via user's auth plugin if available, or direct internal update
        $authplugin = get_auth_plugin($user->auth);
        $updated = false;
        if ($authplugin && method_exists($authplugin, 'user_update_password')) {
            $updated = $authplugin->user_update_password($user, $password);
        }
        if (!$updated) {
            update_internal_user_password($user, $password);
        }
        // NOTE: no second update_internal_user_password() here. devicelock's
        // user_update_password already hashes and writes the password (plus an
        // audit row); calling it twice doubled the cost and logged two
        // identical "Password Changed" rows per reset.
        
        // Clear any force-password-change requirements and failed login counters
        unset_user_preference('auth_forcepasswordchange', $user->id);
        unset_user_preference('create_password', $user->id);
        unset_user_preference('login_failed_count_since_success', $user->id);
        
        // Invalidate token
        unset_user_preference('auth_devicelock_pwdreset_token', $userid);
        unset_user_preference('auth_devicelock_pwdreset_expiry', $userid);
        
        // Log the successful password reset
        if (method_exists('device_manager', 'log_action')) {
            device_manager::log_action($user->id, 'system', 'password_reset_completed', [
                'timestamp' => time(),
                'ip' => getremoteaddr()
            ]);
        }
        
        $success = true;
    }
}

// Load device fingerprinting on the reset page so browser token is ready for login
require_once(__DIR__ . '/classes/local/ios_identity.php');
if (!\auth_devicelock\local\ios_identity::is_request()) {
    $PAGE->requires->js_call_amd('auth_devicelock/fingerprint', 'init');
}

echo $OUTPUT->header();

$sitename = format_string($SITE->fullname);
$sitelogo = $OUTPUT->get_logo_url();

echo '<style>
    .moodle-reset-wrapper {
        min-height: 70vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 40px 15px;
    }
    .moodle-reset-card {
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.01);
        width: 100%;
        max-width: 480px;
        overflow: hidden;
    }
    .moodle-reset-header {
        background: #f8fafc;
        border-bottom: 1px solid #e2e8f0;
        padding: 28px 24px 20px;
        text-align: center;
    }
    .moodle-reset-logo {
        max-height: 50px;
        max-width: 220px;
        margin-bottom: 15px;
    }
    .moodle-reset-header h3 {
        color: #1e293b;
        font-weight: 700;
        font-size: 1.35rem;
        margin: 0;
    }
    .moodle-reset-body {
        padding: 30px 28px 32px;
    }
    .moodle-reset-body .form-control {
        border-color: #cbd5e1;
        border-radius: 6px;
        padding: 10px 14px;
        font-size: 0.95rem;
    }
    .moodle-reset-body .form-control:focus {
        border-color: #0f6cbf;
        box-shadow: 0 0 0 0.2rem rgba(15, 108, 191, 0.2);
    }
    .moodle-reset-body .input-group .btn-outline-secondary {
        border-color: #cbd5e1;
        color: #64748b;
        background: #f8fafc;
        border-top-right-radius: 6px;
        border-bottom-right-radius: 6px;
    }
    .moodle-reset-body .input-group .btn-outline-secondary:hover {
        background: #e2e8f0;
        color: #1e293b;
    }
    .moodle-reset-body .btn-primary {
        background-color: #0f6cbf;
        border-color: #0f6cbf;
        border-radius: 6px;
        padding: 11px 20px;
        font-weight: 600;
        font-size: 1rem;
        letter-spacing: 0.2px;
        transition: background-color 0.15s ease-in-out;
    }
    .moodle-reset-body .btn-primary:hover {
        background-color: #0c5699;
        border-color: #0b4f8d;
    }
    .policy-box {
        background: #f1f5f9;
        border-left: 3px solid #0f6cbf;
        padding: 10px 14px;
        font-size: 0.85rem;
        color: #475569;
        border-radius: 4px;
        margin-bottom: 20px;
    }
</style>';

echo '<div class="moodle-reset-wrapper">';
echo '  <div class="moodle-reset-card">';
echo '    <div class="moodle-reset-header">';

if ($sitelogo) {
    echo '      <img src="' . $sitelogo . '" alt="' . s($sitename) . '" class="moodle-reset-logo d-block mx-auto">';
}
echo '      <h3><i class="fa fa-lock text-primary mr-2"></i>' . get_string('password') . ' ' . get_string('reset') . '</h3>';
echo '      <p class="text-muted small mt-1 mb-0">' . s($sitename) . '</p>';
echo '    </div>';
echo '    <div class="moodle-reset-body">';

if (!empty($error)) {
    echo '    <div class="alert alert-danger d-flex align-items-center mb-4" role="alert">';
    echo '      <i class="fa fa-exclamation-circle fa-2x mr-3 text-danger"></i>';
    echo '      <div>' . s($error) . '</div>';
    echo '    </div>';
    echo '    <div class="text-center mt-3">';
    echo '      <a href="' . $CFG->wwwroot . '/login/index.php" class="btn btn-secondary btn-block py-2">' . get_string('cancel') . '</a>';
    echo '    </div>';
} else if ($success) {
    echo '    <div class="text-center py-3">';
    echo '      <i class="fa fa-check-circle text-success" style="font-size: 3.5rem;"></i>';
    echo '      <h4 class="mt-3 font-weight-bold text-dark">' . get_string('changepassword') . ' ' . get_string('success') . '</h4>';
    echo '      <p class="text-muted mt-2">Your password has been changed successfully. You can now use your new credentials to log in.</p>';
    echo '      <a href="' . $CFG->wwwroot . '/login/index.php" class="btn btn-primary btn-block mt-4 py-2 font-weight-bold">' . get_string('login') . '</a>';
    echo '    </div>';
} else {
    if (!empty($validation_errors)) {
        echo '    <div class="alert alert-danger mb-4">';
        echo '      <strong><i class="fa fa-exclamation-triangle mr-1"></i> ' . get_string('error') . ':</strong>';
        echo '      <ul class="mb-0 mt-2 pl-3">';
        foreach ($validation_errors as $err) {
            echo '        <li>' . s($err) . '</li>';
        }
        echo '      </ul>';
        echo '    </div>';
    }
    
    echo '    <p class="text-muted mb-4 small">Set a new password for account <strong>' . s($user->username) . '</strong> (' . s($user->email) . ').</p>';
    
    $policy = print_password_policy();
    if (!empty($policy)) {
        echo '    <div class="policy-box mb-3">' . $policy . '</div>';
    }
    
    $formurl = new moodle_url('/auth/devicelock/reset_password.php', ['token' => $token, 'userid' => $userid]);
    echo '    <form method="post" action="' . $formurl . '" id="password_reset_form">';
    
    // New Password Input with Unhide Icon
    echo '      <div class="form-group mb-3">';
    echo '        <label for="password" class="font-weight-bold text-dark small text-uppercase mb-1">New Password</label>';
    echo '        <div class="input-group">';
    echo '          <input type="password" name="password" id="password" class="form-control" required autocomplete="new-password" placeholder="Enter new password">';
    echo '          <div class="input-group-append">';
    echo '            <button type="button" class="btn btn-outline-secondary toggle-password-visibility" data-target="password" title="Show/Hide password" tabindex="-1">';
    echo '              <i class="fa fa-eye"></i>';
    echo '            </button>';
    echo '          </div>';
    echo '        </div>';
    echo '      </div>';
    
    // Confirm Password Input with Unhide Icon
    echo '      <div class="form-group mb-4">';
    echo '        <label for="confirmpassword" class="font-weight-bold text-dark small text-uppercase mb-1">Confirm New Password</label>';
    echo '        <div class="input-group">';
    echo '          <input type="password" name="confirmpassword" id="confirmpassword" class="form-control" required autocomplete="new-password" placeholder="Re-enter new password">';
    echo '          <div class="input-group-append">';
    echo '            <button type="button" class="btn btn-outline-secondary toggle-password-visibility" data-target="confirmpassword" title="Show/Hide password" tabindex="-1">';
    echo '              <i class="fa fa-eye"></i>';
    echo '            </button>';
    echo '          </div>';
    echo '        </div>';
    echo '      </div>';
    
    echo '      <button type="submit" class="btn btn-primary btn-block mb-3 py-2 font-weight-bold"><i class="fa fa-save mr-1"></i> Save New Password</button>';
    echo '      <a href="' . $CFG->wwwroot . '/login/index.php" class="btn btn-link btn-block text-muted small">' . get_string('cancel') . '</a>';
    echo '    </form>';
}

echo '    </div>';
echo '  </div>';
echo '</div>';

// Inline script for password visibility toggle
echo '
<script>
document.addEventListener("DOMContentLoaded", function() {
    var toggleButtons = document.querySelectorAll(".toggle-password-visibility");
    toggleButtons.forEach(function(btn) {
        btn.addEventListener("click", function(e) {
            e.preventDefault();
            var targetId = this.getAttribute("data-target");
            var input = document.getElementById(targetId);
            var icon = this.querySelector("i");
            if (!input) return;
            
            if (input.type === "password") {
                input.type = "text";
                icon.classList.remove("fa-eye");
                icon.classList.add("fa-eye-slash");
                this.classList.add("text-primary");
            } else {
                input.type = "password";
                icon.classList.remove("fa-eye-slash");
                icon.classList.add("fa-eye");
                this.classList.remove("text-primary");
            }
        });
    });
});
</script>';

echo $OUTPUT->footer();
