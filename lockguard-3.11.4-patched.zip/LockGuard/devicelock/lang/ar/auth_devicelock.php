<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Arabic strings for Lock Guard plugin
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['pluginname'] = 'تسجيل الدخول بجهاز واحد';
$string['auth_devicelockdescription'] = 'تقييد كل حساب مستخدم بجهاز واحد باستخدام نظام بصمة مضاد للغش';
$string['managedevices'] = 'إدارة تسجيل الدخول بجهاز واحد';
$string['deviceaccess'] = 'التحكم في وصول الجهاز';
// Add to lang/en/auth_devicelock.php and lang/ar/auth_devicelock.php
$string['firstdeviceregistered'] = 'First device registered successfully.';
$string['newdeviceregistered'] = 'New device registered successfully.';

$string['howitworks'] = 'How Lock Guard Works';
$string['howitworks_desc'] = 'This plugin restricts users to login from specific registered devices only.';
$string['feature1'] = 'First device to login gets registered automatically';
$string['feature2'] = 'Each user can have up to {$a} registered devices (configurable)';
$string['feature3'] = 'Login attempts from unregistered devices are blocked';
$string['devicenotregistered'] = 'New device detected. This device will be registered for future logins.';
$string['devicelimitreached'] = 'You have reached the maximum of {$a} devices. Please use one of your registered devices or contact support.';
$string['deviceregistered_subject'] = 'New Device Registered';
$string['deviceregistered_message'] = 'A new device has been registered for your account.';
$string['multipledeviceswarning'] = 'You are logged in from multiple devices. For security, please use only trusted devices.';
$string['pluginstatus'] = 'Plugin Status';
$string['totaldevices'] = 'Total Devices';
$string['devices_remaining'] = 'Devices Remaining';
$string['noregistered'] = 'No Registered Devices';
$string['backtolist'] = 'Back to List';
$string['useractions'] = 'User Actions';
$string['userid'] = 'User ID';
$string['settings'] = 'Settings';
$string['refresh'] = 'Refresh';
$string['confirmation'] = 'Confirmation';
$string['unknown'] = 'Unknown';


// Settings
$string['enabled'] = 'تمكين تسجيل الدخول بجهاز واحد';
$string['enabled_desc'] = 'تمكين قيود تسجيل الدخول القائمة على الجهاز للمستخدمين';
$string['maxdevices'] = 'الحد الأقصى للأجهزة لكل مستخدم';
$string['maxdevices_desc'] = 'الحد الأقصى لعدد الأجهزة المسموح بها لكل مستخدم (الافتراضي: 1)';
$string['excludeguests'] = 'استبعاد المستخدمين الضيوف';
$string['excludeguests_desc'] = 'عدم تطبيق قيود الجهاز على المستخدمين الضيوف';
$string['allowedroles'] = 'الأدوار المراد تقييدها';
$string['allowedroles_desc'] = 'حدد الأدوار التي يجب تقييدها بتسجيل الدخول بجهاز واحد';

// Admin dashboard
$string['userslist'] = 'قائمة المستخدمين';
$string['email'] = 'البريد الإلكتروني';
$string['fullname'] = 'الاسم الكامل';
$string['devicescount'] = 'الأجهزة';
$string['lastlogin'] = 'آخر تسجيل دخول';
$string['status'] = 'الحالة';
$string['actions'] = 'الإجراءات';
$string['viewdevices'] = 'عرض الأجهزة';
$string['blockdevice'] = 'حظر الجهاز';
$string['blockuser'] = 'حظر المستخدم';
$string['resetdevices'] = 'إعادة تعيين الأجهزة';
$string['unblockdevice'] = 'إلغاء حظر الجهاز';
$string['unblockuser'] = 'إلغاء حظر المستخدم';
$string['exportcsv'] = 'تصدير CSV';
$string['searchbyemail'] = 'البحث بالبريد الإلكتروني...';
$string['search'] = 'بحث';
// New strings for admin interface
$string['searchfilter'] = 'Search & Filter';
$string['clear'] = 'Clear';
$string['username'] = 'Username';
$string['active_devices'] = 'Active Devices';
$string['total_devices'] = 'Total Devices';
$string['max_allowed'] = 'Max Allowed';
$string['totalusers'] = 'Total Users';
$string['activestatus'] = 'Plugin Status';
$string['plugindisabled'] = 'Plugin is currently disabled. Enable it in settings.';
$string['disabled'] = 'Disabled';
$string['reason'] = 'Reason';
$string['time'] = 'Time';
$string['contactsupport'] = 'Please contact support for assistance.';
$string['error'] = 'An error occurred';

// Device management
$string['devicedetails'] = 'تفاصيل الجهاز';
$string['devicefingerprint'] = 'بصمة الجهاز';
$string['deviceinfo'] = 'معلومات الجهاز';
$string['ipaddress'] = 'عنوان IP';
$string['useragent'] = 'وكيل المستخدم';
$string['screenresolution'] = 'دقة الشاشة';
$string['registeredon'] = 'مسجل في';
$string['active'] = 'نشط';
$string['blocked'] = 'محظور';
$string['pending'] = 'قيد الانتظار';
$string['backtodashboard'] = 'العودة للوحة التحكم';

// Messages
$string['deviceblocked'] = 'تم حظر الجهاز بنجاح';
$string['deviceunblocked'] = 'تم إلغاء حظر الجهاز بنجاح';
$string['userblocked'] = 'تم حظر المستخدم من جميع الأجهزة';
$string['userunblocked'] = 'تم إلغاء حظر المستخدم من جميع الأجهزة';
$string['devicesreset'] = 'تم إعادة تعيين جميع الأجهزة لهذا المستخدم';
$string['confirmblockdevice'] = 'هل أنت متأكد أنك تريد حظر هذا الجهاز؟ سيتم تسجيل خروج المستخدم فوراً.';
$string['confirmblockuser'] = 'هل أنت متأكد أنك تريد حظر هذا المستخدم من جميع الأجهزة؟';
$string['confirmresetdevices'] = 'هل أنت متأكد أنك تريد إعادة تعيين جميع الأجهزة لهذا المستخدم؟ سيسمح هذا لهم بتسجيل جهاز جديد.';
$string['noaccess'] = 'ليس لديك صلاحية للوصول إلى هذه الصفحة';
$string['nousersfound'] = 'لم يتم العثور على مستخدمين';
$string['nodevicesfound'] = 'لم يتم العثور على أجهزة لهذا المستخدم';

// Login messages
$string['devicenotallowed'] = 'هذا الحساب مرتبط بالفعل بجهاز آخر. يرجى تسجيل الدخول من جهازك المسجل. في حال وجود أي مشكلة يرجى التواصل مع الدعم عبر تيليجرام: https://t.me/Medprep_Support';
$string['deviceblockedmessage'] = 'تم حظر هذا الجهاز من قبل المسؤول. في حال وجود أي مشكلة يرجى التواصل مع الدعم عبر تيليجرام: https://t.me/Medprep_Support';
$string['usernotfound'] = 'المستخدم غير موجود';

// Privacy
$string['privacy:metadata:auth_devicelock_devices'] = 'معلومات حول أجهزة المستخدم لتسجيل الدخول بجهاز واحد';
$string['privacy:metadata:auth_devicelock_devices:userid'] = 'معرف المستخدم';
$string['privacy:metadata:auth_devicelock_devices:device_fingerprint'] = 'بصمة الجهاز المشفرة';
$string['privacy:metadata:auth_devicelock_devices:device_info'] = 'معلومات الجهاز (مجهولة المصدر)';
$string['privacy:metadata:auth_devicelock_devices:status'] = 'حالة الجهاز (نشط/محظور)';
$string['privacy:metadata:auth_devicelock_devices:last_login'] = 'طابع زمني لآخر تسجيل دخول';
$string['privacy:metadata:auth_devicelock_devices:user_agent'] = 'سلسلة وكيل المستخدم';
$string['privacy:metadata:auth_devicelock_devices:screen_resolution'] = 'دقة الشاشة';
$string['privacy:metadata:auth_devicelock_devices:ip_address'] = 'عنوان IP';

$string['privacy:metadata:auth_devicelock_logs'] = 'سجلات محاولات تسجيل الدخول بالجهاز';
$string['privacy:metadata:auth_devicelock_logs:userid'] = 'معرف المستخدم';
$string['privacy:metadata:auth_devicelock_logs:device_fingerprint'] = 'بصمة الجهاز المشفرة';
$string['privacy:metadata:auth_devicelock_logs:action'] = 'الإجراء الذي تم تنفيذه';
$string['privacy:metadata:auth_devicelock_logs:ip_address'] = 'عنوان IP';
$string['privacy:metadata:auth_devicelock_logs:user_agent'] = 'سلسلة وكيل المستخدم';
$string['privacy:metadata:auth_devicelock_logs:timestamp'] = 'الطابع الزمني للإجراء';
$string['privacy:metadata:auth_devicelock_logs:details'] = 'تفاصيل إضافية حول الإجراء';
$string['privacy:metadata:auth_devicelock_user_scores'] = 'نتيجة الأمان الدائمة لكل مستخدم';
$string['privacy:metadata:auth_devicelock_user_scores:userid'] = 'معرف المستخدم الذي تنتمي إليه النتيجة';
$string['privacy:metadata:auth_devicelock_user_scores:score'] = 'نتيجة الأمان الحالية (0-100)';
$string['privacy:metadata:auth_devicelock_user_scores:violation_count'] = 'عدد المخالفات المسجلة';
$string['privacy:metadata:auth_devicelock_user_scores:last_violation'] = 'موعد آخر مخالفة';
$string['privacy:metadata:auth_devicelock_user_scores:last_regain'] = 'موعد آخر استعادة للنقاط';
$string['privacy:metadata:auth_devicelock_user_scores:custom_regain'] = 'ما إذا كان قد تم تعيين معدل استعادة مخصص لهذا المستخدم';
$string['privacy:metadata:auth_devicelock_user_scores:regain_amount'] = 'النقاط المستعادة في كل مرة (إعداد مخصص)';
$string['privacy:metadata:auth_devicelock_user_scores:regain_interval'] = 'الثواني بين عمليات الاستعادة (إعداد مخصص)';
$string['privacy:metadata:auth_devicelock_user_scores:updated_at'] = 'موعد آخر تحديث للنتيجة';

// Purge Data / Danger Zone strings
$string['purge_data_title']        = 'منطقة الخطر: تطهير بيانات الملحق';
$string['purge_data_desc']         = 'سيؤدي هذا إلى حذف جميع الأجهزة المسجلة وبيانات تتبع الجلسة والسجلات والتكوينات المرتبطة بملحق تسجيل الدخول بجهاز واحد بشكل دائم. لا يمكن التراجع عن هذا الإجراء.';
$string['purge_data_btn']          = 'تطهير جميع بيانات الملحق';

// Customizable Email & Limit Override strings
$string['sendemail']              = 'إرسال بريد إلكتروني مخصص';
$string['sendemail_heading']      = 'إرسال بريد إلكتروني مخصص لهذا المستخدم';
$string['sendemail_subject']      = 'الموضوع';
$string['sendemail_body']         = 'الرسالة';
$string['sendemail_submit']       = 'إرسال البريد الإلكتروني';
$string['sendemail_success']      = 'تم إرسال البريد الإلكتروني بنجاح إلى {$a}.';
$string['sendemail_failure']      = 'فشل في إرسال البريد الإلكتروني إلى {$a}. يرجى التحقق من تكوين البريد للموقع.';
$string['sendemail_empty_subject'] = 'يرجى إدخال الموضوع.';
$string['sendemail_empty_body']    = 'يرجى إدخال نص الرسالة.';

$string['userlimit_heading']       = 'حد الأجهزة لكل مستخدم';
$string['userlimit_label']         = 'حد الأجهزة المخصص';
$string['userlimit_desc']          = 'تجاوز حد الأجهزة العام لهذا المستخدم المحدد. اتركه فارغًا أو اضبطه على 0 لاستخدام الحد العام ({$a} أجهزة).';
$string['userlimit_save']          = 'حفظ الحد';
$string['userlimit_cleared']       = 'تم مسح حد الأجهزة المخصص. سيستخدم هذا المستخدم الآن الحد العام.';
$string['userlimit_saved']         = 'تم حفظ حد أجهزة مخصص يبلغ {$a} جهاز(أجهزة) لهذا المستخدم.';
$string['userlimit_invalid']       = 'يجب أن يكون حد الأجهزة عددًا صحيحًا أكبر من الصفر.';
$string['userlimit_current']       = 'الحد الفعلي: {$a} جهاز(أجهزة)';

// Browser Limit strings
$string['maxbrowsers']             = 'الحد الأقصى للمتصفحات لكل جهاز';
$string['maxbrowsers_desc']        = 'الحد الأقصى لعدد المتصفحات المختلفة (مثل Chrome و Firefox و Edge و Safari) المسموح بها على كل جهاز معتمد لجميع المستخدمين. اضبطه على 0 للسماح بعدد غير محدود من المتصفحات على الجهاز المعتمد.';
$string['userbrowserlimit_label']  = 'حد المتصفحات المخصص لكل جهاز';
$string['userbrowserlimit_desc']   = 'تجاوز حد المتصفحات العام لكل جهاز لهذا المستخدم المحدد. اضبطه على 0 أو اتركه فارغاً لاستخدام الحد العام ({$a}).';
$string['userbrowserlimit_saved']  = 'تم حفظ حد المتصفحات المخصص البالغ {$a} متصفح(متصفحات) لكل جهاز لهذا المستخدم.';
$string['userbrowserlimit_cleared']= 'تم مسح حد المتصفحات المخصص. سيستخدم هذا المستخدم الآن الحد العام للمتصفحات.';
$string['browserlimitreached']     = 'تم بلوغ الحد الأقصى للمتصفحات: يُسمح لك باستخدام حتى {$a} متصفح(متصفحات) على جهازك المسجل. يرجى استخدام متصفحك المعتمد سابقاً.';
$string['reset_device_browsers']   = 'إعادة تعيين المتصفحات';
$string['reset_device_browsers_confirm'] = 'هل أنت متأكد من رغبتك في إعادة تعيين المتصفحات المصرح بها لهذا الجهاز؟ سيتمكن المستخدم من تسجيل متصفح جديد عند تسجيل دخوله القادم.';
$string['reset_device_browsers_success'] = 'تمت إعادة تعيين متصفحات الجهاز رقم #{$a} بنجاح.';
$string['reset_all_browsers']            = 'إعادة تعيين جميع المتصفحات';
$string['confirm_reset_user_browsers']   = 'هل أنت متأكد من رغبتك في إعادة تعيين جميع المتصفحات لهذا المستخدم؟ سيؤدي ذلك إلى تسجيل خروج المستخدم من كافة المتصفحات مع الاحتفاظ بسجلات أجهزته المسجلة. سيعاد تسجيل المتصفحات تلقائياً عند تسجيل الدخول القادم من نفس الأجهزة.';
$string['reset_user_browsers_success']   = 'تمت إعادة تعيين بيانات جميع المتصفحات للمستخدم {$a} بنجاح وتسجيل الخروج من كافة الجلسات مع الاحتفاظ بسجلات الأجهزة.';

// ميزة كلمة المرور المؤقتة
$string['generate_temp_password']        = 'توليد كلمة مرور مؤقتة';
$string['temppassword_card_title']       = 'تم إنشاء كلمة المرور المؤقتة';
$string['temppassword_generated_for']    = 'تم إنشاء كلمة مرور مؤقتة بنجاح للمستخدم {$a}';
$string['copy_password']                 = 'نسخ كلمة المرور';
$string['copied']                        = 'تم النسخ!';
$string['temppassword_user_notice']      = 'تنبيه: لقد قمت بتسجيل الدخول باستخدام كلمة مرور مؤقتة. في خانة (كلمة المرور الحالية)، قم بإدخال الباسورد المؤقت الذي أعطاه الأدمن لك، ثم أدخل كلمة المرور الجديدة الخاصة بك مرتين.';
$string['temppassword_current_help']     = 'الباسورد المؤقت الذي أعطاه الأدمن لك';

// تنظيف السجلات التلقائي وتأكيد البريد الإلكتروني
$string['task_cleanup_logs']             = 'حذف سجلات قفل الأجهزة القديمة تلقائياً (أقدم من 3 أسابيع)';
$string['emailconfirmed_login_intro']    = 'تم تأكيد بريدك الإلكتروني بنجاح! يرجى تسجيل الدخول الآن لتسجيل جهازك والوصول إلى حسابك.';
$string['purge_success_uninstall_ready'] = 'تم تطهير جميع بيانات ملحق تسجيل الدخول بجهاز واحد بنجاح. الملحق الآن معطل وجاهز لإلغاء التثبيت أو التحديث أدناه. انقر على "إلغاء التثبيت" لإزالته.';

// ============================================================
// ميزة نسخ بيانات المستخدم (تنسخ اسم المستخدم + كلمة مرور مؤقتة جديدة)
// ============================================================
$string['copy_user_details']              = 'نسخ بيانات المستخدم';
$string['copydetails_card_title']        = 'تم نسخ بيانات المستخدم';
$string['copydetails_generated_for']     = 'بيانات تسجيل الدخول للمستخدم {$a}';
$string['copydetails_notice']            = 'لأسباب أمنية، لا يقوم Moodle بتخزين كلمات المرور بصيغة نصية إطلاقاً. تم توليد كلمة مرور مؤقتة جديدة لهذا الحساب وتعيينها ككلمة المرور الحالية. تم نسخ كل من اسم المستخدم وكلمة المرور المؤقتة الجديدة إلى الحافظة لتتمكن من تسليمها للمستخدم.';
$string['copydetails_username_label']    = 'اسم المستخدم';
$string['copydetails_password_label']    = 'كلمة المرور المؤقتة';
$string['copy_both']                     = 'نسخ اسم المستخدم وكلمة المرور';
$string['copydetails_copied_title']      = 'تم النسخ إلى الحافظة!';
$string['copydetails_copied_body']       = 'اسم المستخدم وكلمة المرور المؤقتة موجودان في الحافظة.';
$string['copydetails_manual']            = 'إذا فشل النسخ التلقائي، انقر على الزر بالأسفل للنسخ يدوياً.';
$string['copydetails_success']           = 'تم نسخ بيانات تسجيل الدخول (اسم المستخدم + كلمة المرور المؤقتة الجديدة) إلى الحافظة للمستخدم {$a}.';
$string['copydetails_return']            = 'رجوع';

// ============================================================
// ميزة حذف حساب المستخدم (تحذف حساب المستخدم نهائياً من Moodle)
// ============================================================
$string['delete_user_account']           = 'حذف حساب المستخدم';
$string['deleteuser_confirm_title']      = 'تأكيد الحذف النهائي للحساب';
$string['deleteuser_confirm_intro']      = 'أنت على وشك الحذف النهائي لحساب المستخدم التالي:';
$string['deleteuser_confirm_name']       = 'الاسم';
$string['deleteuser_confirm_username']   = 'اسم المستخدم';
$string['deleteuser_confirm_email']      = 'البريد الإلكتروني';
$string['deleteuser_confirm_will']       = 'سيقوم هذا الإجراء فوراً بـ:';
$string['deleteuser_confirm_list']       = 'حذف حساب المستخدم من قاعدة بيانات Moodle ووضع علامة محذوف عليه|إزالة جميع بيانات Lock Guard لهذا المستخدم (الأجهزة المسجلة وتتبع المتصفحات/الجلسات وتفضيلات الملحق وسجلات الأمان)|تسجيل خروج المستخدم من كل جلسة نشطة|إزالة جميع تعيينات الأدوار والتسجيلات وبيانات السياق الخاصة بهذا الحساب|إخفاء اسم المستخدم بحيث لا يمكن إعادة استخدامه لتسجيل الدخول';
$string['deleteuser_confirm_warning']    = 'لا يمكن التراجع عن هذا الإجراء. سيختفي الحساب وكل معلوماته إلى الأبد.';
$string['deleteuser_self_error']         = 'لأمانك، لا يمكنك حذف حسابك الخاص من هنا.';
$string['deleteuser_admin_error']        = 'لأسباب أمنية، لا يمكن حذف حسابات مسؤولي الموقع من هذه الشاشة. يرجى استخدام إدارة الموقع القياسية > إدارة المستخدمين بدلاً من ذلك.';
$string['deleteuser_guest_error']        = 'لا يمكن حذف حساب الزائر.';
$string['deleteuser_notfound']           = 'المستخدم غير موجود — ربما تم حذف الحساب بالفعل.';
$string['deleteuser_success']            = 'تم حذف حساب المستخدم "{$a}" نهائياً وإزالة جميع المعلومات المرتبطة به من Moodle.';
$string['deleteuser_confirm_btn']        = 'نعم، احذف هذا الحساب إلى الأبد';
$string['deleteuser_log_label']          = 'تم حذف الحساب';
$string['copydetails_log_label']         = 'تم نسخ البيانات';

// ============================================================
// ميزة الحذف الجماعي للمستخدمين
// ============================================================
$string['bulk_delete_selected']        = 'حذف المحدد';
$string['bulk_delete_users']           = 'حذف المستخدمين المحددين';
$string['bulk_delete_confirm_title']   = 'تأكيد الحذف الجماعي للحسابات';
$string['bulk_delete_confirm_intro']   = 'أنت على وشك الحذف النهائي لحساب (حسابات) المستخدم التالية والبالغ عددها {$a}:';
$string['bulk_delete_confirm_warning'] = 'لا يمكن التراجع عن هذا الإجراء. سيختفي كل حساب مدرج وكل معلوماته إلى الأبد.';
$string['bulk_delete_confirm_btn']     = 'نعم، احذف جميع الحسابات المحددة إلى الأبد';
$string['bulk_delete_none_selected']  = 'لم يتم تحديد أي مستخدمين. حدد مربعات الاختيار بجانب المستخدمين الذين تريد حذفهم أولاً.';
$string['bulk_delete_none_valid']      = 'لا يمكن حذف أي من المستخدمين المحددين من هنا (إنهم إما أنت أو حساب الزائر أو مسؤول موقع).';
$string['bulk_delete_skipped_label']   = 'الحسابات التي سيتم تخطيها للأمان (أنت / الزائر / مسؤول الموقع):';
$string['bulk_delete_result_deleted']  = 'تم حذف {$a->deleted} حساب.';
$string['bulk_delete_result_skipped']  = 'تم تخطي {$a->skipped} حساب للأمان (أنت / الزائر / مسؤول الموقع).';
$string['bulk_delete_result_gone']     = '{$a} حساب كانت قد حُذفت بالفعل.';
$string['bulk_select_all']             = 'تحديد الكل';
$string['bulk_select_visible']         = 'تحديد الظاهرين';
$string['bulk_select_all_hint']        = 'تحديد كل المستخدمين المطابقين للبحث والفلاتر الحالية (كل الصفحات)';
$string['bulk_select_visible_hint']    = 'تحديد المستخدمين الظاهرين في الصفحة الحالية فقط';
$string['bulk_clear_selection']        = 'إلغاء التحديد';
$string['bulk_actions']                = 'إجراءات جماعية';
$string['bulk_selected_count']         = '{$a} محدد';

// ============================================================
// ميزات التصدير (CSV)
// ============================================================
$string['export_users_csv']            = 'تصدير المستخدمين كـ CSV';
$string['export_logs_csv']             = 'تصدير السجلات كـ CSV';
$string['export_no_data']             = 'لا توجد بيانات للتصدير.';
$string['export_users_filename']      = 'lockguard_users';
$string['export_logs_filename']       = 'lockguard_logs';
$string['export_col_order']           = 'الترتيب';
$string['export_col_fullname']        = 'الاسم الكامل';
$string['export_col_username']        = 'اسم المستخدم';
$string['export_col_email']           = 'البريد الإلكتروني';
$string['export_col_auth']            = 'طريقة المصادقة';
$string['export_col_devices']        = 'الأجهزة النشطة';
$string['export_col_maxdevices']     = 'الحد الأقصى للأجهزة';
$string['export_col_type']           = 'نوع المستخدم';
$string['export_col_suspended']      = 'موقوف';
$string['export_col_confirmed']      = 'مؤكد';
$string['export_col_uni_id']         = 'الرقم الجامعي';
$string['export_col_phone']          = 'الهاتف';
$string['export_col_institution']    = 'المؤسسة';
$string['export_col_department']     = 'القسم';
$string['export_col_idnumber']      = 'الرقم التعريفي';

// ============================================================
// ميزة مسح السجلات
// ============================================================
$string['clear_logs']                 = 'مسح جميع السجلات';
$string['clear_logs_confirm']         = 'هل أنت متأكد من رغبتك في حذف جميع سجلات أمان Lock Guard نهائياً؟ لا يمكن التراجع عن هذا الإجراء.';
$string['clear_logs_success']         = 'تم حذف جميع سجلات أمان Lock Guard.';
$string['clear_logs_btn']            = 'مسح جميع السجلات';
$string['bulk_delete_log_label']     = 'حذف جماعي للحسابات';
$string['bulk_delete_capped']        = 'تم تحديد الحذف الجماعي بـ {$a->capped} حساب لكل دفعة (لم تتم معالجة {$a->remaining} — نفّذ دفعة أخرى للباقي).';

// ============================================================
// النسخ الجماعي لبيانات المستخدم (CSV) — مساعد تسجيل المجموعات
// ============================================================
$string['bulk_copy_details']           = 'نسخ البيانات (CSV)';
$string['bulk_copy_details_title']     = 'نسخ جماعي لبيانات المستخدم';
$string['bulk_copy_details_intro']     = 'تم توليد كلمة مرور مؤقتة جديدة لكل مستخدم محدد وتعيينها ككلمة المرور الحالية. يتم تنزيل ملف CSV يحتوي على الاسم الكامل واسم المستخدم وكلمة المرور والبريد الإلكتروني لتتمكن من توزيع بيانات الدخول بأمان.';
$string['bulk_copy_details_warning']   = 'سيتم إعادة تعيين كلمة مرور كل حساب محدد إلى كلمة مرور مؤقتة جديدة للاستخدام مرة واحدة (يجب على المستخدم تغييرها عند تسجيل الدخول القادم). أكد فقط إذا كنت تنوي تسليم هذه البيانات.';
$string['bulk_copy_details_none']      = 'لم يتم تحديد أي مستخدمين. حدد مربعات الاختيار بجانب المستخدمين أولاً.';
$string['bulk_copy_details_capped']    = 'تم تحديد تصدير CSV بـ {$a} مستخدم لكل دفعة. نفّذ دفعة أخرى للباقي.';
$string['bulk_copy_details_filename']  = 'lockguard_user_credentials';
$string['bulk_copy_details_log_label'] = 'نسخ جماعي للبيانات';
$string['bulk_copy_details_col_fullname'] = 'الاسم الكامل';
$string['bulk_copy_details_col_username'] = 'اسم المستخدم';
$string['bulk_copy_details_col_password'] = 'كلمة المرور المؤقتة';
$string['bulk_copy_details_col_email']    = 'البريد الإلكتروني';
$string['bulk_copy_details_col_auth']     = 'طريقة المصادقة';

// ============================================================
// السجل الزمني للتدقيق لكل مستخدم (صفحة مخصصة)
// ============================================================
$string['audit_timeline']               = 'السجل الزمني للتدقيق';
$string['audit_timeline_for']           = 'السجل الزمني للتدقيق الأمني لـ {$a}';
$string['audit_timeline_empty']         = 'لا توجد أحداث أمنية مسجلة لهذا المستخدم حتى الآن.';
$string['audit_timeline_export']        = 'تصدير سجلات هذا المستخدم';
$string['audit_timeline_filter']        = 'تصفية حسب نوع الحدث';
$string['audit_timeline_count']         = '{$a} حدث';
$string['audit_timeline_all_events']    = 'كل الأحداث';
$string['audit_timeline_back']          = 'العودة لتفاصيل المستخدم';

// ============================================================
// تسميات اتجاهات لقطة الأمان الأسبوعية
// (أُزيلت بطاقة "اتجاهات النشاط الأمني" من لوحة التحكم في الإصدار 3.4.2)
// ============================================================
$string['security_trends_blocked_logins'] = 'محاولات تسجيل الدخول المحظورة';
$string['security_trends_device_regs']  = 'تسجيلات الأجهزة';
$string['security_trends_deletions']    = 'حذف الحسابات';

// ============================================================
// استيراد CSV — إنشاء مستخدمين جماعياً بمصادقة قفل الجهاز
// ============================================================
$string['import_users_csv']             = 'استيراد المستخدمين (CSV)';
$string['import_users_title']           = 'استيراد جماعي للمستخدمين من CSV';
$string['import_users_intro']           = 'ارفع ملف CSV لإنشاء حسابات مستخدمين متعددة دفعة واحدة، مُعدّة مسبقاً لاستخدام مصادقة Lock Guard (قفل الجهاز). كل مستخدم جديد سيكون غير موقوف ومؤكد، وسيُجبر على تغيير كلمة المرور عند تسجيل الدخول الأول.';
$string['import_users_template']       = 'تنزيل قالب CSV';
$string['import_users_choose']          = 'اختر ملف CSV';
$string['import_users_submit']         = 'استيراد وإنشاء المستخدمين';
$string['import_users_confirm']        = 'هل أنت متأكد من رغبتك في إنشاء الحسابات المدرجة أدناه؟ لا يمكن التراجع عن هذا الإجراء.';
$string['import_users_none']           = 'لم يتم العثور على صفوف صالحة في ملف CSV المرفوع. الأعمدة المطلوبة: الاسم الأول، اسم العائلة، البريد الإلكتروني، اسم المستخدم. اختياري: كلمة المرور.';
$string['import_users_result_created'] = 'تم إنشاء {$a->created} حساب مستخدم.';
$string['import_users_result_skipped'] = 'تم تخطي {$a->skipped} صف (تكرار اسم المستخدم/البريد أو حقول مطلوبة ناقصة).';
$string['import_users_result_errors']  = 'فشل في إنشاء {$a->errors} صف.';
$string['import_users_preview']        = 'معاينة — أول 25 صفاً';
$string['import_users_col_firstname']  = 'الاسم الأول';
$string['import_users_col_lastname']   = 'اسم العائلة';
$string['import_users_col_email']      = 'البريد الإلكتروني';
$string['import_users_col_username']   = 'اسم المستخدم';
$string['import_users_col_password']   = 'كلمة المرور';
$string['import_users_col_idnumber']   = 'الرقم التعريفي (اختياري)';
$string['import_users_log_label']      = 'استيراد جماعي للمستخدمين';
$string['import_users_capped']         = 'تم تحديد الاستيراد بـ {$a} صفاً لكل دفعة. نفّذ استيراداً آخر للباقي.';
$string['import_users_file_too_big']   = 'حجم الملف المرفوع أكبر من {$a}. يرجى تقسيمه إلى دفعات أصغر.';
$string['import_users_file_badtype']   = 'يُقبل فقط ملفات ‎.csv‎ أو ‎.txt‎.';

// ============================================================
// عبارة تأكيد مكتوبة — حماية للدفعات التدميرية التي تتجاوز 50 مستخدماً
// ============================================================
$string['confirm_phrase_label']        = 'اكتب كلمة DELETE للتأكيد';
$string['confirm_phrase_mismatch']     = 'عبارة التأكيد غير مطابقة. لم يتم تغيير أي شيء.';
$string['confirm_phrase_required']     = 'تتطلب الدفعة التدميرية التي تضم {$a} مستخدماً أن تكتب كلمة DELETE للمتابعة.';

// ============================================================
// السجل الزمني للتدقيق لكل جهاز (صفحة مخصصة)
// ============================================================
$string['device_audit_timeline']          = 'السجل الزمني لتدقيق الجهاز';
$string['device_audit_timeline_for']      = 'السجل الزمني للتدقيق الأمني للجهاز {$a}';
$string['device_audit_timeline_empty']    = 'لا توجد أحداث أمنية مسجلة لهذا الجهاز حتى الآن.';
$string['device_audit_timeline_export']   = 'تصدير سجلات هذا الجهاز';
$string['device_audit_timeline_count']    = '{$a} حدث';
$string['device_audit_timeline_back']     = 'العودة إلى الأجهزة';
$string['device_audit_no_device']         = 'لم يتم توفير بصمة جهاز. يرجى فتح هذه الصفحة من تبويب الأجهزة.';

// ============================================================
// مهمة التنظيف المجدولة — حذف صفوف الأجهزة وتتبع الجلسات اليتيمة
// ============================================================
$string['task_prune_orphans']          = 'حذف صفوف أجهزة Lock Guard وتتبع الجلسات اليتيمة للمستخدمين غير الموجودين في جدول مستخدمي Moodle';
$string['task_prune_orphans_done']     = 'تم حذف {$a->devices} صف جهاز يتيم و {$a->sessions} صف تتبع جلسات يتيم.';

// ============================================================
// درجة الأمان لكل مستخدم (شارة 0-100 من نشاط آخر 30 يوماً)
// ============================================================
$string['security_score']              = 'درجة الأمان';
$string['security_score_label']        = 'درجة الأمان';
$string['security_score_high']         = 'ممتاز';
$string['security_score_good']         = 'جيد';
$string['security_score_fair']         = 'مقبول';
$string['security_score_poor']         = 'معرض للخطر';
$string['security_score_critical']     = 'حرج';
$string['security_score_tooltip']     = 'تبدأ من 100% عند إنشاء الحساب، وتنخفض مع كل مخالفة (تسجيلات الدخول المحظورة -10، الأجهزة غير المتوقعة -12، أحداث App Guard من -8 إلى -25، الإيقاف -15، الحظر -40)، وتُستعاد تدريجياً بمرور الوقت بعد آخر مخالفة.';
$string['security_score_breakdown']    = 'تفصيل الدرجة';

// ============================================================
// استيراد CSV — الوضع التجريبي (التحقق فقط، دون إنشاء حسابات)
// ============================================================
$string['import_users_dryrun']         = 'تشغيل تجريبي (تحقق فقط، لا تنشئ الحسابات)';
$string['import_users_dryrun_label']   = 'تشغيل تجريبي';
$string['import_users_dryrun_result']  = 'اكتمل التشغيل التجريبي: كان سيتم إنشاء {$a->would_create} حساب، وكان سيتم تخطي {$a->would_skip} صف. لم تُجرَ أي تغييرات.';
$string['import_users_dryrun_badge']   = 'تشغيل تجريبي';

// ============================================================
// مخطط مصغر لتوزيع درجات الأمان (بطاقة لوحة التحكم)
// ============================================================
$string['score_distribution']          = 'توزيع درجات الأمان';
$string['score_distribution_desc']    = 'كم عدد المستخدمين الذين يقعون حالياً في كل نطاق خطر (بناءً على نتيجة الأمان الدائمة: تبدأ من 100%، وتنخفض مع المخالفات، وتُستعاد بمرور الوقت).';
$string['score_distribution_total']    = '{$a} مستخدم تم تقييمه';
$string['score_distribution_empty']   = 'لا توجد نتائج بعد — يحصل كل مستخدم على نتيجة تلقائياً.';

// ============================================================
// استيراد CSV — فحص مسبق لسياسة كلمة المرور (الوضع التجريبي)
// ============================================================
$string['import_users_pwcheck_ok']      = 'فحص سياسة كلمة المرور: جميع كلمات المرور المقدمة تستوفي سياسة الموقع.';
$string['import_users_pwcheck_fail']    = 'فحص سياسة كلمة المرور: ستُرفض {$a->failed} من أصل {$a->total} كلمة مرور مقدمة من قِبل سياسة الموقع.';
$string['import_users_pwcheck_row']     = 'الصف {$a->row} ({$a->username}): {$a->reason}';

// ============================================================
// إعادة حساب جميع الدرجات (إجراء المسؤول) + التصفية حسب النطاق
// ============================================================
$string['recalculate_scores']          = 'إعادة حساب جميع الدرجات';
$string['recalculate_scores_btn']      = 'إعادة حساب جميع الدرجات';
$string['recalculate_scores_confirm'] = 'هل تريد تحديث نتيجة الأمان لكل المستخدمين؟ سيتم إنشاء الصفوف المفقودة (بقيمة 100%) وتطبيق كل استعادة مستحقة. قد يستغرق ذلك بضع ثوانٍ على المواقع الكبيرة.';
$string['recalculate_scores_done']    = 'تمت معالجة {$a} مستخدم: إنشاء الصفوف المفقودة (بقيمة 100%) وتطبيق كل استعادة مستحقة.';
$string['recalculate_scores_none']    = 'لم يتم العثور على مستخدمين — لا شيء للقيام به.';
$string['score_band_filter']           = 'نطاق الدرجة';
$string['score_band_filter_all']       = 'كل النطاقات';
$string['score_band_filter_hint']      = 'تصفية الدليل حسب نطاق درجة الأمان';

// ============================================================
// ملخص أمني أسبوعي بالبريد الإلكتروني لمسؤولي الموقع
// ============================================================
$string['task_weekly_snapshot']        = 'ملخص أمني أسبوعي بالبريد الإلكتروني لمسؤولي الموقع';
$string['snapshot_subject']            = 'الملخص الأمني الأسبوعي لـ Lock Guard لـ {$a}';
$string['snapshot_intro']              = 'إليك ملخصك الأمني الأسبوعي لـ Lock Guard لـ {$a}.';
$string['snapshot_section_trends']     = 'اتجاهات النشاط (آخر 7 أيام)';
$string['snapshot_section_distribution']= 'توزيع درجات الأمان';
$string['snapshot_section_toprisk']    = 'أفضل 5 مستخدمين معرضين للخطر (أقل الدرجات)';
$string['snapshot_no_data']            = 'لا توجد أحداث أمنية مسجلة في آخر 7 أيام.';
$string['snapshot_sent']               = 'تم إرسال الملخص الأمني الأسبوعي إلى {$a} مسؤول.';
$string['snapshot_no_admins']          = 'لم يتم العثور على مسؤولين بعناوين بريد صالحة — لم يتم إرسال الملخص.';

// ============================================================
// إعدادات الملخص الأمني + الصفحة داخل المتصفح
// ============================================================
$string['snapshot_heading']            = 'بريد الملخص الأمني';
$string['snapshot_heading_desc']       = 'ملخص أسبوعي بالبريد الإلكتروني يُرسل لكل مسؤولي الموقع يلخص نشاط Lock Guard (اتجاهات 7 أيام، توزيع الدرجات، أفضل 5 مستخدمين معرضين للخطر). يُرسل البريد بواسطة المهمة المجدولة weekly_snapshot — فعّله هنا، ثم تأكد من تشغيل Moodle cron.';
$string['snapshot_enabled']            = 'تفعيل بريد الملخص الأسبوعي';
$string['snapshot_enabled_desc']       = 'عند التفعيل، ترسل المهمة المجدولة weekly_snapshot ملخصاً أمنياً لكل مسؤولي الموقع كل اثنين الساعة 06:00.';
$string['snapshot_page']               = 'الملخص الأمني';
$string['snapshot_page_title']         = 'الملخص الأمني داخل المتصفح';
$string['snapshot_send_test']          = 'إرسال بريد تجريبي الآن';
$string['snapshot_send_test_confirm']  = 'إرسال بريد ملخص تجريبي إلى حساب المسؤول الخاص بك الآن؟';
$string['snapshot_test_sent']          = 'تم إرسال بريد الملخص التجريبي إلى {$a}.';
$string['snapshot_test_no_self']       = 'حساب المسؤول الخاص بك لا يملك عنوان بريد صالح — لا يمكن إرسال بريد تجريبي.';
$string['snapshot_disabled']           = 'بريد الملخص الأسبوعي معطل حالياً في إعدادات الملحق. فعّله لتلقي الملخصات الأسبوعية.';
$string['snapshot_last_sent']          = 'آخر ملخص أسبوعي تم إرساله: {$a}';
$string['snapshot_test_badge']         = 'تجريبي';

// ============================================================
// مخطط سجل الدرجة + العد التنازلي للملخص القادم + التصفية بالنطاق على تبويب غير الملحق
// ============================================================
$string['score_history']               = 'سجل الدرجة (30 يوماً)';
$string['score_history_empty']        = 'لا توجد تغييرات على النتيجة بعد — يظهر المخطط بعد أول مخالفة أو استعادة أو تغيير يدوي.';
$string['snapshot_next_due']           = 'الملخص الأسبوعي القادم مستحق: {$a}';
$string['snapshot_next_due_unknown']   = 'الملخص الأسبوعي القادم مستحق: غير معروف (شغّل المهمة مرة لبدء الجدولة).';
$string['score_band_filter_np_hint']   = 'انقر على شريط نطاق لتصفية هذا الدليل حسب نطاق الدرجة';

// ============================================================
// خيارات نسخ بيانات المستخدم
// ============================================================
$string['copy_option_info']             = 'اسم المستخدم + البريد الإلكتروني فقط';
$string['copy_option_info_desc']        = 'نسخ اسم المستخدم والبريد الإلكتروني. لا يتم تغيير كلمة المرور.';
$string['copy_option_password']         = 'اسم المستخدم + البريد الإلكتروني + كلمة مرور مؤقتة جديدة';
$string['copy_option_password_desc']    = 'توليد كلمة مرور مؤقتة جديدة وتعيينها للحساب ونسخ الحقول الثلاثة. يجب على المستخدم تغييرها عند تسجيل الدخول القادم.';

// ============================================================
// ميزة حظر المستخدم
// ============================================================
$string['ban_user']                     = 'حظر المستخدم';
$string['ban_user_title']               = 'حظر حساب المستخدم';
$string['ban_user_intro']               = 'حظر هذا المستخدم سيمنعه من تسجيل الدخول. سيتم أيضاً حظر عنوان IP وجهازه. ستظهر رسالة الحظر على صفحة تسجيل الدخول.';
$string['ban_reason_label']             = 'سبب الحظر (اختياري)';
$string['ban_reason_desc']              = 'إذا تم تقديمه، سيظهر هذا السبب على صفحة تسجيل الدخول أسفل رسالة الحظر.';
$string['ban_message_default']          = 'أنت محظور من استخدام هذا الموقع!';
$string['ban_reason_prefix']            = 'السبب:';
$string['ban_confirm_btn']              = 'حظر هذا المستخدم';
$string['ban_success']                  = 'تم حظر {$a}.';
$string['unban_user']                   = 'إلغاء حظر المستخدم';
$string['unban_success']                = 'تم إلغاء حظر {$a}.';
$string['ban_status_banned']            = 'محظور';
$string['ban_status_active']            = 'نشط';
$string['bulk_ban_selected']            = 'حظر المحدد';
$string['bulk_unban_selected']          = 'إلغاء حظر المحدد';
$string['bulk_ban_title']               = 'حظر جماعي للمستخدمين';
$string['bulk_ban_intro']               = 'سيتم حظر المستخدمين التاليين ({$a}) من تسجيل الدخول.';
$string['bulk_ban_confirm_btn']         = 'حظر جميع المستخدمين المحددين';
$string['bulk_ban_success']             = 'تم حظر {$a} مستخدم.';
$string['bulk_unban_success']           = 'تم إلغاء حظر {$a} مستخدم.';
$string['ban_message_setting']          = 'رسالة الحظر';
$string['ban_message_desc']             = 'الرسالة التي تظهر على صفحة تسجيل الدخول عندما يحاول مستخدم محظور الدخول. إذا تم تقديم سبب الحظر، سيظهر في سطر جديد أسفل هذه الرسالة كـ "السبب: <السبب>".';
$string['ban_log_label']                = 'تم حظر المستخدم';
$string['unban_log_label']              = 'تم إلغاء حظر المستخدم';
$string['bulk_ban_log_label']           = 'حظر جماعي للمستخدمين';

// ============================================================
// إنشاء سريع للمستخدم
// ============================================================
$string['quick_create_user']            = 'إنشاء سريع لمستخدم';
$string['quick_create_title']           = 'إنشاء حساب مستخدم بسرعة';
$string['quick_create_intro']           = 'إنشاء حساب مستخدم واحد بمصادقة قفل الجهاز. يجب تعبئة كل حقل، أو تحديد خيار "توليد تلقائي" الخاص به ليتم توليده تلقائياً. يمكنك أيضاً تعيين الأدوار وتسجيل المستخدم في المقررات الموجودة.';
$string['quick_create_username']        = 'اسم المستخدم';
$string['quick_create_firstname']      = 'الاسم الأول';
$string['quick_create_lastname']       = 'اسم العائلة';
$string['quick_create_email']           = 'البريد الإلكتروني';
$string['quick_create_password']        = 'كلمة المرور';
$string['quick_create_autogen']         = 'توليد تلقائي';
$string['quick_create_submit']          = 'إنشاء المستخدم';
$string['quick_create_success']         = 'تم إنشاء المستخدم "{$a}" بنجاح.';
$string['quick_create_error']           = 'فشل في إنشاء المستخدم: {$a}';
$string['quick_create_exists']          = 'يوجد مستخدم بهذا الاسم أو البريد الإلكتروني بالفعل.';

// ============================================================
// إنشاء جماعي للمستخدمين
// ============================================================
$string['bulk_create_users']            = 'إنشاء جماعي للمستخدمين';
$string['bulk_create_title']            = 'إنشاء حسابات مستخدمين جماعية';
$string['bulk_create_intro']           = 'إنشاء حسابات مستخدمين متعددة دفعة واحدة. أسماء المستخدمين والبريد الإلكتروني وكلمات المرور يتم ترقيمها تلقائياً (مثل user1 و user2 ...). يجب تعبئة كل حقل أساسي، أو تحديد خيار "توليد تلقائي" الخاص به ليتم توليده تلقائياً.';
$string['bulk_create_count']            = 'عدد المستخدمين المراد إنشاؤهم';
$string['bulk_create_username_base']    = 'أساس اسم المستخدم';
$string['bulk_create_firstname_base']  = 'الأساس للاسم الأول';
$string['bulk_create_lastname_base']   = 'الأساس لاسم العائلة';
$string['bulk_create_email_base']       = 'أساس البريد (الجزء قبل @)';
$string['bulk_create_email_domain']     = 'نطاق البريد (الجزء بعد @)';
$string['bulk_create_password_base']    = 'أساس كلمة المرور';
$string['bulk_create_roles']            = 'الأدوار المراد تعيينها';
$string['bulk_create_custom_role']      = 'اسم دور مخصص (ينشئ دوراً جديداً إذا لم يكن موجوداً)';
$string['bulk_create_submit']           = 'معاينة وإنشاء';
$string['bulk_create_conflict_title']   = 'تم اكتشاف تعارض';
$string['bulk_create_conflict_intro']   = 'بعض أسماء المستخدمين أو البريد الإلكتروني موجودة بالفعل. سيبدأ الترقيم بعد آخر رقم متعارض.';
$string['bulk_create_conflict_detail']  = 'موجود: {$a}';
$string['bulk_create_continue']         = 'متابعة (تخطي التعارضات)';
$string['bulk_create_cancel']           = 'إلغاء';
$string['bulk_create_success']          = 'تم إنشاء {$a->created} مستخدم.';
$string['bulk_create_numbering_auto']  = 'تم رصد حسابات موجودة مسبقاً — سيبدأ ترقيم هذه الدفعة من "{$a}" حتى يتم إنشاء جميع المستخدمين المطلوبين (لا يتم تخطي أي مستخدم).';
$string['bulk_create_none']             = 'لم يتم إنشاء أي مستخدم. يرجى مراجعة الإعدادات والرسائل أعلاه ثم المحاولة مرة أخرى.';
$string['bulk_create_error_detail']     = 'تعذر إنشاء المستخدم — {$a}';
$string['bulk_create_preview']          = 'معاينة — أول 10 مستخدمين';
$string['bulk_create_log_label']        = 'إنشاء جماعي للمستخدمين';
$string['bulk_create_numbering_hint']   = 'أسماء المستخدمين: base1, base2, ... | البريد: base.1@domain, base.2@domain, ... | كلمات المرور: base#1, base#2, ... | الأسماء: يُستخدم الأساس للاسم الأول كما هو ويُضاف الرقم إلى أساس اسم العائلة (مثل John Smith1 و John Smith2 ...). يتابع الترقيم دائماً بعد الحسابات الموجودة مسبقاً، لذلك يتم إنشاء كل مستخدم مطلوب.';

// ============================================================
// التحقق المشترك و التسجيل في المقررات (v3.4.0)
// ============================================================
$string['createuser_field_required']    = 'لا يمكن ترك الحقل/الحقول التالية فارغة أثناء إلغاء تحديد خيار "توليد تلقائي" الخاص بها: {$a}';
$string['createuser_username_chars']   = 'اسم مستخدم غير صالح "{$a}". تسمح مودل فقط بالحروف الصغيرة والأرقام والنقطة (.) والشرطة (-) والشرطة السفلية (_) و @ في أسماء المستخدمين.';
$string['createuser_email_invalid']    = 'عنوان بريد إلكتروني غير صالح: "{$a}".';
$string['createuser_required_js']       = 'يرجى تعبئة هذا الحقل، أو تحديد خيار "توليد تلقائي" الخاص به.';
$string['enrol_courses_label']         = 'التسجيل في المقررات (اختياري)';
$string['enrol_courses_hint']          = 'حدد مقراً أو أكثر من المقررات الموجودة. سيتم تسجيل المستخدم/المستخدمين الجدد تلقائياً عند إنشائهم.';
$string['enrol_select_all']            = 'تحديد الكل / إلغاء التحديد';
$string['enrol_search_courses']        = 'البحث في المقررات...';
$string['enrol_no_courses']            = 'لا توجد مقررات على هذا الموقع بعد.';
$string['enrol_course_hidden']         = 'مخفي';
$string['enrol_role_label']            = 'التسجيل بدور (دور داخل المقرر)';
$string['enrol_duration_label']        = 'مدة التسجيل (بالأيام)';
$string['enrol_duration_hint']         = '0 = بلا حدود.';
$string['enrol_success']               = 'تم تسجيل المستخدم "{$a->user}" في {$a->count} مقرر.';
$string['enrol_bulk_success']          = 'تم إنشاء إجمالي {$a} تسجيل في المقررات للمستخدمين الجدد.';
$string['enrol_failed_course']         = 'تعذر التسجيل في المقرر "{$a->course}": {$a->error}';
$string['enrol_manual_disabled']       = 'تم تخطي التسجيل في المقررات: إضافة "التسجيل اليدوي" غير مفعلة على هذا الموقع.';

// ============================================================
// v3.4.3 — أزرار التصفية السريعة في دليل المستخدمين
// ============================================================
$string['ufilter_label']                = 'تصفية';
$string['ufilter_all']                 = 'كل المستخدمين';
$string['ufilter_banned']              = 'محظورون';
$string['ufilter_unbanned']            = 'غير محظورين';
$string['ufilter_suspended']           = 'موقوفون';
$string['ufilter_active']              = 'نشطون';

// ============================================================
// v3.4.3 — بطاقة الحسابات المُنشأة (بيانات الدخول بعد الإنشاء)
// ============================================================
$string['created_accounts_title']      = 'تم إنشاء الحسابات';
$string['created_accounts_intro']     = 'احفظ بيانات الدخول هذه الآن — كلمات المرور تُخزَّن مشفّرة ولن تظهر مرة أخرى.';
$string['created_col_name']           = 'الاسم';
$string['created_col_username']       = 'اسم المستخدم';
$string['created_col_email']          = 'البريد الإلكتروني';
$string['created_col_password']       = 'كلمة المرور';
$string['created_copy_row']           = 'نسخ اسم المستخدم وكلمة المرور';
$string['created_copy_all']           = 'نسخ الكل (CSV)';
$string['created_download_csv']       = 'تنزيل CSV';

// ============================================================
// v3.4.4 — تفاصيل السجلات القابلة للتوسيع
// ============================================================
$string['log_show_full']               = 'إظهار الكل';
$string['log_show_less']               = 'إظهار أقل';
$string['log_full_details']            = 'التفاصيل الكاملة';

// ============================================================
// نتيجة الأمان الدائمة (v3.5.0)
// ============================================================
$string['score_change']                = 'تغيير النتيجة';
$string['score_change_title']          = 'تغيير النتيجة';
$string['score_op']                    = 'العملية';
$string['score_op_increase']           = 'زيادة بمقدار';
$string['score_op_decrease']           = 'إنقاص بمقدار';
$string['score_op_set']                = 'تعيين إلى';
$string['score_op_reset']              = 'إعادة تعيين إلى 100%';
$string['score_amount']                = 'النقاط';
$string['score_amount_set_lbl']        = 'النتيجة الجديدة (0-100)';
$string['score_amount_hint']           = 'للزيادة / الإنقاص هذا هو عدد النقاط التي ستُضاف أو تُخصم؛ وللتعيين هذه هي النتيجة الجديدة بالضبط (0-100).';
$string['score_reason']                = 'السبب (اختياري)';
$string['score_reason_hint']           = 'مثال: تمت المراجعة يدوياً بعد التحدث مع الطالب';
$string['score_decrease_note']         = 'يُعامل الإنقاص كعقوبة: يعيد تشغيل مؤقت استعادة النقاط ويُحتسب كمخالفة. الزيادة والتعيين المباشر لا يؤثران على المؤقت.';
$string['score_custom_regain']         = 'استخدام إعداد استعادة مخصص لهذا المستخدم';
$string['score_custom_regain_desc']    = 'عند التمكين، يستعيد هذا المستخدم النقاط بمعدله الخاص بدلاً من المعدل العام المحدد في إعدادات الإضافة.';
$string['score_regain_amount_lbl']     = 'النقاط المستعادة';
$string['score_regain_every_lbl']      = 'الاستعادة كل';
$string['score_custom_remove_hint']    = 'ألغِ تحديد المربع أعلاه للعودة إلى استخدام إعدادات الاستعادة العامة.';
$string['score_save']                  = 'حفظ التغييرات';
$string['score_changed_ok']            = 'تم تحديث نتيجة الأمان للمستخدم {$a->name}: من {$a->old}% إلى {$a->new}%.';
$string['score_changed_invalid']       = 'عملية غير معروفة — لم يتم تغيير أي شيء.';
$string['score_reset_ok']              = 'تمت إعادة تعيين نتيجة الأمان إلى 100% لـ {$a} مستخدم.';
$string['bulk_reset_score']            = 'إعادة تعيين النتيجة';
$string['bulk_reset_score_hint']       = 'إعادة تعيين نتيجة الأمان لكل المستخدمين المحددين إلى 100%';
$string['score_autoban_reason']        = 'وصلت نتيجة الأمان إلى {$a}%';
$string['score_autoban_swept']         = 'تم تطبيق حد الحظر التلقائي: تم حظر {$a} من المستخدمين تلقائيًا.';
$string['users_per_page']              = 'مستخدمون في كل صفحة';
$string['show_all_users']              = 'عرض الكل';
$string['show_all_users_hint']         = 'تحميل كل المستخدمين في صفحة واحدة (مؤقت - تحديث الصفحة يعيد حجم الصفحة الافتراضي)';
$string['task_score_regain']           = 'معالجة استعادة نتيجة الأمان';
$string['score_stats_violations']      = 'المخالفات';
$string['score_stats_last_violation']  = 'آخر مخالفة';
$string['score_stats_never']           = 'أبداً';
$string['score_stats_regain']          = 'الاستعادة';
$string['score_stats_global']          = 'عام';
$string['score_stats_custom']          = 'مخصص';
$string['score_next_due']              = 'الاستعادة مستحقة الآن';
$string['score_next_in']               = 'الاستعادة التالية خلال {$a}';
$string['score_unit_seconds']          = 'ثوانٍ';
$string['score_unit_minutes']          = 'دقائق';
$string['score_unit_hours']            = 'ساعات';
$string['score_unit_days']             = 'أيام';
$string['score_unit_weeks']            = 'أسابيع';
$string['score_unit_months']           = 'أشهر';

// ================================================
// v3.8.0 - تغيير الكورسات / تغيير الأدوار (قائمة إجراءات المستخدم + الإجراءات الجماعية).
// ================================================
$string['change_course']                    = 'تغيير الكورسات';
$string['change_course_title']             = 'تغيير تسجيلات الكورسات';
$string['change_course_hint']              = 'تسجيل المستخدم في الكورسات أو إلغاء تسجيله منها';
$string['change_course_intro']             = 'الكورسات المسجل فيها المستخدم بالفعل محددة مسبقًا. ألغِ تحديد كورس لإلغاء تسجيل المستخدم منه، أو حدد كورسًا لتسجيل المستخدم فيه (أو تحديث التسجيل) بعدد الأيام والدور اللذين تختارهما.';
$string['change_course_course_col']        = 'الكورس';
$string['change_course_days_col']          = 'الأيام';
$string['change_course_days_hint']         = 'مدة التسجيل بالأيام (0 = غير محدودة)';
$string['change_course_role']              = 'التسجيل بدور';
$string['change_course_role_hint']         = 'الدور المعين عند التسجيل (الافتراضي: طالب)';
$string['change_course_save']              = 'حفظ تسجيلات الكورسات';
$string['change_course_none']              = 'لا توجد كورسات.';
$string['change_course_success']           = 'تم تحديث تسجيلات الكورسات لـ {$a}.';
$string['change_course_nochange']          = 'لا توجد تغييرات مطلوبة على التسجيلات.';
$string['change_course_enrolled_log']      = 'تم التسجيل / التحديث';
$string['change_course_unenrolled_log']    = 'تم إلغاء التسجيل';
$string['change_role']                     = 'تغيير الأدوار';
$string['change_role_title']               = 'تغيير أدوار النظام';
$string['change_role_hint']                = 'تغيير أدوار المستخدم على مستوى الموقع';
$string['change_role_intro']               = 'الأدوار المعينة بالفعل للمستخدم على مستوى الموقع محددة مسبقًا. ألغِ تحديد دور لإزالته، أو حدد دورًا لتعيينه. هذا يدير الأدوار على مستوى الموقع فقط - الأدوار المعينة داخل الكورسات الفردية لا تتأثر.';
$string['change_role_save']                = 'حفظ الأدوار';
$string['change_role_none']                = 'لا توجد أدوار.';
$string['change_role_success']             = 'تم تحديث الأدوار لـ {$a}.';
$string['change_role_nochange']            = 'لا توجد تغييرات مطلوبة على الأدوار.';
$string['bulk_change_course']              = 'تغيير الكورسات';
$string['bulk_change_course_title']        = 'تغيير تسجيلات الكورسات جماعيًا';
$string['bulk_change_course_intro']        = 'تم تحديد {$a} من المستخدمين. كل كورس بالأسفل يبدأ غير محدد - الكورسات التي تحددها (بأيامها ودورها) تحل محل تسجيلات الكورسات الحالية لكل المستخدمين المحددين: سيتم تسجيل كل مستخدم في الكورسات المحددة فقط وإلغاء تسجيله من كل كورس آخر.';
$string['bulk_change_course_success']      = 'تم تحديث تسجيلات الكورسات لـ {$a} من المستخدمين.';
$string['bulk_change_course_save']         = 'تطبيق على {$a} من المستخدمين';
$string['bulk_change_role']                = 'تغيير الأدوار';
$string['bulk_change_role_title']          = 'تغيير الأدوار جماعيًا';
$string['bulk_change_role_intro']          = 'تم تحديد {$a} من المستخدمين. كل دور بالأسفل يبدأ غير محدد - الأدوار التي تحددها تحل محل الأدوار الحالية على مستوى الموقع لكل المستخدمين المحددين: سيتم تعيين الأدوار المحددة فقط وإزالة كل دور آخر على مستوى الموقع.';
$string['bulk_change_role_success']        = 'تم تحديث الأدوار لـ {$a} من المستخدمين.';
$string['bulk_change_role_save']           = 'تطبيق على {$a} من المستخدمين';

// ================================================
// v3.8.0 - إعداد الأدوار المستثناة (يحل محل خيارَي
// استثناء المديرين / استثناء المعلمين القديمين).
// ================================================
$string['excludedroles']                   = 'الأدوار المستثناة';
$string['excludedroles_desc']              = 'المستخدمون الذين لديهم أي من الأدوار المحددة مستثنون من قيود تسجيل الدخول بالأجهزة (يمكنهم تسجيل الدخول من أي عدد من الأجهزة). يشير "المديرون (مديرو الموقع)" إلى الحسابات المدرجة في إدارة الموقع > الأمان > مديرو الموقع. اضغط مع الاستمرار على Ctrl (أو Cmd) ثم انقر لتحديد عدة أدوار أو إلغاء تحديدها.';
$string['excludedroles_admins']            = 'المديرون (مديرو الموقع)';

// ================================================
// v3.9.0 - دليل المستخدمين والبحث.
// ================================================
$string['usersearch_placeholder']          = 'ابحث بالاسم أو البريد الإلكتروني أو اسم المستخدم أو الدور (مثل teacher) أو الرقم الجامعي (Uni_ID) أو الهاتف أو المؤسسة أو أي حقل في الملف الشخصي...';
