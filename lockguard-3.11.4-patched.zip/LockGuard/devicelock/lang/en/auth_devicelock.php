<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Language strings for Lock Guard plugin
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['pluginname'] = 'Lock Guard';
$string['auth_devicelockdescription'] = 'Restrict users to login from registered devices only';

// Plugin status
$string['enabled'] = 'Enable plugin';
$string['enabled_desc'] = 'Enable device-based login restrictions';
$string['pluginstatus'] = 'Plugin Status';
$string['plugindisabled'] = 'Plugin is disabled';
$string['disabled'] = 'Disabled';

// Device limits
$string['maxdevices'] = 'Maximum devices';
$string['maxdevices_desc'] = 'Maximum devices allowed per user. 0 means no devices are allowed at all.';
$string['max_allowed'] = 'Max Allowed';
$string['devices_remaining'] = 'Devices Remaining';

// Exclusions

// Registration
$string['autoregister'] = 'Auto-register first device';
$string['autoregister_desc'] = 'Automatically register first device';
$string['firstdeviceregistered'] = 'First device registered successfully';
$string['newdeviceregistered'] = 'New device registered successfully';
$string['deviceregisteredinfo'] = 'Your device has been registered successfully. You must log in from the same device and browser each time. If any problems arise, contact the administrator.';
$string['existingdevice'] = 'Logged in from registered device. Continue using this device and browser for future logins.';

// Notifications
$string['sendnotifications'] = 'Send notifications';
$string['sendnotifications_desc'] = 'Send email notifications for device registrations and blocks';

// Error messages
$string['devicenotallowed'] = 'This account is already linked to another device. Please log in from your registered device. In case of any problem, contact support via Telegram: https://t.me/Medprep_Support';
$string['deviceblockedmessage'] = 'This device has been blocked by administrator. In case of any problem, contact support via Telegram: https://t.me/Medprep_Support';
$string['error'] = 'Error';
$string['usernotfound'] = 'User not found';
$string['unknown'] = 'Unknown';

// Success messages
$string['devicesreset'] = 'Devices reset successfully';
$string['deviceblocked'] = 'Device blocked successfully';
$string['deviceunblocked'] = 'Device unblocked successfully';
$string['userblocked'] = 'User blocked successfully';
$string['userunblocked'] = 'User unblocked successfully';
$string['reset_success'] = 'All devices reset successfully! User has been logged out.';
$string['block_success'] = 'Device blocked successfully! User has been logged out.';
$string['userblock_success'] = 'User blocked successfully! All devices deleted and user logged out.';

// Reset notification
$string['deviceresetdone'] = 'Device resets have been performed on this account. This device is now registered as your primary device. Continue using this device and browser for future logins.';

// NEW STRINGS FOR FIXED FEATURES:
// Device reset message (exact text as requested)
$string['deviceresetmessage'] = 'Device resets have been performed on this account.';
// First device registration message (exact text as requested)
$string['firstdevicemessage'] = 'Your device has been registered. You log in from the same device and browser each time, and you cannot change the device. If any problems arise, contact the administrator.';

// Dashboard strings
$string['managedevices'] = 'Device Management';
$string['settings'] = 'Settings';
$string['refresh'] = 'Refresh';
$string['refreshdashboard'] = 'Refresh Dashboard';

// NEW: Reset all users devices
$string['resetallusers'] = 'Reset All Users Devices';
$string['confirmresetallusers'] = 'Are you sure you want to reset all devices for all users?';
$string['confirm_reset_all_users'] = 'Reset All Users Devices';
$string['resetalluserssuccess'] = 'All users devices reset successfully!';

// Statistics
$string['totalusers'] = 'Total Users';
$string['totaldevices'] = 'Total Devices';
$string['totaldevicescount'] = 'Total Active Devices';

// Search
$string['searchbyemail'] = 'Search by email or name';
$string['search'] = 'Search';
$string['clear'] = 'Clear';

// User listing
$string['userslist'] = 'Users List';
$string['fullname'] = 'Full Name';
$string['email'] = 'Email';
$string['username'] = 'Username';
$string['userid'] = 'User ID';
$string['nousersfound'] = 'No users found';
$string['backtolist'] = 'Back to List';

// Device listing
$string['devicedetails'] = 'Device Details';
$string['devicefingerprint'] = 'Device Fingerprint';
$string['deviceinfo'] = 'Device Information';
$string['status'] = 'Status';
$string['active'] = 'Active';
$string['blocked'] = 'Blocked';
$string['lastlogin'] = 'Last Login';
$string['registeredon'] = 'Registered On';
$string['ipaddress'] = 'IP Address';
$string['actions'] = 'Actions';
$string['devices'] = 'Devices';
$string['active_devices'] = 'Active Devices';
$string['total_devices'] = 'Total Devices';
$string['noregistered'] = 'No Registered Devices';
$string['nodevicesfound'] = 'No devices found';

// Action buttons
$string['viewdevices'] = 'View Devices';
$string['blockdevice'] = 'Block Device';
$string['unblockdevice'] = 'Unblock Device';
$string['blockuser'] = 'Block User';
$string['unblockuser'] = 'Unblock User';
$string['resetdevices'] = 'Reset Devices';

// Confirmation dialogs
$string['confirmblockdevice'] = 'Are you sure you want to block this device?';
$string['confirmblockuser'] = 'Are you sure you want to block this user?';
$string['confirmresetdevices'] = 'Are you sure you want to reset all devices?';
$string['confirm_reset_devices'] = 'Reset All Devices';
$string['confirm_block_device'] = 'Block This Device';
$string['confirm_block_user'] = 'Block This User';
$string['action_warning'] = 'This action cannot be undone!';

// Device information messages
$string['device_info_message'] = 'Your device information:';
$string['device_browser'] = 'Browser';
$string['device_os'] = 'Operating System';
$string['device_screen'] = 'Screen Resolution';
$string['device_timezone'] = 'Timezone';
$string['device_language'] = 'Language';

// Login instructions
$string['login_instructions'] = 'For security, you must always use the same device and browser. Changing devices or browsers will require administrator approval.';
$string['contact_admin'] = 'If you need to use a different device, please contact the administrator.';

// Admin instructions
$string['admin_instructions'] = 'Use this dashboard to manage user devices. You can view registered devices, reset all devices for a user, or block specific devices.';
$string['reset_instructions'] = 'Resetting devices will delete all registered devices and log the user out from all sessions. The user will need to register a new device on next login.';
$string['block_instructions'] = 'Blocking a device will delete that specific device and log the user out. Other registered devices will remain active.';
$string['resetall_instructions'] = 'Resetting all users devices will delete all registered devices for ALL users and log ALL users out from all sessions. All users will need to register new devices on next login.';

// Log messages
$string['log_device_registered'] = 'Device registered';
$string['log_device_blocked'] = 'Device blocked';
$string['log_devices_reset'] = 'All devices reset';
$string['log_user_blocked'] = 'User blocked';
$string['log_login_blocked'] = 'Login blocked - device not allowed';
$string['log_login_success'] = 'Login successful from registered device';
$string['log_all_users_reset'] = 'All users devices reset';

// Event strings
$string['eventdeviceaction'] = 'Device action performed';
$string['eventdeviceregistered'] = 'Device registered';
$string['eventdeviceblocked'] = 'Device blocked';
$string['eventdevicesreset'] = 'All devices reset';
$string['eventuserblocked'] = 'User blocked';
$string['eventallusersreset'] = 'All users devices reset';

// Privacy strings
$string['privacy:metadata:auth_devicelock_devices'] = 'Information about devices registered for user login';
$string['privacy:metadata:auth_devicelock_devices:userid'] = 'The ID of the user who owns the device';
$string['privacy:metadata:auth_devicelock_devices:device_fingerprint'] = 'Unique fingerprint of the device';
$string['privacy:metadata:auth_devicelock_devices:device_info'] = 'Information about the device (browser, OS, screen resolution)';
$string['privacy:metadata:auth_devicelock_devices:status'] = 'Status of the device (active/blocked)';
$string['privacy:metadata:auth_devicelock_devices:last_login'] = 'Timestamp of last login from this device';
$string['privacy:metadata:auth_devicelock_devices:user_agent'] = 'Browser user agent string';
$string['privacy:metadata:auth_devicelock_devices:screen_resolution'] = 'Screen resolution of the device';
$string['privacy:metadata:auth_devicelock_devices:ip_address'] = 'IP address used for login';

$string['privacy:metadata:auth_devicelock_logs'] = 'Log of device-related actions';
$string['privacy:metadata:auth_devicelock_logs:userid'] = 'The ID of the user affected by the action';
$string['privacy:metadata:auth_devicelock_logs:device_fingerprint'] = 'Fingerprint of the device involved';
$string['privacy:metadata:auth_devicelock_logs:action'] = 'Type of action performed';
$string['privacy:metadata:auth_devicelock_logs:ip_address'] = 'IP address where action was performed';
$string['privacy:metadata:auth_devicelock_logs:user_agent'] = 'Browser user agent for the action';
$string['privacy:metadata:auth_devicelock_logs:timestamp'] = 'When the action occurred';
$string['privacy:metadata:auth_devicelock_logs:details'] = 'Additional details about the action';
$string['privacy:metadata:auth_devicelock_user_scores'] = 'The persistent per-user security score';
$string['privacy:metadata:auth_devicelock_user_scores:userid'] = 'The ID of the user the score belongs to';
$string['privacy:metadata:auth_devicelock_user_scores:score'] = 'The current security score (0-100)';
$string['privacy:metadata:auth_devicelock_user_scores:violation_count'] = 'How many violations have been recorded';
$string['privacy:metadata:auth_devicelock_user_scores:last_violation'] = 'When the last violation occurred';
$string['privacy:metadata:auth_devicelock_user_scores:last_regain'] = 'When points were last regained';
$string['privacy:metadata:auth_devicelock_user_scores:custom_regain'] = 'Whether a custom regain rate is set for this user';
$string['privacy:metadata:auth_devicelock_user_scores:regain_amount'] = 'Points regained each time (custom setting)';
$string['privacy:metadata:auth_devicelock_user_scores:regain_interval'] = 'Seconds between regains (custom setting)';
$string['privacy:metadata:auth_devicelock_user_scores:updated_at'] = 'When the score was last updated';

// Capability strings
$string['auth/devicelock:managedevices'] = 'Manage user devices';
$string['auth/devicelock:viewdevices'] = 'View user devices';

// ============================================================
// Feature 4: Free-text maxdevices description update
// ============================================================
$string['maxdevices_desc'] = 'Maximum number of devices a user is allowed to register. Enter any whole number (e.g. 1, 2, 5, 10). 0 deliberately means no devices are allowed at all, including the first one - every sign-in will be blocked.';

// ============================================================
// Feature 1: Customizable Email Template Settings
// ============================================================
$string['emailtemplates_heading'] = 'Automated Email Templates';
$string['emailtemplates_heading_desc'] = 'Customize the subject and body of automated emails sent on specific device events. Available placeholders: {firstname}, {fullname}, {username}, {email}, {sitename}, {siteurl}, {devicename}, {ip}, {datetime}, {maxdevices}, {devicecount}.';
$string['email_placeholders_desc'] = 'You may use the following placeholders: {firstname}, {fullname}, {username}, {email}, {sitename}, {siteurl}, {devicename}, {ip}, {datetime}, {maxdevices}, {devicecount}.';

// Email: New Device Registered
$string['email_newdevice_subject']         = 'New Device Registered – Subject';
$string['email_newdevice_subject_desc']    = 'Subject line for the email sent when a new device is successfully registered.';
$string['email_newdevice_subject_default'] = 'Security Alert: New device registered on {sitename}';
$string['email_newdevice_body']            = 'New Device Registered – Body';
$string['email_newdevice_body_default']    = "Dear {firstname},\n\nA new device has just been registered to your account on {sitename}.\n\nDevice: {devicename}\nIP Address: {ip}\nDate & Time: {datetime}\n\nDevice Usage: {devicecount} of {maxdevices} device(s) registered.\n\nIf this was not you, please contact the administrator immediately.\n\nKind regards,\nThe {sitename} Team";

// Email: Device Blocked
$string['email_blocked_subject']         = 'Device Blocked – Subject';
$string['email_blocked_subject_desc']    = 'Subject line for the email sent when an admin blocks one of the user\'s devices.';
$string['email_blocked_subject_default'] = 'Security Alert: A device has been removed from your account on {sitename}';
$string['email_blocked_body']            = 'Device Blocked – Body';
$string['email_blocked_body_default']    = "Dear {firstname},\n\nAn administrator has removed a device from your account on {sitename}.\n\nDevice: {devicename}\nDate & Time: {datetime}\n\nIf you believe this was done in error, please contact the administrator.\n\nKind regards,\nThe {sitename} Team";

// Email: Devices Reset
$string['email_reset_subject']         = 'Devices Reset – Subject';
$string['email_reset_subject_desc']    = 'Subject line for the email sent when an admin resets all devices for the user.';
$string['email_reset_subject_default'] = 'Security Alert: All devices have been reset on {sitename}';
$string['email_reset_body']            = 'Devices Reset – Body';
$string['email_reset_body_default']    = "Dear {firstname},\n\nAll registered devices on your account at {sitename} have been reset by an administrator.\n\nDate & Time: {datetime}\n\nYou will be able to register a fresh device on your next login. If you have any questions, please contact support.\n\nKind regards,\nThe {sitename} Team";

// ============================================================
// Feature 2: Custom Admin-to-User Email UI
// ============================================================
$string['sendemail']              = 'Send Custom Email';
$string['sendemail_heading']      = 'Send a Custom Email to This User';
$string['sendemail_subject']      = 'Subject';
$string['sendemail_body']         = 'Message';
$string['sendemail_submit']       = 'Send Email';
$string['sendemail_success']      = 'Email sent successfully to {$a}.';
$string['sendemail_failure']      = 'Failed to send email to {$a}. Please check the site mail configuration.';
$string['sendemail_empty_subject'] = 'Please enter a subject.';
$string['sendemail_empty_body']    = 'Please enter a message body.';

// ============================================================
// Feature 3: Per-User Device Limit UI
// ============================================================
$string['userlimit_heading']       = 'Per-User Device Limit';
$string['userlimit_label']         = 'Custom Device Limit';
$string['userlimit_desc']          = 'Override the global device limit for this specific user. Leave blank or set to 0 to use the global limit ({$a} devices).';
$string['userlimit_save']          = 'Save Limit';
$string['userlimit_cleared']       = 'Custom device limit cleared. This user will now use the global limit.';
$string['userlimit_saved']         = 'Custom device limit of {$a} device(s) saved for this user.';
$string['userlimit_invalid']       = 'The device limit must be a whole number greater than zero.';
$string['userlimit_current']       = 'Effective limit: {$a} device(s)';

// Purge Data / Danger Zone strings
$string['purge_data_title']        = 'Danger Zone: Purge Plugin Data';
$string['purge_data_desc']         = 'This will permanently delete all registered devices, session tracking data, logs, and configurations associated with the Lock Guard plugin. This action cannot be undone.';
$string['purge_data_btn']          = 'Purge All Plugin Data';

// Browser Limit strings
$string['maxbrowsers']             = 'Maximum Browsers per Device';
$string['maxbrowsers_desc']        = 'The maximum number of distinct browser families (e.g. Chrome, Firefox, Edge, Safari) allowed on each authorized device across all users. Set to 0 for unlimited browsers on the authorized device.';
$string['userbrowserlimit_label']  = 'Custom Browser Limit per Device';
$string['userbrowserlimit_desc']   = 'Override the global browser limit per device for this specific user. Set to 0 or leave blank to use the global limit ({$a}).';
$string['userbrowserlimit_saved']  = 'Custom browser limit of {$a} browser(s) per device saved for this user.';
$string['userbrowserlimit_cleared']= 'Custom browser limit cleared. This user will now use the global browser limit.';
$string['browserlimitreached']     = 'Browser limit reached: You are allowed to use up to {$a} browser(s) on your registered device. Please use your previously authorized browser.';
$string['reset_device_browsers']   = 'Reset Browsers';
$string['reset_device_browsers_confirm'] = 'Are you sure you want to reset the authorized browsers for this device? The user will be able to register a new browser upon their next login.';
$string['reset_device_browsers_success'] = 'Browsers for device #{$a} successfully reset.';
$string['reset_all_browsers']            = 'Reset All Browsers';
$string['confirm_reset_user_browsers']   = 'Are you sure you want to reset all browsers for this user? This will log the user out of all browsers while preserving their registered device records. Browsers will re-register upon next login on the same devices.';
$string['reset_user_browsers_success']   = 'All browser data for user {$a} has been reset and the user has been logged out of all sessions. Device records have been preserved.';

// Temporary Password Feature
$string['generate_temp_password']        = 'Generate Temporary Password';
$string['temppassword_card_title']       = 'Temporary Password Generated';
$string['temppassword_generated_for']    = 'Temporary password successfully generated for {$a}';
$string['copy_password']                 = 'Copy Password';
$string['copied']                        = 'Copied!';
$string['temppassword_user_notice']      = 'Notice: You have logged in using a temporary password. In the (Current password) field, enter the temporary password provided by the administrator, then enter your new password twice below.';
$string['temppassword_current_help']     = 'The temporary password provided by admin';

// Scheduled Log Cleanup & Registration Flow
$string['task_cleanup_logs']             = 'Clean up old device lock logs (older than 3 weeks)';
$string['emailconfirmed_login_intro']    = 'Your email has been confirmed! Please log in to register your device and access the platform.';
$string['purge_success_uninstall_ready'] = 'All Lock Guard (auth_devicelock) data has been completely wiped. The plugin is disabled and appears below under "Additional plugins" where you can click "Uninstall" to remove it or update it cleanly.';

// ============================================================
// Copy User Details Feature (copies username + a fresh temp password)
// ============================================================
$string['copy_user_details']              = 'Copy User Details';
$string['copydetails_card_title']        = 'User Details Copied';
$string['copydetails_generated_for']     = 'Login details for {$a}';
$string['copydetails_notice']            = 'For security, Moodle never stores plain-text passwords. A new temporary password has just been generated for this account and set as the current password. Both the username and the new temporary password have been copied to your clipboard so you can hand them to the user.';
$string['copydetails_username_label']    = 'Username';
$string['copydetails_password_label']    = 'Temporary Password';
$string['copy_both']                     = 'Copy Username &amp; Password';
$string['copydetails_copied_title']      = 'Copied to clipboard!';
$string['copydetails_copied_body']       = 'Username and temporary password are in your clipboard.';
$string['copydetails_manual']            = 'If the automatic copy failed, click the button below to copy manually.';
$string['copydetails_success']           = 'Login details (username + new temporary password) copied to clipboard for {$a}.';
$string['copydetails_return']            = 'Return';

// ============================================================
// Delete User Account Feature (permanently removes the Moodle user)
// ============================================================
$string['delete_user_account']           = 'Delete User Account';
$string['deleteuser_confirm_title']      = 'CONFIRM PERMANENT ACCOUNT DELETION';
$string['deleteuser_confirm_intro']      = 'You are about to PERMANENTLY DELETE the following user account:';
$string['deleteuser_confirm_name']       = 'Name';
$string['deleteuser_confirm_username']   = 'Username';
$string['deleteuser_confirm_email']      = 'Email';
$string['deleteuser_confirm_will']       = 'This action will immediately:';
$string['deleteuser_confirm_list']       = 'Delete the user account from the Moodle database and mark it as deleted|Remove ALL Lock Guard data for this user (registered devices, browser/session tracking, plugin preferences and security logs)|Force-logout the user from every active session|Remove all role assignments, enrolments and context data owned by this account|Anonymise the username so it can never be reused to log in';
$string['deleteuser_confirm_warning']    = 'This action CANNOT be undone. The account and all of its information will be gone forever.';
$string['deleteuser_self_error']         = 'For your safety, you cannot delete your own account from here.';
$string['deleteuser_admin_error']        = 'For safety, site administrator accounts cannot be deleted from this screen. Please use Moodle\'s standard Site administration > Users management instead.';
$string['deleteuser_guest_error']        = 'The guest account cannot be deleted.';
$string['deleteuser_notfound']           = 'User not found — the account may have already been deleted.';
$string['deleteuser_success']            = 'The user account "{$a}" has been permanently deleted and all associated information removed from Moodle.';
$string['deleteuser_confirm_btn']        = 'Yes, Delete This Account Forever';
$string['deleteuser_log_label']          = 'Account Deleted';
$string['copydetails_log_label']         = 'Details Copied';

// ============================================================
// Bulk Delete Users Feature
// ============================================================
$string['bulk_delete_selected']        = 'Delete Selected';
$string['bulk_delete_users']           = 'Delete Selected Users';
$string['bulk_delete_confirm_title']   = 'CONFIRM BULK ACCOUNT DELETION';
$string['bulk_delete_confirm_intro']   = 'You are about to PERMANENTLY DELETE the following {$a} user account(s):';
$string['bulk_delete_confirm_warning'] = 'This action CANNOT be undone. Every listed account and ALL of its information will be gone forever.';
$string['bulk_delete_confirm_btn']     = 'Yes, Delete All Selected Accounts Forever';
$string['bulk_delete_none_selected']  = 'No users were selected. Tick the checkboxes next to the users you want to delete first.';
$string['bulk_delete_none_valid']      = 'None of the selected users can be deleted from here (they are either yourself, the guest account, or a site administrator).';
$string['bulk_delete_skipped_label']   = 'Accounts that will be SKIPPED for safety (yourself, guest, site admin):';
$string['bulk_delete_result_deleted']  = 'Deleted {$a->deleted} account(s).';
$string['bulk_delete_result_skipped']  = 'Skipped {$a->skipped} account(s) for safety (self / guest / site admin).';
$string['bulk_delete_result_gone']     = '{$a} account(s) were already gone.';
$string['bulk_select_all']             = 'Select All';
$string['bulk_select_visible']         = 'Select Visible';
$string['bulk_select_all_hint']        = 'Select every user matching the current search and filters (all pages)';
$string['bulk_select_visible_hint']    = 'Select only the users shown on the current page';
$string['bulk_clear_selection']        = 'Clear Selection';
$string['bulk_actions']                = 'Bulk Actions';
$string['bulk_selected_count']         = '{$a} selected';

// ============================================================
// Export Features (CSV)
// ============================================================
$string['export_users_csv']            = 'Export Users as CSV';
$string['export_logs_csv']             = 'Export Logs as CSV';
$string['export_no_data']             = 'No data available to export.';
$string['export_users_filename']      = 'lockguard_users';
$string['export_logs_filename']       = 'lockguard_logs';
$string['export_col_order']           = 'Order';
$string['export_col_fullname']        = 'Full Name';
$string['export_col_username']        = 'Username';
$string['export_col_email']           = 'Email';
$string['export_col_auth']            = 'Auth Method';
$string['export_col_devices']        = 'Active Devices';
$string['export_col_maxdevices']     = 'Max Devices';
$string['export_col_type']           = 'User Type';
$string['export_col_suspended']      = 'Suspended';
$string['export_col_confirmed']      = 'Confirmed';
$string['export_col_uni_id']         = 'University ID';
$string['export_col_phone']          = 'Phone';
$string['export_col_institution']    = 'Institution';
$string['export_col_department']     = 'Department';
$string['export_col_idnumber']      = 'ID Number';

// ============================================================
// Clear Logs Feature
// ============================================================
$string['clear_logs']                 = 'Clear All Logs';
$string['clear_logs_confirm']         = 'Are you sure you want to PERMANENTLY delete ALL Lock Guard security logs? This cannot be undone.';
$string['clear_logs_success']         = 'All Lock Guard security logs have been deleted.';
$string['clear_logs_btn']            = 'Clear All Logs';
$string['bulk_delete_log_label']     = 'Bulk Account Deletion';
$string['bulk_delete_capped']        = 'Bulk delete capped at {$a->capped} accounts per batch ({$a->remaining} were not processed — run another batch for the rest).';

// ============================================================
// Bulk Copy User Details (CSV) — cohort onboarding helper
// ============================================================
$string['bulk_copy_details']           = 'Copy Details (CSV)';
$string['bulk_copy_details_title']     = 'Bulk Copy User Details';
$string['bulk_copy_details_intro']     = 'A fresh temporary password has been generated for EACH selected user and set as their current password. A CSV file with Full Name, Username, Password and Email is being downloaded so you can distribute the credentials securely.';
$string['bulk_copy_details_warning']   = 'Each selected account will have its password RESET to a new single-use temporary password (the user must change it on next login). Confirm only if you intend to hand out these credentials.';
$string['bulk_copy_details_none']      = 'No users were selected. Tick the checkboxes next to the users first.';
$string['bulk_copy_details_capped']    = 'CSV export capped at {$a} users per batch. Run another batch for the rest.';
$string['bulk_copy_details_filename']  = 'lockguard_user_credentials';
$string['bulk_copy_details_log_label'] = 'Bulk Details Copied';
$string['bulk_copy_details_col_fullname'] = 'Full Name';
$string['bulk_copy_details_col_username'] = 'Username';
$string['bulk_copy_details_col_password'] = 'Temporary Password';
$string['bulk_copy_details_col_email']    = 'Email';
$string['bulk_copy_details_col_auth']     = 'Auth Method';

// ============================================================
// Per-User Audit Timeline (dedicated security-history page)
// ============================================================
$string['audit_timeline']               = 'Audit Timeline';
$string['audit_timeline_for']           = 'Security audit timeline for {$a}';
$string['audit_timeline_empty']         = 'No security events recorded for this user yet.';
$string['audit_timeline_export']        = 'Export This User\'s Logs';
$string['audit_timeline_filter']        = 'Filter by event type';
$string['audit_timeline_count']         = '{$a} event(s)';
$string['audit_timeline_all_events']    = 'All events';
$string['audit_timeline_back']          = 'Back to User Details';

// ============================================================
// Security Snapshot trend labels
// (used by the weekly Security Snapshot page; the dashboard
// "Security Activity Trends" card was removed in v3.4.2)
// ============================================================
$string['security_trends_blocked_logins'] = 'Blocked Logins';
$string['security_trends_device_regs']  = 'Device Registrations';
$string['security_trends_deletions']    = 'Account Deletions';

// ============================================================
// CSV Import — bulk user creation with device-lock auth
// ============================================================
$string['import_users_csv']             = 'Import Users (CSV)';
$string['import_users_title']           = 'Bulk Import Users from CSV';
$string['import_users_intro']           = 'Upload a CSV file to create multiple user accounts at once, pre-configured to use the Lock Guard (device-lock) authentication method. Each new user will be suspended-free, confirmed, and forced to change their password on first login.';
$string['import_users_template']       = 'Download CSV template';
$string['import_users_choose']          = 'Choose CSV file';
$string['import_users_submit']         = 'Import &amp; Create Users';
$string['import_users_confirm']        = 'Are you sure you want to create the accounts listed below? This cannot be undone.';
$string['import_users_none']           = 'No valid rows found in the uploaded CSV. Required columns: firstname, lastname, email, username. Optional: password.';
$string['import_users_result_created'] = 'Created {$a->created} user account(s).';
$string['import_users_result_skipped'] = 'Skipped {$a->skipped} row(s) (duplicate username/email or missing required fields).';
$string['import_users_result_errors']  = 'Failed to create {$a->errors} row(s).';
$string['import_users_preview']        = 'Preview — first 25 rows';
$string['import_users_col_firstname']  = 'firstname';
$string['import_users_col_lastname']   = 'lastname';
$string['import_users_col_email']      = 'email';
$string['import_users_col_username']   = 'username';
$string['import_users_col_password']   = 'password';
$string['import_users_col_idnumber']   = 'idnumber (optional)';
$string['import_users_log_label']      = 'Bulk User Import';
$string['import_users_capped']         = 'Import capped at {$a} rows per batch. Run another import for the rest.';
$string['import_users_file_too_big']   = 'The uploaded file is larger than {$a}. Please split it into smaller batches.';
$string['import_users_file_badtype']   = 'Only .csv or .txt files are accepted.';

// ============================================================
// Typed confirmation phrase — guard for destructive batches > 50 users
// ============================================================
$string['confirm_phrase_label']        = 'Type the word DELETE to confirm';
$string['confirm_phrase_mismatch']     = 'The confirmation phrase did not match. Nothing was changed.';
$string['confirm_phrase_required']     = 'A destructive batch of {$a} users requires you to type the word DELETE to proceed.';

// ============================================================
// Per-Device Audit Timeline (dedicated security-history page for one device)
// ============================================================
$string['device_audit_timeline']          = 'Device Audit Timeline';
$string['device_audit_timeline_for']      = 'Security audit timeline for device {$a}';
$string['device_audit_timeline_empty']    = 'No security events recorded for this device yet.';
$string['device_audit_timeline_export']   = 'Export This Device\'s Logs';
$string['device_audit_timeline_count']    = '{$a} event(s)';
$string['device_audit_timeline_back']     = 'Back to Devices';
$string['device_audit_no_device']         = 'No device fingerprint was supplied. Please open this page from the Devices tab.';

// ============================================================
// Scheduled cleanup task — prune orphaned device/session-tracking rows
// ============================================================
$string['task_prune_orphans']          = 'Prune orphaned Lock Guard device and session-tracking rows for users no longer in the Moodle user table';
$string['task_prune_orphans_done']     = 'Pruned {$a->devices} orphaned device row(s) and {$a->sessions} orphaned session-tracking row(s).';

// ============================================================
// Per-User Security Score (0-100 badge from 30-day log activity)
// ============================================================
$string['security_score']              = 'Security Score';
$string['security_score_label']        = 'Security Score';
$string['security_score_high']         = 'Excellent';
$string['security_score_good']         = 'Good';
$string['security_score_fair']         = 'Fair';
$string['security_score_poor']         = 'At Risk';
$string['security_score_critical']     = 'Critical';
$string['security_score_tooltip']     = 'Starts at 100% when the account is created. Every violation lowers it (blocked logins -10, unexpected devices -12, App Guard events -8 to -25, suspension -15, ban -40), and it slowly regains points over time after the last violation.';
$string['security_score_breakdown']    = 'Score breakdown';

// ============================================================
// CSV Import — dry-run mode (validate only, no user creation)
// ============================================================
$string['import_users_dryrun']         = 'Dry run (validate only, do not create accounts)';
$string['import_users_dryrun_label']   = 'Dry run';
$string['import_users_dryrun_result']  = 'Dry run complete: {$a->would_create} account(s) would be created, {$a->would_skip} row(s) would be skipped. No changes were made.';
$string['import_users_dryrun_badge']   = 'DRY RUN';

// ============================================================
// Security Score Distribution mini-chart (dashboard card)
// ============================================================
$string['score_distribution']          = 'Security Score Distribution';
$string['score_distribution_desc']    = 'How many users currently fall into each risk band (based on the persistent security score: starts at 100%, lowered by violations, regained over time).';
$string['score_distribution_total']    = '{$a} users scored';
$string['score_distribution_empty']   = 'No user scores yet — every user gets a score automatically.';

// ============================================================
// CSV Import — password-policy pre-flight (dry-run mode)
// ============================================================
$string['import_users_pwcheck_ok']      = 'Password policy check: all provided passwords pass the site policy.';
$string['import_users_pwcheck_fail']    = 'Password policy check: {$a->failed} of {$a->total} provided password(s) would be rejected by the site policy.';
$string['import_users_pwcheck_row']     = 'Row {$a->row} ({$a->username}): {$a->reason}';

// ============================================================
// Recalculate All Scores (admin action) + click-to-filter
// ============================================================
$string['recalculate_scores']          = 'Recalculate All Scores';
$string['recalculate_scores_btn']      = 'Recalculate All Scores';
$string['recalculate_scores_confirm'] = 'Refresh the security score of every user? Missing score rows are created (at 100%) and every regain that is already due is applied. This may take a few seconds on large sites.';
$string['recalculate_scores_done']    = 'Processed {$a} user(s): created missing score rows (at 100%) and applied every due regain.';
$string['recalculate_scores_none']    = 'No users found — nothing to do.';
$string['score_band_filter']           = 'Score band';
$string['score_band_filter_all']       = 'All bands';
$string['score_band_filter_hint']      = 'Filter the directory by security-score band';

// ============================================================
// Weekly security-snapshot scheduled email digest
// ============================================================
$string['task_weekly_snapshot']        = 'Weekly security snapshot email digest to site administrators';
$string['snapshot_subject']            = 'Weekly Lock Guard security snapshot for {$a}';
$string['snapshot_intro']              = 'Here is your weekly Lock Guard security summary for {$a}.';
$string['snapshot_section_trends']     = 'Activity trends (last 7 days)';
$string['snapshot_section_distribution']= 'Security score distribution';
$string['snapshot_section_toprisk']    = 'Top 5 at-risk users (lowest scores)';
$string['snapshot_no_data']            = 'No security events recorded in the last 7 days.';
$string['snapshot_sent']               = 'Weekly security snapshot emailed to {$a} administrator(s).';
$string['snapshot_no_admins']          = 'No administrators with valid email found — snapshot not sent.';

// ============================================================
// Security Snapshot settings + in-browser page
// ============================================================
$string['snapshot_heading']            = 'Security Snapshot Email';
$string['snapshot_heading_desc']       = 'A weekly email digest sent to every site administrator summarising Lock Guard activity (7-day trends, score distribution, top-5 at-risk users). The email is sent by the weekly_snapshot scheduled task — enable it here, then make sure Moodle cron is running.';
$string['snapshot_enabled']            = 'Enable weekly snapshot email';
$string['snapshot_enabled_desc']       = 'When enabled, the weekly_snapshot scheduled task sends a security digest to every site admin every Monday at 06:00.';
$string['snapshot_page']               = 'Security Snapshot';
$string['snapshot_page_title']         = 'In-Browser Security Snapshot';
$string['snapshot_send_test']          = 'Send Test Email Now';
$string['snapshot_send_test_confirm']  = 'Send a test snapshot email to your own admin account right now?';
$string['snapshot_test_sent']          = 'Test snapshot email sent to {$a}.';
$string['snapshot_test_no_self']       = 'Your admin account has no valid email address — cannot send a test.';
$string['snapshot_disabled']           = 'The weekly snapshot email is currently disabled in the plugin settings. Enable it to receive weekly digests.';
$string['snapshot_last_sent']          = 'Last weekly snapshot sent: {$a}';
$string['snapshot_test_badge']         = 'TEST';

// ============================================================
// Score-history sparkline + next-snapshot countdown + nonplugin click-to-filter
// ============================================================
$string['score_history']               = 'Score History (30 days)';
$string['score_history_empty']        = 'No score changes yet — the sparkline appears after the first violation, regain or manual change.';
$string['snapshot_next_due']           = 'Next weekly snapshot due: {$a}';
$string['snapshot_next_due_unknown']   = 'Next weekly snapshot due: unknown (run the task once to seed the schedule).';
$string['score_band_filter_np_hint']   = 'Click a band bar to filter this directory by score band';

// ============================================================
// Copy Details — selection options
// ============================================================
$string['copy_option_info']             = 'Username + Email only';
$string['copy_option_info_desc']        = 'Copy the username and email address. No password is changed.';
$string['copy_option_password']         = 'Username + Email + New Temporary Password';
$string['copy_option_password_desc']    = 'Generate a new temporary password, set it on the account, and copy all three fields. The user must change it on next login.';

// ============================================================
// Ban User feature
// ============================================================
$string['ban_user']                     = 'Ban User';
$string['ban_user_title']               = 'Ban User Account';
$string['ban_user_intro']               = 'Banning this user will block them from logging in. Their IP and device will also be blocked. The ban message will be shown on the login page.';
$string['ban_reason_label']             = 'Ban Reason (optional)';
$string['ban_reason_desc']              = 'If provided, this reason will be shown on the login page below the ban message.';
$string['ban_message_default']          = 'You are banned from using this site!';
$string['ban_reason_prefix']            = 'Reason:';
$string['ban_confirm_btn']              = 'Ban This User';
$string['ban_success']                  = '{$a} has been banned.';
$string['unban_user']                   = 'Unban User';
$string['unban_success']                = '{$a} has been unbanned.';
$string['ban_status_banned']            = 'Banned';
$string['ban_status_active']            = 'Active';
$string['bulk_ban_selected']            = 'Ban Selected';
$string['bulk_unban_selected']          = 'Unban Selected';
$string['bulk_ban_title']               = 'Bulk Ban Users';
$string['bulk_ban_intro']               = 'The following {$a} user(s) will be banned from logging in.';
$string['bulk_ban_confirm_btn']         = 'Ban All Selected Users';
$string['bulk_ban_success']             = 'Banned {$a} user(s).';
$string['bulk_unban_success']           = 'Unbanned {$a} user(s).';
$string['ban_message_setting']          = 'Ban message';
$string['ban_message_desc']             = 'The message shown on the login page when a banned user tries to log in. If a ban reason is provided, it will be shown on a new line below this message as "Reason: <reason>".';
$string['ban_log_label']                = 'User Banned';
$string['unban_log_label']              = 'User Unbanned';
$string['bulk_ban_log_label']           = 'Bulk User Ban';

// ============================================================
// Quick Create User
// ============================================================
$string['quick_create_user']            = 'Quick Create User';
$string['quick_create_title']           = 'Quick Create a User Account';
$string['quick_create_intro']           = 'Create a single user account with device-lock authentication. Each field must be filled in, or tick its "Auto-generate" checkbox to have it generated for you. You can also assign roles and enrol the user into existing courses.';
$string['quick_create_username']        = 'Username';
$string['quick_create_firstname']      = 'First name';
$string['quick_create_lastname']       = 'Last name';
$string['quick_create_email']           = 'Email';
$string['quick_create_password']        = 'Password';
$string['quick_create_autogen']         = 'Auto-generate';
$string['quick_create_submit']          = 'Create User';
$string['quick_create_success']         = 'User "{$a}" created successfully.';
$string['quick_create_error']           = 'Failed to create user: {$a}';
$string['quick_create_exists']          = 'A user with that username or email already exists.';

// ============================================================
// Bulk Create Users
// ============================================================
$string['bulk_create_users']            = 'Bulk Create Users';
$string['bulk_create_title']            = 'Bulk Create User Accounts';
$string['bulk_create_intro']            = 'Create multiple user accounts at once. Usernames, emails and passwords are automatically numbered (e.g. user1, user2, ...). Each base field must be filled in, or tick its "Auto-generate" checkbox to have it generated for you.';
$string['bulk_create_count']            = 'Number of users to create';
$string['bulk_create_username_base']    = 'Username base';
$string['bulk_create_firstname_base']  = 'First name base';
$string['bulk_create_lastname_base']   = 'Last name base';
$string['bulk_create_email_base']       = 'Email base (the part before @)';
$string['bulk_create_email_domain']     = 'Email domain (the part after @)';
$string['bulk_create_password_base']    = 'Password base';
$string['bulk_create_roles']            = 'Roles to assign';
$string['bulk_create_custom_role']      = 'Custom role name (creates a new role if it does not exist)';
$string['bulk_create_submit']           = 'Preview & Create';
$string['bulk_create_conflict_title']   = 'Conflict Detected';
$string['bulk_create_conflict_intro']   = 'Some usernames or emails already exist. The numbering will start after the last conflicting number.';
$string['bulk_create_conflict_detail']  = 'Existing: {$a}';
$string['bulk_create_continue']         = 'Continue (skip conflicts)';
$string['bulk_create_cancel']           = 'Cancel';
$string['bulk_create_success']          = 'Created {$a->created} user(s).';
$string['bulk_create_numbering_auto']  = 'Existing accounts were detected — numbering for this batch automatically starts at "{$a}" so all requested users are created (nothing is skipped).';
$string['bulk_create_none']             = 'No users were created. Please review the settings and the messages above, then try again.';
$string['bulk_create_error_detail']     = 'User could not be created — {$a}';
$string['bulk_create_preview']          = 'Preview — first 10 users';
$string['bulk_create_log_label']        = 'Bulk User Creation';
$string['bulk_create_numbering_hint']   = 'Usernames: base1, base2, ... | Emails: base.1@domain, base.2@domain, ... | Passwords: base#1, base#2, ... | Names: the first name base is used as-is and the number is appended to the last name base (e.g. John Smith1, John Smith2, ...). Numbering always continues past existing accounts, so every requested user is always created.';

// ============================================================
// Shared create-user validation & course enrolment (v3.4.0)
// ============================================================
$string['createuser_field_required']    = 'The following field(s) cannot be left empty while their "Auto-generate" option is unchecked: {$a}';
$string['createuser_username_chars']   = 'Invalid username "{$a}". Moodle usernames may only contain lowercase letters, numbers, dots (.), hyphens (-), underscores (_) and @.';
$string['createuser_email_invalid']    = 'Invalid email address: "{$a}".';
$string['createuser_required_js']       = 'Please fill in this field, or tick its "Auto-generate" option.';
$string['enrol_courses_label']         = 'Enrol in courses (optional)';
$string['enrol_courses_hint']          = 'Select one or more existing courses. The new user(s) will be enrolled automatically when they are created.';
$string['enrol_select_all']            = 'Select all / none';
$string['enrol_search_courses']        = 'Search courses...';
$string['enrol_no_courses']            = 'No courses exist on this site yet.';
$string['enrol_course_hidden']         = 'hidden';
$string['enrol_role_label']            = 'Enrol as (course role)';
$string['enrol_duration_label']        = 'Enrolment duration (days)';
$string['enrol_duration_hint']         = '0 = unlimited.';
$string['enrol_success']               = 'User "{$a->user}" was enrolled in {$a->count} course(s).';
$string['enrol_bulk_success']          = 'A total of {$a} course enrolment(s) were created for the new users.';
$string['enrol_failed_course']         = 'Could not enrol into course "{$a->course}": {$a->error}';
$string['enrol_manual_disabled']       = 'Course enrolment was skipped: the "Manual enrolment" plugin is disabled on this site.';

// ============================================================
// v3.4.3 — User Directory quick type filter chips
// ============================================================
$string['ufilter_label']                = 'Filter';
$string['ufilter_all']                 = 'All Users';
$string['ufilter_banned']              = 'Banned';
$string['ufilter_unbanned']            = 'Unbanned';
$string['ufilter_suspended']           = 'Blocked';
$string['ufilter_active']              = 'Active';

// ============================================================
// v3.4.3 — "Created accounts" card (quick/bulk create credentials)
// ============================================================
$string['created_accounts_title']      = 'Accounts created';
$string['created_accounts_intro']     = 'Save these login details now — passwords are stored encrypted and will not be shown again.';
$string['created_col_name']           = 'Name';
$string['created_col_username']       = 'Username';
$string['created_col_email']          = 'Email';
$string['created_col_password']       = 'Password';
$string['created_copy_row']           = 'Copy username and password';
$string['created_copy_all']           = 'Copy all (CSV)';
$string['created_download_csv']       = 'Download CSV';

// ============================================================
// v3.4.4 — Expandable log event details
// ============================================================
$string['log_show_full']               = 'Show all';
$string['log_show_less']               = 'Show less';
$string['log_full_details']            = 'Full details';

// ============================================================
// Persistent Security Score (v3.5.0)
// ============================================================
$string['score_change']                = 'Change Score';
$string['score_change_title']          = 'Change Score';
$string['score_op']                    = 'Operation';
$string['score_op_increase']           = 'Increase by';
$string['score_op_decrease']           = 'Decrease by';
$string['score_op_set']                = 'Set to';
$string['score_op_reset']              = 'Reset to 100%';
$string['score_amount']                = 'Points';
$string['score_amount_set_lbl']        = 'New score (0-100)';
$string['score_amount_hint']           = 'For Increase / Decrease this is the number of points to add or remove; for Set it is the exact new score (0-100).';
$string['score_reason']                = 'Reason (optional)';
$string['score_reason_hint']           = 'e.g. Reviewed manually after talking to the student';
$string['score_decrease_note']         = 'A decrease is treated like a sanction: it restarts the regain timer and counts as a violation. Increases and exact sets do not affect the timer.';
$string['score_custom_regain']         = 'Use a custom regain setting for this user';
$string['score_custom_regain_desc']    = 'When enabled, this user regains score at their own rate instead of the global rate configured in the plugin settings.';
$string['score_regain_amount_lbl']     = 'Points regained';
$string['score_regain_every_lbl']      = 'Regain every';
$string['score_custom_remove_hint']    = 'Uncheck the box above to go back to using the global regain settings.';
$string['score_save']                  = 'Save Changes';
$string['score_changed_ok']            = 'Security score updated for {$a->name}: {$a->old}% → {$a->new}%.';
$string['score_changed_invalid']       = 'Unknown score operation — nothing was changed.';
$string['score_reset_ok']              = 'Security score reset to 100% for {$a} user(s).';
$string['bulk_reset_score']            = 'Reset Score';
$string['bulk_reset_score_hint']       = 'Reset the security score of every selected user to 100%';
$string['score_autoban_reason']        = 'Security score reached {$a}%';
$string['score_autoban_swept']         = 'Auto-ban threshold applied: {$a} user(s) at or below it were banned automatically.';
$string['users_per_page']              = 'Users per page';
$string['show_all_users']              = 'Show All';
$string['show_all_users_hint']         = 'Load every user on one page (temporary - refreshing the page returns to the default page size)';
$string['task_score_regain']           = 'Security score regain processing';
$string['score_stats_violations']      = 'Violations';
$string['score_stats_last_violation']  = 'Last violation';
$string['score_stats_never']           = 'Never';
$string['score_stats_regain']          = 'Regain';
$string['score_stats_global']          = 'global';
$string['score_stats_custom']          = 'custom';
$string['score_next_due']              = 'regain due now';
$string['score_next_in']               = 'next regain in {$a}';
$string['score_unit_seconds']          = 'Seconds';
$string['score_unit_minutes']          = 'Minutes';
$string['score_unit_hours']            = 'Hours';
$string['score_unit_days']             = 'Days';
$string['score_unit_weeks']            = 'Weeks';
$string['score_unit_months']           = 'Months';

// ================================================
// v3.8.0 - Change Course / Change Role (user action menu + bulk actions).
// ================================================
$string['change_course']                    = 'Change Course';
$string['change_course_title']             = 'Change Course Enrolments';
$string['change_course_hint']              = 'Enrol the user into courses or un-enroll them from courses';
$string['change_course_intro']             = 'Courses the user is already enrolled in are pre-checked. Uncheck a course to un-enroll the user from it; check a course to enrol the user (or update the enrolment) with the number of days and the role you choose.';
$string['change_course_course_col']        = 'Course';
$string['change_course_days_col']          = 'Days';
$string['change_course_days_hint']         = 'Enrolment duration in days (0 = unlimited)';
$string['change_course_role']              = 'Enrol as role';
$string['change_course_role_hint']         = 'Role assigned when enrolling (default: Student)';
$string['change_course_save']              = 'Save Course Enrolments';
$string['change_course_none']              = 'No courses found.';
$string['change_course_success']           = 'Course enrolments updated for {$a}.';
$string['change_course_nochange']          = 'No enrolment changes were needed.';
$string['change_course_enrolled_log']      = 'Enrolled / updated';
$string['change_course_unenrolled_log']    = 'Un-enrolled';
$string['change_role']                     = 'Change Role';
$string['change_role_title']               = 'Change System Roles';
$string['change_role_hint']                = 'Change the user\'s site-level (system) roles';
$string['change_role_intro']               = 'Roles already assigned to the user at site level are pre-checked. Uncheck a role to remove it, check a role to assign it. This manages site-level (system) roles only - roles assigned inside individual courses are not affected.';
$string['change_role_save']                = 'Save Roles';
$string['change_role_none']                = 'No roles found.';
$string['change_role_success']             = 'Roles updated for {$a}.';
$string['change_role_nochange']            = 'No role changes were needed.';
$string['bulk_change_course']              = 'Change Course';
$string['bulk_change_course_title']        = 'Bulk Change Course Enrolments';
$string['bulk_change_course_intro']        = '{$a} users selected. Every course below starts UNCHECKED - the courses you check (with their days and role) completely REPLACE the current course enrolments of every selected user: each user will be enrolled in exactly the checked courses and un-enrolled from every other course.';
$string['bulk_change_course_success']      = 'Course enrolments updated for {$a} users.';
$string['bulk_change_course_save']         = 'Apply to {$a} Users';
$string['bulk_change_role']                = 'Change Role';
$string['bulk_change_role_title']          = 'Bulk Change Roles';
$string['bulk_change_role_intro']          = '{$a} users selected. Every role below starts UNCHECKED - the roles you check completely REPLACE the current site-level roles of every selected user: each user will be assigned exactly the checked roles and removed from every other site-level role.';
$string['bulk_change_role_success']        = 'Roles updated for {$a} users.';
$string['bulk_change_role_save']           = 'Apply to {$a} Users';

// ================================================
// v3.8.0 - Excluded roles setting (replaces the old
// exclude-admins / exclude-teachers checkboxes).
// ================================================
$string['excludedroles']                   = 'Excluded roles';
$string['excludedroles_desc']              = 'Users holding any of the selected roles are excluded from the device login restrictions (they can sign in from any number of devices). "Administrators (site admins)" covers the accounts listed in Site administration > Security > Site admins. Hold Ctrl (or Cmd) and click to select or deselect multiple roles.';
$string['excludedroles_admins']            = 'Administrators (site admins)';

// ================================================
// v3.9.0 - User Directory & Search.
// ================================================
$string['usersearch_placeholder']          = 'Search by name, email, username, role (e.g. teacher), university ID (Uni_ID), phone, institution, or any profile field...';

$string['privacy:metadata:ios'] = 'Server-verified Apple device keys and expiring verification state.';
$string['privacy:metadata:ios:fingerprint'] = 'Stable pseudonymous identifier derived from an attested Apple key.';
$string['privacy:metadata:ios:payload'] = 'Public signing key, hashed IDFV/Keychain UUID/Mac Hardware UUID, platform, identity mode and, when Apple-attested, receipt, assertion counter, signed app-version/category and DeviceCheck metadata.';
$string['privacy:metadata:ios:created'] = 'Verification state creation time.';
$string['privacy:metadata:ios:expires'] = 'Challenge or session expiration time.';
$string['privacy:metadata:ios:devicecheck'] = 'Short-lived Apple DeviceCheck token sent to Apple for validation.';
$string['privacy:metadata:ios:apple'] = 'Apple validates the DeviceCheck token and returns vendor-wide two-bit state.';
