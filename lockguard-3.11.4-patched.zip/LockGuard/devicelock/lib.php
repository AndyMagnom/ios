<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Core functions for Lock Guard - SIMPLE WORKING VERSION
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

// Include the device manager
require_once(__DIR__ . '/device_manager.php');

/**
 * Cached helper to check if plugin database tables exist.
 * Avoids repeated expensive information_schema queries under heavy traffic.
 *
 * @return bool True if tables exist
 */
function auth_devicelock_tables_exist() {
    static $exist = null;
    if ($exist !== null) {
        return $exist;
    }
    global $DB;
    if (empty($DB)) {
        return false;
    }
    $exist = $DB->get_manager()->table_exists('auth_devicelock_devices');
    return $exist;
}


/**
 * Generate device fingerprint
 */
function auth_devicelock_generate_strict_fingerprint() {
    global $SESSION;
    
    $data = [
        'ua' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
        'lang' => $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? 'unknown',
        'screen' => $SESSION->auth_devicelock_screen ?? 'unknown',
        'timezone' => $SESSION->auth_devicelock_timezone ?? 'unknown',
        'platform' => $SESSION->auth_devicelock_platform ?? 'unknown',
        'browser_lang' => $SESSION->auth_devicelock_language ?? 'unknown'
    ];
    
    ksort($data);
    return hash('sha256', json_encode($data));
}

/**
 * Ensure devicelock is registered in Moodle's enabled auth plugins list.
 *
 * Only acts when the plugin itself is enabled: reachable pre-authentication
 * pages (admin_devices.php bootstrap, reset_password.php) must not be able to
 * force the auth plugin back into the login chain after an admin disabled it.
 */
function auth_devicelock_ensure_enabled() {
    global $CFG;

    if (!get_config('auth_devicelock', 'enabled')) {
        return;
    }

    // Always include ALL enabled auth plugins (never exclude manual)
    $authsequence = get_enabled_auth_plugins(false);
    $changed = false;

    // Core manual plugin must always be present in Moodle
    if (!in_array('manual', $authsequence)) {
        array_unshift($authsequence, 'manual');
        $changed = true;
    }

    // Ensure devicelock plugin is enabled
    if (!in_array('devicelock', $authsequence)) {
        $authsequence[] = 'devicelock';
        $changed = true;
    }

    if ($changed) {
        set_config('auth', implode(',', array_unique($authsequence)));
    }
}

/**
 * Neutralise spreadsheet formula injection (CSV/Excel) in exported cells.
 *
 * Values starting with =, +, - or @ (or a TAB/CR) would execute as formulas
 * when an admin opens an export in Excel/LibreOffice. Prefixing with a
 * single quote renders them inert while keeping the original characters
 * visible in the cell.
 *
 * @param mixed $value Raw cell value.
 * @return string Safe cell value.
 */
function auth_devicelock_csv_cell($value): string {
    $text = (string)$value;
    if ($text !== '' && preg_match('/^[=+\-@\t\r]/', $text)) {
        return "'" . $text;
    }
    return $text;
}

/**
 * Generate/retrieve current browser fingerprint (UUID token)
 */
function auth_devicelock_get_current_fingerprint() {
    global $SESSION;

    require_once(__DIR__ . '/classes/local/ios_identity.php');
    if (\auth_devicelock\local\ios_identity::is_request()) {
        $verified = \auth_devicelock\local\ios_identity::session();
        if (!$verified) {
            throw new \moodle_exception('nopermissions', 'error', '', 'Verified Apple device required');
        }
        return $verified['fingerprint'];
    }
    // A browser-supplied token must never impersonate an attested Apple key.
    if (!empty($SESSION->auth_devicelock_token) && \auth_devicelock\local\ios_identity::is_apple_fingerprint($SESSION->auth_devicelock_token)) {
        unset($SESSION->auth_devicelock_token);
    }


    // SECURITY FIX: a caller-supplied token must never override an already
    // -established identity for this browser. Previously the raw POST field
    // was trusted FIRST, so editing the hidden login field (or replaying a
    // stolen/shared token) silently overrode the real cookie/session value.
    // Verified sources (cookie, session) are now checked before the POST
    // field. POST is trusted only as a bootstrap fallback for the very
    // first request, before any cookie/session value exists yet.
    $token_regex = '/^(?!(?:ios|mac)_)[a-zA-Z0-9_-]{10,64}$/iD';

    // 1. Session storage (already verified earlier this session)
    if (!empty($SESSION->auth_devicelock_token)) {
        return $SESSION->auth_devicelock_token;
    }

    // 2. Persistent cookie (server/JS-issued, survives across requests)
    if (isset($_COOKIE['auth_devicelock_token']) && !empty($_COOKIE['auth_devicelock_token'])) {
        $cookie_token = clean_param($_COOKIE['auth_devicelock_token'], PARAM_RAW);
        if (preg_match($token_regex, $cookie_token)) {
            if (!empty($SESSION)) {
                $SESSION->auth_devicelock_token = $cookie_token;
            }
            return $cookie_token;
        }
    }

    // 3. POST parameter fallback: ONLY used when no cookie/session token
    // exists yet (true first-touch registration before the round trip that
    // sets the cookie). Never allowed to clobber an existing value above.
    $post_token = optional_param('auth_devicelock_token', '', PARAM_RAW);
    if (!empty($post_token) && preg_match($token_regex, $post_token)) {
        if (!empty($SESSION)) {
            $SESSION->auth_devicelock_token = $post_token;
        }
        return $post_token;
    }
    
    // 4. Hardware cookie payload embedded token
    if (!empty($_COOKIE['auth_devicelock_hw'])) {
        $hw_cookie = @json_decode(urldecode($_COOKIE['auth_devicelock_hw']), true);
        if (!empty($hw_cookie['token']) && preg_match($token_regex, $hw_cookie['token'])) {
            if (!empty($SESSION)) {
                $SESSION->auth_devicelock_token = $hw_cookie['token'];
            }
            return $hw_cookie['token'];
        }
    }
    
    // 5. Fallback cookie
    if (isset($_COOKIE['auth_devicelock_fallback']) && !empty($_COOKIE['auth_devicelock_fallback'])) {
        $fallback = clean_param($_COOKIE['auth_devicelock_fallback'], PARAM_RAW);
        if (preg_match($token_regex, $fallback)) { return $fallback; }
    }
    
    // 6. Generate new fallback token
    $new_fallback = md5(uniqid('device_', true));
    if (!headers_sent()) {
        setcookie('auth_devicelock_fallback', $new_fallback, time() + (10 * 365 * 24 * 60 * 60), '/', '', false, true);
    }
    
    return $new_fallback;
}


/**
 * Get device info from POST parameters, cookies, session, or server headers
 */
/**
 * Normalize screen resolution string so that orientation or whitespace does not affect matching.
 * e.g. "390x844" and "844x390" both normalize to "390x844".
 *
 * @param string $screen
 * @return string
 */
function auth_devicelock_normalize_screen($screen) {
    if (empty($screen) || $screen === 'unknown') {
        return '';
    }
    if (preg_match('/^([0-9]+)\s*x\s*([0-9]+)$/i', trim($screen), $m)) {
        $min = min((int)$m[1], (int)$m[2]);
        $max = max((int)$m[1], (int)$m[2]);
        return $min . 'x' . $max;
    }
    return trim($screen);
}

function auth_devicelock_get_device_info() {
    global $SESSION;

    require_once(__DIR__ . '/classes/local/ios_identity.php');
    if (\auth_devicelock\local\ios_identity::is_request()) {
        return [
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'platform' => ((\auth_devicelock\local\ios_identity::session()['platform'] ?? 'ios') === 'macos' ? 'macOS' : 'iOS'),
            'screen_resolution' => '',
            'browser_language' => '',
            'ip_address' => getremoteaddr(),
            'browser_tokens' => [auth_devicelock_get_current_fingerprint()],
            'ios_attested' => ((\auth_devicelock\local\ios_identity::session()['platform'] ?? 'ios') === 'ios'),
            'apple_attested' => empty(\auth_devicelock\local\ios_identity::session()['deviceKeyHash']),
        ];
    }

    
    // Read hardware data from cookie if available
    $hw_cookie = [];
    if (!empty($_COOKIE['auth_devicelock_hw'])) {
        $decoded = @json_decode(urldecode($_COOKIE['auth_devicelock_hw']), true);
        if (is_array($decoded)) {
            $hw_cookie = $decoded;
        }
    }
    
    // Screen resolution (POST > Session > Cookie > unknown)
    $screen = optional_param('auth_devicelock_screen', '', PARAM_RAW);
    if (empty($screen)) {
        $screen = $SESSION->auth_devicelock_screen ?? ($hw_cookie['screen'] ?? 'unknown');
    }
    $screen = auth_devicelock_normalize_screen($screen);

    // Available screen dimensions
    $avail_screen = optional_param('auth_devicelock_avail_screen', '', PARAM_RAW);
    if (empty($avail_screen)) {
        $avail_screen = $SESSION->auth_devicelock_avail_screen ?? ($hw_cookie['avail_screen'] ?? 'unknown');
    }
    $avail_screen = auth_devicelock_normalize_screen($avail_screen);
    
    // Color depth
    $depth = optional_param('auth_devicelock_colordepth', '', PARAM_RAW);
    if (empty($depth)) {
        $depth = $SESSION->auth_devicelock_colordepth ?? ($hw_cookie['depth'] ?? 'unknown');
    }

    // Pixel ratio
    $pixel_ratio = optional_param('auth_devicelock_pixelratio', '', PARAM_RAW);
    if (empty($pixel_ratio)) {
        $pixel_ratio = $SESSION->auth_devicelock_pixelratio ?? ($hw_cookie['pixel_ratio'] ?? 'unknown');
    }
    
    // Timezone offset
    $timezone = optional_param('auth_devicelock_timezone', '', PARAM_RAW);
    if ($timezone === '' || $timezone === null) {
        $timezone = $SESSION->auth_devicelock_timezone ?? ($hw_cookie['timezone'] ?? 'unknown');
    }

    // IANA Timezone name (e.g. "Africa/Cairo", "Asia/Riyadh", "Europe/London")
    $tzname = optional_param('auth_devicelock_tzname', '', PARAM_RAW);
    if (empty($tzname)) {
        $tzname = $SESSION->auth_devicelock_tzname ?? ($hw_cookie['tzname'] ?? 'unknown');
    }
    $tzname = clean_param($tzname, PARAM_TEXT);
    
    // Platform / OS
    $platform = optional_param('auth_devicelock_platform', '', PARAM_RAW);
    if (empty($platform) || $platform === 'unknown') {
        $platform = $SESSION->auth_devicelock_platform ?? ($hw_cookie['platform'] ?? 'unknown');
    }
    if ($platform === 'unknown') {
        // Fall back to server User Agent parsing
        $ua_info = auth_devicelock_get_ua_os_and_browser($_SERVER['HTTP_USER_AGENT'] ?? '');
        if (!empty($ua_info['os']) && $ua_info['os'] !== 'unknown') {
            $platform = $ua_info['os'];
        }
    }
    
    // GPU renderer & vendor
    $gpu = optional_param('auth_devicelock_gpu', '', PARAM_RAW);
    if (empty($gpu) || $gpu === 'unknown') {
        $gpu = $SESSION->auth_devicelock_gpu ?? ($hw_cookie['gpu'] ?? 'unknown');
    }
    $gpu_vendor = optional_param('auth_devicelock_gpu_vendor', '', PARAM_RAW);
    if (empty($gpu_vendor)) {
        $gpu_vendor = $SESSION->auth_devicelock_gpu_vendor ?? ($hw_cookie['gpu_vendor'] ?? 'unknown');
    }

    // Canvas fingerprint hash
    $canvas_hash = optional_param('auth_devicelock_canvas', '', PARAM_RAW);
    if (empty($canvas_hash)) {
        $canvas_hash = $SESSION->auth_devicelock_canvas ?? ($hw_cookie['canvas'] ?? 'unknown');
    }
    $canvas_hash = preg_match('/^[a-f0-9]{8,64}$/i', $canvas_hash) ? $canvas_hash : 'unknown';

    // Audio fingerprint hash
    $audio_hash = optional_param('auth_devicelock_audio', '', PARAM_RAW);
    if (empty($audio_hash)) {
        $audio_hash = $SESSION->auth_devicelock_audio ?? ($hw_cookie['audio'] ?? 'unknown');
    }
    $audio_hash = preg_match('/^[a-f0-9]{8,64}$/i', $audio_hash) ? $audio_hash : 'unknown';

    // Client Hints browser brands
    $brands = optional_param('auth_devicelock_brands', '', PARAM_RAW);
    if (empty($brands)) {
        $brands = $SESSION->auth_devicelock_brands ?? ($hw_cookie['brands'] ?? 'unknown');
    }
    
    // CPU cores
    $cpu_cores = optional_param('auth_devicelock_concurrency', '', PARAM_RAW);
    if (empty($cpu_cores)) {
        $cpu_cores = $SESSION->auth_devicelock_concurrency ?? ($hw_cookie['concurrency'] ?? 'unknown');
    }

    // Device memory
    $memory = optional_param('auth_devicelock_memory', '', PARAM_RAW);
    if (empty($memory)) {
        $memory = $SESSION->auth_devicelock_memory ?? ($hw_cookie['memory'] ?? 'unknown');
    }
    
    // Touch support
    $touch = optional_param('auth_devicelock_touch', '', PARAM_RAW);
    if ($touch === '' || $touch === null) {
        $touch = $SESSION->auth_devicelock_touch ?? ($hw_cookie['touch'] ?? 'unknown');
    }

    // Language
    $language = optional_param('auth_devicelock_language', '', PARAM_RAW);
    if (empty($language)) {
        $language = $SESSION->auth_devicelock_language ?? ($hw_cookie['language'] ?? ($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? 'unknown'));
    }
    
    $browser_token = auth_devicelock_get_current_fingerprint();
    
    // Hardware data array for stable hardware hash
    $hw_data = [
        'screen' => $screen,
        'depth' => $depth,
        'timezone' => $timezone,
        'platform' => $platform,
        'gpu' => $gpu
    ];
    ksort($hw_data);
    $hw_hash = hash('sha256', 'hw_v3:' . json_encode($hw_data));
    
    return [
        'screen_resolution' => $screen,
        'avail_screen' => $avail_screen,
        'timezone_offset' => $timezone,
        'timezone_name' => $tzname,
        'browser_language' => $language,
        'platform' => $platform,
        'gpu' => $gpu,
        'gpu_vendor' => $gpu_vendor,
        'canvas_hash' => $canvas_hash,
        'audio_hash' => $audio_hash,
        'brands' => $brands,
        'cpu_cores' => $cpu_cores,
        'device_memory' => $memory,
        'pixel_ratio' => $pixel_ratio,
        'touch' => $touch,
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
        'accept_language' => $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? 'unknown',
        'ip_address' => getremoteaddr(),
        'browser_tokens' => [$browser_token],
        'hw_hash' => $hw_hash
    ];
}

/**
 * Get user devices
 */
function auth_devicelock_get_user_devices($userid) {
    return device_manager::get_user_devices($userid);
}

/**
 * Get active device count
 */
function auth_devicelock_get_active_device_count($userid) {
    return device_manager::get_active_device_count($userid);
}

/**
 * Get total active devices count (all users) - ADDED FUNCTION
 */
function auth_devicelock_get_total_active_devices() {
    if (method_exists('device_manager', 'get_total_active_devices')) {
        return device_manager::get_total_active_devices();
    }
    
    // Fallback if method doesn't exist
    global $DB;
    return $DB->count_records('auth_devicelock_devices', ['status' => 'active']);
}

/**
 * Get users with devices
 */
function auth_devicelock_get_users_with_devices($search = '', $limit = 0, $offset = 0) {
    return device_manager::get_users_with_devices($search, $limit, $offset);
}

/**
 * Count users with devices
 */
function auth_devicelock_count_users_with_devices($search = '') {
    return device_manager::count_users_with_devices($search);
}

/**
 * Block a device
 */
function auth_devicelock_block_device($deviceid) {
    return device_manager::block_device($deviceid);
}

/**
 * Reset user devices
 */
function auth_devicelock_reset_user_devices($userid) {
    return device_manager::reset_user_devices($userid);
}

/**
 * Block user
 */
function auth_devicelock_block_user($userid) {
    return device_manager::block_user($userid);
}

/**
 * Format device info
 */
function auth_devicelock_format_device_info($device) {
    $info = [];
    
    if (!empty($device->screen_resolution) && $device->screen_resolution != 'unknown') {
        $info[] = 'Screen: ' . $device->screen_resolution;
    }
    
    if (!empty($device->platform) && $device->platform != 'unknown') {
        $info[] = 'OS: ' . $device->platform;
    }
    
    $deviceinfo = !empty($device->device_info) ? json_decode($device->device_info, true) : [];
    if (!empty($deviceinfo['gpu']) && $deviceinfo['gpu'] != 'unknown') {
        $info[] = 'GPU: ' . $deviceinfo['gpu'];
    }
    
    if (!empty($deviceinfo['cpu_cores']) && $deviceinfo['cpu_cores'] != 'unknown') {
        $info[] = 'CPU Cores: ' . $deviceinfo['cpu_cores'];
    }
    
    return !empty($info) ? implode(' • ', $info) : get_string('unknown', 'auth_devicelock');
}

/**
 * Mask fingerprint
 */
function auth_devicelock_mask_fingerprint($fingerprint) {
    if (strlen($fingerprint) > 16) {
        return substr($fingerprint, 0, 8) . '...' . substr($fingerprint, -8);
    }
    return $fingerprint;
}

/**
 * Get status badge
 */
function auth_devicelock_get_status_badge($status) {
    switch ($status) {
        case 'active':
            return '<span class="badge badge-success">Active</span>';
        case 'blocked':
            return '<span class="badge badge-danger">Blocked</span>';
        default:
            return '<span class="badge badge-secondary">' . $status . '</span>';
    }
}

/**
 * Check if device is allowed - ADDED FUNCTION
 */
function auth_devicelock_is_device_allowed($userid, $fingerprint) {
    return device_manager::is_device_allowed($userid, $fingerprint);
}

/**
 * Register a new device - ADDED FUNCTION
 */
function auth_devicelock_register_device($userid, $fingerprint, $deviceinfo = []) {
    return device_manager::register_device($userid, $fingerprint, $deviceinfo);
}

/**
 * Get device by fingerprint - ADDED FUNCTION
 */
function auth_devicelock_get_device_by_fingerprint($userid, $fingerprint) {
    global $DB;
    return $DB->get_record('auth_devicelock_devices', [
        'userid' => $userid,
        'device_fingerprint' => $fingerprint
    ]);
}

/**
 * Update device login time - ADDED FUNCTION
 */
function auth_devicelock_update_device_login($userid, $fingerprint) {
    global $DB;
    
    $device = $DB->get_record('auth_devicelock_devices', [
        'userid' => $userid,
        'device_fingerprint' => $fingerprint
    ]);
    
    if ($device) {
        $device->last_login = time();
        $device->ip_address = getremoteaddr();
        return $DB->update_record('auth_devicelock_devices', $device);
    }
    
    return false;
}

/**
 * Log device action - ADDED FUNCTION
 */
function auth_devicelock_log_action($userid, $fingerprint, $action, $details = []) {
    global $DB, $USER;
    
    // Check if logs table exists
    if (!$DB->get_manager()->table_exists('auth_devicelock_logs')) {
        return false;
    }

    if (!is_array($details)) {
        $details = (array)$details;
    }

    // Automatically capture admin email and ID if an admin/privileged user is performing this action
    if (!empty($USER) && !empty($USER->id)) {
        $is_admin = is_siteadmin($USER);
        if (!$is_admin && class_exists('context_system')) {
            $is_admin = has_capability('auth/devicelock:managedevices', \context_system::instance(), $USER);
        }
        if ($is_admin || ($USER->id != $userid && !empty($USER->email))) {
            if (empty($details['admin_email']) && !empty($USER->email)) {
                $details['admin_email'] = $USER->email;
            }
            if (empty($details['admin_user'])) {
                $details['admin_user'] = $USER->id;
            }
            if (empty($details['admin_name'])) {
                $details['admin_name'] = fullname($USER);
            }
        }
    }
    
    $log = new stdClass();
    $log->userid = $userid;
    $log->device_fingerprint = $fingerprint;
    $log->action = $action;
    $log->ip_address = getremoteaddr();
    $log->user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $log->timestamp = time();
    $log->details = json_encode($details);
    
    $logid = $DB->insert_record('auth_devicelock_logs', $log);

    // v3.5.0: persistent security score - a logged violation lowers the
    // user's stored score (and can trigger the auto-ban threshold).
    if ($logid) {
        auth_devicelock_score_apply_violation($userid, $action, $details, $logid);
    }
    return $logid;
}

/**
 * Clean up old sessions - ADDED FUNCTION
 */
function auth_devicelock_cleanup_sessions($userid) {
    global $DB;
    
    // Delete sessions older than 1 hour
    $DB->delete_records_select('sessions', 'userid = ? AND timemodified < ?', 
                               [$userid, time() - 3600]);
    return true;
}

/**
 * Check if user has any devices - ADDED FUNCTION
 */
function auth_devicelock_user_has_devices($userid) {
    global $DB;
    return $DB->record_exists('auth_devicelock_devices', [
        'userid' => $userid,
        'status' => 'active'
    ]);
}

/**
 * Get first device for user - ADDED FUNCTION
 */
function auth_devicelock_get_first_device($userid) {
    global $DB;
    return $DB->get_record('auth_devicelock_devices', [
        'userid' => $userid,
        'status' => 'active'
    ], '*', IGNORE_MULTIPLE);
}

/**
 * Set reset notification flag - ADDED FUNCTION
 */
function auth_devicelock_set_reset_notification($userid) {
    global $SESSION;
    $SESSION->device_reset_notification = true;
    return true;
}

/**
 * Check reset notification - ADDED FUNCTION
 */
function auth_devicelock_has_reset_notification() {
    global $SESSION;
    return !empty($SESSION->device_reset_notification);
}

/**
 * Clear reset notification - ADDED FUNCTION
 */
function auth_devicelock_clear_reset_notification() {
    global $SESSION;
    unset($SESSION->device_reset_notification);
    return true;
}

// ================================================
// NEW: Migration helper functions
// ================================================

/**
 * v3.9.0 (moved to lib.php in v3.10.0): SQL fragment that hides site
 * administrators from the user directories, unless the "Show site admins
 * in the User Directory" setting is enabled (admins are excluded by
 * default).
 *
 * Site admins are defined by $CFG->siteadmins (a comma separated id list),
 * NOT by a role assignment, so the exclusion is a simple NOT IN () over
 * those (sanitised, integer only) ids.
 *
 * Shared by the User Directory, its filter chips, the CSV exports, the
 * "Users Not Using Plugin" tab, the dashboard KPI and these lib.php
 * helpers, so every user list on the site agrees on admin visibility.
 *
 * @param string $tablealias Alias of the {user} table in the caller's query.
 * @return string '' when admins are shown, otherwise " AND u.id NOT IN (...)".
 */
function auth_devicelock_admin_exclude_sql($tablealias = 'u') {
    global $CFG;
    static $cache = [];
    $key = (string)$tablealias;
    if (!isset($cache[$key])) {
        $frag = '';
        if (!(bool)get_config('auth_devicelock', 'includeadmins')) {
            $adminids = array_values(array_unique(array_filter(array_map('intval', explode(',', (string)$CFG->siteadmins)))));
            if (!empty($adminids)) {
                $frag = " AND {$tablealias}.id NOT IN (" . implode(',', $adminids) . ")";
            }
        }
        $cache[$key] = $frag;
    }
    return $cache[$key];
}

/**
 * Get users not using Lock Guard
 *
 * @param string $search Optional search term
 * @param int $limit Optional limit
 * @param int $offset Optional offset
 * @return array Array of user records
 */
/**
 * Alias-less twin of auth_devicelock_admin_exclude_sql() for lib.php
 * queries that address {user} WITHOUT a table alias ("... WHERE id > 1").
 *
 * @return string '' when admins are shown, otherwise " AND id NOT IN (...)".
 */
function auth_devicelock_admin_exclude_sql_noalias() {
    $frag = auth_devicelock_admin_exclude_sql('u');
    if ($frag === '') {
        return '';
    }
    return str_replace('u.id NOT IN', 'id NOT IN', $frag);
}

/**
 * Get users not using Lock Guard
 *
 * @param string $search Optional search term
 * @param int $limit Limit
 * @param int $offset Offset
 * @return array Users
 */
function auth_devicelock_get_non_plugin_users($search = '', $limit = 0, $offset = 0) {
    global $DB;

    $params = [];
    $sql = "SELECT id, username, firstname, lastname, email, auth
            FROM {user}
            WHERE auth != 'devicelock'
            AND deleted = 0
            AND suspended = 0
            AND id > 1" // v3.10.0: hide guest only - admins follow the includeadmins setting.
            . auth_devicelock_admin_exclude_sql_noalias();

    if ($search) {
        $sql .= " AND (email LIKE ? OR firstname LIKE ? OR lastname LIKE ? OR username LIKE ?)";
        $searchterm = "%$search%";
        $params = array_fill(0, 4, $searchterm);
    }
    
    $sql .= " ORDER BY lastname, firstname";
    
    if ($limit > 0) {
        return $DB->get_records_sql($sql, $params, $offset, $limit);
    }
    
    return $DB->get_records_sql($sql, $params);
}

/**
 * Count users not using Lock Guard
 * 
 * @param string $search Optional search term
 * @return int Count
 */
function auth_devicelock_count_non_plugin_users($search = '') {
    global $DB;
    
    $params = [];
    $sql = "SELECT COUNT(*)
            FROM {user}
            WHERE auth != 'devicelock'
            AND deleted = 0
            AND suspended = 0
            AND id > 1" // v3.10.0: hide guest only - admins follow the includeadmins setting.
            . auth_devicelock_admin_exclude_sql_noalias();
    
    if ($search) {
        $sql .= " AND (email LIKE ? OR firstname LIKE ? OR lastname LIKE ? OR username LIKE ?)";
        $searchterm = "%$search%";
        $params = array_fill(0, 4, $searchterm);
    }
    
    return $DB->count_records_sql($sql, $params);
}

/**
 * Check if auto-migration is enabled
 * 
 * @return bool True if enabled
 */
function auth_devicelock_is_auto_migrate_enabled() {
    return !empty(get_config('auth_devicelock', 'automigrate'));
}

/**
 * Send security alert email
 * 
 * @param int $userid User ID
 * @param string $action 'new_login' or 'admin_change'
 * @param array|object $deviceinfo Mixed device info used for formatting
 * @return bool
 */
function auth_devicelock_send_security_alert($userid, $action, $deviceinfo) {
    global $DB, $CFG;
    
    $user = $DB->get_record('user', ['id' => $userid]);
    if (!$user) {
        return false;
    }

    $site = get_site();
    $maxdevices = get_config('auth_devicelock', 'maxdevices') ?: 1;
    $currentcount = device_manager::get_active_device_count($userid);

    // Format basic variables
    $device_str = 'Unknown Device';
    $browser_os_str = 'Unknown';
    $location = get_string('country' . current_language(), 'moodle'); // Best guess without true IP geolocator
    if (!$location || $location == '[[country]]') {
        $location = 'غير محدد (Unknown)';
    }

    if (is_array($deviceinfo)) {
        // from new_login
        $device_str = (!empty($deviceinfo['platform']) && $deviceinfo['platform'] != 'unknown') ? $deviceinfo['platform'] : 'PC';
        if (!empty($deviceinfo['gpu']) && $deviceinfo['gpu'] != 'unknown') {
            $device_str .= ' ' . $deviceinfo['gpu'];
        }
        $browser_os_str = (!empty($deviceinfo['user_agent'])) ? 'Browser on OS (From User Agent info)' : 'Unknown';
    } else if (is_object($deviceinfo)) {
        // from DB record
        $device_str = (!empty($deviceinfo->platform) && $deviceinfo->platform != 'unknown') ? $deviceinfo->platform : 'PC';
        $dinfo = @json_decode($deviceinfo->device_info, true);
        if (!empty($dinfo['gpu']) && $dinfo['gpu'] != 'unknown') {
            $device_str .= ' ' . $dinfo['gpu'];
        }
    }

    $date_str = device_manager::format_gmt2_date(time(), 'd M Y, H:i:s A');

    // Create the subject
    if ($action === 'new_login') {
        $subject = 'تنبيه أمني: تم رصد تسجيل دخول جديد لحساب Medprep الخاص بك | Security Alert: New login detected';
    } else {
        $subject = 'تنبيه أمني: تم تغيير أجهزتك المسجلة في Medprep | Security Alert: Registered devices changed';
    }

    // Prepare email message
    $message = "عزيزي المستخدم، / Dear User,\n\n";
    if ($action === 'new_login') {
        $message .= "لقد رصدنا عملية تسجيل دخول إلى حساب Medprep الخاص بك من جهاز أو متصفح جديد. حرصاً على أمان حسابك، نود إخطارك بهذا النشاط.\n\n";
        $message .= "We detected a login to your Medprep account from a new device or browser. To keep your account secure, we are notifying you of this activity.\n\n";
    } else {
        $message .= "قامت الإدارة بتغيير إعدادات الأجهزة المسجلة لحسابك. يرجى التحقق من الأجهزة الخاصة بك.\n\n";
        $message .= "The administration has changed your registered devices settings. Please check your devices.\n\n";
    }

    $message .= "تفاصيل تسجيل الدخول / Login Details\n";
    $message .= "--------------------------------------------------------\n";
    $message .= "الجهاز / Device: {$device_str}\n";
    // $message .= "المتصفح ونظام التشغيل / Browser & OS: {$browser_os_str}\n";
    $message .= "التاريخ / Date: {$date_str}\n";
    $message .= "حالة الأجهزة / Device Usage Status: تم استخدام {$currentcount} من أصل {$maxdevices} من الأجهزة المتاحة. / {$currentcount} out of {$maxdevices} Web Devices registered.\n\n";

    $message .= "تعليمات هامة للحفاظ على حسابك / Important Account Guidelines\n";
    $message .= "--------------------------------------------------------\n";
    $message .= "لتجنب حدوث أي مشاكل تقنية أو توقف مفاجئ للحساب، يرجى الالتزام بالتعليمات التالية:\n";
    $message .= "1. حد الأجهزة: مسموح بتسجيل الحساب على {$maxdevices} جهاز/أجهزة فقط.\n";
    $message .= "2. استخدام المتصفح: يُفضل بشدة استخدام متصفح واحد فقط على كل جهاز. فتح الحساب من أكثر من متصفح على نفس الجهاز قد يجعل النظام يتعرف عليهما كجهازين منفصلين، مما قد يؤدي لإغلاق الحساب.\n";
    $message .= "3. حماية المحتوى: يُمنع منعاً باتاً محاولة نسخ أي محتوى من الموقع. محاولات النسخ المتكررة قد تسبب مشاكل تقنية في حسابك أو تؤدي إلى إيقافه تلقائياً لحماية الحقوق التعليمية.\n\n";

    $message .= "To ensure uninterrupted access to your account and avoid technical lockouts, please follow these rules:\n";
    $message .= "1. Device Limit: You are allowed to use your account on {$maxdevices} device(s) only.\n";
    $message .= "2. Browser Consistency: We strongly recommend using only one browser on each device. Opening your account from multiple browsers on the same device may cause the system to count them as separate devices, potentially locking your account.\n";
    $message .= "3. Content Protection: Copying or attempting to dump content from the platform is strictly prohibited. Repeated attempts to copy materials will trigger security protocols and may lead to automatic account suspension.\n\n";

    if ($action === 'new_login') {
        $message .= "هل كنت أنت؟ / Was this you?\n";
        $message .= "--------------------------------------------------------\n";
        $message .= "نعم (Yes): يمكنك تجاهل هذا البريد الإلكتروني. / You can safely ignore this email.\n";
        $message .= "لا (No): قد يكون حسابك في خطر. نظرًا لأن إعدادات الجهاز مقفلة لأمانك، يرجى التواصل مع المسؤول فوراً عبر قنوات الدعم الرسمية / Your account may be at risk. Since device settings are locked for your security, please contact our administrator immediately via our official support channels:\n\n";
    } else {
        $message .= "إذا كان لديك أي استفسار، يرجى التواصل مع الدعم: / If you have any inquiries, please contact support:\n\n";
    }

    $message .= "دعم تيليجرام / Telegram Support: Medprep Support Telegram\n";
    $message .= "دعم واتساب / WhatsApp Support: Medprep WhatsApp\n\n";

    $message .= "مع تحياتنا، / Stay safe,\n";
    $message .= "فريق Medprep / The Medprep Team\n";

    $htmlmessage = nl2br($message);
    
    // Core moodle function to send emails
    $supportuser = core_user::get_support_user();
    return email_to_user($user, $supportuser, $subject, $message, $htmlmessage);
}

/**
 * Add navigation nodes in Site Administration -> Users
 *
 * @param global_navigation $navigation
 */
function auth_devicelock_extend_navigation(global_navigation $navigation) {
    global $CFG;
    
    // Only add for admins
    if (!is_siteadmin()) {
        return;
    }
    
    // Add to Site administration -> Users
    $usersnode = $navigation->find('users', global_navigation::TYPE_SETTING);
    if ($usersnode) {
        $url = new moodle_url('/auth/devicelock/admin_devices.php');
        $usersnode->add(
            get_string('managedevices', 'auth_devicelock'),
            $url,
            global_navigation::TYPE_SETTING,
            null,
            'auth_devicelock',
            new pix_icon('i/lock', '')
        );
    }
}

/**
 * Check if two IP addresses belong to the same subnet
 */
function auth_devicelock_is_same_subnet($ip1, $ip2) {
    if (strpos($ip1, '.') !== false && strpos($ip2, '.') !== false) {
        $parts1 = explode('.', $ip1);
        $parts2 = explode('.', $ip2);
        if (count($parts1) >= 3 && count($parts2) >= 3) {
            return ($parts1[0] === $parts2[0] && $parts1[1] === $parts2[1] && $parts1[2] === $parts2[2]);
        }
    }
    return false;
}

/**
 * Generate legacy fingerprint for seamless migration
 */
function auth_devicelock_generate_legacy_fingerprint() {
    global $SESSION;
    
    $data = [
        'ua' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
        'lang' => $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? 'unknown',
        'screen' => $SESSION->auth_devicelock_screen ?? 'unknown',
        'timezone' => $SESSION->auth_devicelock_timezone ?? 'unknown',
        'platform' => $SESSION->auth_devicelock_platform ?? 'unknown',
        'browser_lang' => $SESSION->auth_devicelock_language ?? 'unknown'
    ];
    
    ksort($data);
    return hash('sha256', json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
}

/**
 * Extract OS and Browser brand from a user agent string.
 */
function auth_devicelock_get_ua_os_and_browser($ua) {
    if (empty($ua)) {
        return ['os' => 'unknown', 'browser' => 'unknown'];
    }
    
    $os = 'unknown';
    if (stripos($ua, 'Windows') !== false) {
        $os = 'Windows';
    } else if (stripos($ua, 'iPad') !== false) {
        $os = 'iOS';
    } else if (stripos($ua, 'iPhone') !== false || stripos($ua, 'iPod') !== false) {
        $os = 'iOS';
    } else if (stripos($ua, 'Macintosh') !== false || stripos($ua, 'Mac OS X') !== false) {
        // Some iPads on modern Safari report as Macintosh - check touch/mobile
        if (stripos($ua, 'Mobile') !== false) {
            $os = 'iOS';
        } else {
            $os = 'macOS';
        }
    } else if (stripos($ua, 'Android') !== false) {
        $os = 'Android';
    } else if (stripos($ua, 'CrOS') !== false) {
        $os = 'ChromeOS';
    } else if (stripos($ua, 'Linux') !== false) {
        $os = 'Linux';
    }
    
    $browser = 'unknown';
    if (stripos($ua, 'Brave') !== false) {
        $browser = 'Brave';
    } else if (stripos($ua, 'Vivaldi') !== false) {
        $browser = 'Vivaldi';
    } else if (stripos($ua, 'YaBrowser') !== false) {
        $browser = 'Yandex';
    } else if (stripos($ua, 'SamsungBrowser') !== false) {
        $browser = 'SamsungBrowser';
    } else if (stripos($ua, 'UCBrowser') !== false || stripos($ua, 'UBrowser') !== false) {
        $browser = 'UCBrowser';
    } else if (stripos($ua, 'MiuiBrowser') !== false || stripos($ua, 'XiaoMi/MiuiBrowser') !== false) {
        $browser = 'MiuiBrowser';
    } else if (stripos($ua, 'HuaweiBrowser') !== false || (stripos($ua, 'HUAWEI') !== false && stripos($ua, 'Browser') !== false)) {
        $browser = 'HuaweiBrowser';
    } else if (stripos($ua, 'DuckDuckGo') !== false || stripos($ua, 'DDB') !== false) {
        $browser = 'DuckDuckGo';
    } else if (stripos($ua, 'Edge') !== false || stripos($ua, 'Edg') !== false) {
        $browser = 'Edge';
    } else if (stripos($ua, 'Opera') !== false || stripos($ua, 'OPR') !== false) {
        $browser = 'Opera';
    } else if (stripos($ua, 'Chrome') !== false || stripos($ua, 'CriOS') !== false) {
        $browser = 'Chrome';
    } else if (stripos($ua, 'Firefox') !== false || stripos($ua, 'FxiOS') !== false) {
        $browser = 'Firefox';
    } else if (stripos($ua, 'Safari') !== false) {
        $browser = 'Safari';
    }
    
    return ['os' => $os, 'browser' => $browser];
}

/**
 * Check if two user agent strings belong to the same general OS and browser brand.
 */
function auth_devicelock_is_similar_user_agent($ua1, $ua2) {
    if (empty($ua1) || empty($ua2)) {
        return false;
    }
    
    $info1 = auth_devicelock_get_ua_os_and_browser($ua1);
    $info2 = auth_devicelock_get_ua_os_and_browser($ua2);
    
    if ($info1['os'] === 'unknown' || $info2['os'] === 'unknown') {
        return false;
    }
    if ($info1['browser'] === 'unknown' || $info2['browser'] === 'unknown') {
        return false;
    }
    
    return ($info1['os'] === $info2['os'] && $info1['browser'] === $info2['browser']);
}

/**
 * Compare two GPU renderer strings to determine if they represent the same physical graphics hardware.
 * Strips driver revisions, ANGLE wrapper strings, and compares core GPU chipset/model.
 */
function auth_devicelock_is_similar_gpu($gpu1, $gpu2) {
    if (empty($gpu1) || empty($gpu2) || $gpu1 === 'unknown' || $gpu2 === 'unknown') {
        return false;
    }
    
    if ($gpu1 === $gpu2) {
        return true;
    }
    
    // Normalize string: lowercase, replace punctuation with spaces
    $clean1 = strtolower(preg_replace('/[^a-zA-Z0-9]+/', ' ', $gpu1));
    $clean2 = strtolower(preg_replace('/[^a-zA-Z0-9]+/', ' ', $gpu2));
    
    $tokens1 = array_filter(explode(' ', $clean1), function($w) { return strlen($w) >= 3; });
    $tokens2 = array_filter(explode(' ', $clean2), function($w) { return strlen($w) >= 3; });
    
    // Exclude common wrapper words that change across browser updates
    $ignore = ['angle', 'direct3d11', 'direct3d12', 'direct3d9', 'opengl', 'es', 'vs', 'ps', 'renderer', 'driver', 'microsoft', 'basic', 'render'];
    $filtered1 = array_diff($tokens1, $ignore);
    $filtered2 = array_diff($tokens2, $ignore);
    
    if (empty($filtered1) || empty($filtered2)) {
        return false;
    }
    
    $common = array_intersect($filtered1, $filtered2);
    // If they share at least 2 significant GPU tokens (e.g. 'nvidia' and 'rtx' or 'intel' and 'uhd'), it's the same physical GPU
    return count($common) >= 2 || (count($common) >= 1 && (in_array('m1', $common) || in_array('m2', $common) || in_array('m3', $common) || in_array('m4', $common)));
}

/**
 * Calculate matching confidence score (0 - 100) between a registered device and the current login environment.
 *
 * @param stdClass $device Registered device record from auth_devicelock_devices
 * @param array $currentinfo Current login deviceinfo array
 * @param string $current_ua Current HTTP_USER_AGENT
 * @param string $current_ip Current remote IP address
 * @return int Match score between 0 and 100
 */
function auth_devicelock_calculate_device_match_score($device, $currentinfo, $current_ua, $current_ip) {
    $info = @json_decode($device->device_info, true) ?: [];
    
    // 1. Mandatory Gatekeeper: Operating System MUST match.
    $ua_curr = auth_devicelock_get_ua_os_and_browser($current_ua);
    $ua_dev = auth_devicelock_get_ua_os_and_browser($device->user_agent ?? '');
    
    $curr_os = ($ua_curr['os'] !== 'unknown') ? $ua_curr['os'] : ($currentinfo['platform'] ?? '');
    $dev_os = ($ua_dev['os'] !== 'unknown') ? $ua_dev['os'] : ($device->platform ?: ($info['platform'] ?? ''));
    
    if (empty($curr_os) || empty($dev_os)) {
        return 0;
    }
    
    // Normalize OS names (e.g. Win32, Windows, etc.)
    $normalize_os = function($os) {
        $os = strtolower(trim($os));
        if (strpos($os, 'win') !== false) return 'windows';
        if (strpos($os, 'mac') !== false) return 'macos';
        if (strpos($os, 'iphone') !== false || strpos($os, 'ipad') !== false || strpos($os, 'ios') !== false) return 'ios';
        if (strpos($os, 'android') !== false) return 'android';
        if (strpos($os, 'linux') !== false) return 'linux';
        return $os;
    };
    
    if ($normalize_os($curr_os) !== $normalize_os($dev_os)) {
        return 0; // Operating systems differ (e.g. Android vs Windows). Zero match!
    }
    
    $score = 0;
    // SECURITY FIX: soft signals (IP/subnet, screen size, timezone) are common
    // to many DIFFERENT physical machines on the same network (e.g. a shared
    // computer lab). Previously they alone could clear the match threshold,
    // letting a genuinely different device be treated as "same machine, new
    // browser" and skip the device-limit check. A hard, hardware-specific
    // signal (canvas render hash, or GPU+screen together) is now required
    // before any match is accepted at all.
    $hard_signal_matched = false;
    
    // 2. Physical Screen Resolution Match (Normalized min x max to prevent orientation failures)
    $curr_screen = auth_devicelock_normalize_screen($currentinfo['screen_resolution'] ?? '');
    $dev_screen = auth_devicelock_normalize_screen($device->screen_resolution ?: ($info['screen_resolution'] ?? ''));
    
    if (!empty($curr_screen) && !empty($dev_screen) && $curr_screen !== 'unknown' && $dev_screen !== 'unknown') {
        if ($curr_screen === $dev_screen) {
            $score += 35; // Screen resolution is identical hardware attribute
        } else {
            // Different physical resolution strongly indicates a different monitor/device
            $score -= 25;
        }
    }

    // 2b. Available Screen Dimensions Match
    $curr_avail = auth_devicelock_normalize_screen($currentinfo['avail_screen'] ?? '');
    $dev_avail = auth_devicelock_normalize_screen($info['avail_screen'] ?? '');
    if (!empty($curr_avail) && !empty($dev_avail) && $curr_avail !== 'unknown' && $dev_avail !== 'unknown') {
        if ($curr_avail === $dev_avail) {
            $score += 15;
        }
    }
    
    // 3. GPU Chipset Match (Strips browser wrappers like ANGLE/D3D11 and compares physical GPU core)
    $curr_gpu = $currentinfo['gpu'] ?? '';
    $dev_gpu = $info['gpu'] ?? '';
    if (!empty($curr_gpu) && !empty($dev_gpu) && $curr_gpu !== 'unknown' && $dev_gpu !== 'unknown') {
        if (auth_devicelock_is_similar_gpu($curr_gpu, $dev_gpu)) {
            $score += 30;
            // GPU match only counts as a hard signal when paired with a
            // matching screen resolution (identical GPU model alone is too
            // common across a fleet of similar machines).
            if ($curr_screen === $dev_screen && !empty($curr_screen) && $curr_screen !== 'unknown') {
                $hard_signal_matched = true;
            }
        }
    }

    // 3b. Canvas Fingerprint Hash Match (Very high confidence hardware/graphics stack signature)
    $curr_canvas = $currentinfo['canvas_hash'] ?? '';
    $dev_canvas = $info['canvas_hash'] ?? '';
    if (!empty($curr_canvas) && !empty($dev_canvas) && $curr_canvas !== 'unknown' && $dev_canvas !== 'unknown') {
        if ($curr_canvas === $dev_canvas) {
            $score += 25;
            $hard_signal_matched = true; // Canvas hash alone is high-confidence.
        }
    }
    
    // 4. IP Address & Subnet Match
    $dev_ip = $device->ip_address ?? '';
    if (!empty($dev_ip) && !empty($current_ip)) {
        if ($dev_ip === $current_ip) {
            $score += 30; // Exact same IP address
        } else if (auth_devicelock_is_same_subnet($dev_ip, $current_ip)) {
            $score += 20; // Same /24 local network or ISP mobile subnet
        }
    }
    
    // 5. Timezone Offset & Name Match (OS-level clock and region setting)
    $curr_tz = $currentinfo['timezone_offset'] ?? '';
    $dev_tz = $info['timezone_offset'] ?? '';
    if ($curr_tz !== '' && $dev_tz !== '' && $curr_tz !== 'unknown' && $dev_tz !== 'unknown') {
        if ((string)$curr_tz === (string)$dev_tz) {
            $score += 10;
        }
    }
    $curr_tzname = $currentinfo['timezone_name'] ?? '';
    $dev_tzname = $info['timezone_name'] ?? '';
    if (!empty($curr_tzname) && !empty($dev_tzname) && $curr_tzname !== 'unknown' && $dev_tzname !== 'unknown') {
        if ($curr_tzname === $dev_tzname) {
            $score += 10;
        }
    }
    
    // 6. CPU Hardware Concurrency (Number of CPU cores)
    $curr_cpu = $currentinfo['cpu_cores'] ?? '';
    $dev_cpu = $info['cpu_cores'] ?? '';
    if ($curr_cpu !== '' && $dev_cpu !== '' && $curr_cpu !== 'unknown' && $dev_cpu !== 'unknown') {
        if ((int)$curr_cpu > 0 && (int)$curr_cpu === (int)$dev_cpu) {
            $score += 10;
        }
    }
    
    // 7. Touch Support Match
    $curr_touch = $currentinfo['touch'] ?? '';
    $dev_touch = $info['touch'] ?? '';
    if ($curr_touch !== '' && $dev_touch !== '' && $curr_touch !== 'unknown' && $dev_touch !== 'unknown') {
        if ((string)$curr_touch === (string)$dev_touch) {
            $score += 5;
        }
    }

    // SECURITY FIX: reject matches built only from soft/shared signals
    // (same IP, same generic screen size, same timezone) with no hard
    // hardware-specific signal behind them.
    if (!$hard_signal_matched) {
        return 0;
    }

    return $score;
}

/**
 * Find matching device for a user using browser tokens, hardware multi-factor scoring, or legacy migration
 *
 * @param int $userid User ID
 * @param bool $is_login True only during authentication/login events, false during routine page views
 * @return stdClass|bool Matched device record or false
 */
function auth_devicelock_find_device_for_user($userid, $is_login = false) {
    global $DB, $SESSION;

    require_once(__DIR__ . '/classes/local/ios_identity.php');
    if (\auth_devicelock\local\ios_identity::is_request()) {
        $verified = \auth_devicelock\local\ios_identity::session();
        return $verified ? $DB->get_record('auth_devicelock_devices',
            ['userid' => $userid, 'device_fingerprint' => $verified['fingerprint']]) : false;
    }

    
    $browser_token = auth_devicelock_get_current_fingerprint();
    $deviceinfo = auth_devicelock_get_device_info();
    $current_ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $current_ip = getremoteaddr();
    $now = time();
    
    $devices = $DB->get_records('auth_devicelock_devices', ['userid' => $userid]);
    $devices = array_filter($devices, static function($device) {
        return !\auth_devicelock\local\ios_identity::is_apple_fingerprint($device->device_fingerprint);
    });
    if (empty($devices)) {
        return false;
    }

    // Check if the current browser token was revoked during a reset action
    $token_revoked = false;
    if (class_exists('device_manager') && device_manager::is_token_revoked($browser_token)) {
        $token_revoked = true;
    }
    
    // Tier 1: Direct Token Match (Matches stored UUID token from localStorage or cookie)
    // ONLY executed if this token was NOT revoked!
    if (!$token_revoked) {
        foreach ($devices as $d) {
            $info = @json_decode($d->device_info, true) ?: [];
            $tokens = $info['browser_tokens'] ?? [];
            if (!is_array($tokens)) {
                $tokens = [];
            }
            
            $token_match = false;
            // Match against stored tokens or active non-hardware device_fingerprint
            if (in_array($browser_token, $tokens) || (!empty($d->device_fingerprint) && strpos($d->device_fingerprint, 'hw_') !== 0 && $d->device_fingerprint === $browser_token)) {
                $token_match = true;
            }
            
            if ($token_match) {
                // Check if browser limit is exceeded
                if (!auth_devicelock_can_use_browser_on_device($d, $current_ua)) {
                    $maxb = auth_devicelock_get_user_browser_limit($userid);
                    $SESSION->loginerrormsg = get_string('browserlimitreached', 'auth_devicelock', $maxb);
                    $d->browser_limit_exceeded = true;
                    return $d;
                }

                // Update device UA, IP, and last_login if changed or during login (throttled under high traffic)
                $ua_changed = ($d->user_agent !== $current_ua);
                $ip_changed = ($d->ip_address !== $current_ip);
                $last_login_stale = (($now - (int)$d->last_login) > 300);
                
                if ($is_login || $ua_changed || $ip_changed || $last_login_stale) {
                    $d->user_agent = $current_ua;
                    $d->ip_address = $current_ip;
                    $d->last_login = $now;
                    if (!empty($info)) {
                        $info['last_ua'] = $current_ua;
                        $d->device_info = json_encode($info);
                    }
                    $DB->update_record('auth_devicelock_devices', $d);
                }
                auth_devicelock_record_device_browser($d, $current_ua, $is_login);
                return $d;
            }
        }
    }
    
    // Tier 2: Multi-Factor Hardware Machine Match (Enables re-registering on same phone/device after reset or browser change)
    $best_device = null;
    $highest_score = 0;
    
    foreach ($devices as $d) {
        $score = auth_devicelock_calculate_device_match_score($d, $deviceinfo, $current_ua, $current_ip);
        if ($score >= 50 && $score > $highest_score) {
            $highest_score = $score;
            $best_device = $d;
        }
    }
    
    if ($best_device) {
        // Matched existing physical device!
        // Check if new browser is permitted on this device under effective limits
        if (!auth_devicelock_can_use_browser_on_device($best_device, $current_ua)) {
            $maxb = auth_devicelock_get_user_browser_limit($userid);
            $SESSION->loginerrormsg = get_string('browserlimitreached', 'auth_devicelock', $maxb);
            if (function_exists('auth_devicelock_log_action')) {
                auth_devicelock_log_action($userid, $browser_token, 'browser_limit_reached', [
                    'device_id' => $best_device->id,
                    'max_browsers' => $maxb,
                    'user_agent' => substr($current_ua, 0, 255),
                    'ip' => $current_ip,
                    'match_score' => $highest_score
                ]);
            }
            // Mark that browser limit was exceeded so auth.php does NOT treat this as an unregistered device!
            $best_device->browser_limit_exceeded = true;
            return $best_device;
        }
        
        // Browser is allowed on this device!
        // If the old token was revoked or invalid, issue a fresh replacement token
        if ($token_revoked || empty($browser_token) || strpos($browser_token, 'hw_') === 0) {
            $browser_token = md5(uniqid('dev_fresh_', true));
            if (!headers_sent()) {
                setcookie('auth_devicelock_token', $browser_token, time() + (10 * 365 * 24 * 60 * 60), '/', '', false, true);
            }
            if (!empty($SESSION)) {
                $SESSION->auth_devicelock_token = $browser_token;
            }
        }

        // Attach fresh browser token and record browser on the device
        $info = @json_decode($best_device->device_info, true) ?: [];
        if (!isset($info['browser_tokens']) || !is_array($info['browser_tokens'])) {
            $info['browser_tokens'] = [];
        }
        if (!in_array($browser_token, $info['browser_tokens'])) {
            $info['browser_tokens'][] = $browser_token;
        }
        
        $best_device->device_info = json_encode($info);
        $best_device->user_agent = $current_ua;
        $best_device->ip_address = $current_ip;
        $best_device->last_login = time();
        $DB->update_record('auth_devicelock_devices', $best_device);
        auth_devicelock_record_device_browser($best_device, $current_ua, $is_login);
        return $best_device;
    }
    
    // Tier 3: Legacy Fingerprint Migration Fallback
    $legacy_fingerprint = auth_devicelock_generate_legacy_fingerprint();
    foreach ($devices as $d) {
        if ($d->device_fingerprint === $legacy_fingerprint) {
            $info = @json_decode($d->device_info, true) ?: [];
            if (!isset($info['browser_tokens']) || !is_array($info['browser_tokens'])) {
                $info['browser_tokens'] = [$d->device_fingerprint];
            }
            if (!in_array($browser_token, $info['browser_tokens'])) {
                $info['browser_tokens'][] = $browser_token;
            }
            $d->device_info = json_encode($info);
            $d->device_fingerprint = $browser_token;
            $d->user_agent = $current_ua;
            $d->ip_address = $current_ip;
            $d->last_login = time();
            $DB->update_record('auth_devicelock_devices', $d);
            auth_devicelock_record_device_browser($d, $current_ua, $is_login);
            return $d;
        }
    }
    
    return false;
}


/**
 * Check if a browser can be used on an authorized device under effective browser limits.
 *
 * @param stdClass $device Device record
 * @param string $useragent Current HTTP_USER_AGENT
 * @return bool True if allowed, false if browser limit exceeded
 */
function auth_devicelock_can_use_browser_on_device($device, $useragent) {
    if (empty($device)) {
        return true;
    }

    // APP GUARD INTERACTION FIX: "maxbrowsers" exists to stop someone
    // signing in with Chrome AND Firefox AND Edge on one shared device -
    // a scenario that cannot occur once a restricted user can only sign
    // in through the app at all (any real second browser is already
    // refused far earlier, at sign-in). Without this bypass, a restricted
    // user's app re-registering after its storage is reset (reinstall, OS
    // "clear app data", some Android OEMs auto-clearing WebView storage)
    // would look like a "new browser family" on the same device and could
    // eventually trip the limit and lock out a student who never touched
    // a real browser. Skip the count entirely for that population.
    if (auth_devicelock_appguard_enabled() && auth_devicelock_appguard_is_app_request()) {
        global $DB;
        $devuser = $DB->get_record('user', ['id' => $device->userid]);
        if ($devuser && auth_devicelock_appguard_restricted_user($devuser)) {
            return true;
        }
    }

    // Check user's effective browser limit (or global)
    $maxbrowsers = auth_devicelock_get_user_browser_limit($device->userid);
    if ($maxbrowsers <= 0) {
        return true; // 0 means unlimited
    }
    
    $info = !empty($device->device_info) ? @json_decode($device->device_info, true) : [];
    if (!is_array($info)) {
        $info = [];
    }
    
    // Identify current browser family
    $uainfo = auth_devicelock_get_ua_os_and_browser($useragent);
    $browser_family = ($uainfo['browser'] !== 'unknown') ? $uainfo['browser'] : 'Browser';
    $current_family_key = strtolower(trim($browser_family));
    
    // Get existing registered browser families
    $existing_families = [];
    if (isset($info['browsers_used']) && is_array($info['browsers_used'])) {
        foreach ($info['browsers_used'] as $bkey => $bdata) {
            $fam = !empty($bdata['family']) ? strtolower(trim($bdata['family'])) : $bkey;
            $existing_families[$fam] = true;
        }
    } else if (!empty($device->user_agent)) {
        // Fallback: extract from device's initial user_agent only if browsers_used was never initialized
        $initial_ua_info = auth_devicelock_get_ua_os_and_browser($device->user_agent);
        $initial_fam = ($initial_ua_info['browser'] !== 'unknown') ? $initial_ua_info['browser'] : 'Browser';
        if ($initial_fam !== 'unknown' && $initial_fam !== 'Browser') {
            $existing_families[strtolower(trim($initial_fam))] = true;
        }
    }
    
    // If this browser family is ALREADY in the existing registered families, it's allowed!
    if (isset($existing_families[$current_family_key])) {
        return true;
    }
    
    // Otherwise, this is a NEW browser family. Check if count >= maxbrowsers
    if (count($existing_families) >= $maxbrowsers) {
        return false;
    }
    
    return true;
}

/**
 * Record a browser used on an authorized device and log it.
 *
 * @param stdClass $device Device record from auth_devicelock_devices
 * @param string $useragent Current HTTP_USER_AGENT
 * @param bool $is_login True if called during a login event, false during routine page views
 * @return void
 */
function auth_devicelock_record_device_browser($device, $useragent, $is_login = false) {
    global $DB;
    
    if (empty($device) || empty($useragent)) {
        return;
    }
    
    $uainfo = auth_devicelock_get_ua_os_and_browser($useragent);
    $browser_family = ($uainfo['browser'] !== 'unknown') ? $uainfo['browser'] : 'Browser';
    
    // Extract version if possible
    $version = '';
    if (preg_match('/(?:Chrome|CriOS|Firefox|FxiOS|Version|Edge|Edg|OPR|Opera)\/([0-9]+(?:\.[0-9]+)?)/i', $useragent, $matches)) {
        $version = ' ' . $matches[1];
    }
    $browser_label = $browser_family . $version;
    
    $info = !empty($device->device_info) ? @json_decode($device->device_info, true) : [];
    if (!is_array($info)) {
        $info = [];
    }
    
    if (!isset($info['browsers_used']) || !is_array($info['browsers_used'])) {
        $info['browsers_used'] = [];
    }
    
    $now = time();
    $family_key = strtolower(trim($browser_family));
    $is_new_browser = !isset($info['browsers_used'][$family_key]);

    // Performance optimization under heavy load:
    // If browser is already registered, only update DB if this is a login event or if last_seen was > 5 minutes ago.
    if (!$is_new_browser && !$is_login) {
        $last_seen = $info['browsers_used'][$family_key]['last_seen'] ?? 0;
        if (($now - (int)$last_seen) < 300) {
            // Already recorded within last 5 minutes: avoid redundant DB writes during active user navigation
            return;
        }
    }

    // v3.10.0 - ONE "Browser Login" row per real login (was 4-5!).
    // The login flow legitimately calls this function several times for
    // the same sign-in (auth.php user_login() + user_authenticated_hook(),
    // then the user_loggedin event observer - which calls it twice more
    // via find_device_for_user() and directly). Every one of those calls
    // used to pass the is_login flag straight into log_action(), so one
    // login produced a flood of identical "Browser Login" entries.
    // A browser now logs AT MOST ONCE PER 60 SECONDS: the first call
    // stamps last_log, and every duplicate call in the same request (or
    // a stray second one within a minute) stays silent.
    $last_log = (int)($info['browsers_used'][$family_key]['last_log'] ?? 0);
    $should_log = $is_new_browser || ($is_login && (($now - $last_log) >= 60));

    $prev = $info['browsers_used'][$family_key] ?? [];
    $info['browsers_used'][$family_key] = [
        'name' => $browser_label,
        'family' => $browser_family,
        'last_seen' => $now,
        'first_seen' => $prev['first_seen'] ?? $now,
        // Usage count only grows when this call actually represents a
        // distinct login/new-browser event, not once per duplicate call.
        'count' => (int)($prev['count'] ?? 0) + ($should_log ? 1 : 0),
        'ua' => substr($useragent, 0, 255),
        // The dedupe stamp must SURVIVE non-logging calls - it is carried
        // over (not dropped) so the 60-second window counts from the last
        // actual login, never resets mid-request.
        'last_log' => $should_log ? $now : (int)($prev['last_log'] ?? 0),
    ];

    $device->device_info = json_encode($info);
    $DB->update_record('auth_devicelock_devices', $device);

    // Log the browser usage event only on new browser registration or actual login (not every standard page view)
    if ($should_log) {
        $log_action = $is_new_browser ? 'new_browser_on_device' : 'browser_login';
        if (function_exists('auth_devicelock_log_action')) {
            auth_devicelock_log_action($device->userid, $device->device_fingerprint, $log_action, [
                'browser' => $browser_label,
                'browser_family' => $browser_family,
                'is_new' => $is_new_browser,
                'total_browsers_on_device' => count($info['browsers_used']),
                'device_id' => $device->id,
                'ip' => getremoteaddr(),
                'user_agent' => $useragent
            ]);
        }
    }
}


/**
 * Format html badges for browsers used on an authorized device.
 *
 * @param stdClass $device
 * @return string HTML string with browser badges
 */
function auth_devicelock_format_browsers_used($device) {
    if (empty($device->device_info)) {
        return '';
    }
    $info = @json_decode($device->device_info, true);
    if (empty($info['browsers_used']) || !is_array($info['browsers_used'])) {
        // Fallback to UA if no specific browsers list yet
        $ua_info = auth_devicelock_get_ua_os_and_browser($device->user_agent ?? '');
        if (!empty($ua_info['browser']) && $ua_info['browser'] !== 'unknown') {
            return '<span class="badge badge-secondary"><i class="fa fa-globe"></i> ' . s($ua_info['browser']) . '</span>';
        }
        return '';
    }
    
    $badges = [];
    foreach ($info['browsers_used'] as $b) {
        $family = strtolower($b['family'] ?? '');
        $icon = 'fa-globe';
        $badge_class = 'badge-secondary';
        if (strpos($family, 'chrome') !== false) {
            $icon = 'fa-chrome';
            $badge_class = 'badge-primary';
        } else if (strpos($family, 'firefox') !== false) {
            $icon = 'fa-firefox';
            $badge_class = 'badge-warning';
        } else if (strpos($family, 'edge') !== false) {
            $icon = 'fa-edge';
            $badge_class = 'badge-info';
        } else if (strpos($family, 'safari') !== false) {
            $icon = 'fa-safari';
            $badge_class = 'badge-dark';
        } else if (strpos($family, 'opera') !== false) {
            $icon = 'fa-opera';
            $badge_class = 'badge-danger';
        }
        $name = s($b['name'] ?? 'Browser');
        $badges[] = '<span class="badge ' . $badge_class . ' mr-1" title="Seen: ' . date('d M Y, H:i', $b['last_seen'] ?? time()) . '"><i class="fa ' . $icon . '"></i> ' . $name . '</span>';
    }
    return implode(' ', $badges);
}

if (!function_exists('esc_js')) {
    /**
     * Escape string for JS string literals.
     * Alias to Moodle core addslashes_js() for compatibility.
     *
     * @param string $str
     * @return string
     */
    function esc_js($str) {
        return addslashes_js($str);
    }
}

/**
 * Generate a secure yet clean, human-readable temporary password for a user.
 * Conforms to Moodle's password policy (minimum length, digits, upper/lowercase, special chars).
 *
 * @param stdClass|null $user
 * @return string Generated temporary password
 */
function auth_devicelock_generate_temporary_password($user = null, $length = null) {
    global $CFG;
    
    if (file_exists($CFG->libdir . '/moodlelib.php')) {
        require_once($CFG->libdir . '/moodlelib.php');
    }

    $prefixes = ['Pass', 'Temp', 'Fast', 'Easy', 'Gate', 'Safe', 'Code', 'Step', 'Star', 'Blue', 'Peak', 'Moon', 'Wave'];
    $symbols = ['#', '!', '@', '$', '*', '%'];

    // Caller (admin UI) may request a specific total length. Always respect
    // the site's own minimum password length, and cap at a sane maximum.
    $sitemin = !empty($CFG->minpasswordlength) ? (int)$CFG->minpasswordlength : 8;
    $targetlen = ($length !== null && $length !== '') ? (int)$length : max($sitemin, 12);
    $targetlen = max($sitemin, 8, min($targetlen, 64));

    // Try up to 15 times to generate a password that satisfies site password policy
    for ($i = 0; $i < 15; $i++) {
        $prefix = $prefixes[random_int(0, count($prefixes) - 1)];
        $sym = $symbols[random_int(0, count($symbols) - 1)];
        // random_int(), not rand(): cryptographically secure.
        $candidate = $prefix . $sym;

        // Pad to the requested length with random digits, one at a time,
        // so this works correctly for any requested length.
        while (strlen($candidate) < $targetlen) {
            $candidate .= (string)random_int(0, 9);
        }

        $errmsg = '';
        if (function_exists('check_password_policy')) {
            if (check_password_policy($candidate, $errmsg, $user)) {
                return $candidate;
            }
        } else {
            return $candidate;
        }
    }

    // Short, still-random fallback if a custom policy is strict.
    $fallback = $prefixes[random_int(0, count($prefixes) - 1)] . $symbols[random_int(0, count($symbols) - 1)];
    while (strlen($fallback) < $targetlen) {
        $fallback .= (string)random_int(0, 9);
    }
    return $fallback;
}

// =============================================================================
// APP GUARD: app-only sign-in restriction + device security events.
//
// Lets the restricted population (same users Lock Guard already applies its
// device limit to - see should_restrict_user_static()) sign in only through
// a custom WebView app (Windows, Android, Mac, ...), not a plain web
// browser, while still allowing the SAME account on a limited number of
// devices via the existing "Maximum devices per user" setting. The app
// identifies itself with a User-Agent marker (and optionally a shared
// secret header); a request with neither is treated as "browser" and
// blocked for restricted users. Site administrators are always exempt
// (should_restrict_user_static() already excludes them).
//
// Three independent enforcement points, deliberately overlapping:
//   1. auth.php::user_login() - blocks the credential check itself for
//      users already on devicelock auth. No session is ever created, so
//      this never interacts with the device/browser-limit counters below.
//   2. The user_loggedin observer (classes/observer.php) - catches EVERY
//      login regardless of auth method, for restricted users who have not
//      been migrated to devicelock auth yet.
//   3. The before_http_headers hook (classes/hook/output/) - catches
//      sessions that already existed before the restriction was turned on.
// =============================================================================

define('AUTH_DEVICELOCK_APPGUARD_NOTICE_COOKIE', 'auth_devicelock_appguard_notice');
define('AUTH_DEVICELOCK_APPGUARD_NOTICE_TTL', 300);

/**
 * True when "Restrict sign-in to the app" is enabled.
 */
function auth_devicelock_appguard_enabled() {
    return (bool)get_config('auth_devicelock', 'appguard_enabled');
}

/**
 * Split a stored "multi list" setting value into clean items.
 *
 * The list settings (User-Agent markers, App keys) are stored as ONE
 * config value with one item per line - which also keeps single-item
 * values saved by older plugin versions working unchanged.
 *
 * @param string $raw Raw stored value.
 * @return array      Trimmed, non-empty, de-duplicated items.
 */
function auth_devicelock_split_multilist($raw) {
    $out = [];
    $lines = preg_split('/\r\n|\r|\n/', (string)$raw);
    if (!$lines) {
        return [];
    }
    foreach ($lines as $line) {
        $line = trim((string)$line);
        if ($line !== '') {
            $out[] = $line;
        }
    }
    return array_values(array_unique($out));
}

/**
 * The configured App User-Agent markers (one per line in the setting;
 * a single marker saved by an older version still works).
 *
 * @return array Non-empty marker strings.
 */
function auth_devicelock_appguard_uamarkers() {
    return auth_devicelock_split_multilist(get_config('auth_devicelock', 'appguard_uamarker'));
}

/**
 * The configured App keys (one per line in the setting; a single key
 * saved by an older version still works).
 *
 * @return array Non-empty key strings.
 */
function auth_devicelock_appguard_appkeys() {
    return auth_devicelock_split_multilist(get_config('auth_devicelock', 'appguard_appkey'));
}

/**
 * The app key the current request carries, from the X-App-Key or
 * X-AppGuard-Key HTTP header (empty string when neither is set).
 *
 * @return string
 */
function auth_devicelock_appguard_provided_key() {
    $provided = (string)($_SERVER['HTTP_X_APP_KEY'] ?? '');
    if ($provided === '') {
        $provided = (string)($_SERVER['HTTP_X_APPGUARD_KEY'] ?? '');
    }
    return trim($provided);
}

/**
 * True when the given key matches ANY of the configured App keys
 * (timing-safe comparison per key).
 *
 * @param string $provided Key sent by the client.
 * @return bool
 */
function auth_devicelock_appguard_key_valid($provided) {
    $provided = trim((string)$provided);
    if ($provided === '') {
        return false;
    }
    foreach (auth_devicelock_appguard_appkeys() as $key) {
        if (hash_equals($key, $provided)) {
            return true;
        }
    }
    return false;
}

/**
 * True when the current request comes from the custom app, via either:
 *  1. A User-Agent marker: the request's User-Agent contains ANY of the
 *     configured markers (case-insensitive substring; the app appends
 *     e.g. "AppGuard/1.0" to its WebView user-agent).
 *  2. The shared "App key" secret sent as an X-App-Key / X-AppGuard-Key
 *     header - a browser cannot know this, so it defeats simple
 *     user-agent spoofing once the app sends it. ANY configured key is
 *     accepted, so each app build can carry its own key.
 *
 * An EMPTY marker list and no keys means nothing counts as the app -
 * with the restriction enabled that blocks every client, including the
 * app, which fails loudly (everyone blocked) instead of silently
 * protecting nobody.
 */
function auth_devicelock_appguard_is_app_request() {
    require_once(__DIR__ . '/classes/local/ios_identity.php');
    if (\auth_devicelock\local\ios_identity::is_request()) {
        return \auth_devicelock\local\ios_identity::session() !== null;
    }

    $ua = (string)($_SERVER['HTTP_USER_AGENT'] ?? '');
    if ($ua !== '') {
        foreach (auth_devicelock_appguard_uamarkers() as $marker) {
            if (stripos($ua, $marker) !== false) {
                return true;
            }
        }
    }

    return auth_devicelock_appguard_key_valid(auth_devicelock_appguard_provided_key());
}

/**
 * True when the given user is subject to the app-only restriction.
 *
 * Deliberately reuses should_restrict_user_static() - the SAME population
 * the device/browser limit already applies to - rather than a second,
 * independent role list. Two separate "who do we restrict" settings would
 * be very easy to let drift out of sync (e.g. the device limit excludes
 * teachers but the app-only list does not), which is exactly the kind of
 * bug this consolidation avoids.
 */
function auth_devicelock_appguard_restricted_user($user) {
    require_once(__DIR__ . '/auth.php');
    return \auth_plugin_devicelock::should_restrict_user_static($user);
}

/**
 * Bulk-efficient version of auth_devicelock_appguard_restricted_user() for
 * the scheduled task: returns the user IDs of everyone currently subject
 * to the app-only restriction, built with a handful of targeted queries
 * instead of one should_restrict_user_static() call (and its own query)
 * per user on the site - this task runs every minute.
 *
 * Mirrors should_restrict_user_static() exactly: confirmed users only,
 * with the v3.8.0 role-based exclusion list (site admins when the
 * "Administrators" pseudo-entry is selected, plus any user holding one
 * of the selected roles in any context).
 *
 * @return int[]
 */
function auth_devicelock_appguard_restricted_userids() {
    global $DB, $CFG;

    $params = [];
    $where = "u.deleted = 0 AND u.suspended = 0 AND u.confirmed = 1 AND u.id <> :guestid";
    $params['guestid'] = (int)$CFG->siteguest;

    // v3.8.0: role-based exclusion list (replaces the old separate
    // exclude-admins / exclude-teachers checkboxes).
    $excludedroles = (string)get_config('auth_devicelock', 'excludedroles');
    if ($excludedroles !== '') {
        $excluded = array_filter(array_map('trim', explode(',', $excludedroles)), function ($v) {
            return $v !== '';
        });
        if (!empty($excluded)) {
            // Site administrators pseudo-entry.
            if (in_array('admin', $excluded, true)) {
                $adminids = array_filter(array_map('intval', explode(',', (string)$CFG->siteadmins)));
                if (!empty($adminids)) {
                    list($insql, $adminparams) = $DB->get_in_or_equal($adminids, SQL_PARAMS_NAMED, 'adm', false);
                    $where .= " AND u.id $insql";
                    $params = array_merge($params, $adminparams);
                }
            }
            // Any selected role held in ANY context excludes the user.
            $exclroleids = array_values(array_filter(array_map('intval', $excluded), function ($v) {
                return $v > 0;
            }));
            if (!empty($exclroleids)) {
                list($rinsql, $rparams) = $DB->get_in_or_equal($exclroleids, SQL_PARAMS_NAMED, 'exr', true);
                $where .= " AND NOT EXISTS (
                    SELECT 1 FROM {role_assignments} ra
                   WHERE ra.userid = u.id AND ra.roleid $rinsql
                )";
                $params = array_merge($params, $rparams);
            }
        }
    }

    try {
        return array_map('intval', $DB->get_fieldset_select('user', 'id', $where, $params));
    } catch (\Throwable $t) {
        debugging('auth_devicelock appguard restricted-userids query failed: ' . $t->getMessage(), DEBUG_DEVELOPER);
        return [];
    }
}

function auth_devicelock_appguard_set_notice_cookie() {
    global $CFG;
    if (headers_sent()) {
        return;
    }
    $secure = (strpos($CFG->wwwroot, 'https://') === 0);
    try {
        setcookie(AUTH_DEVICELOCK_APPGUARD_NOTICE_COOKIE, (string)time(), [
            'expires' => time() + AUTH_DEVICELOCK_APPGUARD_NOTICE_TTL,
            'path' => ($CFG->cookiepath ?? '/'),
            'httponly' => true,
            'secure' => $secure,
            'samesite' => 'Lax',
        ]);
    } catch (\Throwable $t) {
        /* the restriction itself still holds either way */
    }
}

function auth_devicelock_appguard_notice_cookie_fresh() {
    $value = $_COOKIE[AUTH_DEVICELOCK_APPGUARD_NOTICE_COOKIE] ?? '';
    if (!ctype_digit((string)$value)) {
        return false;
    }
    return (time() - (int)$value) <= AUTH_DEVICELOCK_APPGUARD_NOTICE_TTL;
}

function auth_devicelock_appguard_clear_notice_cookie() {
    global $CFG;
    if (headers_sent()) {
        unset($_COOKIE[AUTH_DEVICELOCK_APPGUARD_NOTICE_COOKIE]);
        return;
    }
    $secure = (strpos($CFG->wwwroot, 'https://') === 0);
    try {
        setcookie(AUTH_DEVICELOCK_APPGUARD_NOTICE_COOKIE, '', [
            'expires' => time() - 3600,
            'path' => ($CFG->cookiepath ?? '/'),
            'httponly' => true,
            'secure' => $secure,
            'samesite' => 'Lax',
        ]);
    } catch (\Throwable $t) {
        /* best effort */
    }
    unset($_COOKIE[AUTH_DEVICELOCK_APPGUARD_NOTICE_COOKIE]);
}

/**
 * Terminates every web session and web-service token of the given user and
 * logs the event into the plugin's OWN Security & Error Logs (the same
 * auth_devicelock_logs table and admin UI as every other DeviceLock
 * event) rather than a separate log store.
 */
function auth_devicelock_appguard_terminate_session($userid, $action, $details) {
    $fingerprint = 'system';
    if ($userid > 0) {
        try {
            $fp = auth_devicelock_get_current_fingerprint();
            if (!empty($fp)) {
                $fingerprint = $fp;
            }
        } catch (\Throwable $t) {
            /* keep 'system' */
        }
    }

    device_manager::log_action($userid, $fingerprint, $action, [
        'details' => $details,
        'user_agent' => substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 250),
        'ip' => getremoteaddr(),
    ]);

    if ($userid > 0) {
        try {
            if (method_exists(\core\session\manager::class, 'destroy_user_sessions')) {
                \core\session\manager::destroy_user_sessions($userid);
            } else {
                \core\session\manager::kill_user_sessions($userid);
            }
        } catch (\Throwable $t) {
            debugging('auth_devicelock appguard session destroy failed: ' . $t->getMessage(), DEBUG_DEVELOPER);
        }
        try {
            $sid = session_id();
            if (!empty($sid)) {
                if (method_exists(\core\session\manager::class, 'destroy')) {
                    \core\session\manager::destroy($sid);
                } else {
                    \core\session\manager::kill_session($sid);
                }
            }
        } catch (\Throwable $t) {
            /* the bulk destroy above already ran */
        }
        try {
            global $DB;
            $DB->delete_records('external_tokens', ['userid' => $userid]);
        } catch (\Throwable $t) {
            /* the scheduled task retries this every minute */
        }
    }
}

/**
 * Called from the EXISTING auth_devicelock login observer
 * (classes/observer.php::user_loggedin) for EVERY login, regardless of the
 * user's auth method - so a restricted user who has not been migrated to
 * devicelock auth yet is still caught. Returns true when the login was
 * blocked (the caller should stop further device-registration logic).
 */
function auth_devicelock_appguard_check_login($userid) {
    try {
        if (!auth_devicelock_appguard_enabled()) {
            return false;
        }
        if (auth_devicelock_appguard_is_app_request()) {
            return false;
        }
        $userid = (int)$userid;
        if ($userid <= 0) {
            return false;
        }
        global $DB;
        $user = $DB->get_record('user', ['id' => $userid]);
        if (!$user || !auth_devicelock_appguard_restricted_user($user)) {
            return false;
        }

        auth_devicelock_appguard_terminate_session(
            $userid,
            'web_browser_sign_in_blocked',
            'Sign-in from outside the app - session terminated.'
        );
        auth_devicelock_appguard_set_notice_cookie();
        return true;
    } catch (\Throwable $t) {
        debugging('auth_devicelock appguard login check failed: ' . $t->getMessage(), DEBUG_DEVELOPER);
        return false;
    }
}

/**
 * Page-view enforcement: called from the before_http_headers hook on every
 * request, for any auth method and any logged-in user. Catches sessions
 * that already existed before the restriction was enabled (or before this
 * user was migrated to devicelock auth).
 */
function auth_devicelock_appguard_enforce_page_view() {
    global $USER, $CFG;

    static $executed = false;
    if ($executed) {
        return;
    }
    $executed = true;

    if (defined('CLI_SCRIPT') || defined('BEHAT_SITE')) {
        return;
    }

    $script = (string)($_SERVER['SCRIPT_NAME'] ?? '');
    $prefix = (string)(parse_url($CFG->wwwroot, PHP_URL_PATH) ?: '');
    if ($prefix !== '' && $prefix !== '/' && strpos($script, $prefix) === 0) {
        $script = substr($script, strlen($prefix));
    }
    // Our own endpoint and notice page manage themselves.
    foreach (['/auth/devicelock/appguard_rest.php', '/auth/devicelock/appguard_blocked.php', '/auth/devicelock/ios_identity.php'] as $own) {
        if (strpos($script, $own) === 0) {
            return;
        }
    }

    if (!auth_devicelock_appguard_enabled()) {
        return;
    }
    if (auth_devicelock_appguard_is_app_request()) {
        return;
    }

    if (isloggedin() && !isguestuser()) {
        $userid = (int)$USER->id;
        if (!auth_devicelock_appguard_restricted_user($USER)) {
            return;
        }
        auth_devicelock_appguard_terminate_session(
            $userid,
            'web_browser_session_terminated',
            'Session terminated: restricted user browsing outside the app.'
        );
        auth_devicelock_appguard_set_notice_cookie();
        redirect(new \moodle_url('/auth/devicelock/appguard_blocked.php'));
    } else if (auth_devicelock_appguard_notice_cookie_fresh()) {
        redirect(new \moodle_url('/auth/devicelock/appguard_blocked.php'));
    }
}

/**
 * Legacy lib.php output callback (pre-hooks-API mechanism). Kept as a
 * belt-and-braces fallback alongside the modern hook; Moodle 4.4+
 * automatically suppresses this one once the modern hook is registered, so
 * the two never double-fire (auth_devicelock_appguard_enforce_page_view()
 * also has its own run-once guard).
 *
 * v3.10.0: the user-activity page logger is captured here TOO, so pages
 * are still tracked on sites where the modern hook dispatch never runs
 * (observed on some Moodle 5.0/5.1 installs, where the v3.6.0 hook-based
 * logger silently never fired). Same suppression rules as above apply,
 * and the capture itself is idempotent per request.
 */
function auth_devicelock_before_http_headers() {
    auth_devicelock_appguard_enforce_page_view();
    auth_devicelock_adminnav_tweaks();
    auth_devicelock_activity_log_current_page();
}

/**
 * Site administration navigation tweaks for the Lock Guard tab.
 *
 *  - Plugin settings page (admin/settings.php?section=authsettingdevicelock):
 *    keep the Lock Guard top-bar tab active (Moodle would pick Plugins).
 *  - Lock Guard tab page (admin/category.php?category=lockguard): hide the
 *    black "Lock Guard" heading row. Moodle always draws a category's own
 *    heading row, so this cannot be done from the admin tree.
 */
function auth_devicelock_adminnav_tweaks() {
    global $PAGE;

    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    if (defined('CLI_SCRIPT') || defined('AJAX_SCRIPT') || defined('BEHAT_SITE')) {
        return;
    }
    if (!isloggedin() || isguestuser() || !$PAGE->has_set_url()) {
        return;
    }

    $path = $PAGE->url->get_path();

    if (str_ends_with($path, '/admin/settings.php')) {
        if ($PAGE->url->get_param('section') === 'authsettingdevicelock') {
            $PAGE->set_secondary_active_tab('lockguard');
        }
        return;
    }

    if (!str_ends_with($path, '/admin/category.php')) {
        return;
    }

    $category = $PAGE->url->get_param('category');
    if ($category !== 'lockguard') {
        return;
    }

    $js = <<<'JS'
(function(mode) {
    try {
        var main = document.getElementById('region-main') || document.querySelector('[role="main"]');
        if (!main) { return; }
        var HSEL = 'h1,h2,h3,h4,h5,h6,.h1,.h2,.h3,.h4,.h5,.h6';
        // Highest ancestor (below main) that holds at most one heading = the section row.
        var rowOf = function(start) {
            var row = start, p = start.parentElement;
            while (p && p !== main && p.querySelectorAll(HSEL).length <= 1) {
                row = p;
                p = p.parentElement;
            }
            return row;
        };
        if (mode === 'lockguard') {
            var heads = main.querySelectorAll(HSEL);
            for (var i = 0; i < heads.length; i++) {
                if (heads[i].textContent.trim() === 'Lock Guard' && !heads[i].querySelector('a')) {
                    var row = rowOf(heads[i]);
                    row.style.display = 'none';
                    var next = row.nextElementSibling;
                    if (next && next.tagName === 'HR') { next.style.display = 'none'; }
                    break;
                }
            }
        }
    } catch (e) { /* cosmetic only */ }
})(%MODE%);
JS;
    $PAGE->requires->js_init_code(str_replace('%MODE%', json_encode($category), $js), true);
}

/**
 * Sends a popup + email message to every site administrator about a
 * device-security event reported by the app (emulator, screenshot,
 * developer options, debugging, screen recording, audio capture).
 */
function auth_devicelock_appguard_notify_admins($offender, $type, $other) {
    global $CFG;
    require_once($CFG->libdir . '/messagelib.php');

    $admins = get_admins();
    if (empty($admins)) {
        return;
    }

    $typenames = [
        'screenshot_attempt'           => 'Screenshot detected',
        'screen_recording_detected'    => 'Screen recording detected',
        'dev_options_detected'         => 'Developer options detected',
        'usb_debugging_detected'       => 'USB debugging detected',
        'wireless_debugging_detected'  => 'Wireless debugging detected',
        'emulator_detected'            => 'Emulator detected',
        'audio_capture_detected'       => 'Audio capture detected',
        'mic_guard_unavailable'        => 'Microphone guard unavailable',
        'mic_contended'                => 'Microphone contended',
        'vm_detected' => 'Virtual machine detected',
        'debugger_detected' => 'Debugger detected',
        'dev_mode_detected' => 'Developer mode detected',
        'test_signing_detected' => 'Test signing detected',
        'remote_session_detected' => 'Remote session detected',
        'virtual_display_detected' => 'Virtual display detected',
        'capture_tool_detected' => 'Capture / remote tool detected',
        'recorder_suspected' => 'Recorder suspected (report only)',
    ];

    $typelabel = $typenames[$type] ?? $type;
    $username = $offender ? (fullname($offender) . ' (' . $offender->username . ')') : 'Unauthenticated device';
    $device = $other['device'] ?: '-';
    $details = $other['details'] ?: '-';
    $when = userdate(time());

    $subject = 'App Guard: ' . $typelabel;
    $plain = "App Guard security event\n\nType: $typelabel\nUser: $username\nDevice: $device\nDetails: $details\nTime: $when";
    $html = '<p><strong>App Guard security event</strong></p><ul>' .
        '<li><strong>Type:</strong> ' . s($typelabel) . '</li>' .
        '<li><strong>User:</strong> ' . s($username) . '</li>' .
        '<li><strong>Device:</strong> ' . s($device) . '</li>' .
        '<li><strong>Details:</strong> ' . s($details) . '</li>' .
        '<li><strong>Time:</strong> ' . s($when) . '</li></ul>';

    foreach ($admins as $admin) {
        $message = new \core\message\message();
        $message->component = 'auth_devicelock';
        $message->name = 'security_alert';
        $message->userfrom = \core_user::get_noreply_user();
        $message->userto = $admin;
        $message->subject = $subject;
        $message->fullmessage = $plain;
        $message->fullmessageformat = FORMAT_MOODLE;
        $message->fullmessagehtml = $html;
        $message->smallmessage = $subject;
        $message->contexturl = $CFG->wwwroot . '/auth/devicelock/admin_devices.php?tab=logs';
        $message->contexturlname = 'Security & Error Logs';
        message_send($message);
    }
}

// ============================================================
// Feature: Persistent Security Score (v3.5.0)
//
// The score lives in {auth_devicelock_user_scores}: every user
// starts at 100 when their account is created, each detected
// violation lowers it by a fixed amount (see
// auth_devicelock_score_violation_deductions()), and it slowly
// regains points over time once the user stops violating. A new
// violation before the regain timer expires restarts the timer,
// so no points are regained until it reaches zero again. When the
// score reaches the auto-ban threshold the user can be banned (setting).
// ============================================================

/**
 * Score points deducted per violation type.
 *
 * Admins can review (and users are informed by) this exact list:
 *  - Login & device violations: 4-12 points each.
 *  - App Guard tampering events: 8-25 points each.
 *  - Admin sanctions (suspension -15, ban -40).
 * Actions logged with the ADMIN as subject (e.g. bulk_ban_users)
 * are NOT in this map - the bulk handlers apply the deduction to
 * each target user themselves.
 *
 * @return array action name => points deducted.
 */
function auth_devicelock_score_violation_deductions() {
    return [
        // Login & device violations (detected automatically).
        'login_prevented'              => 10,
        'blocked_device_login_attempt' => 10,
        'unexpected_device_login'      => 12,
        'device_limit_reached'         => 6,
        'browser_limit_reached'        => 6,
        'login_blocked_limit'          => 8,
        'web_browser_sign_in_blocked'  => 4,
        'device_status_blocked'        => 5,
        // Admin sanctions (logged against the target user).
        'toggle_suspend'               => 15, // Only when suspended, not restored.
        'ban_user'                     => 40,
        // App Guard - Android app security events.
        'screenshot_attempt'           => 15,
        'screen_recording_detected'    => 20,
        'dev_options_detected'         => 20,
        'usb_debugging_detected'       => 18,
        'wireless_debugging_detected'  => 18,
        'emulator_detected'            => 25,
        'audio_capture_detected'       => 15,
        'mic_guard_unavailable'        => 8,
        'mic_contended'                => 10,
        // App Guard - Windows app security events.
        'vm_detected'                  => 25,
        'debugger_detected'            => 20,
        'dev_mode_detected'            => 20,
        'test_signing_detected'        => 18,
        'remote_session_detected'      => 12,
        'virtual_display_detected'     => 15,
        'capture_tool_detected'        => 15,
        'recorder_suspected'           => 15,
    ];
}

/**
 * Read one plugin config value with a default (get_config returns
 * false/null for never-saved settings, which must fall back).
 *
 * @param string $name    Short setting name (without the plugin prefix).
 * @param mixed  $default Value used when the setting was never saved.
 * @return mixed
 */
function auth_devicelock_score_cfg($name, $default) {
    $val = get_config('auth_devicelock', $name);
    if ($val === false || $val === null || $val === '') {
        return $default;
    }
    return $val;
}

/**
 * Seconds represented by one unit of the regain-interval unit list
 * (seconds, minutes, hours, days, weeks, months).
 *
 * @param string $unit Unit name.
 * @return int Seconds (1 day by default).
 */
function auth_devicelock_score_unit_seconds($unit) {
    switch ((string)$unit) {
        case 'seconds': return 1;
        case 'minutes': return 60;
        case 'hours':   return 3600;
        case 'days':    return 86400;
        case 'weeks':   return 604800;
        case 'months':  return 2592000; // 30 days, deterministic.
    }
    return 86400;
}

/**
 * The GLOBAL score settings (from the plugin settings page).
 *
 * @return stdClass {enabled, autoban, autoban_threshold, regain_enabled,
 *                   regain_amount, regain_number, regain_unit, regain_interval}
 */
function auth_devicelock_score_global_config() {
    $cfg = new stdClass();
    $cfg->enabled        = (int)auth_devicelock_score_cfg('score_enabled', 1) === 1;
    $cfg->autoban        = (int)auth_devicelock_score_cfg('score_autoban', 0) === 1;
    // v3.7.0: adjustable auto-ban threshold (0-100%). The default of 0
    // keeps the classic "ban only once the score lands on 0%" behaviour.
    $cfg->autoban_threshold = max(0, min(100, (int)auth_devicelock_score_cfg('score_autoban_threshold', 0)));
    $cfg->regain_enabled = (int)auth_devicelock_score_cfg('score_regain_enabled', 1) === 1;
    $cfg->regain_amount  = max(0, (int)auth_devicelock_score_cfg('score_regain_amount', 5));
    $cfg->regain_number  = max(0, (int)auth_devicelock_score_cfg('score_regain_number', 1));
    $cfg->regain_unit    = (string)auth_devicelock_score_cfg('score_regain_unit', 'days');
    $cfg->regain_interval = $cfg->regain_number * auth_devicelock_score_unit_seconds($cfg->regain_unit);
    return $cfg;
}

/**
 * Effective regain settings for one user (custom override or global).
 *
 * @param stdClass $row Row from auth_devicelock_user_scores.
 * @return array [points per regain, seconds between regains, is_custom]
 */
function auth_devicelock_score_regain_settings_for($row) {
    if (!empty($row->custom_regain)) {
        return [
            max(1, (int)$row->regain_amount),
            max(1, (int)$row->regain_interval),
            true,
        ];
    }
    $gc = auth_devicelock_score_global_config();
    return [(int)$gc->regain_amount, (int)$gc->regain_interval, false];
}

/**
 * Build a fresh score row (100%) for a user.
 *
 * @param int $userid
 * @return stdClass
 */
function auth_devicelock_score_new_row($userid) {
    $row = new stdClass();
    $row->id             = 0;
    $row->userid         = (int)$userid;
    $row->score          = 100;
    $row->violation_count = 0;
    $row->last_violation = 0;
    $row->last_regain    = 0;
    $row->custom_regain  = 0;
    $row->regain_amount  = 0;
    $row->regain_interval = 0;
    $row->updated_at     = time();
    return $row;
}

/**
 * Fetch (and create when missing) the score rows for a set of users.
 *
 * Missing rows are created at 100% - this is what makes a brand-new
 * account "start at 100%" even if the user_created event was missed.
 *
 * @param array $userids
 * @return array userid => row object (only users that exist).
 */
function auth_devicelock_score_ensure_rows_batch(array $userids) {
    global $DB;

    $uids = [];
    foreach ($userids as $uid) {
        $uid = (int)$uid;
        if ($uid > 1) { // Skip guest and the wwwroot "user".
            $uids[$uid] = $uid;
        }
    }
    if (empty($uids)) {
        return [];
    }
    if (!$DB->get_manager()->table_exists('auth_devicelock_user_scores')) {
        return [];
    }

    list($insql, $inparams) = $DB->get_in_or_equal(array_values($uids), SQL_PARAMS_NAMED, 'scensure_');
    $rows = $DB->get_records_select('auth_devicelock_user_scores', "userid $insql", $inparams);

    $byuser = [];
    foreach ($rows as $r) {
        $byuser[(int)$r->userid] = $r;
    }

    $missing = array_diff_key($uids, $byuser);
    if (!empty($missing)) {
        // Only create rows for users that actually exist (protects the FK).
        list($minsql, $minparams) = $DB->get_in_or_equal(array_values($missing), SQL_PARAMS_NAMED, 'scmiss_');
        $real = $DB->get_records_select('user', "id $minsql AND deleted = 0", $minparams, '', 'id');
        foreach ($real as $ru) {
            $new = auth_devicelock_score_new_row($ru->id);
            try {
                $new->id = $DB->insert_record('auth_devicelock_user_scores', $new, true);
                $byuser[(int)$ru->id] = $new;
            } catch (\Exception $e) {
                // Unique-index race (row created meanwhile) - re-read it.
                $existing = $DB->get_record('auth_devicelock_user_scores', ['userid' => (int)$ru->id]);
                if ($existing) {
                    $byuser[(int)$ru->id] = $existing;
                }
            }
        }
    }
    return $byuser;
}

/**
 * Fetch (and create when missing) the score row for one user.
 *
 * @param int $userid
 * @return stdClass
 */
function auth_devicelock_score_ensure_row($userid) {
    $batch = auth_devicelock_score_ensure_rows_batch([(int)$userid]);
    if (isset($batch[(int)$userid])) {
        return $batch[(int)$userid];
    }
    return auth_devicelock_score_new_row($userid);
}

/**
 * Read one user's score row, applying any regain that is already due
 * (so the displayed value is always current, even between cron runs).
 *
 * @param int $userid
 * @return stdClass
 */
function auth_devicelock_score_get($userid) {
    $row = auth_devicelock_score_ensure_row($userid);
    if (!empty($row->id)) {
        // Silent regain (no log row) - the scheduled task logs regains.
        list($row) = auth_devicelock_score_apply_regain($row, time(), false);
    }
    return $row;
}

/**
 * Apply a due regain to one score row.
 *
 * The regain timer: a user regains `amount` points after every full
 * `interval` elapsed since the LAST of (last violation, last regain).
 * Any new violation updates last_violation, which instantly restarts
 * the timer - no points are regained until it reaches zero again.
 *
 * @param stdClass $row  Score row (must have ->id).
 * @param int|null $now  Timestamp (default: now).
 * @param bool     $log  Write a "score_regained" log row (cron) or not (read path).
 * @return array   [updated row, bool changed]
 */
function auth_devicelock_score_apply_regain($row, $now = null, $log = true) {
    global $DB;

    if (empty($row->id)) {
        return [$row, false];
    }
    if ($now === null) {
        $now = time();
    }
    $gc = auth_devicelock_score_global_config();
    $score = (int)$row->score;
    if ($score >= 100 || !$gc->enabled || !$gc->regain_enabled) {
        return [$row, false];
    }

    list($amount, $interval, $iscustom) = auth_devicelock_score_regain_settings_for($row);
    if ($amount <= 0 || $interval <= 0) {
        return [$row, false];
    }

    $lastevent = max((int)$row->last_violation, (int)$row->last_regain);
    if ($lastevent > 0 && ($now - $lastevent) < $interval) {
        return [$row, false]; // Timer has not reached zero yet.
    }

    $new = min(100, $score + $amount);
    $row->score = $new;
    $row->last_regain = $now;
    $row->updated_at = $now;
    $DB->update_record('auth_devicelock_user_scores', $row);
    auth_devicelock_score_record_history((int)$row->userid, $new);

    if ($log) {
        device_manager::log_action((int)$row->userid, 'system', 'score_regained', [
            'gained'       => $new - $score,
            'score_before' => $score,
            'score_after'  => $new,
            'custom'       => $iscustom ? 1 : 0,
        ]);
    }
    return [$row, true];
}

/**
 * Append one snapshot to the score-history table (sparkline data)
 * and opportunistically prune it to the newest 90 rows per user.
 *
 * @param int $userid
 * @param int $score
 * @return void
 */
function auth_devicelock_score_record_history($userid, $score) {
    global $DB;

    if (!$DB->get_manager()->table_exists('auth_devicelock_score_history')) {
        return;
    }
    $bl = auth_devicelock_security_score_band((int)$score);
    $histrec = new stdClass();
    $histrec->userid = (int)$userid;
    $histrec->score = (int)$score;
    $histrec->band = $bl['band'];
    $histrec->timestamp = time();
    try {
        $DB->insert_record('auth_devicelock_score_history', $histrec, false);
    } catch (\Exception $e) {
        return;
    }

    $count = $DB->count_records('auth_devicelock_score_history', ['userid' => (int)$userid]);
    if ($count > 90) {
        $cutoffrow = $DB->get_records('auth_devicelock_score_history', ['userid' => (int)$userid], 'timestamp DESC', 'id, timestamp', 90, 1);
        if (!empty($cutoffrow)) {
            $cutoffts = reset($cutoffrow)->timestamp;
            $DB->delete_records_select(
                'auth_devicelock_score_history',
                'userid = :uid AND timestamp < :ts',
                ['uid' => (int)$userid, 'ts' => $cutoffts]
            );
        }
    }
}

/**
 * Process one logged event as a violation: lower the stored score,
 * restart the regain timer, append history, and auto-ban at the threshold.
 *
 * Called automatically from device_manager::log_action() and
 * auth_devicelock_log_action() for every logged action - actions
 * that are not violations return null immediately.
 *
 * @param int    $userid  The user the violation is against.
 * @param string $action  Log action name.
 * @param array  $details Log details array (by-ref enriched with score info).
 * @param int    $logid   Id of the inserted log row (details updated in place).
 * @return array|null ['old' => int, 'new' => int, 'change' => int] or null.
 */
function auth_devicelock_score_apply_violation($userid, $action, &$details = [], $logid = 0) {
    global $DB;

    static $busy = [];
    $userid = (int)$userid;
    if ($userid <= 2) {
        return null; // Never score guest / the wwwroot pseudo-user.
    }
    $busykey = $userid . '|' . $action;
    if (!empty($busy[$busykey])) {
        return null; // Re-entrancy guard (e.g. the auto-ban's own log row).
    }

    $gc = auth_devicelock_score_global_config();
    if (!$gc->enabled) {
        return null;
    }

    $deductions = auth_devicelock_score_violation_deductions();
    if (!isset($deductions[$action])) {
        return null;
    }

    // Suspending an account is a sanction; restoring it is not.
    if ($action === 'toggle_suspend' && isset($details['suspended']) && empty($details['suspended'])) {
        return null;
    }

    // Site admins and deleted accounts never lose score.
    static $admincache = [];
    if (!isset($admincache[$userid])) {
        $u = $DB->get_record('user', ['id' => $userid], 'id, deleted', IGNORE_MISSING);
        $admincache[$userid] = ($u && !$u->deleted && is_siteadmin($userid));
    }
    if ($admincache[$userid]) {
        return null;
    }

    $row = auth_devicelock_score_ensure_row($userid);
    if (empty($row->id)) {
        return null;
    }

    $old = (int)$row->score;
    $points = (int)$deductions[$action];
    $new = max(0, min(100, $old - $points));

    $busy[$busykey] = true;
    try {
        $row->score = $new;
        $row->violation_count = (int)$row->violation_count + 1;
        $row->last_violation = time();
        $row->updated_at = time();
        $DB->update_record('auth_devicelock_user_scores', $row);
        auth_devicelock_score_record_history($userid, $new);

        // Enrich the original log row so the violation entry itself shows
        // the score change (rendered as chips by the shared details cell).
        if (!empty($logid) && is_array($details)) {
            $details['score_before'] = $old;
            $details['score_after'] = $new;
            $details['score_change'] = $new - $old;
            try {
                $DB->set_field('auth_devicelock_logs', 'details', json_encode($details), ['id' => (int)$logid]);
            } catch (\Exception $e) {
                // Non-fatal - keep the score change even if the log update fails.
            }
        }

        // Auto-ban when the score lands at or below the threshold
        // (setting-controlled; the threshold is adjustable, default 0%).
        if ($gc->autoban && $new <= (int)$gc->autoban_threshold) {
            auth_devicelock_score_autoban_check($userid);
        }
    } finally {
        unset($busy[$busykey]);
    }

    return ['old' => $old, 'new' => $new, 'change' => $new - $old];
}

/**
 * Ban a user whose score reached the auto-ban threshold (when the
 * Auto-ban setting is on).
 *
 * Mirrors the manual ban: active row in {auth_devicelock_bans}, account
 * suspended, all sessions killed, and an audit log entry flagged as
 * automatic. The threshold is adjustable (v3.7.0, default 0%) and is
 * re-verified against the STORED score, so this is safe to call from the
 * settings-save sweep as well as the violation paths.
 *
 * @param int $userid
 * @return bool True when a ban was created.
 */
function auth_devicelock_score_autoban_check($userid) {
    global $DB;

    $userid = (int)$userid;
    if ($userid <= 2 || is_siteadmin($userid)) {
        return false;
    }
    $gc = auth_devicelock_score_global_config();
    if (!$gc->enabled || !$gc->autoban) {
        return false;
    }
    if (!$DB->get_manager()->table_exists('auth_devicelock_bans') ||
        !$DB->get_manager()->table_exists('auth_devicelock_user_scores')) {
        return false;
    }

    $u = $DB->get_record('user', ['id' => $userid], '*', IGNORE_MISSING);
    if (!$u || $u->deleted) {
        return false;
    }

    // Already banned - nothing to do.
    if ($DB->record_exists('auth_devicelock_bans', ['userid' => $userid, 'status' => 'active'])) {
        return false;
    }

    // Defense in depth: callers already compare against the threshold, but
    // verify the STORED score here too so the sweep (and any future caller)
    // can never over-ban.
    $scorerow = $DB->get_record('auth_devicelock_user_scores', ['userid' => $userid], 'score', IGNORE_MISSING);
    if (!$scorerow || (int)$scorerow->score > (int)$gc->autoban_threshold) {
        return false;
    }

    $reason = get_string('score_autoban_reason', 'auth_devicelock', (int)$gc->autoban_threshold);
    $systemadmin = get_admin();

    // Revoke any stale ban, then insert the active auto-ban.
    $DB->set_field('auth_devicelock_bans', 'status', 'revoked', ['userid' => $userid, 'status' => 'active']);
    $ban = new stdClass();
    $ban->userid = $userid;
    $ban->reason = $reason;
    $ban->banned_by = $systemadmin ? (int)$systemadmin->id : 2;
    $ban->banned_at = time();
    $ban->ip_address = '';
    $ban->device_fingerprint = '';
    $ban->status = 'active';
    $DB->insert_record('auth_devicelock_bans', $ban);

    // Suspend the account and kill every session (same as a manual ban).
    $u->suspended = 1;
    $DB->update_record('user', $u);
    if (class_exists('\core\session\manager')) {
        \core\session\manager::kill_user_sessions($userid);
    }

    // Audit log. The 'ban_user' violation this generates is absorbed by the
    // re-entrancy guard / already-banned check (score stays 0 either way).
    device_manager::log_action($userid, 'system', 'ban_user', [
        'automatic'   => 1,
        'reason'      => $reason,
        'trigger'     => 'security_score',
        'admin_user'  => $systemadmin ? (int)$systemadmin->id : 2,
        'admin_name'  => 'Lock Guard (automatic)',
    ]);
    return true;
}

/**
 * v3.7.0: Auto-ban every user whose STORED score is already at or below
 * the configured auto-ban threshold.
 *
 * Runs when the admin saves the Auto-ban checkbox or the threshold
 * setting, so raising the threshold immediately bans the users it now
 * covers, and enabling the feature honours an existing threshold.
 * Idempotent: already-banned, administrator and deleted accounts are all
 * skipped inside auth_devicelock_score_autoban_check().
 *
 * @return int Number of users that were banned by this sweep.
 */
function auth_devicelock_score_autoban_sweep() {
    global $DB;

    $gc = auth_devicelock_score_global_config();
    if (!$gc->enabled || !$gc->autoban) {
        return 0;
    }
    if (!$DB->get_manager()->table_exists('auth_devicelock_user_scores') ||
        !$DB->get_manager()->table_exists('auth_devicelock_bans')) {
        return 0;
    }

    $threshold = (int)$gc->autoban_threshold;
    $count = 0;
    $rs = $DB->get_recordset_select('auth_devicelock_user_scores', 'score <= :thr', ['thr' => $threshold], 'userid ASC', 'userid');
    foreach ($rs as $row) {
        if (auth_devicelock_score_autoban_check((int)$row->userid)) {
            $count++;
        }
    }
    $rs->close();
    return $count;
}

/**
 * Manually change or reset a user's score (Change Score form, bulk
 * reset, and the quick-create/none paths all funnel through here).
 *
 * Semantics:
 *  - reset: score 100, violation counter and both timers cleared.
 *  - a decrease behaves like a sanction: it restarts the regain timer
 *    (and counts as a violation), so the user cannot regain it right back.
 *  - an increase / set does not touch the timers.
 *
 * @param int   $userid
 * @param int   $newscore  Final score (clamped to 0-100).
 * @param array $opts      Optional: operation, amount, reason, reset,
 *                         custom_regain, regain_amount, regain_interval.
 * @return array ['old' => int, 'new' => int, 'row' => stdClass]
 */
function auth_devicelock_score_set($userid, $newscore, $opts = []) {
    global $DB;

    $userid = (int)$userid;
    $row = auth_devicelock_score_ensure_row($userid);
    $old = (int)$row->score;
    $new = max(0, min(100, (int)$newscore));
    $reset = !empty($opts['reset']);

    $row->score = $new;
    $row->updated_at = time();
    if ($reset) {
        $row->violation_count = 0;
        $row->last_violation = 0;
        $row->last_regain = 0;
    } else if ($new < $old) {
        // A manual decrease is a sanction: restart the regain timer.
        $row->violation_count = (int)$row->violation_count + 1;
        $row->last_violation = time();
    }

    // Per-user custom regain settings.
    $customchanged = false;
    if (array_key_exists('custom_regain', $opts)) {
        if (!empty($opts['custom_regain'])) {
            $row->custom_regain = 1;
            $row->regain_amount = max(1, (int)($opts['regain_amount'] ?? $row->regain_amount));
            $row->regain_interval = max(1, (int)($opts['regain_interval'] ?? $row->regain_interval));
        } else {
            $row->custom_regain = 0;
        }
        $customchanged = true;
    }

    if (!empty($row->id)) {
        $DB->update_record('auth_devicelock_user_scores', $row);
    } else {
        $row->id = $DB->insert_record('auth_devicelock_user_scores', $row, true);
    }
    auth_devicelock_score_record_history($userid, $new);

    // Audit log.
    $detail = [
        'operation'    => isset($opts['operation']) ? $opts['operation'] : 'set',
        'score_before' => $old,
        'score_after'  => $new,
    ];
    if (!empty($opts['amount'])) {
        $detail['amount'] = (int)$opts['amount'];
    }
    if (!empty($opts['reason'])) {
        $detail['reason'] = (string)$opts['reason'];
    }
    if ($customchanged) {
        $detail['custom_regain'] = (int)$row->custom_regain;
        if (!empty($row->custom_regain)) {
            $detail['regain_amount'] = (int)$row->regain_amount;
            $detail['regain_interval'] = (int)$row->regain_interval;
        }
    }
    device_manager::log_action($userid, 'system', 'score_changed', $detail);

    // Auto-ban when the score lands at or below the threshold
    // (setting-controlled; the threshold is adjustable, default 0%).
    $gcset = auth_devicelock_score_global_config();
    if ($gcset->enabled && $gcset->autoban && $new <= (int)$gcset->autoban_threshold) {
        auth_devicelock_score_autoban_check($userid);
    }

    return ['old' => $old, 'new' => $new, 'row' => $row];
}

/**
 * Cron entry point: apply every due regain (and log each one).
 *
 * @return int Number of users that regained points.
 */
function auth_devicelock_score_process_regains_all() {
    global $DB;

    if (!$DB->get_manager()->table_exists('auth_devicelock_user_scores')) {
        return 0;
    }
    $gc = auth_devicelock_score_global_config();
    if (!$gc->enabled || !$gc->regain_enabled) {
        return 0;
    }

    $now = time();
    $count = 0;
    $rs = $DB->get_recordset_select('auth_devicelock_user_scores', 'score < 100', null, 'userid ASC', '*');
    foreach ($rs as $row) {
        list($row, $changed) = auth_devicelock_score_apply_regain($row, $now, true);
        if ($changed) {
            $count++;
        }
    }
    $rs->close();
    return $count;
}

/**
 * Map a numeric score to a band key + localized label.
 *
 * (Moved to lib.php in v3.5.0 so the persistent-score engine can record
 * the band into the history table without depending on locallib.php.)
 *
 * @param int $score
 * @return array  ['band' => string, 'label' => string]
 */
function auth_devicelock_security_score_band($score) {
    $score = (int)$score;
    if ($score >= 85) {
        return ['band' => 'high', 'label' => get_string('security_score_high', 'auth_devicelock')];
    } else if ($score >= 70) {
        return ['band' => 'good', 'label' => get_string('security_score_good', 'auth_devicelock')];
    } else if ($score >= 50) {
        return ['band' => 'fair', 'label' => get_string('security_score_fair', 'auth_devicelock')];
    } else if ($score >= 25) {
        return ['band' => 'poor', 'label' => get_string('security_score_poor', 'auth_devicelock')];
    }
    return ['band' => 'critical', 'label' => get_string('security_score_critical', 'auth_devicelock')];
}

/**
 * Human-readable one-unit interval (e.g. "1 day", "2 weeks", "6 hours").
 *
 * @param int $seconds
 * @return string
 */
function auth_devicelock_score_format_interval($seconds) {
    $seconds = (int)$seconds;
    if ($seconds <= 0) {
        return '-';
    }
    $units = [
        [2592000, 'month'],
        [604800, 'week'],
        [86400, 'day'],
        [3600, 'hour'],
        [60, 'minute'],
        [1, 'second'],
    ];
    foreach ($units as $pair) {
        if ($seconds >= $pair[0] && $seconds % $pair[0] === 0) {
            $n = (int)($seconds / $pair[0]);
            return $n . ' ' . $pair[1] . ($n === 1 ? '' : 's');
        }
    }
    // Non-whole value: show a compact approximation.
    foreach ($units as $pair) {
        if ($seconds >= $pair[0]) {
            $n = (int)round($seconds / $pair[0]);
            return '~' . $n . ' ' . $pair[1] . ($n === 1 ? '' : 's');
        }
    }
    return $seconds . ' seconds';
}

/**
 * Seconds until the user's next regain tick.
 *
 * @param stdClass $row Score row.
 * @return int  0 = due now, -1 = not applicable (full score / regain off).
 */
function auth_devicelock_score_next_regain_in($row) {
    $gc = auth_devicelock_score_global_config();
    if ((int)$row->score >= 100 || !$gc->enabled || !$gc->regain_enabled) {
        return -1;
    }
    list($amount, $interval, $iscustom) = auth_devicelock_score_regain_settings_for($row);
    if ($amount <= 0 || $interval <= 0) {
        return -1;
    }
    $lastevent = max((int)$row->last_violation, (int)$row->last_regain);
    if ($lastevent <= 0) {
        return 0;
    }
    return max(0, $lastevent + $interval - time());
}

/**
 * v3.6.0: Is user-activity tracking currently active for THIS request?
 *
 * Shared gate used by the page-view logger, the footer link beacon
 * and the ajax.php 'activitylink' endpoint, so all three always
 * agree on who gets tracked.
 *
 * @return bool True when the current user's activity should be recorded.
 */
function auth_devicelock_activity_tracking_active() {
    global $USER, $PAGE;

    // Master switch. A value that was never saved at all (false) means
    // "use the default", which is ENABLED - the same default the settings
    // checkbox shows - so the feature works straight after upgrading.
    $enabled = get_config('auth_devicelock', 'activitylog_enabled');
    if ($enabled === false || $enabled === '') {
        $enabled = 1;
    }
    if (empty($enabled)) {
        return false;
    }

    // Only real, logged-in accounts are tracked.
    if (!isloggedin() || isguestuser() || empty($USER->id) || (int)$USER->id < 2) {
        return false;
    }

    // Site administrators are excluded unless the admin opted in.
    $trackadmins = get_config('auth_devicelock', 'activitylog_admins');
    if (empty($trackadmins) && is_siteadmin((int)$USER->id)) {
        return false;
    }

    // Lock Guard's own admin pages are administration, not user activity.
    if (isset($PAGE) && $PAGE->has_set_url()) {
        $path = $PAGE->url->get_path();
        if (strpos($path, '/auth/devicelock/') !== false) {
            return false;
        }
    }

    return true;
}

/**
 * v3.8.0: Has a core event observer already recorded activity for this request?
 *
 * Per-request dedupe flag shared between the event observers
 * (auth_devicelock_activity_log_event()) and the generic page-view
 * logger (auth_devicelock_activity_log_current_page()): once an
 * observer has written a specific view (course, module, profile...),
 * the page logger stays silent so the same page is never logged twice.
 *
 * @param bool|null $set When not null, the flag is set to this value first.
 * @return bool True when an event observer already logged this request.
 */
function auth_devicelock_activity_event_logged($set = null) {
    static $logged = false;
    if ($set !== null) {
        $logged = (bool)$set;
    }
    return $logged;
}

/**
 * v3.8.0: Observer-side activity gate for one specific user id.
 *
 * Event observers may run in AJAX or CLI contexts where global $USER
 * is unreliable, so the user is passed in explicitly instead of being
 * read from the session. This mirrors the master switch, real-account
 * and admin-opt-in rules of auth_devicelock_activity_tracking_active()
 * (the page-logger gate) minus the checks that only make sense for
 * a rendered page.
 *
 * @param int $userid The user id the event belongs to.
 * @return bool True when this user's activity should be recorded.
 */
function auth_devicelock_activity_tracking_active_for_user($userid) {

    // Master switch. A value that was never saved at all (false) means
    // "use the default", which is ENABLED - the same default the
    // settings checkbox shows - so the feature works straight after
    // upgrading. Identical resolution to the page-logger gate above.
    $enabled = get_config('auth_devicelock', 'activitylog_enabled');
    if ($enabled === false || $enabled === '') {
        $enabled = 1;
    }
    if (empty($enabled)) {
        return false;
    }

    // Only real, logged-in accounts are tracked.
    if ((int)$userid < 2) {
        return false;
    }

    // Site administrators are excluded unless the admin opted in.
    $trackadmins = get_config('auth_devicelock', 'activitylog_admins');
    if (empty($trackadmins) && is_siteadmin((int)$userid)) {
        return false;
    }

    return true;
}

/**
 * v3.8.0: Shared pipeline that records an observed core event as user activity.
 *
 * All the activity_* event observers (db/events.php) funnel through
 * here: it applies the observer-side tracking gate, fills in the
 * event's own URL when the caller built none and writes the log row
 * through the normal logging pipeline. User-tour events arrive in
 * AJAX web-service requests, so nothing here bails on AJAX scripts.
 * Every failure is swallowed (with debugging output) so a logging
 * problem can never break the page that was being viewed.
 *
 * @param \core\event\base $event The core event that was observed.
 * @param string $action The activity action to log (e.g. 'activity_course').
 * @param array $details Ready-made details for the log row.
 * @return void
 */
function auth_devicelock_activity_log_event(\core\event\base $event, $action, $details = []) {
    global $DB;

    try {
        if (!is_array($details)) {
            $details = [];
        }

        // Never log before the plugin tables exist.
        if (!$DB->get_manager()->table_exists('auth_devicelock_logs')) {
            return;
        }

        // Observer-side gate (works in AJAX/CLI where global $USER is not).
        if (!auth_devicelock_activity_tracking_active_for_user((int)$event->userid)) {
            return;
        }

        // device_manager is not autoloadable on its own.
        require_once(__DIR__ . '/device_manager.php');

        // Fall back to the event's own URL when the caller built none.
        if (empty($details['url'])) {
            try {
                $eventurl = $event->get_url();
                if ($eventurl) {
                    $details['url'] = (string)$eventurl;
                }
            } catch (\Exception $urle) {
                // Some events have no meaningful URL; that is fine.
            }
        }

        // The persistent browser token works for web AND AJAX requests.
        $fingerprint = auth_devicelock_get_current_fingerprint();

        $logid = device_manager::log_action((int)$event->userid, $fingerprint, $action, $details);
        if ($logid) {
            // Keep the generic page-view logger silent for this request.
            auth_devicelock_activity_event_logged(true);
        }
    } catch (\Exception $e) {
        debugging('Device lock plugin (activity event) error: ' . $e->getMessage(), DEBUG_DEVELOPER);
    }
}

/**
 * v3.6.0 / v3.10.0: Record the current page view as a user-activity event.
 *
 * Called from the \core\hook\output\before_http_headers callback
 * (classes/hook/output/activity_logger.php) at the very start of page
 * output, and - as a v3.10.0 fallback for sites where that modern hook
 * dispatch never runs - from the legacy lib.php callback
 * auth_devicelock_before_http_headers(). $PAGE, $USER and $COURSE are
 * all set up by then and cookies can still be written.
 *
 * v3.10.0 REDESIGN - CAPTURE AT HEADER, WRITE AT FOOTER:
 * this function now only CAPTURES the candidate row. The actual log
 * write happens at footer time, in
 * auth_devicelock_activity_log_current_page_flush() (called by the
 * before_footer_html_generation hook / legacy before_footer callback).
 * Reason: some Moodle pages trigger their view event AFTER the header
 * is printed (/course/view.php fires course_viewed at the END of the
 * script), so writing here would have produced BOTH a "Page Viewed"
 * row and the event row for one visit. By the footer, every event for
 * the request has fired, so the per-request dedupe flag
 * (auth_devicelock_activity_event_logged()) is final and exactly ONE
 * row per page visit is written either way.
 *
 * The URL is classified into a semantic activity action
 * ("activity_course" for a course page, "activity_module" for an
 * activity, ...) and written through the normal logging pipeline.
 *
 * Activity actions all start with "activity_" and are NOT in the score
 * violation map, so auth_devicelock_score_apply_violation() ignores
 * them completely - they can never lower a security score.
 *
 * @return void
 */
function auth_devicelock_activity_log_current_page() {
    global $PAGE, $USER, $DB;

    if (defined('CLI_SCRIPT') || defined('AJAX_SCRIPT') || defined('BEHAT_SITE')) {
        return;
    }
    // v3.8.0: when a core event observer already recorded this page view
    // (course_viewed, course_module_viewed, ...), do not log it again here.
    if (auth_devicelock_activity_event_logged()) {
        return;
    }
    if (!auth_devicelock_activity_tracking_active()) {
        return;
    }

    // Canonical page URL. Fall back to the raw request for the rare
    // pages that never call $PAGE->set_url().
    $url  = '';
    $path = '';
    if ($PAGE->has_set_url()) {
        $path = strtolower($PAGE->url->get_path());
        $url  = $PAGE->url->out_as_local_url();
    } else {
        $url  = me();
        $path = strtolower((string)parse_url($url, PHP_URL_PATH));
    }
    if ($path === '' || $path === '/') {
        return;
    }

    $action  = 'activity_page';
    $details = ['url' => $url];

    // The page title the user actually saw in their tab.
    $title = trim((string)$PAGE->title);
    if ($title !== '') {
        $details['page_title'] = $title;
    }

    // Course context, whenever the page is inside a real course.
    if (isset($PAGE->course->id) && $PAGE->course->id != SITEID) {
        $coursename = trim((string)$PAGE->course->fullname);
        if ($coursename !== '') {
            $details['course'] = $coursename;
        }
    }

    if (strpos($path, '/mod/') === 0 && substr($path, -9) === '/view.php' && !empty($PAGE->cm)) {
        // Viewing any activity or resource (assign, forum, page, file...).
        $action = 'activity_module';
        $details['activity'] = trim((string)$PAGE->cm->name);
        $details['module']   = (string)$PAGE->cm->modname;
    } else if ($path === '/course/view.php') {
        $action = 'activity_course';
        $section = (int)$PAGE->url->get_param('section');
        if ($section > 0) {
            $details['section'] = $section;
        }
    } else if ($path === '/course/index.php' || $path === '/course/search.php') {
        $action = 'activity_catalog';
    } else if ($path === '/my/index.php' || $path === '/my' || $path === '/my/') {
        $action = 'activity_dashboard';
    } else if ($path === '/user/view.php' || $path === '/user/profile.php') {
        $action = 'activity_profile';
        $profileid = $PAGE->has_set_url() ? (int)$PAGE->url->get_param('id') : 0;
        if ($profileid > 0) {
            $pu = $DB->get_record('user', ['id' => $profileid], 'firstname,lastname', IGNORE_MISSING);
            if ($pu) {
                $details['profile_user'] = fullname($pu);
            }
        }
    } else if ($path === '/user/index.php') {
        $action = 'activity_participants';
    } else if (strpos($path, '/grade/') === 0) {
        $action = 'activity_grades';
    } else if (strpos($path, '/pluginfile.php') === 0 || strpos($path, '/webservice/pluginfile.php') === 0) {
        $action = 'activity_download';
    }

    // The persistent browser token identifies the device. Safe here -
    // headers have not been sent yet, so a first-visit token cookie can
    // still be set for users who never logged in with this auth method.
    $fingerprint = auth_devicelock_get_current_fingerprint();

    // v3.10.0: CAPTURE ONLY - the row is written at footer time
    // (auth_devicelock_activity_log_current_page_flush()) once every
    // core event for this request has fired.
    auth_devicelock_activity_page_stash([
        'userid'      => (int)$USER->id,
        'fingerprint' => $fingerprint,
        'action'      => $action,
        'details'     => $details,
    ]);
}

/**
 * v3.10.0: per-request stash for the deferred page-view row.
 *
 * @param array|null $set When non-null, store this candidate row.
 * @return array|null The stashed row (or null when nothing captured).
 */
function auth_devicelock_activity_page_stash($set = null) {
    static $candidate = null;
    if ($set !== null) {
        $candidate = $set;
    }
    return $candidate;
}

/**
 * v3.10.0: write the deferred page-view row (footer time).
 *
 * Called from the \core\hook\output\before_footer_html_generation
 * callback (classes/hook/output/footer_beacon.php) and, as a fallback
 * for sites where modern hook dispatch never runs, from the legacy
 * lib.php callback auth_devicelock_before_footer(). By that point every
 * core event of the request has fired, so when an event observer
 * already logged this page (course_viewed, dashboard_viewed, the
 * wildcard *_viewed catch-all, ...) the generic row is skipped - one
 * visit, one row. Idempotent: a second call in the same request (e.g.
 * if both the modern hook and a legacy callback ever ran) is a no-op.
 *
 * @return void
 */
function auth_devicelock_activity_log_current_page_flush() {
    static $done = false;

    if (defined('CLI_SCRIPT') || defined('AJAX_SCRIPT') || defined('BEHAT_SITE')) {
        return;
    }
    if ($done) {
        return;
    }
    $done = true;

    $candidate = auth_devicelock_activity_page_stash();
    if ($candidate === null) {
        return;
    }
    // v3.8.0 / v3.10.0: when a core event observer already recorded this
    // page view (course_viewed, dashboard_viewed, ...), do not also write
    // the generic page-view row.
    if (auth_devicelock_activity_event_logged()) {
        return;
    }

    try {
        require_once(__DIR__ . '/device_manager.php');
        device_manager::log_action(
            (int)$candidate['userid'],
            $candidate['fingerprint'],
            $candidate['action'],
            $candidate['details']
        );
    } catch (\Exception $e) {
        debugging('Device lock plugin (page view) error: ' . $e->getMessage(), DEBUG_DEVELOPER);
    }
}

/**
 * v3.10.0: legacy lib.php callback (before_footer) - footer-time twin of
 * auth_devicelock_before_http_headers(). Writes the deferred page-view
 * row and returns the footer beacon script HTML. Auto-suppressed by the
 * hook manager whenever the modern before_footer_html_generation
 * registration (footer_beacon.php) is active.
 *
 * @return string Footer HTML (the beacon <script>), '' when disabled.
 */
function auth_devicelock_before_footer() {
    auth_devicelock_activity_log_current_page_flush();
    return auth_devicelock_activity_beacon_html();
}

/**
 * v3.6.0: Inline JS that reports clicks on EXTERNAL links.
 *
 * Printed at the very end of the page footer through the
 * \core\hook\output\before_footer_html_generation hook. Internal
 * links are skipped on purpose - the destination page produces its
 * own page-view event - but a click that leaves the Moodle site is
 * reported immediately with navigator.sendBeacon(), which survives
 * the navigation that follows.
 *
 * @return string A <script> block ready for $hook->add_html(), or ''.
 */
function auth_devicelock_activity_beacon_html() {
    if (!auth_devicelock_activity_tracking_active()) {
        return '';
    }

    // v3.10.0: the script now ALSO reports every BUTTON the user clicks
    // (button / input submit / role=button) as an "activity_click" event,
    // not just external links - the admin asked for every page AND button
    // to be tracked. Internal links stay unreported: the destination page
    // logs its own page-view event.
    return '<script>
(function() {
    if (!window.M || !M.cfg || !M.cfg.sesskey || !M.cfg.wwwroot) { return; }
    if (!navigator.sendBeacon) { return; }
    var origin = window.location.origin;
    function beacon(fd) {
        try { navigator.sendBeacon(M.cfg.wwwroot + "/auth/devicelock/ajax.php", fd); }
        catch (e) { /* never break the page */ }
    }
    document.addEventListener("click", function(ev) {
        var t = ev.target;
        var a = (t && t.closest) ? t.closest("a[href]") : null;
        if (!a) { return; }
        var href = a.getAttribute("href") || "";
        if (!/^https?:\\/\\//i.test(href)) { return; }
        try {
            if (new URL(href, origin).origin === origin) { return; }
        } catch (e) { return; }
        var fd = new FormData();
        fd.append("action", "activitylink");
        fd.append("url", href);
        fd.append("sesskey", M.cfg.sesskey);
        beacon(fd);
    }, true);
    var lastKey = "";
    var lastAt = 0;
    document.addEventListener("click", function(ev) {
        var t = ev.target;
        if (!t || !t.closest) { return; }
        var btn = t.closest("button, input[type=submit], input[type=button], input[type=reset], [role=button]");
        if (!btn) { return; }
        var label = "";
        try {
            label = (btn.getAttribute("aria-label") || btn.value || btn.textContent || "").replace(/\s+/g, " ").trim();
        } catch (e) { label = ""; }
        if (label.length > 120) { label = label.substring(0, 120); }
        var type = btn.tagName.toLowerCase();
        if (btn.type) { type += ":" + btn.type; } else if (btn.getAttribute("role") === "button") { type += ":role"; }
        var now = Date.now();
        var key = type + "|" + label;
        if (key === lastKey && (now - lastAt) < 1000) { return; }
        lastKey = key;
        lastAt = now;
        var fd = new FormData();
        fd.append("action", "activityclick");
        fd.append("button", label);
        fd.append("type", type);
        try {
            var form = btn.form || (btn.closest ? btn.closest("form") : null);
            if (form && form.getAttribute("action")) { fd.append("form", form.getAttribute("action")); }
        } catch (e) { /* optional */ }
        fd.append("sesskey", M.cfg.sesskey);
        beacon(fd);
    }, true);
})();
</script>';
}

/** Start a bounded staging window only when the administrator changes this setting. */
function auth_devicelock_macos_testing_updated() {
    set_config('macos_testing_started', (string)get_config('auth_devicelock', 'macos_testing') === '1' ? time() : 0, 'auth_devicelock');
}
