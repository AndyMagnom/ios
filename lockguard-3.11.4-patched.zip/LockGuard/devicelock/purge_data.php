<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Controller logic for purging all auth_devicelock plugin data.
 * Adheres to strict Moodle Page Lifecycle standards.
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/adminlib.php');

// 1. Require login and capability checks
require_login();
$context = context_system::instance();
require_capability('moodle/site:config', $context);

// Retrieve canonical plugin version from version.php
$plugin = new stdClass();
require(__DIR__ . '/version.php');
$pluginversion = $plugin->version;

// Ensure plugin version is recorded in Moodle config so "Section error!" is healed
if (!get_config('auth_devicelock', 'version')) {
    set_config('version', $pluginversion, 'auth_devicelock');
}

// 2. Capture variables
$confirm = optional_param('confirm', 0, PARAM_INT);
$cancelurl = new moodle_url('/admin/plugins.php');
$baseurl = new moodle_url('/auth/devicelock/purge_data.php');

// 3. Process Actions & Redirects
if ($confirm && confirm_sesskey()) {
    global $DB, $CFG;
    $dbman = $DB->get_manager();
    
    // 1. Revert any user whose auth is 'devicelock' back to 'manual' so they are not locked out
    // and Moodle uninstaller does not block removal.
    try {
        $DB->set_field('user', 'auth', 'manual', ['auth' => 'devicelock']);
    } catch (\Exception $e) {
        debugging('Error reverting user auth to manual: ' . $e->getMessage(), DEBUG_DEVELOPER);
    }
    
    // 2. Remove 'devicelock' from Moodle's active auth plugins list so it is disabled
    $authsequence = get_enabled_auth_plugins(true);
    if (($key = array_search('devicelock', $authsequence)) !== false) {
        unset($authsequence[$key]);
        set_config('auth', implode(',', $authsequence));
    }
    
    // 3. Ensure database table structures exist (in case previously dropped) and completely wipe all data.
    // Keeping tables present and empty allows Moodle's native uninstaller to drop them cleanly.
    $installxml = __DIR__ . '/db/install.xml';
    if (file_exists($installxml)) {
        require_once($CFG->libdir . '/ddllib.php');
        $xmldb_file = new xmldb_file($installxml);
        if ($xmldb_file->loadXMLStructure()) {
            $structure = $xmldb_file->getStructure();
            $tables = $structure->getTables();
            foreach ($tables as $t) {
                if (!$dbman->table_exists($t)) {
                    try {
                        $dbman->create_table($t);
                    } catch (\Exception $e) {
                        debugging('Error creating table ' . $t->getName() . ': ' . $e->getMessage(), DEBUG_DEVELOPER);
                    }
                }
            }
        }
    }
    
    $tablenames = ['auth_devicelock_devices', 'auth_devicelock_logs', 'auth_devicelock_session_tracking',
        'auth_devicelock_user_scores', 'auth_devicelock_score_history', 'auth_devicelock_bans',
        // ios_state holds the Apple/native bearer sessions: skipping it would
        // leave verified app sessions alive after an "irreversible" purge.
        'auth_devicelock_ios_state'];
    foreach ($tablenames as $tname) {
        if ($dbman->table_exists($tname)) {
            $DB->delete_records($tname);
        }
    }
    
    // 4. Clear all plugin configurations and user preferences
    unset_all_config_for_plugin('auth_devicelock');
    $DB->delete_records_select('config', "name LIKE '%auth_devicelock%'");
    $DB->delete_records_select('user_preferences', "name LIKE 'auth_devicelock_%'");
    
    // CRITICAL FIX: Retain the plugin version and set disabled state.
    // This guarantees Moodle recognizes the plugin as an installed "Additional plugin"
    // and displays the standard "Uninstall" button on /admin/plugins.php without section errors!
    set_config('version', $pluginversion, 'auth_devicelock');
    set_config('enabled', 0, 'auth_devicelock');
    
    // 5. Clean up disk logout flags, resets, and wipe flags
    $dirs = [
        $CFG->dataroot . '/devicelock_logout_flags',
        $CFG->dataroot . '/devicelock_resets',
        $CFG->dataroot . '/devicelock_wipe_flags'
    ];
    foreach ($dirs as $dir) {
        if (is_dir($dir)) {
            $files = glob($dir . '/*');
            if ($files) {
                foreach ($files as $f) {
                    if (is_file($f)) {
                        @unlink($f);
                    }
                }
            }
            @rmdir($dir);
        }
    }
    
    // 6. Clear caches
    cache_helper::purge_all();
    purge_all_caches();
    
    // Redirect directly to Moodle Plugins Overview where the "Uninstall" button is active
    $msg = get_string('purge_success_uninstall_ready', 'auth_devicelock');
    if (empty($msg) || strpos($msg, '[[') === 0) {
        $msg = 'All Lock Guard (auth_devicelock) data has been completely wiped. The plugin is disabled and appears below under "Additional plugins" where you can click "Uninstall" to remove it or update it cleanly.';
    }
    
    redirect(
        new moodle_url('/admin/plugins.php'), 
        $msg, 
        null, 
        \core\output\notification::NOTIFY_SUCCESS
    );
}

// 4. Page Setup
$PAGE->set_context($context);
$PAGE->set_url($baseurl);
$PAGE->set_pagelayout('admin');
$PAGE->set_title(get_string('pluginname', 'auth_devicelock') . ' - Purge Data');
$PAGE->set_heading(get_string('pluginname', 'auth_devicelock') . ' - Purge Data');

// 5. Output Header
echo $OUTPUT->header();

// 6. Output Body/UI - High-visibility warning card
echo '
<div class="row justify-content-center mt-3 mb-5">
    <div class="col-lg-8 col-md-10">
        <div class="card border-danger shadow">
            <div class="card-header bg-danger text-white py-3">
                <h4 class="mb-0 text-white font-weight-bold">
                    <i class="fa fa-exclamation-triangle"></i> DANGER: Irreversible Data Purge Confirmation
                </h4>
            </div>
            <div class="card-body p-4">
                <div class="alert alert-danger border-danger">
                    <h5 class="alert-heading font-weight-bold mb-2">
                        <i class="fa fa-warning"></i> ATTENTION: YOU ARE ABOUT TO PERMANENTLY WIPE ALL PLUGIN DATA
                    </h5>
                    <p class="mb-0">
                        This action will <strong>completely wipe all user devices, sessions, security audit logs, and settings</strong>.
                        User authentication methods will be safely reverted to manual, and the plugin will be placed into a clean state ready for immediate uninstallation from Moodle.
                    </p>
                </div>

                <h5 class="font-weight-bold text-dark mt-4 mb-3">The following actions will be executed immediately:</h5>
                <ul class="list-group list-group-flush mb-4 border rounded">
                    <li class="list-group-item d-flex align-items-center">
                        <span class="badge badge-danger mr-3 p-2"><i class="fa fa-database"></i></span>
                        <div><strong>Wipe All Plugin Records:</strong> All device registrations in <code>{auth_devicelock_devices}</code>, tracked sessions in <code>{auth_devicelock_session_tracking}</code>, audit logs in <code>{auth_devicelock_logs}</code>, and security scores + score history in <code>{auth_devicelock_user_scores}</code> / <code>{auth_devicelock_score_history}</code> will be completely deleted.</div>
                    </li>
                    <li class="list-group-item d-flex align-items-center">
                        <span class="badge badge-danger mr-3 p-2"><i class="fa fa-history"></i></span>
                        <div><strong>Erase Audit & Security History:</strong> All past device login history, block records, and administrator audit logs will be permanently removed.</div>
                    </li>
                    <li class="list-group-item d-flex align-items-center">
                        <span class="badge badge-danger mr-3 p-2"><i class="fa fa-sliders"></i></span>
                        <div><strong>Remove Plugin Configurations:</strong> All global thresholds, custom overrides, email templates, and preferences will be wiped clean.</div>
                    </li>
                    <li class="list-group-item d-flex align-items-center">
                        <span class="badge badge-success mr-3 p-2"><i class="fa fa-users"></i></span>
                        <div><strong>Safe User Authentication Restore:</strong> Any user currently set to the <code>devicelock</code> authentication method will be safely restored to <code>manual</code> authentication so no users are locked out of Moodle.</div>
                    </li>
                    <li class="list-group-item d-flex align-items-center">
                        <span class="badge badge-warning text-dark mr-3 p-2"><i class="fa fa-eraser"></i></span>
                        <div><strong>Clean Up Disk Logout Flags & Caches:</strong> All disk logout flag files in <code>dataroot</code> and core Moodle caches will be purged.</div>
                    </li>
                    <li class="list-group-item d-flex align-items-center">
                        <span class="badge badge-primary mr-3 p-2"><i class="fa fa-puzzle-piece"></i></span>
                        <div><strong>Ready for Uninstallation:</strong> The plugin will remain registered as an installed additional plugin with clean empty tables so the <strong>Uninstall</strong> button is immediately available in Moodle\'s Plugins overview.</div>
                    </li>
                </ul>

                <div class="alert alert-info">
                    <i class="fa fa-info-circle"></i> Once purged, you will be automatically redirected to <strong>Site administration &gt; Plugins &gt; Plugins overview</strong> where the plugin will appear under <strong>Additional plugins</strong> with an <strong>Uninstall</strong> button.
                </div>

                <div class="d-flex justify-content-between align-items-center pt-3 border-top mt-4">
                    <a href="' . $cancelurl . '" class="btn btn-secondary btn-lg">
                        <i class="fa fa-times"></i> Cancel and Return
                    </a>
                    <form method="post" action="' . $baseurl . '" class="m-0">
                        <input type="hidden" name="confirm" value="1">
                        <input type="hidden" name="sesskey" value="' . sesskey() . '">
                        <button type="submit" class="btn btn-danger btn-lg font-weight-bold shadow">
                            <i class="fa fa-trash"></i> YES, PERMANENTLY PURGE ALL DATA
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>';

// 7. Output Footer
echo $OUTPUT->footer();

