<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Admin dashboard for Lock Guard Plugin
 * Completely rewritten for modern UI/UX and Device-centric architecture.
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/adminlib.php');
require_once(__DIR__ . '/device_manager.php');
require_once(__DIR__ . '/lib.php');
require_once(__DIR__ . '/auth.php');
require_once(__DIR__ . '/locallib.php');

global $DB, $PAGE, $OUTPUT, $CFG;

// NOTE: auth_devicelock_ensure_enabled() is no longer forced here. This page
// was reachable before require_login(), letting any anonymous visitor re-add
// the auth plugin to Moodle's enabled sequence even after an admin disabled
// it. Install/upgrade still call it, and the setting page keeps it registered.

// ============================================================
// 1. Page Setup & Security
// ============================================================
require_login();
$context = context_system::instance();

// Require capability to manage devices
require_capability('auth/devicelock:managedevices', $context);

// Initialize the page in the admin tree (Fix for HTTP 500)
admin_externalpage_setup('lockguard_dashboard');
// Dashboard, Logs and User Directory are all this one page. Force the
// Lock Guard top-bar tab to stay active (URL matching alone would pick
// the Users tab or no tab).
$PAGE->set_secondary_active_tab('lockguard');

$PAGE->requires->css(new moodle_url('/auth/devicelock/styles.css'));

// Get URL parameters
$tab      = optional_param('tab', 'users', PARAM_ALPHA);
$action   = optional_param('action', '', PARAM_ALPHA);
$deviceid = optional_param('deviceid', 0, PARAM_INT);
$userid   = optional_param('userid', 0, PARAM_INT);
$confirm  = optional_param('confirm', 0, PARAM_BOOL);

// Search & Filtering parameters
$search       = optional_param('search', '', PARAM_TEXT);
$filter       = optional_param('filter', 'all', PARAM_ALPHA); // all, active, blocked
$page         = optional_param('page', 0, PARAM_INT);
$user_search  = optional_param('user_search', '', PARAM_TEXT);
$userpage     = optional_param('userpage', 0, PARAM_INT);
// User Directory quick type filter: '' (all), banned, unbanned, suspended, active.
$ufilter      = optional_param('ufilter', '', PARAM_ALPHANUMEXT);
if ($userpage === 0 && ($tab === 'users' || $tab === 'nonplugin') && $page > 0) {
    $userpage = $page;
}
$log_search   = optional_param('log_search', '', PARAM_TEXT);
$log_action_filter = optional_param('log_action_filter', '', PARAM_ALPHANUMEXT);
$logpage      = optional_param('logpage', 0, PARAM_INT);
if ($logpage === 0 && $tab === 'logs' && $page > 0) {
    $logpage = $page;
}
$perpage      = 20;

// v3.7.0: User Directory page size. The ?uperpage= URL parameter is a
// TEMPORARY view choice (10/50/100/250 or "all") - it is never carried
// into the pagination, search or filter links, and an inline script
// strips it from the address bar right after the page renders, so a
// plain refresh or a page change always returns to the default of 20.
$userperpage = $perpage;
$uperpageparam = optional_param('uperpage', '', PARAM_ALPHANUM);
if ($tab === 'users' && $uperpageparam !== '') {
    if ($uperpageparam === 'all') {
        $userperpage = 1000000; // "Show All" - effectively unlimited.
    } else {
        $uperpageparam = (int)$uperpageparam;
        if ($uperpageparam >= 5 && $uperpageparam <= 500) {
            $userperpage = $uperpageparam;
        }
    }
    // Changing the page size always restarts from the first page.
    $userpage = 0;
}

$baseurl = new moodle_url('/auth/devicelock/admin_devices.php', [
    'tab' => $tab,
    'search' => $search,
    'filter' => $filter,
    'user_search' => $user_search,
    'userpage' => $userpage,
    'ufilter' => $ufilter,
    'log_search' => $log_search,
    'log_action_filter' => $log_action_filter,
    'logpage' => $logpage
]);

/**
 * v3.9.0: SQL expression that strips common punctuation / separators from a
 * field value so "bulk-user.64", "bulk user 64" and "bulkuser64" all compare
 * equal (used by the advanced fuzzy search).
 *
 * Built from nested REPLACE() calls with safe single-character literals so
 * it works on every Moodle database (MySQL / MariaDB / PostgreSQL / MSSQL).
 *
 * v3.10.0 CRITICAL FIX: the strip list must NEVER contain a '?' character.
 * Moodle's moodle_database::fix_sql_params() counts EVERY '?' in the SQL
 * string (substr_count, ignoring quoting) and throws
 * "Mixed types of sql query parameters!!" when a query mixes ?-placeholders
 * with :named placeholders - which every fuzzy query does. A literal
 * REPLACE(x, '?', '') therefore crashed the whole search with
 * dml_exception(mixedtypesqlparam) the moment the fuzzy setting was turned
 * on. '?' is now stripped only on the PHP side (the search needle), which
 * is where it matters; database values containing a literal '?' simply
 * keep it in the comparison.
 *
 * @param string $fieldexpr SQL field expression (e.g. "u.username").
 * @return string SQL expression yielding the stripped value.
 */
function auth_devicelock_sql_strip_separators($fieldexpr) {
    $out = (string)$fieldexpr;
    $strip = ['.', '-', '_', '@', ' ', '+', ',', '/', ':', ';', '!', '(', ')', '#', '*'];
    foreach ($strip as $ch) {
        $out = "REPLACE($out, '$ch', '')";
    }
    return $out;
}

/**
 * Helper to build comprehensive user search WHERE clauses across all profile fields
 * including idnumber (university ID), phone1, phone2, institution, department, address, city,
 * full names, and custom profile fields in {user_info_data}.
 *
 * v3.9.0 - two new search capabilities:
 *  1. ROLE SEARCH (always on): the term is also matched against every role
 *     NAME / SHORTNAME / ARCHETYPE the user holds (any context), so typing
 *     "teacher" lists every user with a teacher role.
 *  2. FUZZY SEARCH (setting: "Advanced (fuzzy) user search", off by
 *     default): when enabled, results are also matched with
 *       B. every whitespace-separated token appearing somewhere (AND),
 *          so "bulk user 64" finds "bulkuser.64";
 *       C. the whole term with ALL punctuation/spaces stripped, matched
 *          against a punctuation-stripped username+email+names+idnumber
 *          concatenation, so "bulk-user 64" finds "bulkuser.64";
 *       E. every token (C)-style against that concatenation (AND), so
 *          "bul lkuser" finds "bulkuser.64".
 *       D. single-typo tolerant variants of (C) - one character replaced
 *          by a wildcard, one wildcard inserted or one character dropped.
 *          D is deliberately NOT part of the normal query: it only runs
 *          as a RETRY (see auth_devicelock_fuzzy_typo_retry()) when the
 *          strict strategies found nothing, so "bulk user 64" keeps
 *          returning exactly bulkuser.64 while "buluser 64" (typo)
 *          still finds it on the second pass.
 *     With the setting off, only the classic whole-substring match (A)
 *     plus the new role matching is used.
 */
function auth_devicelock_build_user_search_where($searchterm, $tablealias = 'u', &$params = [], $param_prefix = 'usr_srch_', $allowtypo = false) {
    global $DB;

    $cleansearch = trim((string)$searchterm);
    if ($cleansearch === '') {
        return '1=1';
    }

    $like = '%' . $DB->sql_like_escape($cleansearch) . '%';

    // Every profile field the plain (A) and token (B) strategies search.
    $fieldlist = [
        "$tablealias.username",
        "$tablealias.email",
        "$tablealias.firstname",
        "$tablealias.lastname",
        $DB->sql_fullname("$tablealias.firstname", "$tablealias.lastname"),
        $DB->sql_fullname("$tablealias.lastname", "$tablealias.firstname"),
        "$tablealias.idnumber",
        "$tablealias.phone1",
        "$tablealias.phone2",
        "$tablealias.institution",
        "$tablealias.department",
        "$tablealias.city",
        "$tablealias.address",
    ];
    $userinfook = $DB->get_manager()->table_exists('user_info_data');
    $rolesok = $DB->get_manager()->table_exists('role_assignments') && $DB->get_manager()->table_exists('role');

    // Builds one "(f1 LIKE :p OR f2 LIKE :p2 ...)" group for a search
    // needle, optionally including custom-profile data and role names.
    // $suffix keeps the generated parameter names unique per group.
    $groupmaker = function ($needle, $suffix) use ($DB, $fieldlist, $userinfook, $rolesok, $tablealias, &$params, $param_prefix) {
        $need = is_string($needle) ? $needle : '';
        $clauses = [];
        foreach ($fieldlist as $i => $fld) {
            $p = $param_prefix . $suffix . 'f' . $i;
            $params[$p] = $need;
            $clauses[] = $DB->sql_like($fld, ":$p", false);
        }
        if ($userinfook) {
            $p = $param_prefix . $suffix . 'inf';
            $params[$p] = $need;
            $clauses[] = "EXISTS (SELECT 1 FROM {user_info_data} uid WHERE uid.userid = $tablealias.id AND "
                . $DB->sql_like("uid.data", ":$p", false) . ")";
        }
        if ($rolesok) {
            // v3.9.0 role search: the term matches a role name, shortname
            // or archetype the user holds in ANY context.
            $pn = $param_prefix . $suffix . 'rn';
            $ps = $param_prefix . $suffix . 'rs';
            $pa = $param_prefix . $suffix . 'ra';
            $params[$pn] = $need;
            $params[$ps] = $need;
            $params[$pa] = $need;
            $clauses[] = "EXISTS (SELECT 1 FROM {role_assignments} rra JOIN {role} rr ON rr.id = rra.roleid"
                . " WHERE rra.userid = $tablealias.id AND ("
                . $DB->sql_like("rr.name", ":$pn", false) . ' OR '
                . $DB->sql_like("rr.shortname", ":$ps", false) . ' OR '
                . $DB->sql_like("rr.archetype", ":$pa", false) . '))';
        }
        if (empty($clauses)) {
            return '';
        }
        return '(' . implode(' OR ', $clauses) . ')';
    };

    $strategies = [];

    // ---- Strategy A: classic whole-substring match (plus role names).
    $a = $groupmaker($like, 'a');
    if ($a !== '') {
        $strategies[] = $a;
    }

    // ---- Fuzzy strategies (setting-controlled, v3.9.0).
    $fuzzyon = (bool)get_config('auth_devicelock', 'fuzzysearch');
    if ($fuzzyon) {
        // Lowercased alphanumeric tokens of the search term (single
        // characters still count - "bulk user 5" needs the 5).
        $tokens = preg_split('/[^a-z0-9\p{L}\p{Nd}]+/u', \core_text::strtolower($cleansearch), -1, PREG_SPLIT_NO_EMPTY);
        if (!is_array($tokens)) {
            $tokens = preg_split('/[^a-z0-9]+/', strtolower($cleansearch), -1, PREG_SPLIT_NO_EMPTY);
        }
        $tokens = array_values(array_unique($tokens));
        if (count($tokens) > 6) {
            $tokens = array_slice($tokens, 0, 6);
        }

        // ---- Strategy B: every token must appear somewhere (AND of ORs).
        if (count($tokens) >= 2) {
            $tokgroups = [];
            foreach ($tokens as $ti => $token) {
                $g = $groupmaker('%' . $DB->sql_like_escape($token) . '%', 't' . $ti . '_');
                if ($g !== '') {
                    $tokgroups[] = $g;
                }
            }
            if (count($tokgroups) === count($tokens) && !empty($tokgroups)) {
                $strategies[] = '(' . implode(' AND ', $tokgroups) . ')';
            }
        }

        // ---- Normalised matching (C/D/E): one punctuation-stripped
        // concatenation of username + email + first/last name + idnumber.
        // Fields are concatenated WITHOUT separators so multi-word names
        // compare as they are typed ("liam evans" -> "liamevans"), and each
        // field is COALESCEd because CONCAT/|| propagate NULL (idnumber is
        // NULL-able in {user}) which would kill the whole expression.
        $norm = preg_replace('/[^a-z0-9\p{L}\p{Nd}]+/u', '', \core_text::strtolower($cleansearch));
        if (!is_string($norm) || $norm === null) {
            $norm = preg_replace('/[^a-z0-9]+/', '', strtolower($cleansearch));
        }
        $normconcat = $DB->sql_concat(
            auth_devicelock_sql_strip_separators("COALESCE($tablealias.username, '')"),
            auth_devicelock_sql_strip_separators("COALESCE($tablealias.email, '')"),
            auth_devicelock_sql_strip_separators("COALESCE($tablealias.firstname, '')"),
            auth_devicelock_sql_strip_separators("COALESCE($tablealias.lastname, '')"),
            auth_devicelock_sql_strip_separators("COALESCE($tablealias.idnumber, '')")
        );
        $normgroup = function ($needle, $suffix) use ($DB, $normconcat, &$params, $param_prefix) {
            $p = $param_prefix . $suffix . 'x';
            $params[$p] = $needle;
            return $DB->sql_like($normconcat, ":$p", false);
        };

        // ---- Strategy C: whole term, punctuation-insensitive.
        if (is_string($norm) && \core_text::strlen($norm) >= 3) {
            $strategies[] = $normgroup('%' . $norm . '%', 'n_');
        }

        // ---- Strategy D: single-typo tolerant variants of C (RETRY ONLY:
        // mixed into the query solely when the caller determined that the
        // strict strategies found nothing - keeps precise queries precise).
        // One character replaced by a wildcard (substitution), one wildcard
        // inserted (target has an extra char) or one character dropped
        // (query has an extra char). Every position is covered for needles
        // up to 12 chars; longer needles sample every 2nd position.
        if ($allowtypo && is_string($norm) && \core_text::strlen($norm) >= 5 && \core_text::strlen($norm) <= 20) {
            $len = \core_text::strlen($norm);
            $step = ($len > 12) ? 2 : 1;
            $variants = [];
            for ($i = 0; $i < $len; $i += $step) {
                $variants[] = \core_text::substr($norm, 0, $i) . '_' . \core_text::substr($norm, $i + 1); // Substitute.
                $variants[] = \core_text::substr($norm, 0, $i) . '_' . \core_text::substr($norm, $i);     // Insert.
                $variants[] = \core_text::substr($norm, 0, $i) . \core_text::substr($norm, $i + 1);       // Delete.
            }
            $variants = array_values(array_unique($variants));
            $dgroups = [];
            foreach ($variants as $vi => $variant) {
                $dgroups[] = $normgroup('%' . $variant . '%', 'v' . $vi . '_');
            }
            if (!empty($dgroups)) {
                $strategies[] = '(' . implode(' OR ', $dgroups) . ')';
            }
        }

        // ---- Strategy E: every token against the normalised concat (AND).
        // All tokens must be long enough (>= 3) - shorter ones are already
        // covered by strategy B against the plain fields.
        $elongcount = 0;
        foreach ($tokens as $token) {
            if (\core_text::strlen($token) >= 3) {
                $elongcount++;
            }
        }
        if (count($tokens) >= 2 && $elongcount === count($tokens)) {
            $egroups = [];
            foreach ($tokens as $ti => $token) {
                $egroups[] = $normgroup('%' . $token . '%', 'e' . $ti . '_');
            }
            if (count($egroups) === count($tokens)) {
                $strategies[] = '(' . implode(' AND ', $egroups) . ')';
            }
        }
    }

    if (empty($strategies)) {
        return '1=1';
    }
    if (count($strategies) === 1) {
        return $strategies[0];
    }
    return '(' . implode(' OR ', $strategies) . ')';
}

/**
 * v3.9.0: decide whether the fuzzy typo-tolerant retry should run for a
 * user search.
 *
 * Returns true ONLY when the advanced (fuzzy) search setting is enabled
 * AND the strict fuzzy strategies (plain substring + token-AND +
 * punctuation-insensitive) find not a single user. In that case the caller
 * rebuilds its query with $allowtypo = true so single-typo variants
 * (strategy D) are mixed in - "bulk user 64" keeps returning exactly
 * bulkuser.64 (strict hit, no retry), while "buluser 64" (typo) finds it
 * on the retry instead of returning nothing.
 *
 * @param string $searchterm The raw search term.
 * @param string $basewhere  The caller's base WHERE (deleted/id/admin filters).
 * @param string $tablealias Alias of the {user} table in the caller's query.
 * @return bool True when the query should be rebuilt with typo tolerance.
 */
function auth_devicelock_fuzzy_typo_retry($searchterm, $basewhere, $tablealias = 'u') {
    global $DB;
    if (trim((string)$searchterm) === '' || !(bool)get_config('auth_devicelock', 'fuzzysearch')) {
        return false;
    }
    $strict_params = [];
    $strict_where = $basewhere . ' AND ' . auth_devicelock_build_user_search_where($searchterm, $tablealias, $strict_params, 'lgstrict_');
    $strict_count = (int)$DB->count_records_sql(
        "SELECT COUNT(DISTINCT {$tablealias}.id) FROM {user} {$tablealias} WHERE {$strict_where}", $strict_params);
    return $strict_count === 0;
}

// ============================================================
// 6. Controller Logic (Action Handlers)
// ============================================================
if ($action) {
    switch ($action) {
        
        case 'toggleblock':
            require_sesskey();
            $redirect_to_viewuser = optional_param('redirect_to_viewuser', 0, PARAM_BOOL);
            if ($deviceid) {
                if (device_manager::toggle_device_status($deviceid)) {
                    \core\notification::success("Device status successfully toggled.");
                } else {
                    \core\notification::error("Failed to toggle device status.");
                }
            }
            if ($redirect_to_viewuser && $userid) {
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid]));
            }
            redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'devices', 'search' => $search, 'filter' => $filter]));
            break;

        case 'purgeuser':
            if ($userid && $confirm) {
                require_sesskey();
                $result = device_manager::reset_user_devices($userid);
                if ($result) {
                    \core\notification::success('All devices for the user have been purged. They are logged out everywhere.');
                } else {
                    \core\notification::error('Failed to purge devices.');
                }
                $redirect_to_viewuser = optional_param('redirect_to_viewuser', 0, PARAM_BOOL);
                if ($redirect_to_viewuser) {
                    redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid]));
                }
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => $tab, 'search' => $search, 'user_search' => $user_search, 'userpage' => $userpage]));
            }
            break;

        case 'saveuserlimit':
            // Inline form submission from the separate page
            if ($userid) {
                require_sesskey();
                $newlimit = optional_param('userlimit', 0, PARAM_INT);
                $newbrowserlimit = optional_param('userbrowserlimit', '', PARAM_RAW);
                
                auth_devicelock_set_user_device_limit($userid, $newlimit);
                if ($newlimit > 0) {
                    \core\notification::success(get_string('userlimit_saved', 'auth_devicelock', $newlimit));
                } else {
                    \core\notification::success(get_string('userlimit_cleared', 'auth_devicelock'));
                }
                
                $browser_log_val = null;
                if ($newbrowserlimit !== '' && $newbrowserlimit !== null && is_numeric($newbrowserlimit)) {
                    $b_val = (int)$newbrowserlimit;
                    auth_devicelock_set_user_browser_limit($userid, $b_val);
                    $browser_log_val = $b_val;
                    if ($b_val > 0) {
                        \core\notification::success(get_string('userbrowserlimit_saved', 'auth_devicelock', $b_val));
                    } else {
                        \core\notification::success(get_string('userbrowserlimit_saved', 'auth_devicelock', '0 (Unlimited)'));
                    }
                } else {
                    auth_devicelock_set_user_browser_limit($userid, null); // Clear override
                    \core\notification::info(get_string('userbrowserlimit_cleared', 'auth_devicelock'));
                }

                device_manager::log_action($userid, 'system', 'save_user_limit', [
                    'userlimit' => $newlimit,
                    'browserlimit' => $browser_log_val,
                    'admin_user' => $USER->id,
                    'admin_email' => $USER->email,
                    'admin_name' => fullname($USER)
                ]);
                $redirect_to_viewuser = optional_param('redirect_to_viewuser', 0, PARAM_BOOL);
                if ($redirect_to_viewuser) {
                    redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid]));
                }
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => $tab, 'search' => $search, 'user_search' => $user_search, 'userpage' => $userpage]));
            }
            break;

        case 'resetdevicebrowsers':
            require_sesskey();
            $targetdeviceid = optional_param('deviceid', 0, PARAM_INT);
            if ($targetdeviceid) {
                if (device_manager::reset_device_browsers($targetdeviceid)) {
                    \core\notification::success(get_string('reset_device_browsers_success', 'auth_devicelock', $targetdeviceid));
                } else {
                    \core\notification::error(get_string('error'));
                }
            }
            $redirect_to_viewuser = optional_param('redirect_to_viewuser', 0, PARAM_BOOL);
            if ($redirect_to_viewuser && $userid) {
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid]));
            }
            redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => $tab, 'search' => $search, 'filter' => $filter]));
            break;

        case 'resetuserbrowsers':
            if ($userid) {
                require_sesskey();
                $targetuser = $DB->get_record('user', ['id' => $userid]);
                if (device_manager::reset_user_browsers($userid)) {
                    $uname = $targetuser ? fullname($targetuser) : $userid;
                    \core\notification::success(get_string('reset_user_browsers_success', 'auth_devicelock', $uname));
                } else {
                    \core\notification::error(get_string('error'));
                }
                $redirect_to_viewuser = optional_param('redirect_to_viewuser', 0, PARAM_BOOL);
                if ($redirect_to_viewuser) {
                    redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid]));
                }
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => $tab, 'search' => $search, 'user_search' => $user_search, 'userpage' => $userpage]));
            }
            break;
            
        case 'customemailuser':
            if ($userid) {
                require_sesskey();
                $emailsubject = optional_param('emailsubject', '', PARAM_TEXT);
                $emailbody    = optional_param('emailbody', '', PARAM_CLEANHTML);

                if (empty(trim($emailsubject))) {
                    \core\notification::error(get_string('sendemail_empty_subject', 'auth_devicelock'));
                } else if (empty(trim($emailbody))) {
                    \core\notification::error(get_string('sendemail_empty_body', 'auth_devicelock'));
                } else {
                    $targetuser = $DB->get_record('user', ['id' => $userid]);
                    if ($targetuser && auth_devicelock_send_custom_email($userid, $emailsubject, $emailbody)) {
                        \core\notification::success(get_string('sendemail_success', 'auth_devicelock', $targetuser->email));
                        device_manager::log_action($userid, 'system', 'send_custom_email', [
                            'subject' => $emailsubject,
                            'admin_user' => $USER->id,
                            'admin_email' => $USER->email,
                            'admin_name' => fullname($USER)
                        ]);
                    } else {
                        \core\notification::error(get_string('sendemail_failure', 'auth_devicelock', $targetuser->email ?? 'unknown'));
                    }
                }
                $redirect_to_viewuser = optional_param('redirect_to_viewuser', 0, PARAM_BOOL);
                if ($redirect_to_viewuser) {
                    redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid]));
                }
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => $tab, 'search' => $search, 'user_search' => $user_search, 'userpage' => $userpage]));
            }
            break;
            
        case 'migrateall':
            if ($confirm) {
                require_sesskey();
                $auth = new auth_plugin_devicelock();
                // Strictly migrate confirmed users; unverified accounts must remain on email self-registration
                $users = $DB->get_records_select('user', "auth != 'devicelock' AND confirmed = 1 AND deleted = 0 AND suspended = 0 AND id > 2", [], 'id');
                $migrated = 0; $failed = 0; $skipped = 0;
                
                foreach ($users as $user) {
                    if ($auth->can_migrate_user($user->id)) {
                        if ($auth->migrate_user_to_devicelock($user->id, true)) {
                            device_manager::log_action($user->id, 'system', 'user_migrated_bulk', [
                                'admin_user' => $USER->id,
                                'admin_email' => $USER->email,
                                'admin_name' => fullname($USER)
                            ]);
                            $migrated++;
                        } else {
                            $failed++;
                        }
                    } else {
                        $skipped++;
                    }
                }
                \core\notification::success("Migration complete! Migrated: {$migrated}, Failed: {$failed}, Skipped: {$skipped}");
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']));
            }
            break;

        case 'migrateuser':
            if ($userid) {
                require_sesskey();
                $auth = new auth_plugin_devicelock();
                $targetuser = $DB->get_record('user', ['id' => $userid]);
                if ($targetuser && empty($targetuser->confirmed)) {
                    \core\notification::error("Cannot migrate unverified user " . s(fullname($targetuser)) . ": Email has not been confirmed yet. Unverified accounts must remain on Email-based self-registration until verified.");
                } else if ($auth->can_migrate_user($userid)) {
                    if ($auth->migrate_user_to_devicelock($userid, true)) {
                        device_manager::log_action($userid, 'system', 'user_migrated', [
                            'admin_user' => $USER->id,
                            'admin_email' => $USER->email,
                            'admin_name' => fullname($USER)
                        ]);
                        \core\notification::success("User successfully migrated to Lock Guard plugin.");
                    } else {
                        \core\notification::error("Failed to migrate user.");
                    }
                } else {
                    \core\notification::error("User is not eligible for migration.");
                }
                $redirect_to_viewuser = optional_param('redirect_to_viewuser', 0, PARAM_BOOL);
                if ($redirect_to_viewuser) {
                    redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid]));
                }
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'userpage' => $userpage]));
            }
            break;

        case 'resetall':
            if ($confirm) {
                require_sesskey();
                if (device_manager::reset_all_users_devices()) {
                    \core\notification::success("Reset complete! All registered devices and active sessions for all users have been purged.");
                } else {
                    \core\notification::error("Failed to reset all users' devices.");
                }
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']));
            }
            break;

        case 'changeauth':
            if ($userid) {
                $newauth = optional_param('newauth', '', PARAM_ALPHANUMEXT);
                if ($newauth) {
                    require_sesskey();
                    $targetuser = $DB->get_record('user', ['id' => $userid]);
                    if ($targetuser) {
                        if ($newauth === 'devicelock' && empty($targetuser->confirmed)) {
                            \core\notification::error("Cannot change authentication to Lock Guard for " . s(fullname($targetuser)) . ": Email has not been confirmed yet. Unverified accounts must remain on Email-based self-registration until verified.");
                        } else {
                            $oldauth = $targetuser->auth;
                            $targetuser->auth = $newauth;
                            $DB->update_record('user', $targetuser);
                            
                            // When switched to devicelock, log out all devices and reset registered devices
                            if ($newauth === 'devicelock') {
                                auth_devicelock_ensure_enabled();
                                device_manager::reset_user_devices($userid);
                            }
                            
                            // Log action
                            device_manager::log_action($userid, 'system', 'auth_method_changed', [
                                'from_auth' => $oldauth,
                                'to_auth' => $newauth,
                                'admin_user' => $USER->id,
                                'admin_email' => $USER->email,
                                'admin_name' => fullname($USER)
                            ]);
                            
                            \core\notification::success("Authentication method for " . s(fullname($targetuser)) . " changed to: " . s($newauth));
                        }
                    }
                    $redirect_to_viewuser = optional_param('redirect_to_viewuser', 0, PARAM_BOOL);
                    if ($redirect_to_viewuser) {
                        redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid]));
                    }
                    redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'userpage' => $userpage]));
                }
            }
            break;

        case 'changeauthall':
            if ($confirm) {
                require_sesskey();
                $newauth = required_param('newauth', PARAM_ALPHANUMEXT);
                $users = $DB->get_records_select('user', "deleted = 0 AND suspended = 0 AND id > 2", [], 'id');
                $updated = 0;
                $skipped_unconfirmed = 0;
                
                if ($newauth === 'devicelock') {
                    auth_devicelock_ensure_enabled();
                }
                
                foreach ($users as $user) {
                    if ($user->auth !== $newauth) {
                        if ($newauth === 'devicelock' && empty($user->confirmed)) {
                            $skipped_unconfirmed++;
                            continue; // Unverified accounts must remain on email self-registration!
                        }
                        $user->auth = $newauth;
                        $DB->update_record('user', $user);
                        
                        // When switched to devicelock, log out all devices and reset registered devices
                        if ($newauth === 'devicelock') {
                            device_manager::reset_user_devices($user->id);
                        }
                        device_manager::log_action($user->id, 'system', 'auth_method_changed_bulk', [
                            'to_auth' => $newauth,
                            'admin_user' => $USER->id,
                            'admin_email' => $USER->email,
                            'admin_name' => fullname($USER)
                        ]);
                        $updated++;
                    }
                }
                $msg = "Authentication method changed to '{$newauth}' for {$updated} users.";
                if ($skipped_unconfirmed > 0) {
                    $msg .= " ({$skipped_unconfirmed} unconfirmed users were kept on Email-based self-registration).";
                }
                \core\notification::success($msg);
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']));
            }
            break;

        case 'customemailall':
            require_sesskey();
            $emailsubject = optional_param('emailsubject', '', PARAM_TEXT);
            $emailbody    = optional_param('emailbody', '', PARAM_CLEANHTML);

            if (empty(trim($emailsubject))) {
                \core\notification::error(get_string('sendemail_empty_subject', 'auth_devicelock'));
            } else if (empty(trim($emailbody))) {
                \core\notification::error(get_string('sendemail_empty_body', 'auth_devicelock'));
            } else {
                $users = $DB->get_records_select('user', "deleted = 0 AND suspended = 0 AND id > 2", [], 'id');
                $successcount = 0;
                $failcount = 0;
                foreach ($users as $user) {
                    if (auth_devicelock_send_custom_email($user->id, $emailsubject, $emailbody)) {
                        device_manager::log_action($user->id, 'system', 'send_custom_email_bulk', [
                            'subject' => $emailsubject,
                            'admin_user' => $USER->id,
                            'admin_email' => $USER->email,
                            'admin_name' => fullname($USER)
                        ]);
                        $successcount++;
                    } else {
                        $failcount++;
                    }
                }
                \core\notification::success("Emails sent successfully to {$successcount} users. Fails: {$failcount}.");
            }
            redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => $tab]));
            break;

        case 'bulkconvert':
            require_sesskey();
            $selected_users = optional_param_array('selected_users', [], PARAM_INT);
            if (empty($selected_users)) {
                \core\notification::error("No users selected for conversion.");
            } else {
                $auth = new auth_plugin_devicelock();
                $converted = 0;
                $failed = 0;
                $skipped_unconfirmed = 0;
                foreach ($selected_users as $uid) {
                    $u = $DB->get_record('user', ['id' => $uid]);
                    if ($u && empty($u->confirmed)) {
                        $skipped_unconfirmed++;
                        continue;
                    }
                    if ($auth->can_migrate_user($uid)) {
                        if ($auth->migrate_user_to_devicelock($uid, true)) {
                            device_manager::log_action($uid, 'system', 'user_migrated_bulk', [
                                'admin_user' => $USER->id,
                                'admin_email' => $USER->email,
                                'admin_name' => fullname($USER)
                            ]);
                            $converted++;
                        } else {
                            $failed++;
                        }
                    }
                }
                if ($converted > 0) {
                    \core\notification::success("Successfully converted {$converted} user(s) to Lock Guard plugin.");
                }
                if ($skipped_unconfirmed > 0) {
                    \core\notification::info("Skipped {$skipped_unconfirmed} unconfirmed user(s). They must verify their email before migrating to the plugin.");
                }
                if ($failed > 0) {
                    \core\notification::error("Failed to convert {$failed} user(s).");
                }
            }
            redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'nonplugin', 'user_search' => $user_search, 'userpage' => $userpage]));
            break;

        case 'sendresetpassword':
            require_sesskey();
            if ($userid) {
                global $SITE;
                $targetuser = $DB->get_record('user', ['id' => $userid]);
                if ($targetuser) {
                    $token = bin2hex(random_bytes(16));
                    set_user_preference('auth_devicelock_pwdreset_token', $token, $userid);
                    set_user_preference('auth_devicelock_pwdreset_expiry', time() + 86400, $userid);
                    
                    $reseturl = new moodle_url('/auth/devicelock/reset_password.php', [
                        'token' => $token,
                        'userid' => $userid
                    ]);
                    
                    $subject = 'Reset your password for ' . format_string($SITE->fullname);
                    
                    $body = "Dear " . fullname($targetuser) . ",\n\n";
                    $body .= "A request has been made to reset the password for your account on " . format_string($SITE->fullname) . ".\n\n";
                    $body .= "To reset your password, please click on the following link or copy and paste it into your browser:\n";
                    $body .= $reseturl->out(false) . "\n\n";
                    $body .= "This link is valid for 24 hours. If you did not request a password reset, you can safely ignore this email.\n\n";
                    $body .= "Kind regards,\n" . format_string($SITE->fullname) . " Support";
                    
                    $htmlbody = nl2br(htmlspecialchars($body, ENT_QUOTES));
                    
                    $supportuser = core_user::get_support_user();
                    if (email_to_user($targetuser, $supportuser, $subject, $body, $htmlbody)) {
                        \core\notification::success("Password reset link successfully sent to " . s($targetuser->email));
                        device_manager::log_action($userid, 'system', 'send_reset_password', [
                            'admin_user' => $USER->id,
                            'admin_email' => $USER->email,
                            'admin_name' => fullname($USER)
                        ]);
                    } else {
                        \core\notification::error("Failed to send password reset email to " . s($targetuser->email));
                    }
                }
                $redirect_to_viewuser = optional_param('redirect_to_viewuser', 0, PARAM_BOOL);
                if ($redirect_to_viewuser) {
                    redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid]));
                }
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'userpage' => $userpage]));
            }
            break;

        case 'togglesuspend':
            require_sesskey();
            if ($userid) {
                $targetuser = $DB->get_record('user', ['id' => $userid]);
                if ($targetuser) {
                    $targetuser->suspended = $targetuser->suspended ? 0 : 1;
                    $DB->update_record('user', $targetuser);
                    device_manager::log_action($userid, 'system', 'toggle_suspend', [
                        'suspended' => $targetuser->suspended,
                        'admin_user' => $USER->id,
                        'admin_email' => $USER->email,
                        'admin_name' => fullname($USER)
                    ]);
                    // Invalidate the security-score cache so the badge updates
                    // immediately (suspended accounts are floored at 40).
                    auth_devicelock_invalidate_security_score_cache($userid);
                    if ($targetuser->suspended) {
                        device_manager::reset_user_devices($userid); // Force logout
                        \core\notification::success(s(fullname($targetuser)) . " has been suspended and logged out from all devices.");
                    } else {
                        \core\notification::success(s(fullname($targetuser)) . " has been unsuspended.");
                    }
                }
                $redirect_to_viewuser = optional_param('redirect_to_viewuser', 0, PARAM_BOOL);
                if ($redirect_to_viewuser) {
                    redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid]));
                }
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'userpage' => $userpage]));
            }
            break;

        case 'confirmuser':
            require_sesskey();
            if ($userid) {
                $targetuser = $DB->get_record('user', ['id' => $userid]);
                if ($targetuser) {
                    if (!$targetuser->confirmed) {
                        $targetuser->confirmed = 1;
                        $DB->update_record('user', $targetuser);
                        \core\notification::success(s(fullname($targetuser)) . " has been successfully confirmed.");
                        device_manager::log_action($userid, 'system', 'confirm_user', [
                            'admin_user' => $USER->id,
                            'admin_email' => $USER->email,
                            'admin_name' => fullname($USER)
                        ]);
                        // Invalidate the security-score cache (unconfirmed
                        // accounts are floored at 60; confirming lifts that).
                        auth_devicelock_invalidate_security_score_cache($userid);
                    } else {
                        \core\notification::info(s(fullname($targetuser)) . " is already confirmed.");
                    }
                }
                $redirect_to_viewuser = optional_param('redirect_to_viewuser', 0, PARAM_BOOL);
                if ($redirect_to_viewuser) {
                    redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid]));
                }
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'userpage' => $userpage]));
            }
            break;

        case 'deleteuser':
            // ============================================================
            // PERMANENTLY DELETE A USER ACCOUNT (Moodle core + plugin data)
            // ============================================================
            if ($userid && $confirm) {
                require_sesskey();

                // Safety: never allow deleting your own account.
                if ($userid == $USER->id) {
                    \core\notification::error(get_string('deleteuser_self_error', 'auth_devicelock'));
                    redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'userpage' => $userpage]));
                }

                // Safety: never allow deleting the guest account.
                if (isguestuser($userid)) {
                    \core\notification::error(get_string('deleteuser_guest_error', 'auth_devicelock'));
                    redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'userpage' => $userpage]));
                }

                $targetuser = $DB->get_record('user', ['id' => $userid]);
                if (!$targetuser) {
                    \core\notification::error(get_string('deleteuser_notfound', 'auth_devicelock'));
                    redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'userpage' => $userpage]));
                }

                // Safety: never allow deleting a site administrator from this screen.
                if (is_siteadmin($userid)) {
                    \core\notification::error(get_string('deleteuser_admin_error', 'auth_devicelock'));
                    redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'userpage' => $userpage]));
                }

                // Capture the identity of the account we are about to destroy,
                // so the audit log and the success notification stay meaningful
                // after the {user} record has been anonymised by delete_user().
                $deleted_userid   = (int)$targetuser->id;
                $deleted_username = $targetuser->username;
                $deleted_fullname = fullname($targetuser);
                $deleted_email    = $targetuser->email;
                $deleted_auth     = $targetuser->auth;

                // ------------------------------------------------------------
                // 1. Wipe ALL Lock Guard plugin data that belongs to this user
                //    (devices, browser/session tracking, plugin preferences
                //     and the user's own security-event logs).
                // ------------------------------------------------------------
                if ($DB->get_manager()->table_exists('auth_devicelock_devices')) {
                    $DB->delete_records('auth_devicelock_devices', ['userid' => $deleted_userid]);
                }
                if ($DB->get_manager()->table_exists('auth_devicelock_session_tracking')) {
                    $DB->delete_records('auth_devicelock_session_tracking', ['userid' => $deleted_userid]);
                }
                if ($DB->get_manager()->table_exists('auth_devicelock_logs')) {
                    $DB->delete_records('auth_devicelock_logs', ['userid' => $deleted_userid]);
                }
                // Remove every plugin-scoped user preference (auth_devicelock_*).
                $DB->delete_records_select(
                    'user_preferences',
                    'userid = :uid AND ' . $DB->sql_like('name', ':pat', false),
                    ['uid' => $deleted_userid, 'pat' => 'auth_devicelock_%']
                );

                // ------------------------------------------------------------
                // 2. Record the deletion in the audit log. We attach it to the
                //    ADMIN's own userid (not the deleted user, whose logs we
                //    just purged) so the audit trail survives and clearly shows
                //    who deleted whom.
                // ------------------------------------------------------------
                if ($DB->get_manager()->table_exists('auth_devicelock_logs')) {
                    device_manager::log_action($USER->id, 'system', 'delete_user_account', [
                        'deleted_user_id'  => $deleted_userid,
                        'deleted_username' => $deleted_username,
                        'deleted_fullname' => $deleted_fullname,
                        'deleted_email'    => $deleted_email,
                        'deleted_auth'     => $deleted_auth,
                        'admin_user'       => $USER->id,
                        'admin_email'      => !empty($USER->email) ? $USER->email : '',
                        'admin_name'       => fullname($USER),
                        'ip'               => getremoteaddr(),
                        'timestamp'        => time(),
                    ]);
                }

                // ------------------------------------------------------------
                // 3. Hand off to Moodle core. delete_user() marks the account
                //    as deleted (deleted=1), anonymises username/email, purges
                //    sessions, role assignments, enrolments, context data,
                //    triggers the user_deleted event and runs every auth
                //    plugin's user_delete() hook. This is THE supported way to
                //    fully remove a user from the Moodle DB.
                // ------------------------------------------------------------
                require_once($CFG->libdir . '/moodlelib.php');
                delete_user($targetuser);

                \core\notification::success(get_string('deleteuser_success', 'auth_devicelock', $deleted_fullname . ' (' . $deleted_username . ')'));

                // The viewuser page no longer exists for this user (account gone),
                // so always bounce back to the directory the admin came from.
                $origin_tab = ($tab === 'nonplugin') ? 'nonplugin' : 'users';
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', [
                    'tab' => $origin_tab,
                    'user_search' => $user_search,
                    'userpage' => $userpage,
                ]));
            }
            break;

        case 'bulkdeleteusers':
            // ============================================================
            // BULK DELETE: permanently remove multiple user accounts at once.
            // The list of ids arrives via POST 'selected_users[]'. Safety
            // rules mirror the single-user deleteuser case (no self / guest /
            // siteadmin). The whole batch is logged as ONE grouped entry
            // under the ADMIN's id, listing every deleted account.
            // ============================================================
            if ($confirm) {
                require_sesskey();
                $selected = optional_param_array('selected_users', [], PARAM_INT);
                $selected = array_values(array_filter(array_map('intval', $selected), function ($x) {
                    return $x > 2;
                }));

                $origin_tab = ($tab === 'nonplugin') ? 'nonplugin' : 'users';
                $backurl = new moodle_url('/auth/devicelock/admin_devices.php', [
                    'tab' => $origin_tab, 'user_search' => $user_search, 'userpage' => $userpage,
                ]);

                if (empty($selected)) {
                    \core\notification::error(get_string('bulk_delete_none_selected', 'auth_devicelock'));
                    redirect($backurl);
                }

                // Typed-confirmation-phrase guard for big destructive batches:
                // if the (pre-cap) selection exceeds 50 users, the admin MUST
                // type the word DELETE in the confirm-modal input. This blocks
                // accidental "select all + click" disasters.
                $original_count = count($selected);
                if ($original_count > 50) {
                    $phrase = optional_param('confirm_phrase', '', PARAM_ALPHA);
                    if (strtoupper(trim($phrase)) !== 'DELETE') {
                        \core\notification::error(get_string('confirm_phrase_mismatch', 'auth_devicelock'));
                        redirect($backurl);
                    }
                }

                // Cap at 200 accounts per batch to avoid PHP max_execution_time
                // timeouts (delete_user() is heavy: triggers events, runs hooks,
                // writes to many tables per account). Anything beyond 200 is
                // reported back to the admin so they can run another batch.
                $bulk_cap = 200;
                $truncated_count = 0;
                if (count($selected) > $bulk_cap) {
                    $truncated_count = count($selected) - $bulk_cap;
                    $selected = array_slice($selected, 0, $bulk_cap);
                    \core\notification::warning(get_string('bulk_delete_capped', 'auth_devicelock', ['capped' => $bulk_cap, 'remaining' => $truncated_count]));
                }
                // Give the batch generous room to finish.
                if (function_exists('raise_memory_limit')) {
                    raise_memory_limit(MEMORY_HUGE);
                }
                @set_time_limit(0);
                $coretimeout = ini_get('max_execution_time');
                if ($coretimeout && (int)$coretimeout > 0 && (int)$coretimeout < 600) {
                    @set_time_limit(600);
                }

                $deleted_count = 0;
                $skipped_count = 0;
                $already_gone = 0;
                // v3.8.0: every deleted account is collected here so the
                // whole batch can be audited in ONE grouped log entry after
                // the loop (the list is rendered as a scrollable block in
                // the log row's Full Details).
                $deletedaccounts = [];

                foreach ($selected as $targetid) {
                    $targetid = (int)$targetid;

                    // Safety: never delete self / guest / siteadmin.
                    if ($targetid == $USER->id || isguestuser($targetid) || is_siteadmin($targetid)) {
                        $skipped_count++;
                        continue;
                    }

                    $targetuser = $DB->get_record('user', ['id' => $targetid]);
                    if (!$targetuser) {
                        $already_gone++;
                        continue;
                    }

                    // Capture identity before anonymisation.
                    $du_id   = (int)$targetuser->id;
                    $du_un   = $targetuser->username;
                    $du_fn   = fullname($targetuser);
                    $du_em   = $targetuser->email;
                    $du_auth = $targetuser->auth;

                    // 1. Wipe plugin data for this user.
                    if ($DB->get_manager()->table_exists('auth_devicelock_devices')) {
                        $DB->delete_records('auth_devicelock_devices', ['userid' => $du_id]);
                    }
                    if ($DB->get_manager()->table_exists('auth_devicelock_session_tracking')) {
                        $DB->delete_records('auth_devicelock_session_tracking', ['userid' => $du_id]);
                    }
                    if ($DB->get_manager()->table_exists('auth_devicelock_logs')) {
                        $DB->delete_records('auth_devicelock_logs', ['userid' => $du_id]);
                    }
                    $DB->delete_records_select(
                        'user_preferences',
                        'userid = :uid AND ' . $DB->sql_like('name', ':pat', false),
                        ['uid' => $du_id, 'pat' => 'auth_devicelock_%']
                    );

                    // 2. Hand off to Moodle core; only accounts that were
                    //    ACTUALLY deleted are collected for the ONE grouped
                    //    audit entry written after the loop (it survives the
                    //    user's log purge and keeps the batch in one row).
                    try {
                        require_once($CFG->libdir . '/moodlelib.php');
                        delete_user($targetuser);
                        $deleted_count++;
                        $deletedaccounts[] = $du_id . ' - ' . $du_fn . ' (' . $du_un . ' - ' . $du_em . ')';
                    } catch (\Exception $e) {
                        $skipped_count++;
                    }
                }

                // v3.8.0: ONE grouped audit entry for the whole batch - the
                // full list of deleted accounts lives in its "users" details
                // key (rendered as a scrollable list in Full Details).
                if ($deleted_count > 0 && $DB->get_manager()->table_exists('auth_devicelock_logs')) {
                    device_manager::log_action($USER->id, 'system', 'bulk_delete_user_account', [
                        'count'            => $deleted_count,
                        'users'            => $deletedaccounts,
                        'skipped'          => $skipped_count,
                        'already_gone'     => $already_gone,
                        'admin_user'       => $USER->id,
                        'admin_email'      => !empty($USER->email) ? $USER->email : '',
                        'admin_name'       => fullname($USER),
                        'ip'               => getremoteaddr(),
                        'timestamp'        => time(),
                    ]);
                }

                if ($deleted_count > 0) {
                    \core\notification::success(get_string('bulk_delete_result_deleted', 'auth_devicelock', ['deleted' => $deleted_count]));
                }
                if ($skipped_count > 0) {
                    \core\notification::info(get_string('bulk_delete_result_skipped', 'auth_devicelock', ['skipped' => $skipped_count]));
                }
                if ($already_gone > 0) {
                    \core\notification::info(get_string('bulk_delete_result_gone', 'auth_devicelock', $already_gone));
                }
                redirect($backurl);
            }
            break;

        case 'clearlogs':
            // ============================================================
            // CLEAR ALL Lock Guard security logs (danger-zone action).
            // ============================================================
            if ($confirm) {
                require_sesskey();
                if ($DB->get_manager()->table_exists('auth_devicelock_logs')) {
                    $DB->delete_records('auth_devicelock_logs');
                    // Log the clearing event under the admin.
                    device_manager::log_action($USER->id, 'system', 'clear_all_logs', [
                        'admin_user'  => $USER->id,
                        'admin_email' => !empty($USER->email) ? $USER->email : '',
                        'admin_name'  => fullname($USER),
                        'ip'          => getremoteaddr(),
                        'timestamp'   => time(),
                    ]);
                    \core\notification::success(get_string('clear_logs_success', 'auth_devicelock'));
                }
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', [
                    'tab' => 'logs', 'log_search' => $log_search, 'log_action_filter' => $log_action_filter, 'logpage' => $logpage,
                ]));
            }
            break;

        case 'recalculatescores':
            // ============================================================
            // RECALCULATE ALL security scores (clears cache + recomputes for
            // every user with a log row in the last 30 days).
            // ============================================================
            require_sesskey();
            @set_time_limit(0);
            if (function_exists('raise_memory_limit')) {
                raise_memory_limit(MEMORY_HUGE);
            }
            $recount = auth_devicelock_recalculate_all_security_scores();
            if ($recount > 0) {
                \core\notification::success(get_string('recalculate_scores_done', 'auth_devicelock', $recount));
            } else {
                \core\notification::info(get_string('recalculate_scores_none', 'auth_devicelock'));
            }
            redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => $tab]));
            break;

        case 'bulkcopydetails':
            // ============================================================
            // BULK COPY USER DETAILS → CSV (confirm=1 path).
            // For every selected user: generate a fresh temp password, set it,
            // force password-change on next login, log the event under the
            // admin id, then stream a CSV of Full Name / Username / Password /
            // Email / Auth. Runs in the switch (before $OUTPUT->header) so raw
            // CSV headers can be sent. The confirm=0 path is an intercept below.
            // ============================================================
            if ($confirm) {
                require_sesskey();
                require_once($CFG->libdir . '/moodlelib.php');
                $selected = optional_param_array('selected_users', [], PARAM_INT);
                $selected = array_values(array_filter(array_map('intval', $selected), function ($x) {
                    return $x > 2;
                }));
                $origin_tab = ($tab === 'nonplugin') ? 'nonplugin' : 'users';
                $backurl = new moodle_url('/auth/devicelock/admin_devices.php', [
                    'tab' => $origin_tab, 'user_search' => $user_search, 'userpage' => $userpage,
                ]);

                if (empty($selected)) {
                    \core\notification::error(get_string('bulk_copy_details_none', 'auth_devicelock'));
                    redirect($backurl);
                }

                // Typed-confirmation-phrase guard for big batches: if the
                // selection exceeds 50 users, the admin MUST type the word
                // DELETE in the confirm-modal input (passwords are being reset).
                if (count($selected) > 50) {
                    $phrase = optional_param('confirm_phrase', '', PARAM_ALPHA);
                    if (strtoupper(trim($phrase)) !== 'DELETE') {
                        \core\notification::error(get_string('confirm_phrase_mismatch', 'auth_devicelock'));
                        redirect($backurl);
                    }
                }

                // Cap at 200 per batch (password generation + DB writes per user).
                $copy_cap = 200;
                $capped_remaining = 0;
                if (count($selected) > $copy_cap) {
                    $capped_remaining = count($selected) - $copy_cap;
                    $selected = array_slice($selected, 0, $copy_cap);
                }
                @set_time_limit(0);
                if (function_exists('raise_memory_limit')) {
                    raise_memory_limit(MEMORY_HUGE);
                }

                // Build CSV rows.
                $rows = [];
                foreach ($selected as $sid) {
                    $su = $DB->get_record('user', ['id' => (int)$sid], '*', IGNORE_MISSING);
                    // Safety: skip self / guest / siteadmin (never reset admin
                    // passwords from this screen, never reset own password,
                    // never touch the guest account).
                    if (!$su || is_siteadmin($su->id) || $su->id == $USER->id || isguestuser($su->id)) {
                        continue;
                    }
                    $temppassword = auth_devicelock_generate_temporary_password($su);
                    update_internal_user_password($su, $temppassword);
                    set_user_preference('auth_forcepasswordchange', 1, $su->id);
                    set_user_preference('auth_devicelock_temp_pass', 1, $su->id);

                    // Audit under the admin so the cohort-onboarding event survives.
                    if ($DB->get_manager()->table_exists('auth_devicelock_logs')) {
                        device_manager::log_action($USER->id, 'system', 'bulk_copy_user_details', [
                            'target_user_id' => (int)$su->id,
                            'target_username' => $su->username,
                            'target_fullname' => fullname($su),
                            'target_email' => $su->email,
                            'admin_user'  => $USER->id,
                            'admin_email' => !empty($USER->email) ? $USER->email : '',
                            'admin_name'  => fullname($USER),
                            'ip'          => getremoteaddr(),
                            'timestamp'   => time(),
                        ]);
                    }

                    $rows[] = [fullname($su), $su->username, $temppassword, $su->email, $su->auth];
                }

                if (empty($rows)) {
                    \core\notification::error(get_string('bulk_copy_details_none', 'auth_devicelock'));
                    redirect($backurl);
                }

                $filename = get_string('bulk_copy_details_filename', 'auth_devicelock') . '_' . date('Y-m-d_His') . '.csv';
                header('Content-Type: text/csv; charset=utf-8');
                header('Content-Disposition: attachment; filename="' . $filename . '"');
                header('Cache-Control: max-age=0, no-cache, no-store, must-revalidate');
                header('Pragma: no-cache');

                $out = fopen('php://output', 'w');
                fwrite($out, "\xEF\xBB\xBF"); // UTF-8 BOM for Excel.
                fputcsv($out, [
                    get_string('bulk_copy_details_col_fullname', 'auth_devicelock'),
                    get_string('bulk_copy_details_col_username', 'auth_devicelock'),
                    get_string('bulk_copy_details_col_password', 'auth_devicelock'),
                    get_string('bulk_copy_details_col_email', 'auth_devicelock'),
                    get_string('bulk_copy_details_col_auth', 'auth_devicelock'),
                ]);
                foreach ($rows as $r) {
                    fputcsv($out, array_map('auth_devicelock_csv_cell', $r));
                }
                fclose($out);
                // Note: $capped_remaining (if > 0) is silently dropped here because
                // a CSV download cannot carry a Moodle notification. The admin will
                // simply receive 200 rows and can run another batch for the rest.
                unset($capped_remaining);
                die();
            }
            break;

        case 'importuserscsv':
            // ============================================================
            // CSV IMPORT - bulk create users pre-configured for device-lock
            // auth. confirm=1 path. The confirm=0 (preview) path is an
            // intercept below. This runs in the switch BEFORE
            // $OUTPUT->header() so we can redirect cleanly afterwards.
            // ============================================================
            if ($confirm) {
                require_sesskey();
                require_once($CFG->libdir . '/moodlelib.php');
                require_once($CFG->dirroot . '/user/lib.php');

                // The previewed+signed rows travel back as a JSON blob so we
                // don't re-parse the uploaded file at confirm time.
                $rowsjson = optional_param('import_rows', '', PARAM_RAW);
                $rows = $rowsjson !== '' ? @json_decode($rowsjson, true) : null;
                if (!is_array($rows)) {
                    $rows = [];
                }

                $backurl = new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']);

                // Dry-run mode: validate the rows against the live DB (duplicate
                // username/email checks) and report what WOULD be created, but
                // do NOT call user_create_user(). The admin sees a summary and
                // bounces back without any account being created.
                $isdryrun = optional_param('dryrun', 0, PARAM_BOOL);

                // Cap at 200 per batch.
                $import_cap = 200;
                if (count($rows) > $import_cap) {
                    $rows = array_slice($rows, 0, $import_cap);
                    if (!$isdryrun) {
                        \core\notification::warning(get_string('import_users_capped', 'auth_devicelock', $import_cap));
                    }
                }
                if (!$isdryrun) {
                    @set_time_limit(0);
                }

                // In dry-run we re-validate every row (the live DB may have
                // changed since the preview) and report counts without writing.
                if ($isdryrun) {
                    $would_create = 0;
                    $would_skip = 0;
                    // Password-policy pre-flight: check every PROVIDED password
                    // against the site policy via check_password_policy() so
                    // the admin learns about rejections BEFORE the real import.
                    $pw_total = 0;
                    $pw_failed = 0;
                    $pw_reasons = [];
                    $rownum = 0;
                    foreach ($rows as $r) {
                        $rownum++;
                        $firstname = trim((string)($r['firstname'] ?? ''));
                        $lastname  = trim((string)($r['lastname'] ?? ''));
                        $email     = trim((string)($r['email'] ?? ''));
                        $username  = trim((string)($r['username'] ?? ''));
                        $password  = trim((string)($r['password'] ?? ''));
                        if ($firstname === '' || $lastname === '' || $email === '' || $username === ''
                            || !validate_email($email)
                            || $DB->record_exists('user', ['username' => $username])
                            || $DB->record_exists('user', ['email' => $email])) {
                            $would_skip++;
                            continue;
                        }
                        $would_create++;
                        // Only check provided passwords; blank ones are auto-generated
                        // (which always satisfy the policy).
                        if ($password !== '') {
                            $pw_total++;
                            $pwerr = [];
                            if (function_exists('check_password_policy')) {
                                check_password_policy($password, $pwerr);
                            }
                            if (!empty($pwerr)) {
                                $pw_failed++;
                                $pw_reasons[] = get_string('import_users_pwcheck_row', 'auth_devicelock',
                                    ['row' => $rownum, 'username' => $username, 'reason' => implode('; ', $pwerr)]);
                            }
                        }
                    }
                    \core\notification::info(get_string('import_users_dryrun_result', 'auth_devicelock',
                        ['would_create' => $would_create, 'would_skip' => $would_skip]));
                    // Report the password-policy pre-flight result.
                    if ($pw_total === 0) {
                        // No provided passwords — nothing to report (all auto-gen).
                    } else if ($pw_failed === 0) {
                        \core\notification::success(get_string('import_users_pwcheck_ok', 'auth_devicelock'));
                    } else {
                        \core\notification::warning(get_string('import_users_pwcheck_fail', 'auth_devicelock',
                            ['failed' => $pw_failed, 'total' => $pw_total]));
                        foreach ($pw_reasons as $reason) {
                            \core\notification::warning($reason);
                        }
                    }
                    redirect($backurl);
                }

                // Raise memory limit for the real-creation path.
                if (function_exists('raise_memory_limit')) {
                    raise_memory_limit(MEMORY_HUGE);
                }

                $created = 0;
                $skipped = 0;
                $errors = 0;
                $created_ids = [];

                foreach ($rows as $r) {
                    $firstname = trim((string)($r['firstname'] ?? ''));
                    $lastname  = trim((string)($r['lastname'] ?? ''));
                    $email     = trim((string)($r['email'] ?? ''));
                    $username  = trim((string)($r['username'] ?? ''));
                    $password  = trim((string)($r['password'] ?? ''));
                    $idnumber  = trim((string)($r['idnumber'] ?? ''));

                    if ($firstname === '' || $lastname === '' || $email === '' || $username === '') {
                        $skipped++;
                        continue;
                    }
                    if (!validate_email($email)) {
                        $skipped++;
                        continue;
                    }
                    if ($DB->record_exists('user', ['username' => $username]) ||
                        $DB->record_exists('user', ['email' => $email])) {
                        $skipped++;
                        continue;
                    }

                    if ($password === '') {
                        $password = auth_devicelock_generate_temporary_password((object)['username' => $username]);
                    }

                    $newuser = new stdClass();
                    $newuser->auth       = 'devicelock';
                    $newuser->username   = $username;
                    $newuser->firstname  = $firstname;
                    $newuser->lastname   = $lastname;
                    $newuser->email      = $email;
                    $newuser->password   = $password;
                    $newuser->confirmed  = 1;
                    $newuser->suspended  = 0;
                    $newuser->idnumber   = $idnumber;
                    $newuser->mnethostid = $CFG->mnet_localhost_id;
                    $newuser->lang       = $CFG->lang;
                    $newuser->maildisplay = 2;
                    $newuser->description = '';
                    $newuser->timecreated = time();
                    $newuser->timemodified = time();

                    try {
                        $newid = user_create_user($newuser, false, false);
                        if ($newid) {
                            update_internal_user_password($newuser, $password);
                            set_user_preference('auth_forcepasswordchange', 1, $newid);
                            set_user_preference('auth_devicelock_temp_pass', 1, $newid);
                            $created_ids[] = (int)$newid;
                            $created++;
                        } else {
                            $errors++;
                        }
                    } catch (\Exception $e) {
                        $errors++;
                    }
                }

                // Audit under the admin (one summary row, not one per user).
                if (!empty($created_ids) && $DB->get_manager()->table_exists('auth_devicelock_logs')) {
                    device_manager::log_action($USER->id, 'system', 'bulk_import_users', [
                        'created_user_ids' => $created_ids,
                        'created_count'    => $created,
                        'skipped_count'   => $skipped,
                        'errors_count'     => $errors,
                        'admin_user'  => $USER->id,
                        'admin_email' => !empty($USER->email) ? $USER->email : '',
                        'admin_name'  => fullname($USER),
                        'ip'          => getremoteaddr(),
                        'timestamp'   => time(),
                    ]);
                }

                $a = ['created' => $created, 'skipped' => $skipped, 'errors' => $errors];
                \core\notification::success(get_string('import_users_result_created', 'auth_devicelock', $a));
                if ($skipped > 0) {
                    \core\notification::info(get_string('import_users_result_skipped', 'auth_devicelock', $a));
                }
                if ($errors > 0) {
                    \core\notification::error(get_string('import_users_result_errors', 'auth_devicelock', $a));
                }
                redirect($backurl);
            }
            break;

        case 'sendsnapshottest':
            // ============================================================
            // Send a TEST snapshot email to the current admin only (not all
            // admins). Uses the same body builder as the weekly task. Runs in
            // the switch so it can redirect cleanly afterwards.
            // ============================================================
            require_sesskey();
            global $CFG, $SITE;
            $sent_to = '';
            if (!empty($USER->email) && validate_email($USER->email)) {
                // Build the snapshot data + email bodies via the SHARED helpers
                // (same data the weekly task + the in-browser page use) and send
                // ONLY to the current admin — not all admins.
                $data = auth_devicelock_build_snapshot_data(7);
                $sitename = format_string($SITE->fullname);
                $subject = get_string('snapshot_subject', 'auth_devicelock', $sitename)
                         . ' [' . get_string('snapshot_test_badge', 'auth_devicelock') . ']';
                $textbody = auth_devicelock_render_snapshot_text($data, $sitename);
                $htmlbody = auth_devicelock_render_snapshot_html($data, $sitename, $CFG->wwwroot);

                $recipient = clone $USER;
                $recipient->mailformat = 1;
                $supportuser = \core_user::get_support_user();
                if (email_to_user($recipient, $supportuser, $subject, $textbody, $htmlbody)) {
                    $sent_to = $USER->email;
                    \core\notification::success(get_string('snapshot_test_sent', 'auth_devicelock', $sent_to));
                } else {
                    \core\notification::error(get_string('snapshot_test_no_self', 'auth_devicelock'));
                }
            } else {
                \core\notification::error(get_string('snapshot_test_no_self', 'auth_devicelock'));
            }
            redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewsnapshot', 'tab' => $tab]));
            break;

        case 'banuser':
            if ($confirm) {
                require_sesskey();
                $ban_reason = optional_param('ban_reason', '', PARAM_TEXT);
                $redirect_to_viewuser = optional_param('redirect_to_viewuser', 0, PARAM_BOOL);
                $targetuser = $DB->get_record('user', ['id' => $userid]);
                if ($targetuser && !is_siteadmin($userid) && $userid != $USER->id) {
                    if ($DB->get_manager()->table_exists('auth_devicelock_bans')) {
                        // Revoke any existing active ban first.
                        $DB->set_field('auth_devicelock_bans', 'status', 'revoked', ['userid' => $userid, 'status' => 'active']);
                        // Insert the new ban.
                        $ban = new stdClass();
                        $ban->userid = $userid;
                        $ban->reason = $ban_reason;
                        $ban->banned_by = $USER->id;
                        $ban->banned_at = time();
                        $ban->ip_address = '';
                        $ban->device_fingerprint = '';
                        $ban->status = 'active';
                        $DB->insert_record('auth_devicelock_bans', $ban);
                    }
                    // Kill all user sessions so they're forced to re-login (and hit the ban check).
                    if (class_exists('\core\session\manager')) {
                        \core\session\manager::kill_user_sessions($userid);
                    }
                    // Suspend the account too.
                    $targetuser->suspended = 1;
                    $DB->update_record('user', $targetuser);
                    // Invalidate score cache.
                    auth_devicelock_invalidate_security_score_cache($userid);
                    device_manager::log_action($userid, 'system', 'ban_user', [
                        'reason' => $ban_reason, 'admin_user' => $USER->id, 'admin_name' => fullname($USER),
                    ]);
                    \core\notification::success(get_string('ban_success', 'auth_devicelock', s(fullname($targetuser))));
                }
                if ($redirect_to_viewuser) {
                    redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid]));
                }
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'userpage' => $userpage]));
            }
            break;

        case 'unbanuser':
            require_sesskey();
            $redirect_to_viewuser = optional_param('redirect_to_viewuser', 0, PARAM_BOOL);
            $targetuser = $DB->get_record('user', ['id' => $userid]);
            if ($targetuser && $DB->get_manager()->table_exists('auth_devicelock_bans')) {
                $DB->set_field('auth_devicelock_bans', 'status', 'revoked', ['userid' => $userid, 'status' => 'active']);
                // Unsuspend the account.
                $targetuser->suspended = 0;
                $DB->update_record('user', $targetuser);
                auth_devicelock_invalidate_security_score_cache($userid);
                device_manager::log_action($userid, 'system', 'unban_user', [
                    'admin_user' => $USER->id, 'admin_name' => fullname($USER),
                ]);
                \core\notification::success(get_string('unban_success', 'auth_devicelock', s(fullname($targetuser))));
            }
            if ($redirect_to_viewuser) {
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid]));
            }
            redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'userpage' => $userpage]));
            break;

        case 'bulkbanusers':
            if ($confirm) {
                require_sesskey();
                $selected = optional_param_array('selected_users', [], PARAM_INT);
                $ban_reason = optional_param('ban_reason', '', PARAM_TEXT);
                $banned = 0;
                $bannedusers = [];
                foreach ($selected as $sid) {
                    $sid = (int)$sid;
                    if ($sid == $USER->id || is_siteadmin($sid)) { continue; }
                    $su = $DB->get_record('user', ['id' => $sid], '*', IGNORE_MISSING);
                    if (!$su) { continue; }
                    if ($DB->get_manager()->table_exists('auth_devicelock_bans')) {
                        $DB->set_field('auth_devicelock_bans', 'status', 'revoked', ['userid' => $sid, 'status' => 'active']);
                        $ban = new stdClass();
                        $ban->userid = $sid;
                        $ban->reason = $ban_reason;
                        $ban->banned_by = $USER->id;
                        $ban->banned_at = time();
                        $ban->ip_address = '';
                        $ban->device_fingerprint = '';
                        $ban->status = 'active';
                        $DB->insert_record('auth_devicelock_bans', $ban);
                    }
                    if (class_exists('\core\session\manager')) {
                        \core\session\manager::kill_user_sessions($sid);
                    }
                    $su->suspended = 1;
                    $DB->update_record('user', $su);
                    auth_devicelock_invalidate_security_score_cache($sid);
                    // v3.5.0: a ban is a violation - lower the stored score
                    // too (the single-user ban path gets this automatically
                    // via the log hook; the bulk log row is stored against
                    // the admin, so the deduction is applied per user here).
                    $banscoredetails = ['via' => 'bulk_ban', 'reason' => $ban_reason];
                    auth_devicelock_score_apply_violation($sid, 'ban_user', $banscoredetails);
                    // v3.8.0: remember every banned user for the log's
                    // affected-user list.
                    $bannedusers[] = fullname($su) . ' (' . $su->username . ' - ' . $su->email . ')';
                    $banned++;
                }
                if ($banned > 0) {
                    device_manager::log_action($USER->id, 'system', 'bulk_ban_users', [
                        'count' => $banned, 'reason' => $ban_reason, 'admin_user' => $USER->id,
                        'users' => $bannedusers,
                    ]);
                    \core\notification::success(get_string('bulk_ban_success', 'auth_devicelock', $banned));
                }
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'userpage' => $userpage]));
            }
            break;

        case 'bulkunbanusers':
            require_sesskey();
            $selected = optional_param_array('selected_users', [], PARAM_INT);
            $unbanned = 0;
            $unbannedusers = [];
            foreach ($selected as $sid) {
                $sid = (int)$sid;
                if ($DB->get_manager()->table_exists('auth_devicelock_bans')) {
                    $DB->set_field('auth_devicelock_bans', 'status', 'revoked', ['userid' => $sid, 'status' => 'active']);
                }
                $su = $DB->get_record('user', ['id' => $sid], '*', IGNORE_MISSING);
                if ($su) {
                    $su->suspended = 0;
                    $DB->update_record('user', $su);
                    // v3.8.0: remember every unbanned user for the log's
                    // affected-user list (only users that were actually
                    // found and unsuspended).
                    $unbannedusers[] = fullname($su) . ' (' . $su->username . ' - ' . $su->email . ')';
                }
                auth_devicelock_invalidate_security_score_cache($sid);
                $unbanned++;
            }
            if ($unbanned > 0) {
                device_manager::log_action($USER->id, 'system', 'bulk_unban_users', [
                    'count' => $unbanned, 'admin_user' => $USER->id, 'users' => $unbannedusers,
                ]);
                \core\notification::success(get_string('bulk_unban_success', 'auth_devicelock', $unbanned));
            }
            redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'userpage' => $userpage]));
            break;

        case 'changescore':
            // ============================================================
            // CHANGE SCORE (manual increase / decrease / set / reset from
            // the Change Score form; can also override the per-user regain
            // settings).
            // ============================================================
            require_sesskey();
            $redirect_to_viewuser = optional_param('redirect_to_viewuser', 0, PARAM_BOOL);
            $targetuser = $DB->get_record('user', ['id' => $userid]);
            if ($targetuser) {
                $score_op = optional_param('score_op', '', PARAM_ALPHANUMEXT);
                $score_amount = optional_param('score_amount', 0, PARAM_INT);
                $score_reason = optional_param('score_reason', '', PARAM_TEXT);
                $use_custom = optional_param('score_use_custom', 0, PARAM_BOOL);
                $custom_amount = optional_param('score_custom_amount', 5, PARAM_INT);
                $custom_number = optional_param('score_custom_number', 1, PARAM_INT);
                $custom_unit = optional_param('score_custom_unit', 'days', PARAM_ALPHANUMEXT);

                $current = auth_devicelock_score_get($userid);
                $oldscore = (int)$current->score;
                $valid = true;
                $newscore = $oldscore;
                $amountused = 0;
                switch ($score_op) {
                    case 'increase':
                        $score_amount = max(1, min(100, $score_amount));
                        $newscore = $oldscore + $score_amount;
                        $amountused = $score_amount;
                        break;
                    case 'decrease':
                        $score_amount = max(1, min(100, $score_amount));
                        $newscore = $oldscore - $score_amount;
                        $amountused = $score_amount;
                        break;
                    case 'set':
                        $score_amount = max(0, min(100, $score_amount));
                        $newscore = $score_amount;
                        $amountused = $score_amount;
                        break;
                    case 'reset':
                        $newscore = 100;
                        break;
                    default:
                        $valid = false;
                }

                if ($valid) {
                    $opts = [
                        'operation' => $score_op,
                        'reason'    => $score_reason,
                        'reset'     => ($score_op === 'reset'),
                    ];
                    if ($amountused > 0) {
                        $opts['amount'] = $amountused;
                    }
                    if ($use_custom) {
                        $custom_amount = max(1, min(100, $custom_amount));
                        $custom_number = max(1, min(100000, $custom_number));
                        $opts['custom_regain'] = 1;
                        $opts['regain_amount'] = $custom_amount;
                        $opts['regain_interval'] = $custom_number * auth_devicelock_score_unit_seconds($custom_unit);
                    } else {
                        $opts['custom_regain'] = 0;
                    }
                    $res = auth_devicelock_score_set($userid, $newscore, $opts);
                    $sa = new stdClass();
                    $sa->name = s(fullname($targetuser));
                    $sa->old = (int)$res['old'];
                    $sa->new = (int)$res['new'];
                    \core\notification::success(get_string('score_changed_ok', 'auth_devicelock', $sa));
                } else {
                    \core\notification::error(get_string('score_changed_invalid', 'auth_devicelock'));
                }
            }
            if ($redirect_to_viewuser) {
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid]));
            }
            redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'userpage' => $userpage]));
            break;

        case 'changecourse':
            // ============================================================
            // CHANGE COURSE (single user): enrol into / update every CHECKED
            // course and un-enroll from every unchecked one. The form is
            // pre-checked with the user's current enrolments, so saving it
            // re-syncs the user's whole course list (frontpage is never
            // touched).
            // ============================================================
            require_sesskey();
            $targetuser = $DB->get_record('user', ['id' => $userid]);
            if (!$targetuser) {
                \core\notification::error(get_string('usernotfound', 'auth_devicelock'));
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'userpage' => $userpage]));
            }
            $cccourses = optional_param_array('cc_courses', [], PARAM_INT);
            $ccdays = optional_param_array('cc_days', [], PARAM_INT);
            $ccrole = optional_param('cc_role', 0, PARAM_INT);
            // Per-course durations, clamped server-side to 0..3650 days.
            $ccdaysmap = [];
            foreach ($ccdays as $ccid => $ccd) {
                $ccdaysmap[(int)$ccid] = max(0, min(3650, (int)$ccd));
            }
            // The same course universe the Change Course form lists.
            $ccallcourses = $DB->get_records_sql("
                SELECT c.id, c.fullname, c.shortname, c.visible, cc.name AS catname
                  FROM {course} c
                  JOIN {course_categories} cc ON cc.id = c.category
                 WHERE c.id > 1
              ORDER BY cc.sortorder, c.sortorder");
            $ccvalidids = array_map('intval', array_keys($ccallcourses));
            $cccurrent = auth_devicelock_get_user_course_enrolments($userid);

            $ccerrors = [];
            $ccinstancecache = [];
            $ccenrolled = [];
            $ccunenrolled = [];

            // 1. Enrol into / update every CHECKED (and existing) course.
            foreach ($cccourses as $ccid) {
                $ccid = (int)$ccid;
                if ($ccid <= 1 || !in_array($ccid, $ccvalidids, true)) {
                    continue;
                }
                $ccdur = isset($ccdaysmap[$ccid]) ? $ccdaysmap[$ccid] : 0;
                if (auth_devicelock_set_course_enrolment($userid, $ccid, $ccrole, $ccdur, $ccerrors, $ccinstancecache)) {
                    $ccname = isset($ccallcourses[$ccid]) ? $ccallcourses[$ccid]->fullname : ('#' . $ccid);
                    $ccenrolled[] = $ccname . ' (' . $ccdur . ' days)';
                }
            }

            // 2. Un-enroll from every currently-held course that is no
            //    longer checked (frontpage enrolments always stay).
            foreach ($cccurrent as $ccid => $ccjunk) {
                $ccid = (int)$ccid;
                if ($ccid <= 1 || in_array($ccid, $cccourses, true)) {
                    continue;
                }
                if (auth_devicelock_unenrol_user_from_course($userid, $ccid)) {
                    $ccname = isset($ccallcourses[$ccid]) ? $ccallcourses[$ccid]->fullname : ('#' . $ccid);
                    $ccunenrolled[] = $ccname;
                }
            }

            $cctotal = count($ccenrolled) + count($ccunenrolled);
            // Role display name for the audit log (mirrors the Student
            // fallback auth_devicelock_set_course_enrolment applies).
            $ccrolename = 'student';
            if ($ccrole > 0) {
                $ccrolerec = $DB->get_record('role', ['id' => $ccrole], 'id, name, shortname', IGNORE_MISSING);
                if ($ccrolerec) {
                    $ccrolename = !empty($ccrolerec->name) ? $ccrolerec->name : ucfirst($ccrolerec->shortname);
                }
            }

            if ($cctotal > 0 && $DB->get_manager()->table_exists('auth_devicelock_logs')) {
                device_manager::log_action($USER->id, 'system', 'change_course', [
                    'target_user_id'     => (int)$targetuser->id,
                    'target_username'    => $targetuser->username,
                    'target_fullname'    => fullname($targetuser),
                    'target_email'       => $targetuser->email,
                    'role'               => $ccrolename,
                    'courses_enrolled'   => $ccenrolled,
                    'courses_unenrolled' => $ccunenrolled,
                    'enrolled_count'     => count($ccenrolled),
                    'unenrolled_count'   => count($ccunenrolled),
                ]);
            }

            if ($cctotal > 0) {
                \core\notification::success(get_string('change_course_success', 'auth_devicelock', fullname($targetuser)));
            } else {
                \core\notification::info(get_string('change_course_nochange', 'auth_devicelock'));
            }
            foreach (array_slice($ccerrors, 0, 5) as $ccerr) {
                \core\notification::error($ccerr);
            }
            redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'userpage' => $userpage]));
            break;

        case 'changerole':
            // ============================================================
            // CHANGE ROLE (single user): site-level (system context) roles.
            // The form is pre-checked with the roles the user already holds
            // at system level; checking assigns, unchecking removes. The
            // guest/user role assignments are never manageable here.
            // ============================================================
            require_sesskey();
            $targetuser = $DB->get_record('user', ['id' => $userid]);
            if (!$targetuser) {
                \core\notification::error(get_string('usernotfound', 'auth_devicelock'));
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'userpage' => $userpage]));
            }
            $crroles = optional_param_array('cr_roles', [], PARAM_INT);
            $syscontext = context_system::instance();

            // Roles the user currently holds at SYSTEM level.
            $crassignednow = $DB->get_records('role_assignments', ['userid' => $userid, 'contextid' => $syscontext->id], '', 'roleid');

            // The manageable role universe (guest/user stay untouchable).
            $crallroles = $DB->get_records('role', null, 'sortorder ASC', 'id, name, shortname');
            $crmanageable = [];
            foreach ($crallroles as $crrole) {
                if ($crrole->shortname === 'guest' || $crrole->shortname === 'user') {
                    continue;
                }
                $crmanageable[(int)$crrole->id] = $crrole;
            }

            $cradded = [];
            $crremoved = [];

            // 1. Assign every checked role the user does not hold yet.
            foreach ($crroles as $crrid) {
                $crrid = (int)$crrid;
                if ($crrid <= 0 || !isset($crmanageable[$crrid]) || isset($crassignednow[$crrid])) {
                    continue;
                }
                role_assign($crrid, $userid, $syscontext->id);
                $cradded[] = !empty($crmanageable[$crrid]->name) ? $crmanageable[$crrid]->name : ucfirst($crmanageable[$crrid]->shortname);
            }

            // 2. Remove every held role that is no longer checked (only
            //    manageable roles - guest/user assignments always stay).
            foreach ($crassignednow as $crrid => $crjunk) {
                $crrid = (int)$crrid;
                if (!isset($crmanageable[$crrid]) || in_array($crrid, $crroles, true)) {
                    continue;
                }
                role_unassign($crrid, $userid, $syscontext->id);
                $crremoved[] = !empty($crmanageable[$crrid]->name) ? $crmanageable[$crrid]->name : ucfirst($crmanageable[$crrid]->shortname);
            }

            $crtotal = count($cradded) + count($crremoved);
            if ($crtotal > 0 && $DB->get_manager()->table_exists('auth_devicelock_logs')) {
                device_manager::log_action($USER->id, 'system', 'change_role', [
                    'target_user_id'  => (int)$targetuser->id,
                    'target_username' => $targetuser->username,
                    'target_fullname' => fullname($targetuser),
                    'target_email'    => $targetuser->email,
                    'roles_added'     => $cradded,
                    'roles_removed'   => $crremoved,
                ]);
            }

            if ($crtotal > 0) {
                \core\notification::success(get_string('change_role_success', 'auth_devicelock', fullname($targetuser)));
            } else {
                \core\notification::info(get_string('change_role_nochange', 'auth_devicelock'));
            }
            redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'userpage' => $userpage]));
            break;

        case 'bulkresetscores':
            // ============================================================
            // BULK RESET SCORE -> 100% for every selected user.
            // ============================================================
            require_sesskey();
            $selected = optional_param_array('selected_users', [], PARAM_INT);
            $resetcount = 0;
            foreach ($selected as $sid) {
                $sid = (int)$sid;
                if ($sid <= 2) { continue; }
                $su = $DB->get_record('user', ['id' => $sid], '*', IGNORE_MISSING);
                if (!$su || $su->deleted) { continue; }
                auth_devicelock_score_set($sid, 100, ['operation' => 'bulk_reset', 'reset' => true]);
                $resetcount++;
            }
            if ($resetcount > 0) {
                device_manager::log_action($USER->id, 'system', 'bulk_score_reset', [
                    'count' => $resetcount, 'admin_user' => $USER->id, 'admin_name' => fullname($USER),
                ]);
                \core\notification::success(get_string('score_reset_ok', 'auth_devicelock', $resetcount));
            }
            redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'userpage' => $userpage]));
            break;

        case 'bulkchangecourse':
            // ============================================================
            // BULK CHANGE COURSE (confirm=1): the checked courses + days +
            // role completely REPLACE every selected user's enrolments -
            // each user ends up enrolled in exactly the checked courses
            // (frontpage enrolments are never touched).
            // ============================================================
            if ($confirm) {
                require_sesskey();
                $selected = optional_param_array('selected_users', [], PARAM_INT);
                $selected = array_values(array_unique(array_filter(array_map('intval', $selected), function ($x) {
                    return $x > 2;
                })));
                $backurl = new moodle_url('/auth/devicelock/admin_devices.php', [
                    'tab' => 'users', 'user_search' => $user_search, 'userpage' => $userpage,
                ]);
                if (empty($selected)) {
                    \core\notification::error(get_string('bulk_delete_none_selected', 'auth_devicelock'));
                    redirect($backurl);
                }

                // Cap at 200 per batch (enrol + unenrol writes per user).
                $bulk_cap = 200;
                if (count($selected) > $bulk_cap) {
                    $truncated_count = count($selected) - $bulk_cap;
                    $selected = array_slice($selected, 0, $bulk_cap);
                    \core\notification::warning(get_string('bulk_delete_capped', 'auth_devicelock', ['capped' => $bulk_cap, 'remaining' => $truncated_count]));
                }
                if (function_exists('raise_memory_limit')) {
                    raise_memory_limit(MEMORY_HUGE);
                }
                @set_time_limit(0);
                $coretimeout = ini_get('max_execution_time');
                if ($coretimeout && (int)$coretimeout > 0 && (int)$coretimeout < 600) {
                    @set_time_limit(600);
                }

                $bc2courses = optional_param_array('bc2_courses', [], PARAM_INT);
                $bc2days = optional_param_array('bc2_days', [], PARAM_INT);
                $bc2role = optional_param('bc2_role', 0, PARAM_INT);
                // Per-course durations, clamped server-side to 0..3650 days.
                $bc2daysmap = [];
                foreach ($bc2days as $bcid => $bcd) {
                    $bc2daysmap[(int)$bcid] = max(0, min(3650, (int)$bcd));
                }
                $bc2allcourses = $DB->get_records_sql("
                    SELECT c.id, c.fullname, c.shortname, c.visible, cc.name AS catname
                      FROM {course} c
                      JOIN {course_categories} cc ON cc.id = c.category
                     WHERE c.id > 1
                  ORDER BY cc.sortorder, c.sortorder");
                $bc2validids = array_map('intval', array_keys($bc2allcourses));

                $bc2errors = [];
                $bc2instancecache = [];
                $bc2affected = [];
                $bc2enrollednames = [];
                $bc2unenrollednames = [];
                $bc2processed = 0;
                $bc2skipped = 0;

                foreach ($selected as $sid) {
                    $sid = (int)$sid;

                    // Safety: never touch self / guest / siteadmin.
                    if ($sid == $USER->id || isguestuser($sid) || is_siteadmin($sid)) {
                        $bc2skipped++;
                        continue;
                    }
                    $su = $DB->get_record('user', ['id' => $sid], '*', IGNORE_MISSING);
                    if (!$su || $su->deleted) {
                        $bc2skipped++;
                        continue;
                    }

                    $sucurrent = auth_devicelock_get_user_course_enrolments($sid);

                    // 1. Un-enroll from every course NOT in the new set.
                    foreach ($sucurrent as $sucid => $sujunk) {
                        $sucid = (int)$sucid;
                        if ($sucid <= 1 || in_array($sucid, $bc2courses, true)) {
                            continue;
                        }
                        if (auth_devicelock_unenrol_user_from_course($sid, $sucid)) {
                            $bc2unenrollednames[$sucid] = isset($bc2allcourses[$sucid]) ? $bc2allcourses[$sucid]->fullname : ('#' . $sucid);
                        }
                    }

                    // 2. Enrol into / update every CHECKED course.
                    foreach ($bc2courses as $sucid) {
                        $sucid = (int)$sucid;
                        if ($sucid <= 1 || !in_array($sucid, $bc2validids, true)) {
                            continue;
                        }
                        $sudur = isset($bc2daysmap[$sucid]) ? $bc2daysmap[$sucid] : 0;
                        if (auth_devicelock_set_course_enrolment($sid, $sucid, $bc2role, $sudur, $bc2errors, $bc2instancecache)) {
                            $bc2enrollednames[$sucid] = (isset($bc2allcourses[$sucid]) ? $bc2allcourses[$sucid]->fullname : ('#' . $sucid))
                                . ' (' . $sudur . ' days)';
                        }
                    }

                    $bc2affected[] = fullname($su) . ' (' . $su->username . ' - ' . $su->email . ')';
                    $bc2processed++;
                }

                // Role display name for the audit log (mirrors the Student
                // fallback auth_devicelock_set_course_enrolment applies).
                $bc2rolename = 'student';
                if ($bc2role > 0) {
                    $bc2rolerec = $DB->get_record('role', ['id' => $bc2role], 'id, name, shortname', IGNORE_MISSING);
                    if ($bc2rolerec) {
                        $bc2rolename = !empty($bc2rolerec->name) ? $bc2rolerec->name : ucfirst($bc2rolerec->shortname);
                    }
                }

                if ($bc2processed > 0 && $DB->get_manager()->table_exists('auth_devicelock_logs')) {
                    device_manager::log_action($USER->id, 'system', 'bulk_change_course', [
                        'count'              => $bc2processed,
                        'users'              => $bc2affected,
                        'courses_enrolled'   => array_values($bc2enrollednames),
                        'courses_unenrolled' => array_values($bc2unenrollednames),
                        'role'               => $bc2rolename,
                        'admin_user'         => $USER->id,
                    ]);
                }

                if ($bc2processed > 0) {
                    \core\notification::success(get_string('bulk_change_course_success', 'auth_devicelock', $bc2processed));
                }
                if ($bc2skipped > 0) {
                    \core\notification::info(get_string('bulk_delete_result_skipped', 'auth_devicelock', ['skipped' => $bc2skipped]));
                }
                foreach (array_slice($bc2errors, 0, 5) as $bc2err) {
                    \core\notification::error($bc2err);
                }
                redirect($backurl);
            }
            break;

        case 'bulkchangerole':
            // ============================================================
            // BULK CHANGE ROLE (confirm=1): the checked roles completely
            // REPLACE every selected user's site-level (system context)
            // roles - guest/user assignments are never touched.
            // ============================================================
            if ($confirm) {
                require_sesskey();
                $selected = optional_param_array('selected_users', [], PARAM_INT);
                $selected = array_values(array_unique(array_filter(array_map('intval', $selected), function ($x) {
                    return $x > 2;
                })));
                $backurl = new moodle_url('/auth/devicelock/admin_devices.php', [
                    'tab' => 'users', 'user_search' => $user_search, 'userpage' => $userpage,
                ]);
                if (empty($selected)) {
                    \core\notification::error(get_string('bulk_delete_none_selected', 'auth_devicelock'));
                    redirect($backurl);
                }

                // Cap at 200 per batch (role writes per user).
                $bulk_cap = 200;
                if (count($selected) > $bulk_cap) {
                    $truncated_count = count($selected) - $bulk_cap;
                    $selected = array_slice($selected, 0, $bulk_cap);
                    \core\notification::warning(get_string('bulk_delete_capped', 'auth_devicelock', ['capped' => $bulk_cap, 'remaining' => $truncated_count]));
                }
                if (function_exists('raise_memory_limit')) {
                    raise_memory_limit(MEMORY_HUGE);
                }
                @set_time_limit(0);
                $coretimeout = ini_get('max_execution_time');
                if ($coretimeout && (int)$coretimeout > 0 && (int)$coretimeout < 600) {
                    @set_time_limit(600);
                }

                $br2roles = optional_param_array('br2_roles', [], PARAM_INT);
                $syscontext = context_system::instance();
                $br2allroles = $DB->get_records('role', null, 'sortorder ASC', 'id, name, shortname');
                $br2manageable = [];
                foreach ($br2allroles as $br2role) {
                    if ($br2role->shortname === 'guest' || $br2role->shortname === 'user') {
                        continue;
                    }
                    $br2manageable[(int)$br2role->id] = $br2role;
                }

                $br2affected = [];
                $br2addednames = [];
                $br2removednames = [];
                $br2processed = 0;
                $br2skipped = 0;

                foreach ($selected as $sid) {
                    $sid = (int)$sid;

                    // Safety: never touch self / guest / siteadmin.
                    if ($sid == $USER->id || isguestuser($sid) || is_siteadmin($sid)) {
                        $br2skipped++;
                        continue;
                    }
                    $su = $DB->get_record('user', ['id' => $sid], '*', IGNORE_MISSING);
                    if (!$su || $su->deleted) {
                        $br2skipped++;
                        continue;
                    }

                    $br2assignednow = $DB->get_records('role_assignments', ['userid' => $sid, 'contextid' => $syscontext->id], '', 'roleid');

                    // 1. Assign every checked role the user does not hold.
                    foreach ($br2roles as $brrid) {
                        $brrid = (int)$brrid;
                        if ($brrid <= 0 || !isset($br2manageable[$brrid]) || isset($br2assignednow[$brrid])) {
                            continue;
                        }
                        role_assign($brrid, $sid, $syscontext->id);
                        $br2addednames[$brrid] = !empty($br2manageable[$brrid]->name) ? $br2manageable[$brrid]->name : ucfirst($br2manageable[$brrid]->shortname);
                    }

                    // 2. Remove every held role that is not checked (only
                    //    manageable roles - guest/user assignments stay).
                    foreach ($br2assignednow as $brrid => $brjunk) {
                        $brrid = (int)$brrid;
                        if (!isset($br2manageable[$brrid]) || in_array($brrid, $br2roles, true)) {
                            continue;
                        }
                        role_unassign($brrid, $sid, $syscontext->id);
                        $br2removednames[$brrid] = !empty($br2manageable[$brrid]->name) ? $br2manageable[$brrid]->name : ucfirst($br2manageable[$brrid]->shortname);
                    }

                    $br2affected[] = fullname($su) . ' (' . $su->username . ' - ' . $su->email . ')';
                    $br2processed++;
                }

                if ($br2processed > 0 && $DB->get_manager()->table_exists('auth_devicelock_logs')) {
                    device_manager::log_action($USER->id, 'system', 'bulk_change_role', [
                        'count'         => $br2processed,
                        'users'         => $br2affected,
                        'roles_added'   => array_values($br2addednames),
                        'roles_removed' => array_values($br2removednames),
                        'admin_user'    => $USER->id,
                    ]);
                }

                if ($br2processed > 0) {
                    \core\notification::success(get_string('bulk_change_role_success', 'auth_devicelock', $br2processed));
                }
                if ($br2skipped > 0) {
                    \core\notification::info(get_string('bulk_delete_result_skipped', 'auth_devicelock', ['skipped' => $br2skipped]));
                }
                redirect($backurl);
            }
            break;

        case 'quickcreateuser':
            require_sesskey();
            require_once($CFG->libdir . '/moodlelib.php');
            require_once($CFG->dirroot . '/user/lib.php');
            $qc_username = optional_param('qc_username', '', PARAM_TEXT);
            $qc_email = optional_param('qc_email', '', PARAM_EMAIL);
            $qc_password = optional_param('qc_password', '', PARAM_RAW);
            $qc_autogen_user = optional_param('qc_autogen_user', 0, PARAM_BOOL);
            $qc_autogen_email = optional_param('qc_autogen_email', 0, PARAM_BOOL);
            $qc_autogen_pass = optional_param('qc_autogen_pass', 0, PARAM_BOOL);
            // v3.4.4: first/last name fields (with their own Auto-generate
            // checkbox that fills a random realistic name pair).
            $qc_firstname = trim(optional_param('qc_firstname', '', PARAM_TEXT));
            $qc_lastname = trim(optional_param('qc_lastname', '', PARAM_TEXT));
            $qc_autogen_name = optional_param('qc_autogen_name', 0, PARAM_BOOL);
            if ($qc_autogen_name) {
                $qc_firstname = auth_devicelock_random_firstname();
                $qc_lastname = auth_devicelock_random_lastname();
            }
            if ($qc_autogen_user) { $qc_username = 'user' . random_int(1000, 9999); }
            if ($qc_autogen_email) { $qc_email = 'user' . random_int(1000, 9999) . '@example.com'; }
            if ($qc_autogen_pass) { $qc_password = auth_devicelock_generate_temporary_password((object)['username' => $qc_username]); }
            $qc_username = trim(strtolower($qc_username));
            $qc_email = trim(strtolower($qc_email));
            // Per-field required validation: a field must be filled in unless its
            // "Auto-generate" checkbox was used.
            $qc_missing = [];
            if ($qc_username === '') {
                $qc_missing[] = get_string('quick_create_username', 'auth_devicelock');
            }
            if ($qc_firstname === '') {
                $qc_missing[] = get_string('quick_create_firstname', 'auth_devicelock');
            }
            if ($qc_lastname === '') {
                $qc_missing[] = get_string('quick_create_lastname', 'auth_devicelock');
            }
            if ($qc_email === '') {
                $qc_missing[] = get_string('quick_create_email', 'auth_devicelock');
            }
            if (trim($qc_password) === '') {
                $qc_missing[] = get_string('quick_create_password', 'auth_devicelock');
            }
            if (!empty($qc_missing)) {
                \core\notification::error(get_string('createuser_field_required', 'auth_devicelock', implode(', ', $qc_missing)));
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'quickcreateuserform', 'tab' => 'users']));
            }
            // Moodle only allows letters, numbers, dot, dash, underscore and @ in
            // usernames - anything else makes user_create_user() throw
            // "invalidusername". Reject early with a clear message instead.
            if (clean_param($qc_username, PARAM_USERNAME) !== $qc_username) {
                \core\notification::error(get_string('createuser_username_chars', 'auth_devicelock', $qc_username));
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'quickcreateuserform', 'tab' => 'users']));
            }
            if (!validate_email($qc_email)) {
                \core\notification::error(get_string('createuser_email_invalid', 'auth_devicelock', $qc_email));
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'quickcreateuserform', 'tab' => 'users']));
            }
            if ($DB->record_exists('user', ['username' => $qc_username]) || $DB->record_exists('user', ['email' => $qc_email])) {
                \core\notification::error(get_string('quick_create_exists', 'auth_devicelock'));
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'quickcreateuserform', 'tab' => 'users']));
            }
            // Course enrolment settings (applied after the user is created).
            $qc_courses = optional_param_array('qc_courses', [], PARAM_INT);
            $qc_enrol_role = (int)optional_param('qc_enrol_role', 0, PARAM_INT);
            $qc_enrol_duration = (int)optional_param('qc_enrol_duration', 0, PARAM_INT);
            $newuser = new stdClass();
            $newuser->auth = 'devicelock';
            $newuser->username = $qc_username;
            $newuser->firstname = $qc_firstname;
            $newuser->lastname = $qc_lastname;
            $newuser->email = $qc_email;
            $newuser->password = $qc_password;
            $newuser->confirmed = 1;
            $newuser->suspended = 0;
            $newuser->mnethostid = $CFG->mnet_localhost_id;
            $newuser->lang = $CFG->lang;
            $newuser->maildisplay = 2;
            $newuser->timecreated = time();
            $newuser->timemodified = time();
            try {
                $newid = user_create_user($newuser, false, false);
                if ($newid) {
                    // FIX: update_internal_user_password needs the user object with an id.
                    $newuser->id = $newid;
                    update_internal_user_password($newuser, $qc_password);
                    set_user_preference('auth_forcepasswordchange', 1, $newid);
                    set_user_preference('auth_devicelock_temp_pass', 1, $newid);
                    // Assign selected role(s) to the new user.
                    $qc_roles = optional_param_array('qc_roles', [], PARAM_INT);
                    $qc_custom_role = trim(optional_param('qc_custom_role', '', PARAM_TEXT));
                    $role_ids = $qc_roles;
                    if ($qc_custom_role !== '') {
                        $existing_role = $DB->get_record('role', ['shortname' => $qc_custom_role], 'id', IGNORE_MISSING);
                        if ($existing_role) {
                            $role_ids[] = (int)$existing_role->id;
                        } else {
                            // Create a new role (Moodle 5.x: create_role takes 3 string args).
                            $newroleid = create_role($qc_custom_role, $qc_custom_role, 'Custom role for quick-created user');
                            $role_ids[] = (int)$newroleid;
                        }
                    }
                    $syscontext = context_system::instance();
                    foreach ($role_ids as $rid) {
                        if ($rid > 0) {
                            role_assign($rid, $newid, $syscontext->id);
                        }
                    }
                    // Default student role if none selected.
                    if (empty($role_ids)) {
                        $studentrole = $DB->get_record('role', ['shortname' => 'student'], 'id', IGNORE_MISSING);
                        if ($studentrole) {
                            role_assign((int)$studentrole->id, $newid, $syscontext->id);
                        }
                    }
                    // Enrol the new user into the selected existing courses.
                    $qc_enrolled = 0;
                    if (!empty($qc_courses)) {
                        $qc_enrolerrors = [];
                        $qc_enrolcache = [];
                        $qc_enrolled = auth_devicelock_enrol_user_in_courses(
                            $newid, $qc_courses, $qc_enrol_role, $qc_enrol_duration, $qc_enrolerrors, $qc_enrolcache);
                        if ($qc_enrolled > 0) {
                            \core\notification::success(get_string('enrol_success', 'auth_devicelock',
                                ['user' => $qc_username, 'count' => $qc_enrolled]));
                        }
                        foreach (array_slice($qc_enrolerrors, 0, 5) as $qc_eerr) {
                            \core\notification::error($qc_eerr);
                        }
                    }
                    device_manager::log_action($newid, 'system', 'quick_create_user',
                        ['admin_user' => $USER->id, 'username' => $qc_username, 'courses_enrolled' => $qc_enrolled]);
                    \core\notification::success(get_string('quick_create_success', 'auth_devicelock', $qc_username));
                    // v3.4.3: flash the created login details (including the
                    // generated password) through the session so the users tab
                    // can show them ONCE after the redirect. Moodle never stores
                    // plaintext passwords, so this is the only chance the admin
                    // gets to copy it.
                    $SESSION->auth_devicelock_created_accounts = [[
                        'name'     => $qc_firstname . ' ' . $qc_lastname,
                        'username' => $qc_username,
                        'email'    => $qc_email,
                        'password' => $qc_password,
                    ]];
                }
            } catch (\Exception $e) {
                \core\notification::error(get_string('quick_create_error', 'auth_devicelock', $e->getMessage()));
            }
            redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'created' => 1]));
            break;

        case 'bulkcreateusers':
            require_sesskey();
            require_once($CFG->libdir . '/moodlelib.php');
            require_once($CFG->dirroot . '/user/lib.php');
            $bc_count = (int)optional_param('bc_count', 5, PARAM_INT);
            $bc_user_base = trim(optional_param('bc_user_base', '', PARAM_TEXT));
            $bc_email_base = trim(optional_param('bc_email_base', '', PARAM_TEXT));
            $bc_email_domain = trim(strtolower(optional_param('bc_email_domain', '', PARAM_TEXT)));
            $bc_pass_base = trim(optional_param('bc_pass_base', '', PARAM_RAW));
            $bc_autogen_user = optional_param('bc_autogen_user', 0, PARAM_BOOL);
            $bc_autogen_email = optional_param('bc_autogen_email', 0, PARAM_BOOL);
            $bc_autogen_pass = optional_param('bc_autogen_pass', 0, PARAM_BOOL);
            // v3.4.4: first/last name bases. When the "Auto-generate"
            // checkbox is ticked, every user in the batch gets a different
            // random realistic name pair instead.
            $bc_firstname = trim(optional_param('bc_firstname', '', PARAM_TEXT));
            $bc_lastname = trim(optional_param('bc_lastname', '', PARAM_TEXT));
            $bc_autogen_name = optional_param('bc_autogen_name', 0, PARAM_BOOL);
            $bc_roles = optional_param_array('bc_roles', [], PARAM_INT);
            $bc_custom_role = trim(optional_param('bc_custom_role', '', PARAM_TEXT));
            $bc_start = max(1, (int)optional_param('bc_start', 1, PARAM_INT));
            if ($bc_autogen_user) { $bc_user_base = 'bulkuser'; }
            if ($bc_autogen_email) { $bc_email_base = 'bulkuser'; $bc_email_domain = 'example.com'; }
            if ($bc_autogen_pass) { $bc_pass_base = 'TempPass'; }
            $bc_count = max(1, min($bc_count, 200));
            // Per-field required validation: every base field must be filled in
            // unless its "Auto-generate" checkbox was used.
            $bc_missing = [];
            if ($bc_user_base === '') {
                $bc_missing[] = get_string('bulk_create_username_base', 'auth_devicelock');
            }
            if (!$bc_autogen_name && $bc_firstname === '') {
                $bc_missing[] = get_string('bulk_create_firstname_base', 'auth_devicelock');
            }
            if (!$bc_autogen_name && $bc_lastname === '') {
                $bc_missing[] = get_string('bulk_create_lastname_base', 'auth_devicelock');
            }
            if ($bc_email_base === '' || $bc_email_domain === '') {
                $bc_missing[] = get_string('bulk_create_email_base', 'auth_devicelock');
            }
            if ($bc_pass_base === '') {
                $bc_missing[] = get_string('bulk_create_password_base', 'auth_devicelock');
            }
            if (!empty($bc_missing)) {
                \core\notification::error(get_string('createuser_field_required', 'auth_devicelock', implode(', ', $bc_missing)));
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'bulkcreateusersform', 'tab' => 'users']));
            }
            // BUG FIX (v3.4.0): Moodle usernames may only contain lowercase
            // letters, numbers, dot, dash, underscore and @. The old numbering
            // scheme used "base#N", the "#" was rejected by user_create_user()
            // ("invalidusername") and EVERY user in the batch was silently
            // counted as "skipped". The numbering is now "baseN" and the base
            // itself is validated here, before anything is created.
            $bc_user_base = strtolower($bc_user_base);
            if (clean_param($bc_user_base, PARAM_USERNAME) !== $bc_user_base) {
                \core\notification::error(get_string('createuser_username_chars', 'auth_devicelock', $bc_user_base));
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'bulkcreateusersform', 'tab' => 'users']));
            }
            // Basic sanity check of the generated email format.
            $bc_email_base = strtolower($bc_email_base);
            if (!validate_email($bc_email_base . '.' . $bc_start . '@' . $bc_email_domain)) {
                \core\notification::error(get_string('createuser_email_invalid', 'auth_devicelock',
                    $bc_email_base . '.' . $bc_start . '@' . $bc_email_domain));
                redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'bulkcreateusersform', 'tab' => 'users']));
            }
            // Course enrolment settings (applied to every created user).
            $bc_courses = optional_param_array('bc_courses', [], PARAM_INT);
            $bc_enrol_role = (int)optional_param('bc_enrol_role', 0, PARAM_INT);
            $bc_enrol_duration = (int)optional_param('bc_enrol_duration', 0, PARAM_INT);
            // Resolve role IDs.
            $role_ids = $bc_roles;
            if ($bc_custom_role !== '') {
                $existing = $DB->get_record('role', ['shortname' => $bc_custom_role], 'id', IGNORE_MISSING);
                if ($existing) {
                    $role_ids[] = (int)$existing->id;
                } else {
                    // Create a new role (Moodle 5.x: create_role takes 3 string args).
                    $newroleid = create_role($bc_custom_role, $bc_custom_role, 'Custom role for bulk-created users');
                    $role_ids[] = (int)$newroleid;
                }
            }
            $created = 0;
            $skipped = 0;
            $createerrors = [];
            // v3.4.3: remember every created account (username + email + the
            // exact password used) so it can be shown to the admin once after
            // the redirect. The numbering can jump over existing accounts, so
            // the admin cannot reliably guess which numbers were actually used.
            $createdaccounts = [];
            $totalenrolled = 0;
            $enrolerrors = [];
            $enrolcache = [];
            $studentrole = $DB->get_record('role', ['shortname' => 'student'], 'id', IGNORE_MISSING);
            $studentroleid = $studentrole ? (int)$studentrole->id : 0;
            $syscontext = context_system::instance();
            // v3.4.4: the batch ALWAYS creates the requested number of
            // accounts. Before creating anything, the numbering is advanced
            // past every username AND email that already exists (e.g. after
            // an earlier batch created base1..base5, this batch simply
            // starts at base6) — existing accounts are never "skipped",
            // the admin always gets the full count, and is told where the
            // numbering started.
            $bc_start_original = $bc_start;
            $maxprobe = $bc_start + $bc_count * 25 + 500;
            $probe = $bc_start;
            while ($probe < $maxprobe) {
                $probename = $bc_user_base . $probe;
                $probeemail = $bc_email_base . '.' . $probe . '@' . $bc_email_domain;
                if (!$DB->record_exists('user', ['username' => $probename])
                        && !$DB->record_exists('user', ['email' => $probeemail])) {
                    break;
                }
                $probe++;
            }
            if ($probe > $bc_start_original) {
                $bc_start = $probe;
                \core\notification::info(get_string('bulk_create_numbering_auto', 'auth_devicelock',
                    $bc_user_base . $probe));
            }
            // The loop below keeps a safety net for gaps (e.g. base1 and
            // base3 exist but base2 is free): it jumps over any leftover
            // collision without counting it as a failure, so the requested
            // number of accounts is still created.
            $maxattempts = $bc_count * 25 + 200;
            $attempts = 0;
            $i = $bc_start;
            while ($created < $bc_count && $attempts < $maxattempts) {
                $attempts++;
                // Moodle-safe username: base + number (no "#", no spaces, ...).
                $username = $bc_user_base . $i;
                $email = $bc_email_base . '.' . $i . '@' . $bc_email_domain;
                $password = $bc_pass_base . '#' . $i;
                if ($DB->record_exists('user', ['username' => $username]) || $DB->record_exists('user', ['email' => $email])) {
                    $skipped++;
                    $i++;
                    continue;
                }
                $newuser = new stdClass();
                $newuser->auth = 'devicelock';
                $newuser->username = $username;
                if ($bc_autogen_name) {
                    // A random realistic name for every user in the batch.
                    $newuser->firstname = auth_devicelock_random_firstname();
                    $newuser->lastname = auth_devicelock_random_lastname();
                } else {
                    // First name base as-is, number appended to the last name
                    // base (matches the classic "Bulk User1" pattern).
                    $newuser->firstname = $bc_firstname;
                    $newuser->lastname = $bc_lastname . $i;
                }
                $newuser->email = $email;
                $newuser->password = $password;
                $newuser->confirmed = 1;
                $newuser->suspended = 0;
                $newuser->mnethostid = $CFG->mnet_localhost_id;
                $newuser->lang = $CFG->lang;
                $newuser->maildisplay = 2;
                $newuser->timecreated = time();
                $newuser->timemodified = time();
                try {
                    $newid = user_create_user($newuser, false, false);
                    if ($newid) {
                        // FIX: update_internal_user_password needs the user object with an id.
                        $newuser->id = $newid;
                        update_internal_user_password($newuser, $password);
                        set_user_preference('auth_forcepasswordchange', 1, $newid);
                        set_user_preference('auth_devicelock_temp_pass', 1, $newid);
                        // Assign roles.
                        foreach ($role_ids as $rid) {
                            if ($rid > 0) {
                                role_assign($rid, $newid, $syscontext->id);
                            }
                        }
                        // Default student role if no roles selected.
                        if (empty($role_ids) && $studentroleid > 0) {
                            role_assign($studentroleid, $newid, $syscontext->id);
                        }
                        // Enrol into the selected existing courses.
                        if (!empty($bc_courses)) {
                            $totalenrolled += auth_devicelock_enrol_user_in_courses(
                                $newid, $bc_courses, $bc_enrol_role, $bc_enrol_duration, $enrolerrors, $enrolcache);
                        }
                        $created++;
                        $createdaccounts[] = [
                            'name'     => $newuser->firstname . ' ' . $newuser->lastname,
                            'username' => $username,
                            'email'    => $email,
                            'password' => $password,
                        ];
                    }
                } catch (\Exception $e) {
                    // Never fail silently again: keep the reason and show it.
                    $createerrors[] = $username . ': ' . $e->getMessage();
                }
                $i++;
            }
            // v3.8.0: the log's affected-user list carries names, usernames
            // and emails only - the passwords must NEVER reach the log.
            $createduserlist = array_map(function ($a) {
                return $a['name'] . ' (' . $a['username'] . ' - ' . $a['email'] . ')';
            }, $createdaccounts);
            if ($created > 0) {
                device_manager::log_action($USER->id, 'system', 'bulk_create_users',
                    ['created' => $created, 'skipped' => $skipped, 'enrolled' => $totalenrolled, 'admin_user' => $USER->id, 'users' => $createduserlist]);
                \core\notification::success(get_string('bulk_create_success', 'auth_devicelock', ['created' => $created]));
                if ($totalenrolled > 0) {
                    \core\notification::success(get_string('enrol_bulk_success', 'auth_devicelock', $totalenrolled));
                }
                // v3.4.3: flash the full list of created accounts (with their
                // passwords) so the users tab can show them once.
                $SESSION->auth_devicelock_created_accounts = $createdaccounts;
            } else {
                \core\notification::error(get_string('bulk_create_none', 'auth_devicelock'));
            }
            // v3.4.4 note: the in-loop $skipped counter can only be bumped by
            // the rare "gap" safety net (the numbering was already pre-advanced
            // past existing accounts above). It is NOT a failure — the batch
            // still created every requested account — so there is no longer a
            // scary "skipped" notification; the count stays in the log entry
            // (already written above) for auditing.
            foreach (array_slice($createerrors, 0, 5) as $cerr) {
                \core\notification::error(get_string('bulk_create_error_detail', 'auth_devicelock', $cerr));
            }
            foreach (array_slice($enrolerrors, 0, 5) as $eerr) {
                \core\notification::error($eerr);
            }
            redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'created' => 1]));
            break;
    }
}

// ============================================================
// CSV EXPORT INTERCEPTS — must run BEFORE any $OUTPUT->header()
// call so we can stream raw CSV download headers to the browser.
// ============================================================

// Export the filtered Users directory as a CSV download.
if ($action === 'exportuserscsv') {
    require_sesskey();
    require_once($CFG->libdir . '/moodlelib.php');

    // scope=nonplugin limits the export to users NOT using the plugin auth.
    $export_scope = optional_param('scope', '', PARAM_ALPHA);

    // Reuse the exact same filter as the Users directory (no pagination).
    $export_params = [];
    // v3.10.0: u.id > 1 (not > 2!) - only the GUEST account (id 1) is always
    // hidden. The old "id > 2" also hard-hid the PRIMARY ADMIN (id 2), which
    // made the new "Show site admins in the User Directory" setting useless
    // for the main admin account - it never appeared even when enabled.
    // Admin visibility is now controlled ONLY by auth_devicelock_admin_exclude_sql().
    $export_base_where = "u.deleted = 0 AND u.id > 1" . auth_devicelock_admin_exclude_sql('u');
    $export_where = $export_base_where;
    if ($export_scope === 'nonplugin') {
        $export_where .= " AND u.auth != 'devicelock'";
    }
    if ($user_search) {
        // v3.9.0: the export honours the same fuzzy typo-retry semantics
        // as the directory it exports, so the CSV always matches the list.
        $export_typo_retry = auth_devicelock_fuzzy_typo_retry($user_search, $export_where);
        $export_where .= " AND " . auth_devicelock_build_user_search_where($user_search, 'u', $export_params, 'exp_srch_', $export_typo_retry);
    }
    $export_sql = "SELECT u.id, u.username, u.firstname, u.lastname, u.email, u.idnumber, u.phone1, u.phone2,
                          u.institution, u.department, u.auth, u.suspended, u.confirmed,
                          (SELECT COUNT(*) FROM {auth_devicelock_devices} d WHERE d.userid = u.id AND d.status = 'active') AS device_count
                   FROM {user} u
                   WHERE $export_where
                   ORDER BY u.lastname ASC, u.firstname ASC";
    $export_users = $DB->get_records_sql($export_sql, $export_params, 0, 10000);
    $export_identifiers = !empty($export_users) ? auth_devicelock_get_custom_profile_identifiers(array_keys($export_users)) : [];

    $filename = get_string('export_users_filename', 'auth_devicelock') . '_' . date('Y-m-d_His') . '.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: max-age=0, no-cache, no-store, must-revalidate');
    header('Pragma: no-cache');

    $out = fopen('php://output', 'w');
    // UTF-8 BOM so Excel opens the file with the correct encoding.
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, [
        get_string('export_col_order', 'auth_devicelock'),
        get_string('export_col_fullname', 'auth_devicelock'),
        get_string('export_col_username', 'auth_devicelock'),
        get_string('export_col_email', 'auth_devicelock'),
        get_string('export_col_auth', 'auth_devicelock'),
        get_string('export_col_devices', 'auth_devicelock'),
        get_string('export_col_maxdevices', 'auth_devicelock'),
        get_string('export_col_type', 'auth_devicelock'),
        get_string('export_col_suspended', 'auth_devicelock'),
        get_string('export_col_confirmed', 'auth_devicelock'),
        get_string('export_col_uni_id', 'auth_devicelock'),
        get_string('export_col_phone', 'auth_devicelock'),
        get_string('export_col_idnumber', 'auth_devicelock'),
        get_string('export_col_institution', 'auth_devicelock'),
        get_string('export_col_department', 'auth_devicelock'),
        get_string('security_score_label', 'auth_devicelock'),
    ]);

    // PERFORMANCE: batch-fetch all cached security scores in ONE query
    // instead of N per-row compute_security_score() calls (avoids 10 000
    // cache reads on a 10 000-row export).
    $export_score_cache = auth_devicelock_compute_security_scores_batch(array_keys($export_users));

    $rownum = 0;
    foreach ($export_users as $eu) {
        $rownum++;
        $ci = $export_identifiers[$eu->id] ?? ['uni_id' => '', 'phone' => ''];
        $uni_id = !empty($ci['uni_id']) ? $ci['uni_id'] : (!empty($eu->idnumber) ? $eu->idnumber : '');
        $phone  = !empty($ci['phone'])  ? $ci['phone']  : (!empty($eu->phone1) ? $eu->phone1 : (!empty($eu->phone2) ? $eu->phone2 : ''));
        $usertype = 'Student / User';
        if (is_siteadmin($eu->id)) {
            $usertype = 'Site Admin';
        } else {
            $eroles = $DB->get_records_sql("SELECT DISTINCT r.shortname FROM {role_assignments} ra JOIN {role} r ON ra.roleid = r.id WHERE ra.userid = ?", [$eu->id]);
            foreach ($eroles as $role) {
                if (in_array($role->shortname, ['teacher', 'editingteacher', 'manager'])) {
                    $usertype = 'Teacher / Manager';
                    break;
                }
            }
        }
        $maxdev = auth_devicelock_get_user_device_limit($eu->id);
        // Pull the score from the batched cache (no per-row query).
        $sc = $export_score_cache[$eu->id] ?? ['score' => 100, 'label' => get_string('security_score_high', 'auth_devicelock')];
        fputcsv($out, array_map('auth_devicelock_csv_cell', [
            $rownum,
            fullname($eu),
            $eu->username,
            $eu->email,
            $eu->auth,
            (int)$eu->device_count,
            $maxdev,
            $usertype,
            $eu->suspended ? 'Yes' : 'No',
            $eu->confirmed ? 'Yes' : 'No',
            $uni_id,
            $phone,
            $eu->idnumber,
            $eu->institution,
            $eu->department,
            $sc['score'] . ' (' . $sc['label'] . ')',
        ]));
    }
    fclose($out);
    die();
}

// Download a CSV TEMPLATE for the bulk-import flow (one header row + 2 examples).
if ($action === 'importuserstemplate') {
    require_sesskey();
    $filename = 'lockguard_import_template.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: max-age=0, no-cache, no-store, must-revalidate');
    header('Pragma: no-cache');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF"); // UTF-8 BOM for Excel.
    fputcsv($out, ['firstname', 'lastname', 'email', 'username', 'password', 'idnumber']);
    fputcsv($out, ['John', 'Doe', 'john.doe@example.com', 'johndoe', '', '1001']);
    fputcsv($out, ['Jane', 'Smith', 'jane.smith@example.com', 'janesmith', '', '1002']);
    fclose($out);
    die();
}

// Export the filtered Logs as a CSV download.
if ($action === 'exportlogscsv') {
    require_sesskey();
    if (!$DB->get_manager()->table_exists('auth_devicelock_logs')) {
        \core\notification::error(get_string('export_no_data', 'auth_devicelock'));
        redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'logs']));
    }

    $log_params = [];
    $log_where = "1=1";
    // Per-user audit export: when audit_userid is provided, restrict to that user.
    $audit_userid = optional_param('audit_userid', 0, PARAM_INT);
    if ($audit_userid > 0) {
        $log_where .= " AND l.userid = :ls_audit_uid";
        $log_params['ls_audit_uid'] = $audit_userid;
    }
    // Per-device audit export: when devicefp is provided (64-char hex), restrict to that device.
    $audit_devicefp = optional_param('devicefp', '', PARAM_RAW);
    $audit_devicefp = trim($audit_devicefp);
    if (strlen($audit_devicefp) === 64 && ctype_xdigit($audit_devicefp)) {
        $log_where .= " AND l.device_fingerprint = :ls_audit_fp";
        $log_params['ls_audit_fp'] = $audit_devicefp;
    }
    if ($log_search) {
        $log_where .= " AND (" . $DB->sql_like('l.action', ':ls_action', false) . " OR " . $DB->sql_like('l.ip_address', ':ls_ip', false) . ")";
        $escaped = $DB->sql_like_escape($log_search);
        $log_params['ls_action'] = '%' . $escaped . '%';
        $log_params['ls_ip'] = '%' . $escaped . '%';
    }
    if ($log_action_filter) {
        if ($log_action_filter === 'activity_all') {
            // Pseudo-filter: every user-activity event type at once.
            $log_where .= " AND " . $DB->sql_like('l.action', ':ls_actlike', true, true, false);
            $log_params['ls_actlike'] = 'activity%';
        } else {
            $log_where .= " AND l.action = :ls_filter";
            $log_params['ls_filter'] = $log_action_filter;
        }
    }
    $export_logs_sql = "SELECT l.id, l.userid, l.action, l.ip_address, l.user_agent, l.timestamp, l.details, l.device_fingerprint
                         FROM {auth_devicelock_logs} l
                         WHERE $log_where
                         ORDER BY l.timestamp DESC, l.id DESC";
    $export_logs = $DB->get_records_sql($export_logs_sql, $log_params, 0, 50000);

    $filename = get_string('export_logs_filename', 'auth_devicelock') . '_' . date('Y-m-d_His') . '.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: max-age=0, no-cache, no-store, must-revalidate');
    header('Pragma: no-cache');

    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, ['#', 'Time', 'User ID', 'User (Full Name)', 'Event / Action', 'IP Address', 'User Agent', 'Fingerprint', 'Details']);

    $usercache = [];
    foreach ($export_logs as $idx => $lg) {
        if (!isset($usercache[$lg->userid])) {
            $u_rec = $DB->get_record('user', ['id' => $lg->userid], 'id,firstname,lastname,username,deleted', IGNORE_MISSING);
            $usercache[$lg->userid] = $u_rec ? $u_rec : null;
        }
        $urec = $usercache[$lg->userid];
        $uname = $urec ? fullname($urec) . ' (@' . $urec->username . ($urec->deleted ? ' [deleted]' : '') . ')' : ('#' . $lg->userid);
        fputcsv($out, array_map('auth_devicelock_csv_cell', [
            $idx + 1,
            date('Y-m-d H:i:s', $lg->timestamp),
            $lg->userid,
            $uname,
            $lg->action,
            $lg->ip_address,
            $lg->user_agent,
            $lg->device_fingerprint ?? '',
            $lg->details,
        ]));
    }
    fclose($out);
    die();
}

// ============================================================
// Confirmation & Action Modals / Separate Sub-pages
// ============================================================

// Intercept for Purge User Confirmation
if ($action === 'purgeuser' && !$confirm && $userid) {
    echo $OUTPUT->header();
    $targetuser = $DB->get_record('user', ['id' => $userid]);
    
    $msg = '<div class="text-left">';
    $msg .= '  <h3 class="text-danger mb-3"><i class="fa fa-exclamation-triangle"></i> CONFIRM DEVICE RESET</h3>';
    $msg .= '  <p class="font-weight-bold">This action will immediately:</p>';
    $msg .= '  <ul class="mb-3">';
    $msg .= '    <li>DELETE ALL REGISTERED DEVICES from the database</li>';
    $msg .= '    <li>FORCE LOGOUT the user from ALL active sessions</li>';
    $msg .= '    <li>User will need to register a new device on the next login</li>';
    $msg .= '    <li>User will see "Device resets have been performed on this account." message</li>';
    $msg .= '  </ul>';
    $msg .= '  <p class="text-danger font-weight-bold">⚠️ This action cannot be undone!</p>';
    $msg .= '</div>';
    
    $redirect_to_viewuser = optional_param('redirect_to_viewuser', 0, PARAM_BOOL);
    $confirmurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'purgeuser', 'userid' => $userid, 'confirm' => 1, 'sesskey' => sesskey(), 'tab' => $tab, 'redirect_to_viewuser' => $redirect_to_viewuser]);
    $cancelurl = $redirect_to_viewuser ? new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid]) : new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => $tab]);
    echo $OUTPUT->confirm($msg, $confirmurl, $cancelurl);
    echo $OUTPUT->footer();
    exit;
}

// Intercept for Delete User Account Confirmation
if ($action === 'deleteuser' && !$confirm && $userid) {
    echo $OUTPUT->header();

    // Safety pre-checks (mirror the ones in the action handler) so we render a
    // friendly notice instead of a scary confirmation for accounts that can't
    // be deleted anyway.
    if ($userid == $USER->id) {
        \core\notification::error(get_string('deleteuser_self_error', 'auth_devicelock'));
        redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => $tab, 'user_search' => $user_search, 'userpage' => $userpage]));
    }
    if (isguestuser($userid)) {
        \core\notification::error(get_string('deleteuser_guest_error', 'auth_devicelock'));
        redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => $tab, 'user_search' => $user_search, 'userpage' => $userpage]));
    }
    $targetuser = $DB->get_record('user', ['id' => $userid]);
    if (!$targetuser) {
        \core\notification::error(get_string('deleteuser_notfound', 'auth_devicelock'));
        redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => $tab, 'user_search' => $user_search, 'userpage' => $userpage]));
    }
    if (is_siteadmin($userid)) {
        \core\notification::error(get_string('deleteuser_admin_error', 'auth_devicelock'));
        redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => $tab, 'user_search' => $user_search, 'userpage' => $userpage]));
    }

    // Build the bullet list of consequences from the pipe-separated lang string.
    $consequence_items = array_filter(array_map('trim', explode('|', get_string('deleteuser_confirm_list', 'auth_devicelock'))));
    $consequence_html = '';
    foreach ($consequence_items as $item) {
        $consequence_html .= '<li><i class="fa fa-times-circle text-danger mr-1"></i>' . $item . '</li>';
    }

    $msg = '<div class="text-left">';
    $msg .= '  <h3 class="text-danger mb-3"><i class="fa fa-trash"></i> ' . get_string('deleteuser_confirm_title', 'auth_devicelock') . '</h3>';
    $msg .= '  <p class="font-weight-bold">' . get_string('deleteuser_confirm_intro', 'auth_devicelock') . '</p>';
    $msg .= '  <table class="table table-sm table-bordered mb-3" style="max-width:480px;">';
    $msg .= '    <tr><th class="bg-light" style="width:120px;">' . get_string('deleteuser_confirm_name', 'auth_devicelock') . '</th><td class="font-weight-bold">' . s(fullname($targetuser)) . '</td></tr>';
    $msg .= '    <tr><th class="bg-light">' . get_string('deleteuser_confirm_username', 'auth_devicelock') . '</th><td class="font-monospace">' . s($targetuser->username) . '</td></tr>';
    $msg .= '    <tr><th class="bg-light">' . get_string('deleteuser_confirm_email', 'auth_devicelock') . '</th><td>' . s($targetuser->email) . '</td></tr>';
    $msg .= '  </table>';
    $msg .= '  <p class="font-weight-bold mb-1">' . get_string('deleteuser_confirm_will', 'auth_devicelock') . '</p>';
    $msg .= '  <ul class="mb-3">' . $consequence_html . '</ul>';
    $msg .= '  <div class="alert alert-danger mb-0"><i class="fa fa-exclamation-triangle"></i> <strong>' . get_string('deleteuser_confirm_warning', 'auth_devicelock') . '</strong></div>';
    $msg .= '</div>';

    $confirmurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'deleteuser', 'userid' => $userid, 'confirm' => 1, 'sesskey' => sesskey(), 'tab' => $tab, 'user_search' => $user_search, 'userpage' => $userpage]);
    $cancelurl = ($tab === 'nonplugin' || $tab === 'users')
        ? new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => $tab, 'user_search' => $user_search, 'userpage' => $userpage])
        : new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid, 'tab' => $tab]);
    echo $OUTPUT->confirm($msg, $confirmurl, $cancelurl);
    echo $OUTPUT->footer();
    exit;
}

// Intercept for BULK Delete Users Confirmation
// Receives selected_users[] via POST, partitions into deletable vs skipped
// (self/guest/admin), and renders a custom POST-form confirmation page.
if ($action === 'bulkdeleteusers' && !$confirm) {
    require_sesskey();
    $selected = optional_param_array('selected_users', [], PARAM_INT);
    $selected = array_values(array_unique(array_filter(array_map('intval', $selected), function ($x) {
        return $x > 2;
    })));

    $origin_tab = ($tab === 'nonplugin') ? 'nonplugin' : 'users';
    $cancelurl = new moodle_url('/auth/devicelock/admin_devices.php', [
        'tab' => $origin_tab, 'user_search' => $user_search, 'userpage' => $userpage,
    ]);

    if (empty($selected)) {
        \core\notification::error(get_string('bulk_delete_none_selected', 'auth_devicelock'));
        redirect($cancelurl);
    }

    // Partition: deletable vs skipped-for-safety.
    $deletable = [];
    $skipped = [];
    foreach ($selected as $sid) {
        if ($sid == $USER->id || isguestuser($sid) || is_siteadmin($sid)) {
            $skipped[] = $sid;
            continue;
        }
        $su = $DB->get_record('user', ['id' => $sid], '*', IGNORE_MISSING);
        if (!$su) {
            continue; // already gone — silently drop from the list
        }
        $deletable[] = $su;
    }

    if (empty($deletable)) {
        \core\notification::error(get_string('bulk_delete_none_valid', 'auth_devicelock'));
        redirect($cancelurl);
    }

    echo $OUTPUT->header();

    echo '<div class="card border-danger shadow mx-auto my-4" style="max-width: 820px; border-radius: 12px; overflow: hidden;">';
    echo '  <div class="card-header bg-danger text-white py-3"><h4 class="mb-0 text-white"><i class="fa fa-trash"></i> ' . get_string('bulk_delete_confirm_title', 'auth_devicelock') . '</h4></div>';
    echo '  <div class="card-body p-4">';

    echo '    <div class="alert alert-warning">';
    echo '      <i class="fa fa-exclamation-triangle"></i> ' . get_string('bulk_delete_confirm_intro', 'auth_devicelock', count($deletable));
    echo '    </div>';

    echo '    <table class="table table-sm table-bordered table-striped mb-3">';
    echo '      <thead class="thead-light"><tr><th>#</th><th>Full Name</th><th>Username</th><th>Email</th><th>Auth</th></tr></thead><tbody>';
    $i = 0;
    foreach ($deletable as $su) {
        $i++;
        echo '      <tr><td>' . $i . '</td><td class="font-weight-bold">' . s(fullname($su)) . '</td><td class="font-monospace">' . s($su->username) . '</td><td>' . s($su->email) . '</td><td>' . s($su->auth) . '</td></tr>';
    }
    echo '      </tbody></table>';

    if (!empty($skipped)) {
        $skipped_names = [];
        foreach ($skipped as $sid) {
            $su = $DB->get_record('user', ['id' => $sid], 'firstname,lastname,username', IGNORE_MISSING);
            $skipped_names[] = $su ? (fullname($su) . ' (@' . $su->username . ')') : ('#' . $sid);
        }
        echo '    <div class="alert alert-secondary"><strong><i class="fa fa-shield-alt"></i> ' . get_string('bulk_delete_skipped_label', 'auth_devicelock') . '</strong><br>' . implode(', ', array_map('s', $skipped_names)) . '</div>';
    }

    echo '    <div class="alert alert-danger mb-3"><i class="fa fa-exclamation-triangle"></i> <strong>' . get_string('bulk_delete_confirm_warning', 'auth_devicelock') . '</strong></div>';

    // POST form carrying every deletable id forward to confirm=1.
    $formurl = new moodle_url('/auth/devicelock/admin_devices.php');
    echo '    <form method="post" action="' . $formurl . '" onsubmit="return lgConfirmPhraseCheck(this);">';
    echo '      <input type="hidden" name="action" value="bulkdeleteusers">';
    echo '      <input type="hidden" name="confirm" value="1">';
    echo '      <input type="hidden" name="sesskey" value="' . sesskey() . '">';
    echo '      <input type="hidden" name="tab" value="' . s($origin_tab) . '">';
    echo '      <input type="hidden" name="user_search" value="' . s($user_search) . '">';
    echo '      <input type="hidden" name="userpage" value="' . (int)$userpage . '">';
    foreach ($deletable as $su) {
        echo '      <input type="hidden" name="selected_users[]" value="' . (int)$su->id . '">';
    }
    // Typed-confirmation-phrase guard: only required for batches > 50 users.
    if (count($deletable) > 50) {
        echo '      <div class="alert alert-warning"><i class="fa fa-key"></i> ' . get_string('confirm_phrase_required', 'auth_devicelock', count($deletable)) . '</div>';
        echo '      <div class="form-group row align-items-center mb-3">';
        echo '        <label class="col-sm-4 col-form-label font-weight-bold" for="confirm_phrase">' . get_string('confirm_phrase_label', 'auth_devicelock') . '</label>';
        echo '        <div class="col-sm-8"><input type="text" id="confirm_phrase" name="confirm_phrase" class="form-control text-monospace font-weight-bold" autocomplete="off" placeholder="DELETE" required></div>';
        echo '      </div>';
    }
    echo '      <div class="d-flex justify-content-between align-items-center">';
    echo '        <a href="' . $cancelurl . '" class="btn btn-secondary px-4"><i class="fa fa-times"></i> Cancel</a>';
    echo '        <button type="submit" class="btn btn-danger font-weight-bold px-4"><i class="fa fa-trash"></i> ' . get_string('bulk_delete_confirm_btn', 'auth_devicelock') . '</button>';
    echo '      </div>';
    echo '    </form>';

    echo '  </div>';
    echo '</div>';

    echo $OUTPUT->footer();
    exit;
}

// Intercept for Clear All Logs Confirmation
if ($action === 'clearlogs' && !$confirm) {
    require_sesskey();
    echo $OUTPUT->header();
    $msg = '<div class="text-left">';
    $msg .= '  <h3 class="text-danger mb-3"><i class="fa fa-eraser"></i> ' . get_string('clear_logs', 'auth_devicelock') . '</h3>';
    $msg .= '  <p class="font-weight-bold">' . get_string('clear_logs_confirm', 'auth_devicelock') . '</p>';
    $msg .= '</div>';
    $confirmurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'clearlogs', 'confirm' => 1, 'sesskey' => sesskey(), 'tab' => 'logs', 'log_search' => $log_search, 'log_action_filter' => $log_action_filter, 'logpage' => $logpage]);
    $cancelurl = new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'logs', 'log_search' => $log_search, 'log_action_filter' => $log_action_filter, 'logpage' => $logpage]);
    echo $OUTPUT->confirm($msg, $confirmurl, $cancelurl);
    echo $OUTPUT->footer();
    exit;
}

// Intercept for BULK Copy User Details (CSV) Confirmation.
// confirm=0 path: list the selected users + a strong password-reset warning,
// then a POST form carrying every id forward to the CSV-download step.
if ($action === 'bulkcopydetails' && !$confirm) {
    require_sesskey();
    $selected = optional_param_array('selected_users', [], PARAM_INT);
    $selected = array_values(array_unique(array_filter(array_map('intval', $selected), function ($x) {
        return $x > 2;
    })));

    $origin_tab = ($tab === 'nonplugin') ? 'nonplugin' : 'users';
    $cancelurl = new moodle_url('/auth/devicelock/admin_devices.php', [
        'tab' => $origin_tab, 'user_search' => $user_search, 'userpage' => $userpage,
    ]);

    if (empty($selected)) {
        \core\notification::error(get_string('bulk_copy_details_none', 'auth_devicelock'));
        redirect($cancelurl);
    }

    // Partition: copyable vs skipped-for-safety (self / guest / siteadmin).
    $copyable = [];
    $skipped = [];
    foreach ($selected as $sid) {
        $su = $DB->get_record('user', ['id' => $sid], 'id,firstname,lastname,username,email,auth', IGNORE_MISSING);
        if (!$su) {
            continue;
        }
        if (is_siteadmin($sid) || $sid == $USER->id || isguestuser($sid)) {
            $skipped[] = $su;
            continue;
        }
        $copyable[] = $su;
    }

    if (empty($copyable)) {
        \core\notification::error(get_string('bulk_copy_details_none', 'auth_devicelock'));
        redirect($cancelurl);
    }

    // If the batch exceeds the cap, show the admin how many will be processed.
    $copy_cap = 200;
    $capped_remaining = 0;
    if (count($copyable) > $copy_cap) {
        $capped_remaining = count($copyable) - $copy_cap;
    }

    echo $OUTPUT->header();

    echo '<div class="card border-success shadow mx-auto my-4" style="max-width: 820px; border-radius: 12px; overflow: hidden;">';
    echo '  <div class="card-header bg-success text-white py-3"><h4 class="mb-0 text-white"><i class="fa fa-clone"></i> ' . get_string('bulk_copy_details_title', 'auth_devicelock') . '</h4></div>';
    echo '  <div class="card-body p-4">';

    echo '    <div class="alert alert-info">';
    echo '      <i class="fa fa-info-circle"></i> ' . get_string('bulk_copy_details_intro', 'auth_devicelock');
    echo '    </div>';

    if ($capped_remaining > 0) {
        echo '    <div class="alert alert-warning"><i class="fa fa-exclamation-triangle"></i> ' . get_string('bulk_copy_details_capped', 'auth_devicelock', $copy_cap) . '</div>';
    }

    echo '    <table class="table table-sm table-bordered table-striped mb-3">';
    echo '      <thead class="thead-light"><tr><th>#</th><th>Full Name</th><th>Username</th><th>Email</th><th>Auth</th></tr></thead><tbody>';
    $i = 0;
    foreach ($copyable as $su) {
        $i++;
        echo '      <tr><td>' . $i . '</td><td class="font-weight-bold">' . s(fullname($su)) . '</td><td class="font-monospace">' . s($su->username) . '</td><td>' . s($su->email) . '</td><td>' . s($su->auth) . '</td></tr>';
    }
    echo '      </tbody></table>';

    if (!empty($skipped)) {
        echo '    <div class="alert alert-secondary"><strong><i class="fa fa-shield-alt"></i> ' . get_string('bulk_delete_skipped_label', 'auth_devicelock') . '</strong><br>' . implode(', ', array_map(function ($s) { return s(fullname($s) . ' (@' . $s->username . ')'); }, $skipped)) . '</div>';
    }

    echo '    <div class="alert alert-warning"><i class="fa fa-key"></i> <strong>' . get_string('bulk_copy_details_warning', 'auth_devicelock') . '</strong></div>';

    $formurl = new moodle_url('/auth/devicelock/admin_devices.php');
    echo '    <form method="post" action="' . $formurl . '" onsubmit="return lgConfirmPhraseCheck(this);">';
    echo '      <input type="hidden" name="action" value="bulkcopydetails">';
    echo '      <input type="hidden" name="confirm" value="1">';
    echo '      <input type="hidden" name="sesskey" value="' . sesskey() . '">';
    echo '      <input type="hidden" name="tab" value="' . s($origin_tab) . '">';
    echo '      <input type="hidden" name="user_search" value="' . s($user_search) . '">';
    echo '      <input type="hidden" name="userpage" value="' . (int)$userpage . '">';
    foreach ($copyable as $su) {
        echo '      <input type="hidden" name="selected_users[]" value="' . (int)$su->id . '">';
    }
    // Typed-confirmation-phrase guard: only required for batches > 50 users.
    if (count($copyable) > 50) {
        echo '      <div class="alert alert-warning"><i class="fa fa-key"></i> ' . get_string('confirm_phrase_required', 'auth_devicelock', count($copyable)) . '</div>';
        echo '      <div class="form-group row align-items-center mb-3">';
        echo '        <label class="col-sm-4 col-form-label font-weight-bold" for="confirm_phrase">' . get_string('confirm_phrase_label', 'auth_devicelock') . '</label>';
        echo '        <div class="col-sm-8"><input type="text" id="confirm_phrase" name="confirm_phrase" class="form-control text-monospace font-weight-bold" autocomplete="off" placeholder="DELETE" required></div>';
        echo '      </div>';
    }
    echo '      <div class="d-flex justify-content-between align-items-center">';
    echo '        <a href="' . $cancelurl . '" class="btn btn-secondary px-4"><i class="fa fa-times"></i> Cancel</a>';
    echo '        <button type="submit" class="btn btn-success font-weight-bold px-4"><i class="fa fa-download"></i> ' . get_string('bulk_copy_details', 'auth_devicelock') . '</button>';
    echo '      </div>';
    echo '    </form>';

    echo '  </div>';
    echo '</div>';

    echo $OUTPUT->footer();
    exit;
}

// ============================================================
// CSV IMPORT preview/confirmation page (action=importuserscsv, !confirm).
// Parses the uploaded CSV via Moodle's draftfile API, validates each row,
// shows a preview table, and posts the validated rows as JSON to confirm=1.
// ============================================================
if ($action === 'importuserscsv' && !$confirm) {
    require_sesskey();
    require_once($CFG->libdir . '/moodlelib.php');

    $backurl = new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']);

    // Dry-run flag propagates from the upload form through to the confirm step.
    $isdryrun = optional_param('dryrun', 0, PARAM_BOOL);

    // Retrieve the uploaded CSV: prefer a direct multipart upload
    // ($_FILES['importcsv_file_input']), fall back to a draftfile area, then
    // to a raw paste textarea.
    $csvtext = '';
    if (!empty($_FILES['importcsv_file_input']['tmp_name']) && is_uploaded_file($_FILES['importcsv_file_input']['tmp_name'])) {
        // SECURITY: validate the upload before reading it.
        $upname = $_FILES['importcsv_file_input']['name'] ?? '';
        $upsize = (int)($_FILES['importcsv_file_input']['size'] ?? 0);
        $uperr  = (int)($_FILES['importcsv_file_input']['error'] ?? UPLOAD_ERR_NO_FILE);
        $maxsize = 2 * 1024 * 1024; // 2 MB cap — plenty for 200 user rows.
        $ext = strtolower(pathinfo($upname, PATHINFO_EXTENSION));
        if ($uperr !== UPLOAD_ERR_OK) {
            \core\notification::error(get_string('import_users_none', 'auth_devicelock'));
            redirect($backurl);
        }
        if ($upsize > $maxsize) {
            \core\notification::error(get_string('import_users_file_too_big', 'auth_devicelock', '2 MB'));
            redirect($backurl);
        }
        if ($ext !== 'csv' && $ext !== 'txt') {
            \core\notification::error(get_string('import_users_file_badtype', 'auth_devicelock'));
            redirect($backurl);
        }
        $csvtext = file_get_contents($_FILES['importcsv_file_input']['tmp_name']);
    }
    if ($csvtext === '') {
        $draftid = optional_param('importcsv_file', 0, PARAM_INT);
        if (empty($draftid)) {
            $draftid = optional_param('importcsv_draftid', 0, PARAM_INT);
        }
        if (!empty($draftid)) {
            $fs = get_file_storage();
            $context = context_system::instance();
            $files = $fs->get_area_files($context->id, 'user', 'draft', $draftid, 'id', false);
            foreach ($files as $f) {
                $csvtext = $f->get_content();
                break;
            }
        }
    }
    if ($csvtext === '') {
        // Fallback: accept a raw paste.
        $csvtext = optional_param('importcsv_raw', '', PARAM_RAW);
    }

    $rows = [];
    if ($csvtext !== '') {
        // Strip UTF-8 BOM if present.
        if (substr($csvtext, 0, 3) === "\xEF\xBB\xBF") {
            $csvtext = substr($csvtext, 3);
        }
        $tmpname = tempnam(sys_get_temp_dir(), 'lgcsv_');
        file_put_contents($tmpname, $csvtext);
        $fh = fopen($tmpname, 'r');
        if ($fh) {
            $header = fgetcsv($fh);
            if ($header) {
                $header = array_map('strtolower', array_map('trim', $header));
                $hidx = array_flip($header);
                while (($line = fgetcsv($fh)) !== false) {
                    if (count($line) === 1 && $line[0] === '') {
                        continue; // skip blank lines
                    }
                    $row = [];
                    foreach (['firstname', 'lastname', 'email', 'username', 'password', 'idnumber'] as $col) {
                        $row[$col] = isset($hidx[$col]) ? ($line[$hidx[$col]] ?? '') : '';
                    }
                    $rows[] = $row;
                }
            }
            fclose($fh);
            @unlink($tmpname);
        }
    }

    echo $OUTPUT->header();

    echo '<div class="card border-info shadow mx-auto my-4" style="max-width: 920px; border-radius: 12px; overflow: hidden;">';
    $dryrun_badge = $isdryrun ? ' <span class="badge badge-warning badge-pill ml-2">' . get_string('import_users_dryrun_badge', 'auth_devicelock') . '</span>' : '';
    echo '  <div class="card-header bg-info text-white py-3 d-flex justify-content-between align-items-center"><h4 class="mb-0 text-white"><i class="fa fa-upload"></i> ' . get_string('import_users_title', 'auth_devicelock') . $dryrun_badge . '</h4></div>';
    echo '  <div class="card-body p-4">';

    echo '    <div class="alert alert-info"><i class="fa fa-info-circle"></i> ' . get_string('import_users_intro', 'auth_devicelock') . '</div>';

    if (empty($rows)) {
        echo '    <div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> ' . get_string('import_users_none', 'auth_devicelock') . '</div>';
        $tplurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'importuserstemplate', 'sesskey' => sesskey(), 'tab' => 'users']);
        echo '    <a href="' . $tplurl . '" class="btn btn-outline-info"><i class="fa fa-download"></i> ' . get_string('import_users_template', 'auth_devicelock') . '</a>';
        echo '    <a href="' . $backurl . '" class="btn btn-secondary ml-2"><i class="fa fa-arrow-left"></i> ' . get_string('backtolist', 'auth_devicelock') . '</a>';
        echo $OUTPUT->footer();
        exit;
    }

    // Validate every row (presence + email + uniqueness).
    $valid_rows = [];
    $invalid_rows = [];
    foreach ($rows as $r) {
        $missing = ($r['firstname'] === '' || $r['lastname'] === '' || $r['email'] === '' || $r['username'] === '');
        $bademail = !empty($r['email']) && !validate_email($r['email']);
        $dupuser = !empty($r['username']) && $DB->record_exists('user', ['username' => $r['username']]);
        $dupmail = !empty($r['email']) && $DB->record_exists('user', ['email' => $r['email']]);
        if ($missing || $bademail || $dupuser || $dupmail) {
            $r['_issue'] = $missing ? 'missing required field' : ($bademail ? 'invalid email' : ($dupuser ? 'duplicate username' : 'duplicate email'));
            $invalid_rows[] = $r;
        } else {
            $valid_rows[] = $r;
        }
    }

    // Cap preview + import at 200.
    $import_cap = 200;
    $capped_remaining = 0;
    if (count($valid_rows) > $import_cap) {
        $capped_remaining = count($valid_rows) - $import_cap;
        $valid_rows = array_slice($valid_rows, 0, $import_cap);
    }

    if ($capped_remaining > 0) {
        echo '    <div class="alert alert-warning"><i class="fa fa-exclamation-triangle"></i> ' . get_string('import_users_capped', 'auth_devicelock', $import_cap) . '</div>';
    }

    echo '    <p class="font-weight-bold mb-2"><i class="fa fa-check-circle text-success"></i> ' . count($valid_rows) . ' valid row(s) ready to import';
    if (count($invalid_rows) > 0) {
        echo ' &nbsp;<span class="text-danger"><i class="fa fa-times-circle"></i> ' . count($invalid_rows) . ' row(s) will be skipped</span>';
    }
    echo '    </p>';

    // Preview table (first 25 valid rows).
    $prev = new html_table();
    $prev->head = ['#', get_string('import_users_col_firstname', 'auth_devicelock'), get_string('import_users_col_lastname', 'auth_devicelock'), get_string('import_users_col_email', 'auth_devicelock'), get_string('import_users_col_username', 'auth_devicelock'), get_string('import_users_col_password', 'auth_devicelock'), get_string('import_users_col_idnumber', 'auth_devicelock')];
    $prev->attributes['class'] = 'table table-sm table-bordered table-striped mb-3';
    $i = 0;
    foreach ($valid_rows as $r) {
        $i++;
        if ($i > 25) {
            break;
        }
        $pw = $r['password'] !== '' ? '<span class="badge badge-warning">' . s($r['password']) . '</span>' : '<span class="text-muted small">(auto-generated)</span>';
        $prev->data[] = [$i, s($r['firstname']), s($r['lastname']), s($r['email']), s($r['username']), $pw, s($r['idnumber'])];
    }
    echo '<h6 class="text-muted"><i class="fa fa-eye"></i> ' . get_string('import_users_preview', 'auth_devicelock') . '</h6>';
    echo html_writer::table($prev);

    if (!empty($invalid_rows)) {
        echo '<h6 class="text-danger mt-3"><i class="fa fa-exclamation-triangle"></i> Skipped rows</h6>';
        $sk = new html_table();
        $sk->head = ['Row', get_string('import_users_col_username', 'auth_devicelock'), get_string('import_users_col_email', 'auth_devicelock'), 'Issue'];
        $sk->attributes['class'] = 'table table-sm table-bordered mb-3';
        $j = 0;
        foreach ($invalid_rows as $r) {
            $j++;
            $sk->data[] = [$j, s($r['username']), s($r['email']), s($r['_issue'])];
        }
        echo html_writer::table($sk);
    }

    // POST form carrying the validated rows as JSON.
    $formurl = new moodle_url('/auth/devicelock/admin_devices.php');
    echo '<form method="post" action="' . $formurl . '">';
    echo '  <input type="hidden" name="action" value="importuserscsv">';
    echo '  <input type="hidden" name="confirm" value="1">';
    echo '  <input type="hidden" name="sesskey" value="' . sesskey() . '">';
    echo '  <input type="hidden" name="tab" value="users">';
    if ($isdryrun) {
        echo '  <input type="hidden" name="dryrun" value="1">';
    }
    echo '  <input type="hidden" name="import_rows" value="' . s(json_encode($valid_rows, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) . '">';
    echo '  <div class="d-flex justify-content-between align-items-center">';
    echo '    <a href="' . $backurl . '" class="btn btn-secondary px-4"><i class="fa fa-times"></i> Cancel</a>';
    $submitlabel = $isdryrun ? get_string('import_users_dryrun_label', 'auth_devicelock') : get_string('import_users_submit', 'auth_devicelock');
    $submiticon  = $isdryrun ? 'fa-vial' : 'fa-upload';
    $submitcls   = $isdryrun ? 'btn-warning' : 'btn-info';
    echo '    <button type="submit" class="btn ' . $submitcls . ' font-weight-bold px-4" onclick="return confirm(\'' . s(get_string('import_users_confirm', 'auth_devicelock')) . '\');"><i class="fa ' . $submiticon . '"></i> ' . $submitlabel . '</button>';
    echo '  </div>';
    echo '</form>';

    echo '  </div>';
    echo '</div>';

    echo $OUTPUT->footer();
    exit;
}

// Intercept for Reset All Users Confirmation
if ($action === 'resetall' && !$confirm) {
    echo $OUTPUT->header();
    $msg = "<strong>Are you sure you want to reset ALL users' devices?</strong><br><br>";
    $msg .= "This action will delete all registered devices and force logout all users on all active sessions immediately.";
    
    $confirmurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'resetall', 'confirm' => 1, 'sesskey' => sesskey(), 'tab' => $tab]);
    $cancelurl = new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => $tab]);
    echo $OUTPUT->confirm($msg, $confirmurl, $cancelurl);
    echo $OUTPUT->footer();
    exit;
}

// Intercept for Change Auth Method for All Users Confirmation
if ($action === 'changeauthall' && !$confirm) {
    echo $OUTPUT->header();
    $authplugins = get_enabled_auth_plugins();
    
    echo '<div class="card border-warning shadow-sm mx-auto" style="max-width: 600px;">';
    echo '  <div class="card-header bg-warning text-white"><h4 class="mb-0 text-white"><i class="fa fa-random"></i> Change Auth Method for ALL Users</h4></div>';
    echo '  <div class="card-body">';
    echo '    <p>Select the new authentication method to apply to all active users. <strong>Warning: This will change the login method for all accounts immediately.</strong></p>';
    $formurl = new moodle_url('/auth/devicelock/admin_devices.php', ['sesskey' => sesskey()]);
    echo '    <form method="post" action="' . $formurl . '">';
    echo '      <input type="hidden" name="sesskey" value="' . sesskey() . '">';
    echo '      <input type="hidden" name="action" value="changeauthall">';
    echo '      <input type="hidden" name="confirm" value="1">';
    
    echo '      <div class="form-group">';
    echo '        <label for="newauth"><strong>Select Authentication Method</strong></label>';
    echo '        <select name="newauth" id="newauth" class="form-control">';
    foreach ($authplugins as $plugin) {
        $stringname = get_string('pluginname', 'auth_' . $plugin);
        if (strpos($stringname, '[[') !== false) {
            $stringname = ucfirst($plugin);
        }
        $selected = ($plugin === 'devicelock') ? 'selected' : '';
        echo '          <option value="' . s($plugin) . '" ' . $selected . '>' . s($stringname) . ' (' . s($plugin) . ')</option>';
    }
    echo '        </select>';
    echo '      </div>';
    
    echo '      <div class="mt-4">';
    echo '        <button type="submit" class="btn btn-warning text-white">Confirm Change All</button>';
    echo '        <a href="' . new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']) . '" class="btn btn-secondary ml-2">Cancel</a>';
    echo '      </div>';
    echo '    </form>';
    echo '  </div>';
    echo '</div>';
    
    echo $OUTPUT->footer();
    exit;
}

// Intercept for Change Auth Method Page (Single User)
if ($action === 'changeauth' && $userid) {
    echo $OUTPUT->header();
    $targetuser = $DB->get_record('user', ['id' => $userid]);
    $authplugins = get_enabled_auth_plugins();
    $redirect_to_viewuser = optional_param('redirect_to_viewuser', 0, PARAM_BOOL);
    
    echo '<div class="card border-warning shadow-sm mx-auto" style="max-width: 600px;">';
    echo '  <div class="card-header bg-warning text-white"><h4 class="mb-0 text-white"><i class="fa fa-random"></i> Change Auth Method: ' . s(fullname($targetuser)) . '</h4></div>';
    echo '  <div class="card-body">';
    echo '    <p>Select the new authentication method for this user:</p>';
    $formurl = new moodle_url('/auth/devicelock/admin_devices.php', ['sesskey' => sesskey()]);
    echo '    <form method="post" action="' . $formurl . '">';
    echo '      <input type="hidden" name="sesskey" value="' . sesskey() . '">';
    echo '      <input type="hidden" name="action" value="changeauth">';
    echo '      <input type="hidden" name="userid" value="' . $userid . '">';
    echo '      <input type="hidden" name="redirect_to_viewuser" value="' . $redirect_to_viewuser . '">';
    
    echo '      <div class="form-group">';
    echo '        <label for="newauth"><strong>New Authentication Method</strong></label>';
    echo '        <select name="newauth" id="newauth" class="form-control">';
    foreach ($authplugins as $plugin) {
        $stringname = get_string('pluginname', 'auth_' . $plugin);
        if (strpos($stringname, '[[') !== false) {
            $stringname = ucfirst($plugin);
        }
        $selected = ($targetuser->auth === $plugin) ? 'selected' : '';
        echo '          <option value="' . s($plugin) . '" ' . $selected . '>' . s($stringname) . ' (' . s($plugin) . ')</option>';
    }
    echo '        </select>';
    echo '      </div>';
    
    echo '      <div class="mt-4">';
    echo '        <button type="submit" class="btn btn-warning text-white">Save Changes</button>';
    $cancelurl = $redirect_to_viewuser ? new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid]) : new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']);
    echo '        <a href="' . $cancelurl . '" class="btn btn-secondary ml-2">Cancel</a>';
    echo '      </div>';
    echo '    </form>';
    echo '  </div>';
    echo '</div>';
    
    echo $OUTPUT->footer();
    exit;
}

// Intercept for Generate Temporary Password: length selection form
if ($action === 'generatetemppasswordform' && $userid) {
    echo $OUTPUT->header();
    $targetuser = $DB->get_record('user', ['id' => $userid]);
    $redirect_to_viewuser = optional_param('redirect_to_viewuser', 0, PARAM_BOOL);
    $sitemin = !empty($CFG->minpasswordlength) ? (int)$CFG->minpasswordlength : 8;

    if (!$targetuser) {
        \core\notification::error(get_string('error'));
        redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']));
    }

    echo '<div class="card border-info shadow-sm" style="max-width: 600px; margin: 0 auto;">';
    echo '<div class="card-header bg-info text-white"><h4 class="mb-0 text-white"><i class="fa fa-key"></i> ' . get_string('generate_temp_password', 'auth_devicelock') . ': ' . s(fullname($targetuser)) . '</h4></div>';
    echo '<div class="card-body">';

    echo '<form method="post" action="' . $baseurl . '">';
    echo '<input type="hidden" name="sesskey" value="' . sesskey() . '">';
    echo '<input type="hidden" name="action" value="generatetemppassword">';
    echo '<input type="hidden" name="userid" value="' . $userid . '">';
    echo '<input type="hidden" name="redirect_to_viewuser" value="' . $redirect_to_viewuser . '">';

    echo '<div class="form-group">';
    echo '<label for="pwlength"><strong>Password length</strong></label>';
    echo '<input type="number" name="pwlength" id="pwlength" class="form-control" style="max-width: 150px;" min="' . $sitemin . '" max="64" value="12">';
    echo '<small class="form-text text-muted">Between ' . $sitemin . ' and 64 characters. The user will be forced to change it on next login, as usual.</small>';
    echo '</div>';

    echo '<div class="mt-4">';
    echo '<button type="submit" class="btn btn-info text-white"><i class="fa fa-key"></i> Generate</button>';
    $cancelurl = $redirect_to_viewuser ? new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid]) : $baseurl;
    echo '<a href="' . $cancelurl . '" class="btn btn-secondary ml-2">Cancel</a>';
    echo '</div>';
    echo '</form>';
    echo '</div></div>';
    echo $OUTPUT->footer();
    exit;
}

// ============================================================
// Change Score: manual score management form (v3.5.0).
// Increase / decrease / set / reset the persistent security score,
// and optionally give this user their own regain rate instead of
// the global one.
// ============================================================
if ($action === 'changescoreform' && $userid) {
    echo $OUTPUT->header();
    $targetuser = $DB->get_record('user', ['id' => $userid]);
    $redirect_to_viewuser = optional_param('redirect_to_viewuser', 0, PARAM_BOOL);

    if (!$targetuser) {
        \core\notification::error(get_string('error'));
        redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']));
    }

    $scorerow = auth_devicelock_score_get($userid);
    $sb = auth_devicelock_security_score_band((int)$scorerow->score);
    list($r_amount, $r_interval, $r_custom) = auth_devicelock_score_regain_settings_for($scorerow);
    $nextin = auth_devicelock_score_next_regain_in($scorerow);

    $sc_colormap = ['high' => 'success', 'good' => 'primary', 'fair' => 'warning', 'poor' => 'danger', 'critical' => 'dark'];
    $sc_barcolor = ['high' => '#16a34a', 'good' => '#2563eb', 'fair' => '#f59e0b', 'poor' => '#dc2626', 'critical' => '#1f2937'];
    $sc_badge = $sc_colormap[$sb['band']] ?? 'secondary';
    $sc_bar = $sc_barcolor[$sb['band']] ?? '#6c757d';

    // Custom-regain fields are pre-filled with the CURRENT custom values
    // when a custom setting exists, otherwise with the global ones.
    $c_amount = !empty($scorerow->custom_regain) ? (int)$scorerow->regain_amount : $r_amount;
    $c_interval = !empty($scorerow->custom_regain) ? (int)$scorerow->regain_interval : $r_interval;
    $c_number = 1;
    $c_unit = 'days';
    foreach (['months' => 2592000, 'weeks' => 604800, 'days' => 86400, 'hours' => 3600, 'minutes' => 60, 'seconds' => 1] as $cu => $cs) {
        if ($c_interval > 0 && $c_interval % $cs === 0) {
            $c_number = (int)($c_interval / $cs);
            $c_unit = $cu;
            break;
        }
    }

    echo '<div class="card border-primary shadow-sm" style="max-width: 680px; margin: 0 auto;">';
    echo '<div class="card-header bg-primary text-white"><h4 class="mb-0 text-white"><i class="fa fa-tachometer"></i> ' . get_string('score_change_title', 'auth_devicelock') . ': ' . s(fullname($targetuser)) . '</h4></div>';
    echo '<div class="card-body">';

    // Current score summary.
    echo '<div class="text-center mb-4">';
    echo '  <span class="badge badge-' . $sc_badge . ' px-3 py-2" style="font-size:1.15rem; min-width:120px;"><i class="fa fa-shield"></i> ' . (int)$scorerow->score . '% &middot; ' . s($sb['label']) . '</span>';
    echo '  <div class="progress mt-2" style="height:10px; max-width:420px; margin:0 auto;" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' . (int)$scorerow->score . '" aria-label="' . s(get_string('security_score_label', 'auth_devicelock')) . '">';
    echo '    <div class="progress-bar" style="width:' . (int)$scorerow->score . '%; background:' . $sc_bar . ';"></div>';
    echo '  </div>';
    echo '  <div class="small text-muted mt-2">';
    echo      get_string('score_stats_violations', 'auth_devicelock') . ': <strong>' . (int)$scorerow->violation_count . '</strong>';
    echo ' &middot; ' . get_string('score_stats_last_violation', 'auth_devicelock') . ': <strong>' . (!empty($scorerow->last_violation) ? userdate((int)$scorerow->last_violation, get_string('strftimedatetimeshort', 'langconfig')) : get_string('score_stats_never', 'auth_devicelock')) . '</strong>';
    echo ' &middot; ' . get_string('score_stats_regain', 'auth_devicelock') . ': <strong>+' . (int)$r_amount . ' / ' . auth_devicelock_score_format_interval($r_interval) . '</strong>';
    echo ' <span class="badge badge-' . ($r_custom ? 'info' : 'light border text-muted') . '">' . ($r_custom ? get_string('score_stats_custom', 'auth_devicelock') : get_string('score_stats_global', 'auth_devicelock')) . '</span>';
    if ($nextin === 0) {
        echo ' &middot; <span class="text-success"><i class="fa fa-check-circle"></i> ' . get_string('score_next_due', 'auth_devicelock') . '</span>';
    } else if ($nextin > 0) {
        echo ' &middot; ' . get_string('score_next_in', 'auth_devicelock', auth_devicelock_score_format_interval($nextin));
    }
    echo '  </div>';
    echo '</div>';

    echo '<form method="post" action="' . $baseurl . '">';
    echo '<input type="hidden" name="sesskey" value="' . sesskey() . '">';
    echo '<input type="hidden" name="action" value="changescore">';
    echo '<input type="hidden" name="userid" value="' . $userid . '">';
    echo '<input type="hidden" name="redirect_to_viewuser" value="' . $redirect_to_viewuser . '">';

    // Operation choice.
    echo '<div class="form-group">';
    echo '  <label class="d-block"><strong>' . get_string('score_op', 'auth_devicelock') . '</strong></label>';
    $ops = [
        'increase' => get_string('score_op_increase', 'auth_devicelock'),
        'decrease' => get_string('score_op_decrease', 'auth_devicelock'),
        'set'      => get_string('score_op_set', 'auth_devicelock'),
        'reset'    => get_string('score_op_reset', 'auth_devicelock'),
    ];
    $opchecked = 'increase';
    foreach ($ops as $opkey => $oplabel) {
        echo '  <div class="form-check form-check-inline">';
        echo '    <input class="form-check-input" type="radio" name="score_op" id="score_op_' . $opkey . '" value="' . $opkey . '"' . ($opchecked === $opkey ? ' checked' : '') . ' onchange="lgScoreOpUpdate();">';
        echo '    <label class="form-check-label" for="score_op_' . $opkey . '">' . $oplabel . '</label>';
        echo '  </div>';
    }
    echo '</div>';

    // Amount.
    echo '<div class="form-group">';
    echo '  <label for="score_amount"><strong id="score_amount_label">' . get_string('score_amount', 'auth_devicelock') . '</strong></label>';
    echo '  <input type="number" name="score_amount" id="score_amount" class="form-control" style="max-width: 150px;" min="1" max="100" value="5" required>';
    echo '  <small class="form-text text-muted">' . get_string('score_amount_hint', 'auth_devicelock') . '</small>';
    echo '</div>';

    // Reason.
    echo '<div class="form-group">';
    echo '  <label for="score_reason"><strong>' . get_string('score_reason', 'auth_devicelock') . '</strong></label>';
    echo '  <input type="text" name="score_reason" id="score_reason" class="form-control" maxlength="255" placeholder="' . s(get_string('score_reason_hint', 'auth_devicelock')) . '">';
    echo '  <small class="form-text text-muted">' . get_string('score_decrease_note', 'auth_devicelock') . '</small>';
    echo '</div>';

    echo '<hr>';

    // Custom regain settings for this user.
    echo '<div class="form-group">';
    echo '  <div class="form-check">';
    echo '    <input class="form-check-input" type="checkbox" name="score_use_custom" id="score_use_custom" value="1"' . (!empty($scorerow->custom_regain) ? ' checked' : '') . ' onchange="lgScoreCustomToggle();">';
    echo '    <label class="form-check-label" for="score_use_custom"><strong>' . get_string('score_custom_regain', 'auth_devicelock') . '</strong></label>';
    echo '  </div>';
    echo '  <small class="form-text text-muted mb-2">' . get_string('score_custom_regain_desc', 'auth_devicelock') . '</small>';
    echo '  <div id="lg_custom_regain_box" class="border rounded p-3 bg-light"' . (empty($scorerow->custom_regain) ? ' style="display:none;"' : '') . '>';
    echo '    <div class="row">';
    echo '      <div class="col-sm-4 mb-2">';
    echo '        <label for="score_custom_amount" class="small">' . get_string('score_regain_amount_lbl', 'auth_devicelock') . '</label>';
    echo '        <input type="number" name="score_custom_amount" id="score_custom_amount" class="form-control" min="1" max="100" value="' . (int)$c_amount . '">';
    echo '      </div>';
    echo '      <div class="col-sm-4 mb-2">';
    echo '        <label for="score_custom_number" class="small">' . get_string('score_regain_every_lbl', 'auth_devicelock') . '</label>';
    echo '        <input type="number" name="score_custom_number" id="score_custom_number" class="form-control" min="1" max="100000" value="' . (int)$c_number . '">';
    echo '      </div>';
    echo '      <div class="col-sm-4 mb-2">';
    echo '        <label for="score_custom_unit" class="small">&nbsp;</label>';
    echo '        <select name="score_custom_unit" id="score_custom_unit" class="form-control">';
    foreach (['seconds' => get_string('score_unit_seconds', 'auth_devicelock'), 'minutes' => get_string('score_unit_minutes', 'auth_devicelock'), 'hours' => get_string('score_unit_hours', 'auth_devicelock'), 'days' => get_string('score_unit_days', 'auth_devicelock'), 'weeks' => get_string('score_unit_weeks', 'auth_devicelock'), 'months' => get_string('score_unit_months', 'auth_devicelock')] as $cuk => $cul) {
        echo '          <option value="' . $cuk . '"' . ($c_unit === $cuk ? ' selected' : '') . '>' . $cul . '</option>';
    }
    echo '        </select>';
    echo '      </div>';
    echo '    </div>';
    echo '    <small class="form-text text-muted">' . get_string('score_custom_remove_hint', 'auth_devicelock') . '</small>';
    echo '  </div>';
    echo '</div>';

    echo '<div class="mt-4">';
    echo '  <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> ' . get_string('score_save', 'auth_devicelock') . '</button>';
    $cancelurl = $redirect_to_viewuser ? new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid]) : $baseurl;
    echo '  <a href="' . $cancelurl . '" class="btn btn-secondary ml-2">' . get_string('cancel', 'moodle') . '</a>';
    echo '</div>';
    echo '</form>';

    // Live behaviour: hide/disable the amount box for "reset", relabel it
    // for "set", and toggle the custom-regain box.
    echo '<script>
    function lgScoreOpUpdate() {
        var checked = document.querySelector(\'input[name="score_op"]:checked\');
        var amt = document.getElementById(\'score_amount\');
        var lbl = document.getElementById(\'score_amount_label\');
        if (!checked || !amt || !lbl) { return; }
        if (checked.value === \'reset\') {
            amt.disabled = true;
            amt.removeAttribute(\'required\');
            amt.value = 100;
            lbl.textContent = ' . json_encode(get_string('score_op_reset', 'auth_devicelock')) . ';
        } else if (checked.value === \'set\') {
            amt.disabled = false;
            amt.setAttribute(\'required\', \'required\');
            amt.min = 0;
            amt.max = 100;
            lbl.textContent = ' . json_encode(get_string('score_amount_set_lbl', 'auth_devicelock')) . ';
        } else {
            amt.disabled = false;
            amt.setAttribute(\'required\', \'required\');
            amt.min = 1;
            amt.max = 100;
            lbl.textContent = ' . json_encode(get_string('score_amount', 'auth_devicelock')) . ';
        }
    }
    function lgScoreCustomToggle() {
        var cb = document.getElementById(\'score_use_custom\');
        var box = document.getElementById(\'lg_custom_regain_box\');
        if (cb && box) { box.style.display = cb.checked ? \'\' : \'none\'; }
    }
    lgScoreOpUpdate();
    lgScoreCustomToggle();
    </script>';

    echo '</div></div>';
    echo $OUTPUT->footer();
    exit;
}

// ============================================================
// Change Course form (single user): enrol into / un-enroll from
// courses. Current enrolments are pre-checked with their duration
// prefilled; saving re-syncs the user's whole enrolment list.
// ============================================================
if ($action === 'changecourseform' && $userid) {
    echo $OUTPUT->header();
    $targetuser = $DB->get_record('user', ['id' => $userid]);

    if (!$targetuser) {
        \core\notification::error(get_string('usernotfound', 'auth_devicelock'));
        redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']));
    }

    // Current enrolments (any plugin) + the full course + role universes.
    $cccurrent = auth_devicelock_get_user_course_enrolments($userid);
    $allcourses = $DB->get_records_sql("
        SELECT c.id, c.fullname, c.shortname, c.visible, cc.name AS catname
          FROM {course} c
          JOIN {course_categories} cc ON cc.id = c.category
         WHERE c.id > 1
      ORDER BY cc.sortorder, c.sortorder");
    $allroles = $DB->get_records('role', null, 'sortorder ASC', 'id, name, shortname');
    $studentrole = $DB->get_record('role', ['shortname' => 'student'], 'id', IGNORE_MISSING);
    $defaultroleid = $studentrole ? (int)$studentrole->id : 0;

    echo '<div class="card border-info shadow mx-auto my-4" style="max-width: 860px; border-radius: 12px; overflow: hidden;">';
    echo '  <div class="card-header bg-info text-white py-3"><h5 class="mb-0 text-white"><i class="fa fa-graduation-cap mr-2"></i> ' . get_string('change_course_title', 'auth_devicelock') . ': ' . s(fullname($targetuser)) . '</h5></div>';
    echo '  <div class="card-body p-4">';
    echo '    <div class="alert alert-info small">' . get_string('change_course_intro', 'auth_devicelock') . '</div>';
    $formurl = new moodle_url('/auth/devicelock/admin_devices.php');
    echo '    <form method="post" action="' . $formurl . '" id="lg-changecourse-form">';
    echo '      <input type="hidden" name="action" value="changecourse">';
    echo '      <input type="hidden" name="sesskey" value="' . sesskey() . '">';
    echo '      <input type="hidden" name="userid" value="' . (int)$userid . '">';
    echo '      <input type="hidden" name="tab" value="' . s($tab) . '">';
    echo '      <input type="hidden" name="user_search" value="' . s($user_search) . '">';
    echo '      <input type="hidden" name="userpage" value="' . (int)$userpage . '">';

    // Role used for enrolment (default: Student).
    echo '      <div class="form-group">';
    echo '        <label class="font-weight-bold" for="cc_role">' . get_string('change_course_role', 'auth_devicelock') . '</label>';
    echo '        <select name="cc_role" id="cc_role" class="form-control" style="max-width:320px;">';
    foreach ($allroles as $role) {
        $rname = !empty($role->name) ? $role->name : ucfirst($role->shortname);
        $sel = ((int)$role->id === $defaultroleid) ? ' selected' : '';
        echo '          <option value="' . (int)$role->id . '"' . $sel . '>' . s($rname) . ' (' . s($role->shortname) . ')</option>';
    }
    echo '        </select>';
    echo '        <small class="form-text text-muted">' . get_string('change_course_role_hint', 'auth_devicelock') . '</small>';
    echo '      </div>';

    // Course list: current enrolments pre-checked, per-course days.
    echo '      <div class="form-group mt-2">';
    echo '        <label class="font-weight-bold">' . get_string('enrol_courses_label', 'auth_devicelock') . '</label>';
    echo '        <div class="small text-muted mb-1">' . get_string('change_course_days_hint', 'auth_devicelock') . '</div>';
    if (!empty($allcourses)) {
        echo '        <input type="text" class="form-control form-control-sm mb-2" placeholder="' . s(get_string('enrol_search_courses', 'auth_devicelock')) . '" onkeyup="lgFilterCcCourseList(this.value)">';
        echo '        <div class="form-check mb-2"><label class="form-check-label"><input type="checkbox" class="form-check-input mr-2" onclick="lgToggleAllCcCourses(this.checked)"> <span class="font-weight-bold">' . s(get_string('enrol_select_all', 'auth_devicelock')) . '</span></label></div>';
        echo '        <div id="cc-course-list" class="border rounded p-2 mb-2" style="max-height:320px; overflow-y:auto;">';
        // Column header row (Course / Days).
        echo '          <div class="d-flex small text-muted font-weight-bold border-bottom pb-1 mb-1">';
        echo '            <div class="flex-grow-1">' . s(get_string('change_course_course_col', 'auth_devicelock'))
            . ' <span class="badge badge-info" style="font-size:70%;">' . s(get_string('change_course_enrolled_log', 'auth_devicelock')) . '</span>'
            . ' <span class="badge badge-secondary" style="font-size:70%;">' . s(get_string('change_course_unenrolled_log', 'auth_devicelock')) . '</span></div>';
        echo '            <div style="min-width:140px; text-align:right;">' . s(get_string('change_course_days_col', 'auth_devicelock')) . '</div>';
        echo '          </div>';
        foreach ($allcourses as $course) {
            $cid = (int)$course->id;
            $isenrolled = isset($cccurrent[$cid]);
            // Prefill the duration with the enrolment's current length
            // (0 when open-ended or not enrolled).
            $prefdays = 0;
            if ($isenrolled && !empty($cccurrent[$cid]->timeend)) {
                $prefdays = (int)round(((int)$cccurrent[$cid]->timeend - (int)$cccurrent[$cid]->timestart) / 86400);
            }
            $csearch = s($course->fullname . ' ' . $course->shortname . ' ' . $course->catname);
            echo '          <div class="d-flex align-items-center py-1" data-search="' . $csearch . '">';
            echo '            <div class="form-check mb-0 flex-grow-1">';
            echo '              <label class="form-check-label">';
            echo '                <input type="checkbox" name="cc_courses[]" value="' . $cid . '" class="form-check-input mr-2"' . ($isenrolled ? ' checked' : '') . '> '
                . format_string($course->fullname) . ' <small class="text-muted">(' . s($course->shortname) . ')</small>'
                . ($course->visible ? '' : ' <span class="badge badge-warning">' . s(get_string('enrol_course_hidden', 'auth_devicelock')) . '</span>')
                . ($isenrolled ? ' <span class="badge badge-info" style="font-size:70%;">' . s(get_string('change_course_enrolled_log', 'auth_devicelock')) . '</span>' : '');
            echo '              </label>';
            echo '            </div>';
            echo '            <div class="d-flex align-items-center">';
            echo '              <input type="number" name="cc_days[' . $cid . ']" value="' . $prefdays . '" min="0" max="3650" class="form-control form-control-sm" style="max-width:110px;" title="' . s(get_string('change_course_days_hint', 'auth_devicelock')) . '">';
            echo '              <small class="text-muted ml-1">' . s(get_string('change_course_days_col', 'auth_devicelock')) . '</small>';
            echo '            </div>';
            echo '          </div>';
        }
        echo '        </div>';
    } else {
        echo '        <div class="alert alert-secondary small mb-0">' . s(get_string('change_course_none', 'auth_devicelock')) . '</div>';
    }
    echo '      </div>';
    echo '      <div class="d-flex justify-content-between mt-3">';
    echo '        <a href="' . $baseurl . '" class="btn btn-secondary px-4"><i class="fa fa-times"></i> ' . get_string('cancel', 'moodle') . '</a>';
    echo '        <button type="submit" class="btn btn-info px-4"><i class="fa fa-graduation-cap"></i> ' . get_string('change_course_save', 'auth_devicelock') . '</button>';
    echo '      </div>';
    echo '    </form>';
    echo '  </div>';
    echo '</div>';
    // Self-contained copies of the course-list helpers (scoped to this
    // page's list id, so this form never depends on another page's script).
    echo '<script>' . "\n";
    echo <<<'EOJS'
function lgFilterCcCourseList(query) {
    var list = document.getElementById('cc-course-list');
    if (!list) { return; }
    query = (query || '').toLowerCase();
    var items = list.querySelectorAll('[data-search]');
    for (var k = 0; k < items.length; k++) {
        var hay = items[k].getAttribute('data-search') || '';
        items[k].style.display = (hay.toLowerCase().indexOf(query) !== -1) ? '' : 'none';
    }
}
function lgToggleAllCcCourses(checked) {
    var list = document.getElementById('cc-course-list');
    if (!list) { return; }
    var boxes = list.querySelectorAll('input[type="checkbox"]');
    for (var k = 0; k < boxes.length; k++) { boxes[k].checked = checked; }
}
EOJS;
    echo '</script>';
    echo $OUTPUT->footer();
    exit;
}

// ============================================================
// Change Role form (single user): site-level (system) roles. The
// roles the user already holds at system level are pre-checked.
// ============================================================
if ($action === 'changeroleform' && $userid) {
    echo $OUTPUT->header();
    $targetuser = $DB->get_record('user', ['id' => $userid]);

    if (!$targetuser) {
        \core\notification::error(get_string('usernotfound', 'auth_devicelock'));
        redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']));
    }

    $syscontext = context_system::instance();
    $assignednow = $DB->get_records('role_assignments', ['userid' => $userid, 'contextid' => $syscontext->id], '', 'roleid');
    $allroles = $DB->get_records('role', null, 'sortorder ASC', 'id, name, shortname');
    // Manageable role universe (guest/user are never manageable).
    $manageableroles = [];
    foreach ($allroles as $role) {
        if ($role->shortname === 'guest' || $role->shortname === 'user') {
            continue;
        }
        $manageableroles[] = $role;
    }

    echo '<div class="card border-primary shadow mx-auto my-4" style="max-width: 720px; border-radius: 12px; overflow: hidden;">';
    echo '  <div class="card-header bg-primary text-white py-3"><h5 class="mb-0 text-white"><i class="fa fa-user-tag mr-2"></i> ' . get_string('change_role_title', 'auth_devicelock') . ': ' . s(fullname($targetuser)) . '</h5></div>';
    echo '  <div class="card-body p-4">';
    echo '    <div class="alert alert-info small">' . get_string('change_role_intro', 'auth_devicelock') . '</div>';
    $formurl = new moodle_url('/auth/devicelock/admin_devices.php');
    echo '    <form method="post" action="' . $formurl . '">';
    echo '      <input type="hidden" name="action" value="changerole">';
    echo '      <input type="hidden" name="sesskey" value="' . sesskey() . '">';
    echo '      <input type="hidden" name="userid" value="' . (int)$userid . '">';
    echo '      <input type="hidden" name="tab" value="' . s($tab) . '">';
    echo '      <input type="hidden" name="user_search" value="' . s($user_search) . '">';
    echo '      <input type="hidden" name="userpage" value="' . (int)$userpage . '">';

    if (!empty($manageableroles)) {
        echo '      <div class="form-group">';
        echo '        <label class="font-weight-bold">' . get_string('change_role', 'auth_devicelock') . '</label>';
        echo '        <div class="border rounded p-2" style="max-height:300px; overflow-y:auto;">';
        foreach ($manageableroles as $role) {
            $rname = !empty($role->name) ? $role->name : ucfirst($role->shortname);
            $isassigned = isset($assignednow[(int)$role->id]);
            echo '          <div class="form-check">';
            echo '            <label class="form-check-label"><input type="checkbox" name="cr_roles[]" value="' . (int)$role->id . '" class="form-check-input mr-2"' . ($isassigned ? ' checked' : '') . '> ' . s($rname) . ' <small class="text-muted">(' . s($role->shortname) . ')</small></label>';
            echo '          </div>';
        }
        echo '        </div>';
        echo '      </div>';
    } else {
        echo '      <div class="alert alert-secondary small mb-0">' . s(get_string('change_role_none', 'auth_devicelock')) . '</div>';
    }
    echo '      <div class="d-flex justify-content-between mt-3">';
    echo '        <a href="' . $baseurl . '" class="btn btn-secondary px-4"><i class="fa fa-times"></i> ' . get_string('cancel', 'moodle') . '</a>';
    echo '        <button type="submit" class="btn btn-primary px-4"><i class="fa fa-user-tag"></i> ' . get_string('change_role_save', 'auth_devicelock') . '</button>';
    echo '      </div>';
    echo '    </form>';
    echo '  </div>';
    echo '</div>';
    echo $OUTPUT->footer();
    exit;
}

// Intercept for Generate Temporary Password Card
if ($action === 'generatetemppassword' && $userid) {
    require_sesskey();
    echo $OUTPUT->header();
    $targetuser = $DB->get_record('user', ['id' => $userid]);
    $redirect_to_viewuser = optional_param('redirect_to_viewuser', 0, PARAM_BOOL);
    
    if (!$targetuser) {
        \core\notification::error(get_string('error'));
        $cancelurl = new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']);
        redirect($cancelurl);
    }
    
    // 1. Generate clean, easy-to-read temporary password that complies with site password policy
    $pwlength = optional_param('pwlength', 12, PARAM_INT);
    $temppassword = auth_devicelock_generate_temporary_password($targetuser, $pwlength);
    
    // 2. Set password for user in Moodle internal storage
    update_internal_user_password($targetuser, $temppassword);
    
    // 3. Mark for forced password change and temporary password mode
    set_user_preference('auth_forcepasswordchange', 1, $targetuser->id);
    set_user_preference('auth_devicelock_temp_pass', 1, $targetuser->id);
    
    // 4. Log the audit event with admin identity
    device_manager::log_action($targetuser->id, 'system', 'generate_temporary_password', [
        'admin_user' => $USER->id,
        'admin_email' => !empty($USER->email) ? $USER->email : '',
        'admin_name' => fullname($USER),
        'pwlength' => $pwlength,
        'timestamp' => time(),
        'ip' => getremoteaddr()
    ]);
    
    $returnurl = $redirect_to_viewuser ? 
        new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid]) : 
        new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']);
    
    echo '
    <div class="card border-info shadow mx-auto my-4" style="max-width: 620px; border-radius: 12px; overflow: hidden;">
        <div class="card-header bg-info text-white py-3 d-flex align-items-center justify-content-between">
            <h5 class="mb-0 text-white font-weight-bold"><i class="fa fa-key mr-2"></i> ' . get_string('temppassword_card_title', 'auth_devicelock') . '</h5>
            <span class="badge badge-light text-info font-weight-bold"><i class="fa fa-shield"></i> Single-Use Login</span>
        </div>
        <div class="card-body p-4">
            <div class="alert alert-success d-flex align-items-center mb-3">
                <i class="fa fa-check-circle fa-2x mr-3 text-success"></i>
                <div>
                    <h6 class="mb-1 font-weight-bold">' . get_string('temppassword_generated_for', 'auth_devicelock', s(fullname($targetuser))) . '</h6>
                    <span class="text-muted small">Username: <strong>' . s($targetuser->username) . '</strong> &bull; Email: <strong>' . s($targetuser->email) . '</strong></span>
                </div>
            </div>

            <p class="mb-2 font-weight-bold text-dark"><i class="fa fa-lock text-primary"></i> Temporary Password (Single Login Only):</p>
            
            <div class="d-flex align-items-center justify-content-between p-3 mb-3 bg-light border rounded" style="border: 2px dashed #0284c7 !important;">
                <span id="temp_password_val" class="h3 font-weight-bold text-monospace mb-0 text-primary" style="letter-spacing: 2px;">' . s($temppassword) . '</span>
                <button type="button" id="copy_btn" class="btn btn-primary font-weight-bold px-3 py-2" onclick="copyTempPassword(this);">
                    <i class="fa fa-clone"></i> ' . get_string('copy_password', 'auth_devicelock') . '
                </button>
            </div>

            <div class="card bg-light border-0 p-3 mb-3" style="border-left: 4px solid #0284c7 !important;">
                <h6 class="font-weight-bold text-dark mb-2"><i class="fa fa-info-circle text-info"></i> How it works:</h6>
                <ul class="small text-muted mb-0 pl-3">
                    <li class="mb-1">Copy this temporary password and securely send it to the user.</li>
                    <li class="mb-1">The user logs in with this temporary password on their authorized device.</li>
                    <li class="mb-1"><strong>Upon login, the user will be instantly prompted with clear instructions to create and save their new permanent password.</strong></li>
                    <li>This temporary password allows for a single login only and expires once the user sets their new password.</li>
                </ul>
            </div>

            <div class="text-center mt-4">
                <a href="' . $returnurl . '" class="btn btn-secondary px-4"><i class="fa fa-arrow-left"></i> Return</a>
            </div>
        </div>
    </div>

    <script>
    function copyTempPassword(btn) {
        var passText = document.getElementById("temp_password_val").innerText.trim();
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(passText).then(function() {
                showCopyFeedback(btn);
            }).catch(function() {
                fallbackCopy(passText, btn);
            });
        } else {
            fallbackCopy(passText, btn);
        }
    }
    function fallbackCopy(text, btn) {
        var ta = document.createElement("textarea");
        ta.value = text;
        ta.style.position = "fixed";
        ta.style.left = "-999999px";
        document.body.appendChild(ta);
        ta.select();
        try {
            document.execCommand("copy");
            showCopyFeedback(btn);
        } catch (e) {
            alert("Please copy the password manually: " + text);
        }
        document.body.removeChild(ta);
    }
    function showCopyFeedback(btn) {
        var originalHtml = btn.innerHTML;
        btn.innerHTML = \'<i class="fa fa-check"></i> ' . addslashes_js(get_string('copied', 'auth_devicelock')) . '\';
        btn.classList.remove("btn-primary");
        btn.classList.add("btn-success");
        setTimeout(function() {
            btn.innerHTML = originalHtml;
            btn.classList.remove("btn-success");
            btn.classList.add("btn-primary");
        }, 2500);
    }
    </script>
    ';
    
    echo $OUTPUT->footer();
    exit;
}

// ============================================================
// Intercept for "Copy User Details" — generate a fresh temporary
// password, set it on the account, and copy BOTH username + password
// to the admin's clipboard in a single click. Moodle never stores
// plain-text passwords, so a new single-use credential is generated.
// ============================================================
// Copy User Details — TWO-STEP flow:
// Step 1 (copyuserdetailsform): selection page — choose what to copy.
// Step 2 (copyuserdetails): execute + show result card (no auto-copy,
//   no clipboard messages, no "passwords never stored" notice).
// ============================================================

// Step 1: Selection page.
if ($action === 'copyuserdetailsform' && $userid) {
    require_sesskey();
    echo $OUTPUT->header();
    $targetuser = $DB->get_record('user', ['id' => $userid]);
    $redirect_to_viewuser = optional_param('redirect_to_viewuser', 0, PARAM_BOOL);

    if (!$targetuser) {
        \core\notification::error(get_string('usernotfound', 'auth_devicelock'));
        redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']));
    }

    $returnurl = $redirect_to_viewuser
        ? new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid])
        : new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']);

    echo '<div class="card border-primary shadow mx-auto my-4" style="max-width: 580px; border-radius: 12px; overflow: hidden;">';
    echo '  <div class="card-header bg-primary text-white py-3"><h5 class="mb-0 text-white"><i class="fa fa-clone mr-2"></i> ' . get_string('copy_user_details', 'auth_devicelock') . '</h5></div>';
    echo '  <div class="card-body p-4">';
    echo '    <p class="font-weight-bold mb-3">' . s(fullname($targetuser)) . ' <span class="text-muted small">(@' . s($targetuser->username) . ')</span></p>';

    $formurl = new moodle_url('/auth/devicelock/admin_devices.php');
    echo '    <form method="post" action="' . $formurl . '">';
    echo '      <input type="hidden" name="action" value="copyuserdetails">';
    echo '      <input type="hidden" name="userid" value="' . (int)$userid . '">';
    echo '      <input type="hidden" name="sesskey" value="' . sesskey() . '">';
    echo '      <input type="hidden" name="redirect_to_viewuser" value="' . (int)$redirect_to_viewuser . '">';

    echo '      <div class="form-group">';
    echo '        <div class="form-check mb-3 p-3 border rounded">';
    echo '          <label class="form-check-label d-block">';
    echo '            <input type="radio" name="mode" value="info" class="form-check-input mr-2" checked>';
    echo '            <strong><i class="fa fa-info-circle text-primary"></i> ' . get_string('copy_option_info', 'auth_devicelock') . '</strong>';
    echo '            <br><small class="text-muted ml-4">' . get_string('copy_option_info_desc', 'auth_devicelock') . '</small>';
    echo '          </label>';
    echo '        </div>';
    echo '        <div class="form-check mb-3 p-3 border rounded">';
    echo '          <label class="form-check-label d-block">';
    echo '            <input type="radio" name="mode" value="withpassword" class="form-check-input mr-2">';
    echo '            <strong><i class="fa fa-key text-warning"></i> ' . get_string('copy_option_password', 'auth_devicelock') . '</strong>';
    echo '            <br><small class="text-muted ml-4">' . get_string('copy_option_password_desc', 'auth_devicelock') . '</small>';
    echo '          </label>';
    echo '        </div>';
    echo '      </div>';

    echo '      <div class="d-flex justify-content-between">';
    echo '        <a href="' . $returnurl . '" class="btn btn-secondary px-4"><i class="fa fa-times"></i> ' . get_string('backtolist', 'auth_devicelock') . '</a>';
    echo '        <button type="submit" class="btn btn-primary px-4"><i class="fa fa-arrow-right"></i> ' . get_string('continue', 'moodle') . '</button>';
    echo '      </div>';
    echo '    </form>';
    echo '  </div>';
    echo '</div>';

    echo $OUTPUT->footer();
    exit;
}

// Step 2: Execute + show result.
if ($action === 'copyuserdetails' && $userid) {
    require_sesskey();
    echo $OUTPUT->header();
    $targetuser = $DB->get_record('user', ['id' => $userid]);
    $redirect_to_viewuser = optional_param('redirect_to_viewuser', 0, PARAM_BOOL);
    $mode = optional_param('mode', 'info', PARAM_ALPHA);

    if (!$targetuser) {
        \core\notification::error(get_string('usernotfound', 'auth_devicelock'));
        redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']));
    }

    // Safety: refuse to reset credentials for site admins.
    if (is_siteadmin($userid) && $mode === 'withpassword') {
        \core\notification::error(get_string('deleteuser_admin_error', 'auth_devicelock'));
        $cancelurl = $redirect_to_viewuser
            ? new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid])
            : new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']);
        redirect($cancelurl);
    }

    $temppassword = null;
    if ($mode === 'withpassword') {
        // Generate + set a new temporary password.
        $temppassword = auth_devicelock_generate_temporary_password($targetuser);
        update_internal_user_password($targetuser, $temppassword);
        set_user_preference('auth_forcepasswordchange', 1, $targetuser->id);
        set_user_preference('auth_devicelock_temp_pass', 1, $targetuser->id);
    }

    // Audit the action.
    device_manager::log_action($targetuser->id, 'system', 'copy_user_details', [
        'admin_user'  => $USER->id,
        'admin_email' => !empty($USER->email) ? $USER->email : '',
        'admin_name'  => fullname($USER),
        'mode'        => $mode,
        'timestamp'   => time(),
        'ip'          => getremoteaddr(),
    ]);

    $returnurl = $redirect_to_viewuser
        ? new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid])
        : new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'userpage' => $userpage]);

    // Build the copy payload based on the selected mode.
    if ($mode === 'withpassword') {
        $copy_payload = "Username: " . $targetuser->username . "\nEmail: " . $targetuser->email . "\nPassword: " . $temppassword;
    } else {
        $copy_payload = "Username: " . $targetuser->username . "\nEmail: " . $targetuser->email;
    }

    echo '<div class="card border-success shadow mx-auto my-4" style="max-width: 660px; border-radius: 12px; overflow: hidden;">';
    echo '  <div class="card-header bg-success text-white py-3"><h5 class="mb-0 text-white"><i class="fa fa-check-circle mr-2"></i> ' . get_string('copydetails_card_title', 'auth_devicelock') . '</h5></div>';
    echo '  <div class="card-body p-4">';

    echo '    <div class="d-flex align-items-center mb-3">';
    echo '      <i class="fa fa-check-circle fa-2x mr-3 text-success"></i>';
    echo '      <div>';
    echo '        <h6 class="mb-1 font-weight-bold">' . get_string('copydetails_generated_for', 'auth_devicelock', s(fullname($targetuser))) . '</h6>';
    echo '      </div>';
    echo '    </div>';

    // Username field.
    echo '    <div class="mb-2">';
    echo '      <label class="font-weight-bold text-dark mb-1"><i class="fa fa-user text-primary"></i> ' . get_string('copydetails_username_label', 'auth_devicelock') . '</label>';
    echo '      <div class="p-2 bg-light border rounded font-weight-bold text-monospace" style="letter-spacing:1px;">' . s($targetuser->username) . '</div>';
    echo '    </div>';

    // Email field.
    echo '    <div class="mb-2">';
    echo '      <label class="font-weight-bold text-dark mb-1"><i class="fa fa-envelope text-info"></i> ' . get_string('email', 'auth_devicelock') . '</label>';
    echo '      <div class="p-2 bg-light border rounded font-weight-bold text-monospace">' . s($targetuser->email) . '</div>';
    echo '    </div>';

    // Password field (only if mode=withpassword).
    if ($mode === 'withpassword') {
        echo '    <div class="mb-3">';
        echo '      <label class="font-weight-bold text-dark mb-1"><i class="fa fa-key text-success"></i> ' . get_string('copydetails_password_label', 'auth_devicelock') . '</label>';
        echo '      <div class="p-2 bg-light border rounded font-weight-bold text-monospace text-success" style="letter-spacing:2px; border:2px dashed #16a34a !important;" id="copydetails_password_val">' . s($temppassword) . '</div>';
        echo '    </div>';
    }

    // Manual copy button (no auto-copy, no "Copied!" feedback).
    echo '    <div class="d-flex justify-content-between align-items-center mt-3">';
    echo '      <button type="button" class="btn btn-success font-weight-bold px-4 py-2" onclick="copyUserDetailsManual(this);">';
    echo '        <i class="fa fa-clone"></i> ' . get_string('copy_both', 'auth_devicelock');
    echo '      </button>';
    echo '      <a href="' . $returnurl . '" class="btn btn-secondary px-4"><i class="fa fa-arrow-left"></i> ' . get_string('copydetails_return', 'auth_devicelock') . '</a>';
    echo '    </div>';

    // Hidden textarea for the copy payload + simple JS (no feedback message).
    echo '    <textarea id="copydetails_payload" style="position:fixed;left:-9999px;top:0;">' . s($copy_payload) . '</textarea>';
    echo '    <script>';
    echo '    function copyUserDetailsManual(btn) {';
    echo '        var ta = document.getElementById("copydetails_payload");';
    echo '        ta.select();';
    echo '        try { document.execCommand("copy"); } catch(e) {}';
    echo '        ta.blur();';
    echo '    }';
    echo '    </script>';

    echo '  </div>';
    echo '</div>';

    echo $OUTPUT->footer();
    exit;
}

// Intercept for Change Password: choose custom or auto-generated
if ($action === 'changepasswordform' && $userid) {
    echo $OUTPUT->header();
    $targetuser = $DB->get_record('user', ['id' => $userid]);
    $redirect_to_viewuser = optional_param('redirect_to_viewuser', 0, PARAM_BOOL);
    $sitemin = !empty($CFG->minpasswordlength) ? (int)$CFG->minpasswordlength : 8;

    if (!$targetuser) {
        \core\notification::error(get_string('error'));
        redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']));
    }

    echo '<div class="card border-success shadow-sm" style="max-width: 600px; margin: 0 auto;">';
    echo '<div class="card-header bg-success text-white"><h4 class="mb-0 text-white"><i class="fa fa-key"></i> Change Password: ' . s(fullname($targetuser)) . '</h4></div>';
    echo '<div class="card-body">';
    echo '<p class="text-muted small">This sets the user\'s real password. They will <strong>not</strong> be prompted to change it on next login.</p>';

    echo '<form method="post" action="' . $baseurl . '" id="changepasswordform">';
    echo '<input type="hidden" name="sesskey" value="' . sesskey() . '">';
    echo '<input type="hidden" name="action" value="changepassword">';
    echo '<input type="hidden" name="userid" value="' . $userid . '">';
    echo '<input type="hidden" name="redirect_to_viewuser" value="' . $redirect_to_viewuser . '">';

    echo '<div class="form-group">';
    echo '<div class="custom-control custom-radio">';
    echo '<input type="radio" id="pwmode_auto" name="pwmode" value="auto" class="custom-control-input" checked onclick="devicelockTogglePwMode();">';
    echo '<label class="custom-control-label" for="pwmode_auto">Auto-generate a password</label>';
    echo '</div>';
    echo '<div class="custom-control custom-radio">';
    echo '<input type="radio" id="pwmode_custom" name="pwmode" value="custom" class="custom-control-input" onclick="devicelockTogglePwMode();">';
    echo '<label class="custom-control-label" for="pwmode_custom">Enter a custom password</label>';
    echo '</div>';
    echo '</div>';

    echo '<div id="pwmode_auto_fields" class="form-group">';
    echo '<label for="pwlength"><strong>Password length</strong></label>';
    echo '<input type="number" name="pwlength" id="pwlength" class="form-control" style="max-width: 150px;" min="' . $sitemin . '" max="64" value="12">';
    echo '<small class="form-text text-muted">Between ' . $sitemin . ' and 64 characters.</small>';
    echo '</div>';

    echo '<div id="pwmode_custom_fields" class="form-group" style="display:none;">';
    echo '<label for="custompassword"><strong>New password</strong></label>';
    echo '<input type="password" name="custompassword" id="custompassword" class="form-control" autocomplete="new-password">';
    echo '<label for="custompassword2" class="mt-2"><strong>Confirm new password</strong></label>';
    echo '<input type="password" name="custompassword2" id="custompassword2" class="form-control" autocomplete="new-password">';
    echo '<small class="form-text text-muted">Must satisfy the site\'s password policy (minimum length ' . $sitemin . ').</small>';
    echo '</div>';

    echo '<div class="mt-4">';
    echo '<button type="submit" class="btn btn-success text-white"><i class="fa fa-key"></i> Change Password</button>';
    $cancelurl = $redirect_to_viewuser ? new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid]) : $baseurl;
    echo '<a href="' . $cancelurl . '" class="btn btn-secondary ml-2">Cancel</a>';
    echo '</div>';
    echo '</form>';
    echo '</div></div>';

    echo '<script>
    function devicelockTogglePwMode() {
        var isCustom = document.getElementById("pwmode_custom").checked;
        document.getElementById("pwmode_auto_fields").style.display = isCustom ? "none" : "block";
        document.getElementById("pwmode_custom_fields").style.display = isCustom ? "block" : "none";
    }
    </script>';

    echo $OUTPUT->footer();
    exit;
}

// Intercept for Change Password (permanent) Card
if ($action === 'changepassword' && $userid) {
    require_sesskey();
    $targetuser = $DB->get_record('user', ['id' => $userid]);
    $redirect_to_viewuser = optional_param('redirect_to_viewuser', 0, PARAM_BOOL);

    if (!$targetuser) {
        echo $OUTPUT->header();
        \core\notification::error(get_string('error'));
        $cancelurl = new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']);
        redirect($cancelurl);
    }

    $formurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'changepasswordform', 'userid' => $userid, 'redirect_to_viewuser' => (int)$redirect_to_viewuser]);

    // 1. Work out the new password: admin's own custom password, or an
    // auto-generated one, per their choice on the previous form.
    $pwmode = optional_param('pwmode', 'auto', PARAM_ALPHA);

    if ($pwmode === 'custom') {
        // PARAM_RAW: a password must not be stripped/altered by cleaning.
        $custompassword  = optional_param('custompassword', '', PARAM_RAW);
        $custompassword2 = optional_param('custompassword2', '', PARAM_RAW);

        if ($custompassword === '' || $custompassword2 === '') {
            \core\notification::error('Please enter and confirm the new password.');
            redirect($formurl);
        }
        if (!hash_equals($custompassword, $custompassword2)) {
            \core\notification::error('The two passwords you entered do not match.');
            redirect($formurl);
        }
        $errmsg = '';
        if (function_exists('check_password_policy') && !check_password_policy($custompassword, $errmsg, $targetuser)) {
            \core\notification::error($errmsg !== '' ? $errmsg : get_string('error'));
            redirect($formurl);
        }
        $newpassword = $custompassword;
        $pwlength = strlen($newpassword);
    } else {
        $pwmode = 'auto';
        $pwlength = optional_param('pwlength', 12, PARAM_INT);
        $newpassword = auth_devicelock_generate_temporary_password($targetuser, $pwlength);
    }

    echo $OUTPUT->header();

    // 2. Set password for user in Moodle internal storage.
    update_internal_user_password($targetuser, $newpassword);

    // 3. Unlike Generate Temporary Password, this is a REAL password change:
    // no forced change prompt and no single-use temp-password mode. Clear
    // both flags in case a temp password was previously issued to this user
    // and is still pending, so it doesn't linger after this permanent change.
    unset_user_preference('auth_forcepasswordchange', $targetuser->id);
    unset_user_preference('auth_devicelock_temp_pass', $targetuser->id);

    // 4. Log the audit event with admin identity
    device_manager::log_action($targetuser->id, 'system', 'change_password_direct', [
        'admin_user' => $USER->id,
        'admin_email' => !empty($USER->email) ? $USER->email : '',
        'admin_name' => fullname($USER),
        'pwmode' => $pwmode,
        'pwlength' => $pwlength,
        'timestamp' => time(),
        'ip' => getremoteaddr()
    ]);

    $returnurl = $redirect_to_viewuser ?
        new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid]) :
        new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']);

    echo '
    <div class="card border-success shadow mx-auto my-4" style="max-width: 620px; border-radius: 12px; overflow: hidden;">
        <div class="card-header bg-success text-white py-3 d-flex align-items-center justify-content-between">
            <h5 class="mb-0 text-white font-weight-bold"><i class="fa fa-key mr-2"></i> Password Changed</h5>
            <span class="badge badge-light text-success font-weight-bold"><i class="fa fa-check"></i> Permanent</span>
        </div>
        <div class="card-body p-4">
            <div class="alert alert-success d-flex align-items-center mb-3">
                <i class="fa fa-check-circle fa-2x mr-3 text-success"></i>
                <div>
                    <h6 class="mb-1 font-weight-bold">New password set for ' . s(fullname($targetuser)) . '</h6>
                    <span class="text-muted small">Username: <strong>' . s($targetuser->username) . '</strong> &bull; Email: <strong>' . s($targetuser->email) . '</strong></span>
                </div>
            </div>

            <p class="mb-2 font-weight-bold text-dark"><i class="fa fa-lock text-primary"></i> New Password:</p>

            <div class="d-flex align-items-center justify-content-between p-3 mb-3 bg-light border rounded" style="border: 2px dashed #16a34a !important;">
                <span id="temp_password_val" class="h3 font-weight-bold text-monospace mb-0 text-success" style="letter-spacing: 2px;">' . s($newpassword) . '</span>
                <button type="button" id="copy_btn" class="btn btn-success font-weight-bold px-3 py-2" onclick="copyTempPassword(this);">
                    <i class="fa fa-clone"></i> ' . get_string('copy_password', 'auth_devicelock') . '
                </button>
            </div>

            <div class="card bg-light border-0 p-3 mb-3" style="border-left: 4px solid #16a34a !important;">
                <h6 class="font-weight-bold text-dark mb-2"><i class="fa fa-info-circle text-info"></i> How it works:</h6>
                <ul class="small text-muted mb-0 pl-3">
                    <li class="mb-1">This is the user\'s real password now, set directly &mdash; not a single-use login.</li>
                    <li class="mb-1">The user is <strong>not</strong> prompted to change it on their next login.</li>
                    <li>Copy this password and securely send it to the user yourself.</li>
                </ul>
            </div>

            <div class="text-center mt-4">
                <a href="' . $returnurl . '" class="btn btn-secondary px-4"><i class="fa fa-arrow-left"></i> Return</a>
            </div>
        </div>
    </div>

    <script>
    function copyTempPassword(btn) {
        var passText = document.getElementById("temp_password_val").innerText.trim();
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(passText).then(function() {
                showCopyFeedback(btn);
            }).catch(function() {
                fallbackCopy(passText, btn);
            });
        } else {
            fallbackCopy(passText, btn);
        }
    }
    function fallbackCopy(text, btn) {
        var ta = document.createElement("textarea");
        ta.value = text;
        ta.style.position = "fixed";
        ta.style.left = "-999999px";
        document.body.appendChild(ta);
        ta.select();
        try {
            document.execCommand("copy");
            showCopyFeedback(btn);
        } catch (e) {
            alert("Please copy the password manually: " + text);
        }
        document.body.removeChild(ta);
    }
    function showCopyFeedback(btn) {
        var originalHtml = btn.innerHTML;
        btn.innerHTML = \'<i class="fa fa-check"></i> ' . addslashes_js(get_string('copied', 'auth_devicelock')) . '\';
        btn.classList.remove("btn-success");
        btn.classList.add("btn-success");
        setTimeout(function() {
            btn.innerHTML = originalHtml;
        }, 2500);
    }
    </script>
    ';

    echo $OUTPUT->footer();
    exit;
}

// Intercept for Set Custom Limit Page
if ($action === 'setlimit' && $userid) {
    echo $OUTPUT->header();
    $targetuser = $DB->get_record('user', ['id' => $userid]);
    $currentlimit = get_user_preferences('auth_devicelock_userlimit', '', $userid);
    $currentbrowserlimit = get_user_preferences('auth_devicelock_browserlimit', '', $userid);
    $globallimit = (int)(get_config('auth_devicelock', 'maxdevices') ?: 1);
    $globalbrowserlimit = (int)(get_config('auth_devicelock', 'maxbrowsers') ?: 0);
    
    $redirect_to_viewuser = optional_param('redirect_to_viewuser', 0, PARAM_BOOL);
    
    echo '<div class="card border-primary shadow-sm" style="max-width: 600px; margin: 0 auto;">';
    echo '<div class="card-header bg-primary text-white"><h4 class="mb-0 text-white"><i class="fa fa-sliders"></i> Set Custom Limits: ' . s(fullname($targetuser)) . '</h4></div>';
    echo '<div class="card-body">';
    echo '<p class="text-muted">Configure custom device and browser limits for this specific user. Leave blank or enter 0 to revert to the global settings.</p>';
    
    echo '<form method="post" action="' . $baseurl . '">';
    echo '<input type="hidden" name="sesskey" value="' . sesskey() . '">';
    echo '<input type="hidden" name="action" value="saveuserlimit">';
    echo '<input type="hidden" name="userid" value="' . $userid . '">';
    echo '<input type="hidden" name="redirect_to_viewuser" value="' . $redirect_to_viewuser . '">';
    
    echo '<div class="form-group mb-3">';
    echo '<label for="userlimit"><strong>' . get_string('userlimit_label', 'auth_devicelock') . '</strong></label>';
    echo '<input type="number" name="userlimit" id="userlimit" class="form-control" value="' . s($currentlimit) . '" min="0" placeholder="Global: ' . $globallimit . ' devices">';
    echo '<small class="form-text text-muted">Maximum number of devices allowed for this user.</small>';
    echo '</div>';

    echo '<div class="form-group mb-3">';
    echo '<label for="userbrowserlimit"><strong>' . get_string('userbrowserlimit_label', 'auth_devicelock') . '</strong></label>';
    $bplaceholder = $globalbrowserlimit > 0 ? $globalbrowserlimit . ' browsers' : 'Unlimited (0)';
    echo '<input type="number" name="userbrowserlimit" id="userbrowserlimit" class="form-control" value="' . s($currentbrowserlimit) . '" min="0" placeholder="Global: ' . $bplaceholder . '">';
    echo '<small class="form-text text-muted">Maximum number of distinct browsers allowed per device for this user (0 = Unlimited).</small>';
    echo '</div>';
    
    echo '<div class="mt-4 pt-2 border-top">';
    echo '<button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save Limits</button>';
    $cancelurl = $redirect_to_viewuser ? new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid]) : $baseurl;
    echo '<a href="' . $cancelurl . '" class="btn btn-secondary ml-2">Cancel</a>';
    echo '</div>';
    echo '</form>';
    echo '</div></div>';
    echo $OUTPUT->footer();
    exit;
}

// Intercept for Send Custom Email Page
if ($action === 'sendemail' && $userid) {
    echo $OUTPUT->header();
    $targetuser = $DB->get_record('user', ['id' => $userid]);
    $redirect_to_viewuser = optional_param('redirect_to_viewuser', 0, PARAM_BOOL);
    
    echo '<div class="card border-info shadow-sm" style="max-width: 800px; margin: 0 auto;">';
    echo '<div class="card-header bg-info text-white"><h4 class="mb-0 text-white"><i class="fa fa-envelope"></i> Send Email to: ' . s(fullname($targetuser)) . '</h4></div>';
    echo '<div class="card-body">';
    
    echo '<form method="post" action="' . $baseurl . '">';
    echo '<input type="hidden" name="sesskey" value="' . sesskey() . '">';
    echo '<input type="hidden" name="action" value="customemailuser">';
    echo '<input type="hidden" name="userid" value="' . $userid . '">';
    echo '<input type="hidden" name="redirect_to_viewuser" value="' . $redirect_to_viewuser . '">';
    
    echo '<div class="form-group">';
    echo '<label for="emailsubject"><strong>Subject</strong></label>';
    echo '<input type="text" name="emailsubject" id="emailsubject" class="form-control" required placeholder="e.g. Account Security Update">';
    echo '</div>';
    
    echo '<div class="form-group">';
    echo '<label for="emailbody"><strong>Message</strong></label>';
    echo '<textarea name="emailbody" id="emailbody" class="form-control" rows="8" required placeholder="Write your message here..."></textarea>';
    echo '</div>';
    
    echo '<div class="mt-4">';
    echo '<button type="submit" class="btn btn-info text-white"><i class="fa fa-paper-plane"></i> Send Email</button>';
    $cancelurl = $redirect_to_viewuser ? new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid]) : $baseurl;
    echo '<a href="' . $cancelurl . '" class="btn btn-secondary ml-2">Cancel</a>';
    echo '</div>';
    echo '</form>';
    echo '</div></div>';
    echo $OUTPUT->footer();
    exit;
}

// Intercept for Send Email to All Users Page
if ($action === 'sendemailall') {
    echo $OUTPUT->header();
    
    echo '<div class="card border-info shadow-sm" style="max-width: 800px; margin: 0 auto;">';
    echo '<div class="card-header bg-info text-white"><h4 class="mb-0 text-white"><i class="fa fa-envelope"></i> Send Email to All Users</h4></div>';
    echo '<div class="card-body">';
    echo '<p class="text-muted">Compose an email to be broadcasted to all active users.</p>';
    
    $formurl = new moodle_url('/auth/devicelock/admin_devices.php', ['sesskey' => sesskey()]);
    echo '<form method="post" action="' . $formurl . '">';
    echo '<input type="hidden" name="sesskey" value="' . sesskey() . '">';
    echo '<input type="hidden" name="action" value="customemailall">';
    
    echo '<div class="form-group">';
    echo '<label for="emailsubject"><strong>Subject</strong></label>';
    echo '<input type="text" name="emailsubject" id="emailsubject" class="form-control" required placeholder="e.g. Important Account Security Update">';
    echo '</div>';
    
    echo '<div class="form-group">';
    echo '<label for="emailbody"><strong>Message</strong></label>';
    echo '<textarea name="emailbody" id="emailbody" class="form-control" rows="8" required placeholder="Write your message here..."></textarea>';
    echo '</div>';
    
    echo '<div class="mt-4">';
    echo '<button type="submit" class="btn btn-info text-white"><i class="fa fa-paper-plane"></i> Send Email to All Users</button>';
    echo '<a href="' . $baseurl . '" class="btn btn-secondary ml-2">Cancel</a>';
    echo '</div>';
    echo '</form>';
    echo '</div></div>';
    echo $OUTPUT->footer();
    exit;
}

// Intercept for View User Details & Devices Page
if ($action === 'viewuser' && $userid) {
    $targetuser = $DB->get_record('user', ['id' => $userid]);
    if (!$targetuser) {
        \core\notification::error("User not found.");
        redirect(new moodle_url('/auth/devicelock/admin_devices.php'));
    }
    
    echo $OUTPUT->header();
    
    // Header section
    echo '<div class="d-flex justify-content-between align-items-center mb-4">';
    echo '  <h3><i class="fa fa-user text-primary"></i> User Details: ' . s(fullname($targetuser)) . '</h3>';
    echo '  <a href="' . new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']) . '" class="btn btn-secondary"><i class="fa fa-arrow-left"></i> Return to Directory</a>';
    echo '</div>';
    
    // Quick Actions Bar
    echo '<div class="card mb-4 bg-light shadow-sm">';
    echo '  <div class="card-body py-2 d-flex flex-wrap align-items-center justify-content-between">';
    echo '    <span class="my-1 font-weight-bold"><i class="fa fa-bolt"></i> Quick Actions for this User:</span>';
    echo '    <div class="btn-group my-1">';
    
    $limiturl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'setlimit', 'userid' => $userid, 'redirect_to_viewuser' => 1]);
    echo '      <a href="' . $limiturl . '" class="btn btn-sm btn-outline-secondary"><i class="fa fa-cog" style="color: #a855f7;"></i> Adjust Limit Override</a>';
    
    $purgeurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'purgeuser', 'userid' => $userid, 'redirect_to_viewuser' => 1]);
    echo '      <a href="' . $purgeurl . '" class="btn btn-sm btn-outline-secondary"><i class="fa fa-refresh" style="color: #ef4444;"></i> Purge & Logout All Devices</a>';
    
    $resetbrowsersurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'resetuserbrowsers', 'userid' => $userid, 'sesskey' => sesskey(), 'redirect_to_viewuser' => 1]);
    echo '      <a href="' . $resetbrowsersurl . '" class="btn btn-sm btn-outline-secondary" onclick="return confirm(\'' . addslashes_js(get_string('confirm_reset_user_browsers', 'auth_devicelock')) . '\');"><i class="fa fa-globe" style="color: #3b82f6;"></i> ' . get_string('reset_all_browsers', 'auth_devicelock') . '</a>';
    
    $emailurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'sendemail', 'userid' => $userid, 'redirect_to_viewuser' => 1]);
    echo '      <a href="' . $emailurl . '" class="btn btn-sm btn-outline-secondary"><i class="fa fa-envelope" style="color: #06b6d4;"></i> Send Custom Email</a>';
    
    $resetpwdurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'sendresetpassword', 'userid' => $userid, 'sesskey' => sesskey(), 'redirect_to_viewuser' => 1]);
    echo '      <a href="' . $resetpwdurl . '" class="btn btn-sm btn-outline-secondary"><i class="fa fa-key" style="color: #eab308;"></i> Send Reset Password</a>';

    $temppassurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'generatetemppasswordform', 'userid' => $userid, 'redirect_to_viewuser' => 1]);
    echo '      <a href="' . $temppassurl . '" class="btn btn-sm btn-outline-secondary"><i class="fa fa-key" style="color: #0ea5e9;"></i> ' . get_string('generate_temp_password', 'auth_devicelock') . '</a>';

    $changepasswordurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'changepasswordform', 'userid' => $userid, 'redirect_to_viewuser' => 1]);
    echo '      <a href="' . $changepasswordurl . '" class="btn btn-sm btn-outline-secondary"><i class="fa fa-key" style="color: #16a34a;"></i> Change Password</a>';

    $changeauthurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'changeauth', 'userid' => $userid, 'redirect_to_viewuser' => 1]);
    echo '      <a href="' . $changeauthurl . '" class="btn btn-sm btn-outline-secondary"><i class="fa fa-random" style="color: #f97316;"></i> Change Auth Method</a>';

    if ($targetuser->auth !== 'devicelock') {
        $migrateurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'migrateuser', 'userid' => $userid, 'sesskey' => sesskey(), 'redirect_to_viewuser' => 1]);
        echo '      <a href="' . $migrateurl . '" class="btn btn-sm btn-outline-secondary"><i class="fa fa-lock" style="color: #10b981;"></i> Migrate to Plugin</a>';
    }

    // Suspend Site Access (Block User)
    $suspendurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'togglesuspend', 'userid' => $userid, 'sesskey' => sesskey(), 'redirect_to_viewuser' => 1]);
    if ($targetuser->suspended) {
        echo '      <a href="' . $suspendurl . '" class="btn btn-sm btn-outline-secondary"><i class="fa fa-unlock-alt" style="color: #14b8a6;"></i> Restore Site Access</a>';
    } else {
        echo '      <a href="' . $suspendurl . '" class="btn btn-sm btn-outline-secondary"><i class="fa fa-user-times" style="color: #f43f5e;"></i> Block Site Access</a>';
    }

    // Confirm account
    if (!$targetuser->confirmed) {
        $confirmuserurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'confirmuser', 'userid' => $userid, 'sesskey' => sesskey(), 'redirect_to_viewuser' => 1]);
        echo '      <a href="' . $confirmuserurl . '" class="btn btn-sm btn-outline-secondary"><i class="fa fa-check-circle" style="color: #84cc16;"></i> Confirm Account</a>';
    }

    // Edit user info page
    $editurl = new moodle_url('/user/editadvanced.php', ['id' => $userid]);
    echo '      <a href="' . $editurl . '" class="btn btn-sm btn-outline-secondary" target="_blank"><i class="fa fa-pencil-square" style="color: #6366f1;"></i> Edit Profile Info</a>';

    // Copy User Details (copies username + a fresh temp password to clipboard)
    $copydetailsurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'copyuserdetailsform', 'userid' => $userid, 'sesskey' => sesskey(), 'redirect_to_viewuser' => 1]);
    echo '      <a href="' . $copydetailsurl . '" class="btn btn-sm btn-outline-secondary" title="' . s(get_string('copy_user_details', 'auth_devicelock')) . '"><i class="fa fa-clone" style="color: #16a34a;"></i> ' . get_string('copy_user_details', 'auth_devicelock') . '</a>';

    // Delete User Account (permanently removes the Moodle user + all info)
    $deleteuserurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'deleteuser', 'userid' => $userid, 'sesskey' => sesskey(), 'tab' => $tab]);
    echo '      <a href="' . $deleteuserurl . '" class="btn btn-sm btn-outline-danger" title="' . s(get_string('delete_user_account', 'auth_devicelock')) . '"><i class="fa fa-trash" style="color: #dc2626;"></i> ' . get_string('delete_user_account', 'auth_devicelock') . '</a>';

    // Audit Timeline (per-user security history, filterable + exportable)
    $audittimelineurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuseraudit', 'userid' => $userid, 'tab' => $tab]);
    echo '      <a href="' . $audittimelineurl . '" class="btn btn-sm btn-outline-info" title="' . s(get_string('audit_timeline', 'auth_devicelock')) . '"><i class="fa fa-history" style="color: #0ea5e9;"></i> ' . get_string('audit_timeline', 'auth_devicelock') . '</a>';

    // Change Score (manual score management + custom regain override)
    $changescoreurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'changescoreform', 'userid' => $userid, 'tab' => $tab]);
    echo '      <a href="' . $changescoreurl . '" class="btn btn-sm btn-outline-primary" title="' . s(get_string('score_change_title', 'auth_devicelock')) . '"><i class="fa fa-tachometer" style="color: #2563eb;"></i> ' . get_string('score_change', 'auth_devicelock') . '</a>';

    echo '    </div>';
    echo '  </div>';
    echo '</div>';

    // Score-history sparkline card (pure CSS, 30-day trend).
    $score_history = auth_devicelock_get_score_history($userid, 30);
    $sparkline = auth_devicelock_render_score_sparkline($score_history);
    echo '<div class="card mb-4 shadow-sm">';
    echo '  <div class="card-header bg-white d-flex justify-content-between align-items-center">';
    echo '    <strong class="text-dark"><i class="fa fa-chart-area text-primary"></i> ' . get_string('score_history', 'auth_devicelock') . '</strong>';
    if (!empty($sparkline)) {
        echo '    <span class="badge badge-primary badge-pill">' . count($score_history) . ' points</span>';
    }
    echo '  </div>';
    echo '  <div class="card-body p-3">';
    // v3.5.0: live score summary (progress bar + regain information).
    $vscorerow = auth_devicelock_score_get($userid);
    $vsb = auth_devicelock_security_score_band((int)$vscorerow->score);
    list($vr_amount, $vr_interval, $vr_custom) = auth_devicelock_score_regain_settings_for($vscorerow);
    $vnext = auth_devicelock_score_next_regain_in($vscorerow);
    $vsbbadge = ['high' => 'success', 'good' => 'primary', 'fair' => 'warning', 'poor' => 'danger', 'critical' => 'dark'];
    $vsbbar = ['high' => '#16a34a', 'good' => '#2563eb', 'fair' => '#f59e0b', 'poor' => '#dc2626', 'critical' => '#1f2937'];
    echo '  <div class="d-flex flex-wrap align-items-center mb-3">';
    echo '    <span class="badge badge-' . ($vsbbadge[$vsb['band']] ?? 'secondary') . ' px-2 py-1 mr-2" style="font-size:0.95rem; min-width:56px;">' . (int)$vscorerow->score . '%</span>';
    echo '    <div class="progress flex-grow-1 mr-3" style="height:8px; min-width:120px;"><div class="progress-bar" style="width:' . (int)$vscorerow->score . '%; background:' . ($vsbbar[$vsb['band']] ?? '#6c757d') . ';"></div></div>';
    echo '    <span class="small text-muted">' . get_string('score_stats_violations', 'auth_devicelock') . ': <strong>' . (int)$vscorerow->violation_count . '</strong> &middot; ' . get_string('score_stats_last_violation', 'auth_devicelock') . ': <strong>' . (!empty($vscorerow->last_violation) ? userdate((int)$vscorerow->last_violation, get_string('strftimedatetimeshort', 'langconfig')) : get_string('score_stats_never', 'auth_devicelock')) . '</strong> &middot; ' . get_string('score_stats_regain', 'auth_devicelock') . ': <strong>+' . (int)$vr_amount . ' / ' . auth_devicelock_score_format_interval($vr_interval) . '</strong> <span class="badge badge-' . ($vr_custom ? 'info' : 'light border text-muted') . '">' . ($vr_custom ? get_string('score_stats_custom', 'auth_devicelock') : get_string('score_stats_global', 'auth_devicelock')) . '</span>' . ($vnext === 0 ? ' &middot; <span class="text-success"><i class="fa fa-check-circle"></i> ' . get_string('score_next_due', 'auth_devicelock') . '</span>' : ($vnext > 0 ? ' &middot; ' . get_string('score_next_in', 'auth_devicelock', auth_devicelock_score_format_interval($vnext)) : '')) . '</span>';
    echo '  </div>';
    if (empty($sparkline)) {
        echo '    <div class="text-center text-muted py-2"><i class="fa fa-info-circle"></i> ' . get_string('score_history_empty', 'auth_devicelock') . '</div>';
    } else {
        echo '    ' . $sparkline;
        echo '    <div class="d-flex justify-content-between mt-1 small text-muted"><span>oldest</span><span>newest</span></div>';
    }
    echo '  </div>';
    echo '</div>';

    // User Profile Metadata Card
    $usertype = 'Student / User';
    $usertypebadge = 'badge-light';
    if (is_siteadmin($userid)) {
        $usertype = 'Site Admin';
        $usertypebadge = 'badge-danger';
    } else {
        $roles = $DB->get_records_sql("
            SELECT DISTINCT r.shortname 
            FROM {role_assignments} ra 
            JOIN {role} r ON ra.roleid = r.id 
            WHERE ra.userid = ?
        ", [$userid]);
        foreach ($roles as $role) {
            if (in_array($role->shortname, ['teacher', 'editingteacher', 'manager'])) {
                $usertype = 'Teacher / Manager';
                $usertypebadge = 'badge-warning';
                break;
            }
        }
    }
    
    $limit = auth_devicelock_get_user_device_limit($userid);
    $globallimit = (int)(get_config('auth_devicelock', 'maxdevices') ?: 1);
    $hascustom = (get_user_preferences('auth_devicelock_userlimit', null, $userid) !== null) && ($limit !== $globallimit);
    $active_count = device_manager::get_active_device_count($userid);
    
    $browser_limit = auth_devicelock_get_user_browser_limit($userid);
    $hascustom_browser = (get_user_preferences('auth_devicelock_browserlimit', null, $userid) !== null);
    
    $target_custom = auth_devicelock_get_custom_profile_identifiers($userid, $targetuser);
    $display_phone  = !empty($target_custom['phone']) ? $target_custom['phone'] : (!empty($targetuser->phone1) ? $targetuser->phone1 : (!empty($targetuser->phone2) ? $targetuser->phone2 : ''));
    $display_uni_id = !empty($target_custom['uni_id']) ? $target_custom['uni_id'] : (!empty($targetuser->idnumber) ? $targetuser->idnumber : '');

    echo '<div class="row mb-4">';
    echo '  <div class="col-md-12">';
    echo '    <div class="card shadow-sm">';
    echo '      <div class="card-header bg-dark text-white font-weight-bold d-flex justify-content-between align-items-center">';
    echo '        <span><i class="fa fa-id-card"></i> Account Information</span>';
    // Per-user security score badge (30-day window).
    $scoreset = auth_devicelock_compute_security_score($userid);
    echo '        <span>' . auth_devicelock_render_security_score_badge($scoreset) . '</span>';
    echo '      </div>';
    echo '      <div class="card-body">';
    echo '        <div class="row align-items-center">';
    echo '          <div class="col-md-2 text-center border-right">';
    $userpic = $OUTPUT->user_picture($targetuser, ['size' => 80, 'class' => 'rounded-circle shadow-sm mb-2']);
    echo '            ' . $userpic;
    echo '            <h5 class="mt-2 mb-0">' . s(fullname($targetuser)) . '</h5>';
    echo '            <small class="text-monospace text-muted text-break">@' . s($targetuser->username) . '</small>';
    echo '          </div>';
    echo '          <div class="col-md-10">';
    echo '            <div class="row">';
    echo '              <div class="col-md-3 mb-3">
                <span class="text-muted small d-block">Email Address</span>
                <strong><code>' . s($targetuser->email) . '</code></strong>
              </div>
              <div class="col-md-3 mb-3">
                <span class="text-muted small d-block">Phone Number</span>
                <strong>' . (!empty($display_phone) ? s($display_phone) : '<span class="text-muted">N/A</span>') . '</strong>
              </div>
              <div class="col-md-3 mb-3">
                <span class="text-muted small d-block">Your University ID</span>
                <strong>' . (!empty($display_uni_id) ? s($display_uni_id) : '<span class="text-muted">N/A</span>') . '</strong>
              </div>';
    echo '              <div class="col-md-3 mb-3">';
    echo '                <span class="text-muted small d-block">Authentication Method</span>';
    echo '                <strong>' . ($targetuser->auth === 'devicelock' ? '<span class="badge badge-success"><i class="fa fa-lock"></i> Single Device Lock</span>' : '<span class="badge badge-secondary">' . s($targetuser->auth) . '</span>') . '</strong>';
    echo '              </div>';
    echo '              <div class="col-md-3 mb-3">';
    echo '                <span class="text-muted small d-block">User Type Class</span>';
    echo '                <strong><span class="badge ' . $usertypebadge . '">' . $usertype . '</span></strong>';
    echo '              </div>';
    echo '              <div class="col-md-3 mb-3">';
    echo '                <span class="text-muted small d-block">Status</span>';
    echo '                <strong>' . ($targetuser->suspended ? '<span class="text-danger"><i class="fa fa-times-circle"></i> Suspended</span>' : '<span class="text-success"><i class="fa fa-check-circle"></i> Active / Confirmed</span>') . '</strong>';
    echo '              </div>';
    echo '              <div class="col-md-3 mb-3">';
    echo '                <span class="text-muted small d-block">Active Device Count</span>';
    echo '                <strong><span class="text-primary font-weight-bold h4">' . $active_count . '</span> active</strong>';
    echo '              </div>';
    echo '              <div class="col-md-3 mb-3">';
    echo '                <span class="text-muted small d-block">Allowed Max Devices</span>';
    echo '                <strong><span class="h4 font-weight-bold">' . $limit . '</span>' . ($hascustom ? ' <span class="badge badge-primary">Custom Override</span>' : ' <span class="badge badge-light">Global Default</span>') . '</strong>';
    echo '              </div>';
    echo '              <div class="col-md-3 mb-3">';
    echo '                <span class="text-muted small d-block">Allowed Browsers / Device</span>';
    echo '                <strong><span class="h4 font-weight-bold">' . ($browser_limit === 0 ? 'Unlimited' : $browser_limit) . '</span>' . ($hascustom_browser ? ' <span class="badge badge-primary">Custom Override</span>' : ' <span class="badge badge-light">Global Default</span>') . '</strong>';
    echo '              </div>';
    echo '              <div class="col-md-9 mb-3">';
    echo '                <span class="text-muted small d-block">Exclude Checks Status</span>';
    // v3.8.0: role-based exclusion list (replaces the old exclude-admins /
    // exclude-teachers checkboxes).
    $excluded = 'Subject to all plugin checks';
    $excllist = array_filter(array_map('trim', explode(',', (string)get_config('auth_devicelock', 'excludedroles'))), function ($v) {
        return $v !== '';
    });
    if (!empty($excllist)) {
        if (is_siteadmin($userid) && in_array('admin', $excllist, true)) {
            $excluded = 'Excluded (Site Admin override)';
        } else {
            $exclroleids = array_values(array_filter(array_map('intval', $excllist), function ($v) {
                return $v > 0;
            }));
            if (!empty($exclroleids) && $DB->record_exists_sql(
                'SELECT 1 FROM {role_assignments} ra WHERE ra.userid = :exuid AND ra.roleid ' .
                implode(' OR ra.roleid = ', array_fill(0, count($exclroleids), '?')),
                array_merge([$userid], $exclroleids)
            )) {
                $excluded = 'Excluded (role override)';
            }
        }
    }
    echo '                <strong>' . $excluded . '</strong>';
    echo '              </div>';
    echo '            </div>'; // End nested row
    echo '          </div>'; // End col-10
    echo '        </div>'; // End row
    echo '      </div>'; // End card-body
    echo '    </div>'; // End card
    echo '  </div>'; // End col
    echo '</div>'; // End row
    
    // User Registered Devices (ordered by created_at ASC)
    $devices = $DB->get_records('auth_devicelock_devices', ['userid' => $userid], 'created_at ASC');
    
    echo '<div class="card mb-4 shadow-sm">';
    echo '  <div class="card-header bg-primary text-white font-weight-bold"><i class="fa fa-desktop"></i> Registered Device Inventory (Chronological Order)</div>';
    echo '  <div class="card-body p-0 table-responsive">';
    
    if (empty($devices)) {
        echo '    <div class="p-4 text-center text-muted">No registered devices found for this user.</div>';
    } else {
        $table = new html_table();
        $table->head = ['# Order', 'Device OS / Platform', 'Details / Hardware Specs', 'IP Address', 'First Registered', 'Last Login', 'Status', 'Actions'];
        $table->attributes['class'] = 'table table-hover table-striped mb-0 align-middle';
        
        $order = 1;
        foreach ($devices as $d) {
            $device_specs = auth_devicelock_format_device_info($d);
            
            $first_reg = $d->created_at ? device_manager::format_gmt2_date($d->created_at, 'd M Y, H:i:s') : '-';
            $last_login = $d->last_login ? device_manager::format_gmt2_date($d->last_login, 'd M Y, H:i:s') : '-';
            
            $status_badge = auth_devicelock_get_status_badge($d->status);
            
            // Generate action button
            $toggleurl = new moodle_url('/auth/devicelock/admin_devices.php', [
                'action' => 'toggleblock',
                'deviceid' => $d->id,
                'userid' => $userid,
                'sesskey' => sesskey(),
                'redirect_to_viewuser' => 1
            ]);
            $toggletext = $d->status === 'active' ? '<i class="fa fa-ban"></i> Block' : '<i class="fa fa-check"></i> Unblock';
            $toggleclass = $d->status === 'active' ? 'btn-outline-danger' : 'btn-outline-success';
            
            $action_btn = '<a href="' . $toggleurl . '" class="btn btn-sm ' . $toggleclass . '">' . $toggletext . '</a>';

            $resetbrowserurl = new moodle_url('/auth/devicelock/admin_devices.php', [
                'action' => 'resetdevicebrowsers',
                'deviceid' => $d->id,
                'userid' => $userid,
                'sesskey' => sesskey(),
                'redirect_to_viewuser' => 1
            ]);
            $reset_browser_btn = '<a href="' . $resetbrowserurl . '" class="btn btn-sm btn-outline-warning ml-1" title="' . s(get_string('reset_device_browsers', 'auth_devicelock')) . '" onclick="return confirm(\'' . addslashes_js(get_string('reset_device_browsers_confirm', 'auth_devicelock')) . '\');"><i class="fa fa-refresh"></i> ' . get_string('reset_device_browsers', 'auth_devicelock') . '</a>';
            $action_btn = '<div class="btn-group">' . $action_btn . $reset_browser_btn . '</div>';
            
            $os_browser = '<strong>' . s($d->platform ?: 'Unknown Platform') . '</strong>';
            $browser_badges = auth_devicelock_format_browsers_used($d);
            if ($browser_badges) {
                $os_browser .= '<div class="mt-1">' . $browser_badges . '</div>';
            }
            if ($d->user_agent) {
                $os_browser .= '<small class="text-muted d-block mt-1" title="' . s($d->user_agent) . '">' . substr($d->user_agent, 0, 50) . '...</small>';
            }
            
            $details_cell = '<div class="small">' . $device_specs . '</div>';
            if ($d->device_fingerprint) {
                $details_cell .= '<div class="mt-1 mb-1">' . auth_devicelock_fingerprint_span($d->device_fingerprint) . '</div>';
            }
            if ($d->device_info) {
                $decoded = @json_decode($d->device_info, true);
                if ($decoded) {
                    $pretty = json_encode($decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
                    $details_cell .= '<details class="mt-1"><summary class="text-primary font-weight-bold" style="cursor:pointer; font-size: 0.8rem;">View Raw Operational Data</summary>';
                    $details_cell .= '<pre class="bg-light p-2 rounded small mt-1 text-left" style="max-height: 200px; overflow-y: auto; font-family: monospace; font-size: 0.75rem;"><code>' . s($pretty) . '</code></pre>';
                    $details_cell .= '</details>';
                }
            }
            
            $table->data[] = [
                '<strong>#' . $order++ . '</strong>',
                $os_browser,
                $details_cell,
                '<code>' . s($d->ip_address) . '</code>',
                $first_reg,
                $last_login,
                $status_badge,
                $action_btn
            ];
        }
        echo html_writer::table($table);
    }
    
    echo '  </div>'; // End table responsive
    echo '</div>'; // End card
    
    // User specific security logs
    $logs = $DB->get_records_sql("
        SELECT l.id, l.action, l.ip_address, l.device_fingerprint, l.timestamp, l.details 
        FROM {auth_devicelock_logs} l 
        WHERE l.userid = ? 
        ORDER BY l.timestamp DESC
    ", [$userid], 0, 50);

    
    echo '<div class="card shadow-sm">';
    echo '  <div class="card-header bg-danger text-white font-weight-bold"><i class="fa fa-shield"></i> Activity & Security History (Last 50 Events)</div>';
    echo '  <div class="card-body p-0 table-responsive">';
    
    if (empty($logs)) {
        echo '    <div class="p-4 text-center text-muted">No events logged for this user yet.</div>';
    } else {
        $logtable = new html_table();
        $logtable->head = ['Time (GMT+2)', 'Event / Action', 'IP Address', 'Fingerprint', 'Metadata / Details'];
        $logtable->attributes['class'] = 'table table-hover table-striped mb-0 align-middle';
        
        foreach ($logs as $l) {
            $timecell = '<span class="lg-log-time">' . device_manager::format_gmt2_date($l->timestamp, 'd M Y, H:i:s') . '</span>';
            
            // Humanize action badges (shared helper).
            $actioncell = auth_devicelock_action_badge($l->action);
            
            $ipcell = '<code>' . s($l->ip_address) . '</code>';
            $fpcell = auth_devicelock_fingerprint_span($l->device_fingerprint);
            
            // Details (styled chips, shared helper).
            $detailscell = auth_devicelock_log_details_cell($l->details);
            
            $logtable->data[] = [$timecell, $actioncell, $ipcell, $fpcell, $detailscell];
        }
        echo html_writer::table($logtable);
        // v3.4.4: click-to-expand behaviour for the event rows.
        auth_devicelock_print_log_expand_js();
    }
    
    echo '  </div>'; // End responsive table
    echo '</div>'; // End card

    echo $OUTPUT->footer();
    exit;
}

// ============================================================
// Per-User Audit Timeline page (action=viewuseraudit).
// A dedicated, filterable + exportable view of every Lock Guard log row
// that belongs to a single user — handy for security investigations.
// ============================================================
if ($action === 'viewuseraudit' && $userid) {
    $targetuser = $DB->get_record('user', ['id' => $userid]);
    if (!$targetuser) {
        \core\notification::error(get_string('deleteuser_notfound', 'auth_devicelock'));
        redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']));
    }

    $audit_action_filter = optional_param('log_action_filter', '', PARAM_ALPHANUMEXT);
    $auditpage = optional_param('auditpage', 0, PARAM_INT);
    $auditperpage = 50;

    echo $OUTPUT->header();

    // Header.
    echo '<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">';
    echo '  <h3><i class="fa fa-history text-info"></i> ' . get_string('audit_timeline_for', 'auth_devicelock', s(fullname($targetuser))) . '</h3>';
    echo '  <div>';
    echo '    <a href="' . new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid, 'tab' => 'users']) . '" class="btn btn-secondary"><i class="fa fa-arrow-left"></i> ' . get_string('audit_timeline_back', 'auth_devicelock') . '</a>';
    echo '  </div>';
    echo '</div>';

    // User identity card.
    echo '<div class="card mb-4 shadow-sm">';
    echo '  <div class="card-header bg-info text-white"><strong><i class="fa fa-id-card"></i> Account</strong></div>';
    echo '  <div class="card-body p-3">';
    echo '    <div class="row small">';
    echo '      <div class="col-md-4"><strong>Full Name:</strong> ' . s(fullname($targetuser)) . '</div>';
    echo '      <div class="col-md-4"><strong>Username:</strong> <span class="font-monospace">' . s($targetuser->username) . '</span></div>';
    echo '      <div class="col-md-4"><strong>Email:</strong> ' . s($targetuser->email) . '</div>';
    echo '      <div class="col-md-4"><strong>Auth:</strong> ' . s($targetuser->auth) . '</div>';
    echo '      <div class="col-md-4"><strong>User ID:</strong> ' . (int)$targetuser->id . '</div>';
    echo '      <div class="col-md-4"><strong>Status:</strong> ' . ($targetuser->suspended ? '<span class="badge badge-danger">Suspended</span>' : '<span class="badge badge-success">Active</span>') . '</div>';
    echo '    </div>';
    echo '  </div>';
    echo '</div>';

    // Build the per-user log query.
    $log_params = ['audit_uid' => $userid];
    $log_where = "l.userid = :audit_uid";
    if ($audit_action_filter !== '') {
        if ($audit_action_filter === 'activity_all') {
            // Pseudo-filter: every user-activity event type at once.
            $log_where .= " AND " . $DB->sql_like('l.action', ':la_actlike', true, true, false);
            $log_params['la_actlike'] = 'activity%';
        } else {
            $log_where .= " AND l.action = :audit_filter";
            $log_params['audit_filter'] = $audit_action_filter;
        }
    }
    $audit_total = $DB->get_manager()->table_exists('auth_devicelock_logs')
        ? $DB->count_records_sql("SELECT COUNT(*) FROM {auth_devicelock_logs} l WHERE $log_where", $log_params)
        : 0;
    $audit_logs = [];
    if ($audit_total > 0 && $DB->get_manager()->table_exists('auth_devicelock_logs')) {
        $audit_logs = $DB->get_records_sql(
            "SELECT l.id, l.userid, l.action, l.ip_address, l.user_agent, l.timestamp, l.details, l.device_fingerprint
             FROM {auth_devicelock_logs} l
             WHERE $log_where
             ORDER BY l.timestamp DESC, l.id DESC",
            $log_params,
            $auditpage * $auditperpage,
            $auditperpage
        );
    }

    // Export link (reuses exportlogscsv with audit_userid).
    $audit_export_url = new moodle_url('/auth/devicelock/admin_devices.php', [
        'action' => 'exportlogscsv', 'sesskey' => sesskey(), 'tab' => 'logs',
        'audit_userid' => $userid, 'log_action_filter' => $audit_action_filter,
    ]);

    echo '<div class="card mb-4 shadow-sm">';
    echo '<div class="card-header d-flex flex-wrap justify-content-between align-items-center">';
    echo '  <strong class="text-info"><i class="fa fa-list-ul"></i> ' . get_string('audit_timeline', 'auth_devicelock') . '</strong> <span class="badge badge-info badge-pill ml-1">' . get_string('audit_timeline_count', 'auth_devicelock', $audit_total) . '</span>';
    echo '  <a href="' . $audit_export_url . '" class="btn btn-sm btn-outline-success"><i class="fa fa-file-csv"></i> ' . get_string('audit_timeline_export', 'auth_devicelock') . '</a>';
    echo '</div>';
    echo '<div class="card-body p-0 table-responsive">';

    // Event-type filter dropdown (same option set as the main logs tab).
    $log_action_groups = [
        'User Activity' => [
            'activity_all'          => 'All User Activity',
            'activity_page'         => 'Page Viewed',
            'activity_course'       => 'Course Viewed',
            'activity_section'      => 'Section Viewed',
            'activity_module'       => 'Activity Viewed',
            'activity_dashboard'    => 'Dashboard Viewed',
            'activity_mycourses'    => 'My Courses Viewed',
            'activity_profile'      => 'Profile Viewed',
            'activity_participants' => 'Participants Viewed',
            'activity_grades'       => 'Grades Viewed',
            'activity_catalog'      => 'Course Catalog Viewed',
            'activity_download'     => 'File Accessed',
            'activity_link'         => 'External Link Opened',
            'activity_click'        => 'Button Clicked',
            'activity_tour'         => 'User Tour',
        ],
        'Device & account' => [
            'login_prevented' => 'Blocked Login', 'device_limit_reached' => 'Limit Blocked',
            'unexpected_device_login' => 'Unexpected Login', 'device_status_blocked' => 'Device Blocked',
            'device_status_active' => 'Device Unblocked', 'new_browser_on_device' => 'New Browser',
            'browser_login' => 'Browser Login', 'device_registered' => 'Registered',
            'device_login' => 'Device Login', 'user_logout' => 'User Logout', 'auth_method_migrated' => 'Migrated',
            'reset_all_devices' => 'Reset User Devices', 'reset_device_browsers' => 'Browsers Reset',
            'browser_limit_reached' => 'Browser Limit', 'reset_all_users_devices' => 'Reset All Users',
            'save_user_limit' => 'Limit Changed', 'send_custom_email' => 'Email Sent',
            'auth_method_changed' => 'Auth Changed', 'send_reset_password' => 'Pwd Reset Sent',
            'generate_temporary_password' => 'Temp Pwd Created', 'change_password_direct' => 'Password Changed',
            'toggle_suspend' => 'Suspend Toggled', 'confirm_user' => 'User Confirmed',
            'copy_user_details' => 'Details Copied', 'delete_user_account' => 'Account Deleted',
            'bulk_delete_user_account' => 'Bulk Deletion', 'clear_all_logs' => 'Logs Cleared',
            'bulk_copy_user_details' => 'Bulk Details Copied', 'bulk_import_users' => 'Bulk User Import',
            'quick_create_user' => 'Quick User Created', 'bulk_create_users' => 'Bulk Users Created',
            'password_changed' => 'Password Changed', 'password_reset_completed' => 'Password Reset Completed',
            'user_migrated' => 'User Migrated', 'user_migrated_bulk' => 'Users Migrated (Bulk)',
            'auth_method_changed_bulk' => 'Auth Changed (Bulk)', 'send_custom_email_bulk' => 'Email Sent (Bulk)',
            'reset_user_browsers' => 'User Browsers Reset',
            'ban_user' => 'User Banned', 'unban_user' => 'User Unbanned',
            'bulk_ban_users' => 'Bulk Ban', 'bulk_unban_users' => 'Bulk Unban',
            'change_course' => 'Courses Changed', 'bulk_change_course' => 'Bulk Course Change',
            'change_role' => 'Roles Changed', 'bulk_change_role' => 'Bulk Role Change',
        ],
    ];

    // Filter form.
    echo '<form method="get" action="' . new moodle_url('/auth/devicelock/admin_devices.php') . '" class="p-2 bg-light border-bottom d-flex align-items-center">';
    echo '<input type="hidden" name="action" value="viewuseraudit">';
    echo '<input type="hidden" name="userid" value="' . (int)$userid . '">';
    echo '<label class="font-weight-bold mr-2 mb-0" for="audit_filter_sel">' . get_string('audit_timeline_filter', 'auth_devicelock') . '</label>';
    echo '<select id="audit_filter_sel" name="log_action_filter" class="form-control form-control-sm" style="max-width:280px;" onchange="this.form.submit();">';
    echo '<option value="">' . get_string('audit_timeline_all_events', 'auth_devicelock') . '</option>';
    foreach ($log_action_groups as $groupname => $opts) {
        echo '<optgroup label="' . s($groupname) . '">';
        foreach ($opts as $val => $label) {
            $sel = ($audit_action_filter === $val) ? ' selected' : '';
            echo '<option value="' . s($val) . '"' . $sel . '>' . s($label) . '</option>';
        }
        echo '</optgroup>';
    }
    echo '</select></form>';

    if (empty($audit_logs)) {
        echo '<div class="p-4 text-center text-muted">' . get_string('audit_timeline_empty', 'auth_devicelock') . '</div>';
    } else {
        $atable = new html_table();
        $atable->head = ['#', 'Time', 'Event / Action', 'IP Address', 'Fingerprint', 'Details'];
        $atable->attributes['class'] = 'table table-hover table-striped mb-0 align-middle';
        $arow = 0;
        foreach ($audit_logs as $al) {
            $arow++;
            $tcell = '<span class="lg-log-time">' . device_manager::format_gmt2_date($al->timestamp, 'd M Y, H:i:s') . '</span>';
            $evcell = auth_devicelock_action_badge($al->action);
            $fpcell = auth_devicelock_fingerprint_span($al->device_fingerprint);
            $detcell = auth_devicelock_log_details_cell($al->details);
            $atable->data[] = [$arow, $tcell, $evcell, s($al->ip_address), $fpcell, $detcell];
        }
        echo html_writer::table($atable);
        // v3.4.4: click-to-expand behaviour for the event rows.
        auth_devicelock_print_log_expand_js();
    }
    echo '</div>'; // card-body

    // Pagination.
    if ($audit_total > $auditperpage) {
        echo '<div class="mt-3 p-3">';
        echo $OUTPUT->render(new \paging_bar(
            $audit_total,
            $auditpage,
            $auditperpage,
            new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuseraudit', 'userid' => $userid, 'log_action_filter' => $audit_action_filter]),
            'auditpage'
        ));
        echo '</div>';
    }
    echo '</div>'; // card

    echo $OUTPUT->footer();
    exit;
}

// ============================================================
// Per-Device Audit Timeline page (action=viewdeviceaudit).
// A dedicated, filterable + exportable view of every Lock Guard log row
// scoped to one device fingerprint — completes the audit trilogy.
// ============================================================
if ($action === 'viewdeviceaudit') {
    // The device fingerprint arrives as a GET param (64-char hex). PARAM_RAW
    // then validated/sanitised below — PARAM_ALPHANUMEXT would strip hex.
    $devicefp = optional_param('devicefp', '', PARAM_RAW);
    $devicefp = trim($devicefp);
    if (strlen($devicefp) !== 64 || !ctype_xdigit($devicefp)) {
        \core\notification::error(get_string('device_audit_no_device', 'auth_devicelock'));
        redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'devices']));
    }

    // Resolve an optional owner user for the identity card.
    $owner = null;
    if ($DB->get_manager()->table_exists('auth_devicelock_devices')) {
        $devrow = $DB->get_record('auth_devicelock_devices', ['device_fingerprint' => $devicefp], '*', IGNORE_MULTIPLE);
        if ($devrow) {
            $owner = $DB->get_record('user', ['id' => $devrow->userid], 'id,firstname,lastname,username,email,auth,suspended', IGNORE_MISSING);
        }
    }

    $audit_action_filter = optional_param('log_action_filter', '', PARAM_ALPHANUMEXT);
    $auditpage = optional_param('auditpage', 0, PARAM_INT);
    $auditperpage = 50;

    echo $OUTPUT->header();

    // Header.
    echo '<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">';
    echo '  <h3><i class="fa fa-history text-info"></i> ' . get_string('device_audit_timeline', 'auth_devicelock') . '</h3>';
    echo '  <a href="' . new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'devices']) . '" class="btn btn-secondary"><i class="fa fa-arrow-left"></i> ' . get_string('device_audit_timeline_back', 'auth_devicelock') . '</a>';
    echo '</div>';

    // Device identity card.
    echo '<div class="card mb-4 shadow-sm">';
    echo '  <div class="card-header bg-info text-white"><strong><i class="fa fa-fingerprint"></i> ' . get_string('device_audit_timeline_for', 'auth_devicelock', s(substr($devicefp, 0, 12) . '…')) . '</strong></div>';
    echo '  <div class="card-body p-3">';
    echo '    <div class="row small">';
    echo '      <div class="col-md-8"><strong>Fingerprint:</strong> <code class="text-monospace">' . s($devicefp) . '</code></div>';
    if ($owner) {
        echo '      <div class="col-md-4"><strong>Owner:</strong> ' . s(fullname($owner)) . ' (<code>' . s($owner->username) . '</code>)</div>';
        echo '      <div class="col-md-4"><strong>Email:</strong> ' . s($owner->email) . '</div>';
        echo '      <div class="col-md-4"><strong>Status:</strong> ' . ($owner->suspended ? '<span class="badge badge-danger">Suspended</span>' : '<span class="badge badge-success">Active</span>') . '</div>';
    } else {
        echo '      <div class="col-md-4 text-muted"><em>No registered device/owner found — showing orphaned log rows only.</em></div>';
    }
    echo '    </div>';
    echo '  </div>';
    echo '</div>';

    // Build the per-device log query.
    $log_params = ['audit_fp' => $devicefp];
    $log_where = "l.device_fingerprint = :audit_fp";
    if ($audit_action_filter !== '') {
        if ($audit_action_filter === 'activity_all') {
            // Pseudo-filter: every user-activity event type at once.
            $log_where .= " AND " . $DB->sql_like('l.action', ':lda_actlike', true, true, false);
            $log_params['lda_actlike'] = 'activity%';
        } else {
            $log_where .= " AND l.action = :audit_filter";
            $log_params['audit_filter'] = $audit_action_filter;
        }
    }
    $audit_total = $DB->get_manager()->table_exists('auth_devicelock_logs')
        ? $DB->count_records_sql("SELECT COUNT(*) FROM {auth_devicelock_logs} l WHERE $log_where", $log_params)
        : 0;
    $audit_logs = [];
    if ($audit_total > 0 && $DB->get_manager()->table_exists('auth_devicelock_logs')) {
        $audit_logs = $DB->get_records_sql(
            "SELECT l.id, l.userid, l.action, l.ip_address, l.user_agent, l.timestamp, l.details, l.device_fingerprint
             FROM {auth_devicelock_logs} l
             WHERE $log_where
             ORDER BY l.timestamp DESC, l.id DESC",
            $log_params,
            $auditpage * $auditperpage,
            $auditperpage
        );
    }

    // Export link (reuses exportlogscsv with a device fingerprint filter).
    $audit_export_url = new moodle_url('/auth/devicelock/admin_devices.php', [
        'action' => 'exportlogscsv', 'sesskey' => sesskey(), 'tab' => 'logs',
        'devicefp' => $devicefp, 'log_action_filter' => $audit_action_filter,
    ]);

    echo '<div class="card mb-4 shadow-sm">';
    echo '<div class="card-header d-flex flex-wrap justify-content-between align-items-center">';
    echo '  <strong class="text-info"><i class="fa fa-list-ul"></i> ' . get_string('device_audit_timeline', 'auth_devicelock') . '</strong> <span class="badge badge-info badge-pill ml-1">' . get_string('device_audit_timeline_count', 'auth_devicelock', $audit_total) . '</span>';
    echo '  <a href="' . $audit_export_url . '" class="btn btn-sm btn-outline-success"><i class="fa fa-file-csv"></i> ' . get_string('device_audit_timeline_export', 'auth_devicelock') . '</a>';
    echo '</div>';
    echo '<div class="card-body p-0 table-responsive">';

    // Event-type filter dropdown (same option set as the per-user audit page).
    $log_action_groups = [
        'User Activity' => [
            'activity_all'          => 'All User Activity',
            'activity_page'         => 'Page Viewed',
            'activity_course'       => 'Course Viewed',
            'activity_section'      => 'Section Viewed',
            'activity_module'       => 'Activity Viewed',
            'activity_dashboard'    => 'Dashboard Viewed',
            'activity_mycourses'    => 'My Courses Viewed',
            'activity_profile'      => 'Profile Viewed',
            'activity_participants' => 'Participants Viewed',
            'activity_grades'       => 'Grades Viewed',
            'activity_catalog'      => 'Course Catalog Viewed',
            'activity_download'     => 'File Accessed',
            'activity_link'         => 'External Link Opened',
            'activity_click'        => 'Button Clicked',
            'activity_tour'         => 'User Tour',
        ],
        'Device & account' => [
            'login_prevented' => 'Blocked Login', 'device_limit_reached' => 'Limit Blocked',
            'unexpected_device_login' => 'Unexpected Login', 'device_status_blocked' => 'Device Blocked',
            'device_status_active' => 'Device Unblocked', 'new_browser_on_device' => 'New Browser',
            'browser_login' => 'Browser Login', 'device_registered' => 'Registered',
            'device_login' => 'Device Login', 'user_logout' => 'User Logout', 'auth_method_migrated' => 'Migrated',
            'reset_all_devices' => 'Reset User Devices', 'reset_device_browsers' => 'Browsers Reset',
            'browser_limit_reached' => 'Browser Limit', 'reset_all_users_devices' => 'Reset All Users',
            'save_user_limit' => 'Limit Changed', 'send_custom_email' => 'Email Sent',
            'auth_method_changed' => 'Auth Changed', 'send_reset_password' => 'Pwd Reset Sent',
            'generate_temporary_password' => 'Temp Pwd Created', 'change_password_direct' => 'Password Changed',
            'toggle_suspend' => 'Suspend Toggled', 'confirm_user' => 'User Confirmed',
            'copy_user_details' => 'Details Copied', 'delete_user_account' => 'Account Deleted',
            'bulk_delete_user_account' => 'Bulk Deletion', 'clear_all_logs' => 'Logs Cleared',
            'bulk_copy_user_details' => 'Bulk Details Copied', 'bulk_import_users' => 'Bulk User Import',
            'quick_create_user' => 'Quick User Created', 'bulk_create_users' => 'Bulk Users Created',
            'password_changed' => 'Password Changed', 'password_reset_completed' => 'Password Reset Completed',
            'user_migrated' => 'User Migrated', 'user_migrated_bulk' => 'Users Migrated (Bulk)',
            'auth_method_changed_bulk' => 'Auth Changed (Bulk)', 'send_custom_email_bulk' => 'Email Sent (Bulk)',
            'reset_user_browsers' => 'User Browsers Reset',
            'ban_user' => 'User Banned', 'unban_user' => 'User Unbanned',
            'bulk_ban_users' => 'Bulk Ban', 'bulk_unban_users' => 'Bulk Unban',
            'change_course' => 'Courses Changed', 'bulk_change_course' => 'Bulk Course Change',
            'change_role' => 'Roles Changed', 'bulk_change_role' => 'Bulk Role Change',
        ],
    ];

    // Filter form.
    echo '<form method="get" action="' . new moodle_url('/auth/devicelock/admin_devices.php') . '" class="p-2 bg-light border-bottom d-flex align-items-center">';
    echo '<input type="hidden" name="action" value="viewdeviceaudit">';
    echo '<input type="hidden" name="devicefp" value="' . s($devicefp) . '">';
    echo '<label class="font-weight-bold mr-2 mb-0" for="audit_filter_sel">' . get_string('audit_timeline_filter', 'auth_devicelock') . '</label>';
    echo '<select id="audit_filter_sel" name="log_action_filter" class="form-control form-control-sm" style="max-width:280px;" onchange="this.form.submit();">';
    echo '<option value="">' . get_string('audit_timeline_all_events', 'auth_devicelock') . '</option>';
    foreach ($log_action_groups as $groupname => $opts) {
        echo '<optgroup label="' . s($groupname) . '">';
        foreach ($opts as $val => $label) {
            $sel = ($audit_action_filter === $val) ? ' selected' : '';
            echo '<option value="' . s($val) . '"' . $sel . '>' . s($label) . '</option>';
        }
        echo '</optgroup>';
    }
    echo '</select></form>';

    if (empty($audit_logs)) {
        echo '<div class="p-4 text-center text-muted">' . get_string('device_audit_timeline_empty', 'auth_devicelock') . '</div>';
    } else {
        $atable = new html_table();
        $atable->head = ['#', 'Time', 'User', 'Event / Action', 'IP Address', 'Details'];
        $atable->attributes['class'] = 'table table-hover table-striped mb-0 align-middle';
        $arow = 0;
        $usercache = [];
        foreach ($audit_logs as $al) {
            $arow++;
            if (!isset($usercache[$al->userid])) {
                $urec = $DB->get_record('user', ['id' => $al->userid], 'id,firstname,lastname,username,deleted', IGNORE_MISSING);
                $usercache[$al->userid] = $urec ? $urec : null;
            }
            $ucell = $usercache[$al->userid] ? s(fullname($usercache[$al->userid])) : '<span class="text-muted">#' . (int)$al->userid . '</span>';
            $tcell = '<span class="lg-log-time">' . device_manager::format_gmt2_date($al->timestamp, 'd M Y, H:i:s') . '</span>';
            $evcell = auth_devicelock_action_badge($al->action);
            $detcell = auth_devicelock_log_details_cell($al->details);
            $atable->data[] = [$arow, $tcell, $ucell, $evcell, s($al->ip_address), $detcell];
        }
        echo html_writer::table($atable);
        // v3.4.4: click-to-expand behaviour for the event rows.
        auth_devicelock_print_log_expand_js();
    }
    echo '</div>'; // card-body

    // Pagination.
    if ($audit_total > $auditperpage) {
        echo '<div class="mt-3 p-3">';
        echo $OUTPUT->render(new \paging_bar(
            $audit_total,
            $auditpage,
            $auditperpage,
            new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewdeviceaudit', 'devicefp' => $devicefp, 'log_action_filter' => $audit_action_filter]),
            'auditpage'
        ));
        echo '</div>';
    }
    echo '</div>'; // card

    echo $OUTPUT->footer();
    exit;
}

// ============================================================
// In-Browser Security Snapshot page (action=viewsnapshot).
// Renders the same digest as the weekly email + a "Send Test Email" button.
// ============================================================
if ($action === 'viewsnapshot') {
    require_once(__DIR__ . '/classes/task/weekly_snapshot_task.php');
    $task = new \auth_devicelock\task\weekly_snapshot_task();

    echo $OUTPUT->header();

    // Header.
    echo '<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">';
    echo '  <h2><i class="fa fa-envelope text-primary"></i> ' . get_string('snapshot_page_title', 'auth_devicelock') . '</h2>';
    $testurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'sendsnapshottest', 'sesskey' => sesskey(), 'tab' => $tab]);
    echo '  <a href="' . $testurl . '" class="btn btn-primary" onclick="return confirm(\'' . s(get_string('snapshot_send_test_confirm', 'auth_devicelock')) . '\');"><i class="fa fa-paper-plane"></i> ' . get_string('snapshot_send_test', 'auth_devicelock') . '</a>';
    echo '</div>';

    // Show disabled notice if the setting is off.
    if (!get_config('auth_devicelock', 'snapshot_enabled')) {
        echo '<div class="alert alert-warning"><i class="fa fa-exclamation-triangle"></i> ' . get_string('snapshot_disabled', 'auth_devicelock') . '</div>';
    }

    // Build the snapshot data via the SHARED helper (single source of truth —
    // the weekly email task + this page + the send-test action all reuse it).
    $snapdata = auth_devicelock_build_snapshot_data(7);
    $trend = $snapdata['trend'];
    $dist = $snapdata['dist'];
    $dist_total = $snapdata['dist_total'];
    $toprisk = $snapdata['toprisk'];

    // Last-sent timestamp (config_plugin setting, recorded by the weekly task).
    $last_sent = (int)get_config('auth_devicelock', 'snapshot_last_sent');
    if ($last_sent > 0) {
        $last_sent_str = userdate($last_sent, get_string('strftimedatetimeshort', 'langconfig'));
        echo '<div class="alert alert-secondary small mb-3"><i class="fa fa-clock"></i> ' . get_string('snapshot_last_sent', 'auth_devicelock', $last_sent_str) . '</div>';

        // Next-due countdown: the weekly task runs Monday 06:00. If last_sent
        // is more than 7 days ago, the next run is "today at 06:00" (or
        // already past); otherwise it's next Monday 06:00.
        $next_monday = strtotime('next Monday 06:00', $last_sent);
        if ($next_monday <= time()) {
            // Already past — the next run is the upcoming Monday.
            $next_monday = strtotime('next Monday 06:00');
        }
        $next_due_str = userdate($next_monday, get_string('strftimedatetimeshort', 'langconfig'));
        $days_until = max(0, (int)round(($next_monday - time()) / 86400));
        echo '<div class="alert alert-info small mb-3"><i class="fa fa-calendar"></i> ' . get_string('snapshot_next_due', 'auth_devicelock', $next_due_str . ' (' . $days_until . ' day' . ($days_until === 1 ? '' : 's') . ')') . '</div>';
    } else {
        echo '<div class="alert alert-info small mb-3"><i class="fa fa-calendar"></i> ' . get_string('snapshot_next_due_unknown', 'auth_devicelock') . '</div>';
    }

    // Render trends card.
    echo '<div class="card mb-4 shadow-sm">';
    echo '<div class="card-header bg-primary text-white"><strong><i class="fa fa-chart-line"></i> ' . get_string('snapshot_section_trends', 'auth_devicelock') . '</strong></div>';
    echo '<div class="card-body">';
    echo '<div class="row text-center">';
    $trend_cards = [
        ['label' => get_string('security_trends_blocked_logins', 'auth_devicelock'), 'val' => $trend['blocked'], 'color' => 'danger', 'icon' => 'fa-ban'],
        ['label' => get_string('security_trends_device_regs', 'auth_devicelock'), 'val' => $trend['regs'], 'color' => 'success', 'icon' => 'fa-mobile'],
        ['label' => get_string('security_trends_deletions', 'auth_devicelock'), 'val' => $trend['deletions'], 'color' => 'dark', 'icon' => 'fa-trash'],
    ];
    foreach ($trend_cards as $tc) {
        echo '<div class="col-md-4 mb-2">';
        echo '<div class="card border-' . $tc['color'] . ' h-100"><div class="card-body p-2">';
        echo '<i class="fa ' . $tc['icon'] . ' fa-2x text-' . $tc['color'] . ' mb-1"></i>';
        echo '<h4 class="text-' . $tc['color'] . '">' . (int)$tc['val'] . '</h4>';
        echo '<small class="text-muted">' . s($tc['label']) . '</small>';
        echo '</div></div></div>';
    }
    echo '</div></div></div>';

    // Render distribution card.
    echo '<div class="card mb-4 shadow-sm">';
    echo '<div class="card-header bg-info text-white"><strong><i class="fa fa-chart-bar"></i> ' . get_string('snapshot_section_distribution', 'auth_devicelock') . ' (' . $dist_total . ')</strong></div>';
    echo '<div class="card-body">';
    $bandcolours = ['high' => '#16a34a', 'good' => '#2563eb', 'fair' => '#f59e0b', 'poor' => '#dc2626', 'critical' => '#1f2937'];
    $bandlabels = [
        'high' => get_string('security_score_high', 'auth_devicelock'),
        'good' => get_string('security_score_good', 'auth_devicelock'),
        'fair' => get_string('security_score_fair', 'auth_devicelock'),
        'poor' => get_string('security_score_poor', 'auth_devicelock'),
        'critical' => get_string('security_score_critical', 'auth_devicelock'),
    ];
    echo '<table class="table table-sm">';
    foreach ($bandcolours as $band => $colour) {
        echo '<tr><td style="width:20px;"><span style="color:' . $colour . '; font-size:1.5rem;">&#9632;</span></td><td>' . s($bandlabels[$band]) . '</td><td class="text-right font-weight-bold">' . (int)$dist[$band] . '</td></tr>';
    }
    echo '</table></div></div>';

    // Render top-risk card.
    echo '<div class="card mb-4 shadow-sm">';
    echo '<div class="card-header bg-danger text-white"><strong><i class="fa fa-exclamation-triangle"></i> ' . get_string('snapshot_section_toprisk', 'auth_devicelock') . '</strong></div>';
    echo '<div class="card-body p-0">';
    if (empty($toprisk)) {
        echo '<div class="p-3 text-muted">' . get_string('snapshot_no_data', 'auth_devicelock') . '</div>';
    } else {
        echo '<table class="table table-sm table-striped mb-0"><thead><tr><th>#</th><th>User</th><th>Username</th><th>Email</th><th>Score</th></tr></thead><tbody>';
        $i = 0;
        foreach ($toprisk as $tr) {
            $i++;
            echo '<tr><td>' . $i . '</td><td class="font-weight-bold">' . s($tr['fullname']) . '</td><td class="font-monospace">@' . s($tr['username']) . '</td><td>' . s($tr['email']) . '</td><td><span class="badge badge-danger">' . (int)$tr['score'] . '</span></td></tr>';
        }
        echo '</tbody></table>';
    }
    echo '</div></div>';

    echo $OUTPUT->footer();
    exit;
}

// ============================================================
// Ban User confirmation form (asks for ban reason).
// ============================================================
if ($action === 'banuserform' && $userid) {
    require_sesskey();
    echo $OUTPUT->header();
    $targetuser = $DB->get_record('user', ['id' => $userid]);
    $redirect_to_viewuser = optional_param('redirect_to_viewuser', 0, PARAM_BOOL);
    if (!$targetuser) {
        \core\notification::error(get_string('usernotfound', 'auth_devicelock'));
        redirect(new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']));
    }
    $cancelurl = $redirect_to_viewuser
        ? new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $userid])
        : new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']);
    echo '<div class="card border-danger shadow mx-auto my-4" style="max-width: 580px; border-radius: 12px; overflow: hidden;">';
    echo '  <div class="card-header bg-danger text-white py-3"><h5 class="mb-0 text-white"><i class="fa fa-ban mr-2"></i> ' . get_string('ban_user_title', 'auth_devicelock') . '</h5></div>';
    echo '  <div class="card-body p-4">';
    echo '    <p class="font-weight-bold">' . s(fullname($targetuser)) . ' <span class="text-muted small">(@' . s($targetuser->username) . ')</span></p>';
    echo '    <div class="alert alert-warning small">' . get_string('ban_user_intro', 'auth_devicelock') . '</div>';
    $formurl = new moodle_url('/auth/devicelock/admin_devices.php');
    echo '    <form method="post" action="' . $formurl . '">';
    echo '      <input type="hidden" name="action" value="banuser">';
    echo '      <input type="hidden" name="confirm" value="1">';
    echo '      <input type="hidden" name="sesskey" value="' . sesskey() . '">';
    echo '      <input type="hidden" name="userid" value="' . (int)$userid . '">';
    echo '      <input type="hidden" name="redirect_to_viewuser" value="' . (int)$redirect_to_viewuser . '">';
    echo '      <div class="form-group">';
    echo '        <label for="ban_reason"><strong>' . get_string('ban_reason_label', 'auth_devicelock') . '</strong></label>';
    echo '        <textarea name="ban_reason" id="ban_reason" class="form-control" rows="3" placeholder="' . s(get_string('ban_reason_desc', 'auth_devicelock')) . '"></textarea>';
    echo '      </div>';
    echo '      <div class="d-flex justify-content-between">';
    echo '        <a href="' . $cancelurl . '" class="btn btn-secondary px-4"><i class="fa fa-times"></i> ' . get_string('backtolist', 'auth_devicelock') . '</a>';
    echo '        <button type="submit" class="btn btn-danger px-4"><i class="fa fa-ban"></i> ' . get_string('ban_confirm_btn', 'auth_devicelock') . '</button>';
    echo '      </div>';
    echo '    </form>';
    echo '  </div>';
    echo '</div>';
    echo $OUTPUT->footer();
    exit;
}

// ============================================================
// Bulk Ban confirmation form (asks for ban reason).
// ============================================================
if ($action === 'bulkbanusers' && !$confirm) {
    require_sesskey();
    $selected = optional_param_array('selected_users', [], PARAM_INT);
    $selected = array_values(array_filter(array_map('intval', $selected), function ($x) { return $x > 2; }));
    $cancelurl = new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'userpage' => $userpage]);
    if (empty($selected)) {
        \core\notification::error(get_string('bulk_delete_none_selected', 'auth_devicelock'));
        redirect($cancelurl);
    }
    echo $OUTPUT->header();
    echo '<div class="card border-danger shadow mx-auto my-4" style="max-width: 720px; border-radius: 12px; overflow: hidden;">';
    echo '  <div class="card-header bg-danger text-white py-3"><h5 class="mb-0 text-white"><i class="fa fa-ban mr-2"></i> ' . get_string('bulk_ban_title', 'auth_devicelock') . '</h5></div>';
    echo '  <div class="card-body p-4">';
    echo '    <div class="alert alert-warning">' . get_string('bulk_ban_intro', 'auth_devicelock', count($selected)) . '</div>';
    $formurl = new moodle_url('/auth/devicelock/admin_devices.php');
    echo '    <form method="post" action="' . $formurl . '">';
    echo '      <input type="hidden" name="action" value="bulkbanusers">';
    echo '      <input type="hidden" name="confirm" value="1">';
    echo '      <input type="hidden" name="sesskey" value="' . sesskey() . '">';
    echo '      <input type="hidden" name="tab" value="users">';
    foreach ($selected as $sid) {
        echo '      <input type="hidden" name="selected_users[]" value="' . (int)$sid . '">';
    }
    echo '      <div class="form-group">';
    echo '        <label for="ban_reason"><strong>' . get_string('ban_reason_label', 'auth_devicelock') . '</strong></label>';
    echo '        <textarea name="ban_reason" id="ban_reason" class="form-control" rows="3" placeholder="' . s(get_string('ban_reason_desc', 'auth_devicelock')) . '"></textarea>';
    echo '      </div>';
    echo '      <div class="d-flex justify-content-between">';
    echo '        <a href="' . $cancelurl . '" class="btn btn-secondary px-4"><i class="fa fa-times"></i> Cancel</a>';
    echo '        <button type="submit" class="btn btn-danger px-4"><i class="fa fa-ban"></i> ' . get_string('bulk_ban_confirm_btn', 'auth_devicelock') . '</button>';
    echo '      </div>';
    echo '    </form>';
    echo '  </div>';
    echo '</div>';
    echo $OUTPUT->footer();
    exit;
}

// ============================================================
// Bulk Change Course form (confirm=0): pick the REPLACEMENT set of
// courses (with shared role and per-course days) for every selected
// user. All courses start UNCHECKED - whatever gets checked overrides
// ALL courses for ALL selected users.
// ============================================================
if ($action === 'bulkchangecourseform' && !$confirm) {
    require_sesskey();
    $selected = optional_param_array('selected_users', [], PARAM_INT);
    $selected = array_values(array_unique(array_filter(array_map('intval', $selected), function ($x) { return $x > 2; })));
    $cancelurl = new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'userpage' => $userpage]);
    if (empty($selected)) {
        \core\notification::error(get_string('bulk_delete_none_selected', 'auth_devicelock'));
        redirect($cancelurl);
    }

    // Partition: processable vs skipped-for-safety (self / guest / siteadmin).
    $copyable = [];
    $skipped = [];
    foreach ($selected as $sid) {
        $su = $DB->get_record('user', ['id' => $sid], 'id,firstname,lastname,username,email,auth', IGNORE_MISSING);
        if (!$su || $su->deleted) {
            continue;
        }
        if (is_siteadmin($sid) || $sid == $USER->id || isguestuser($sid)) {
            $skipped[] = $su;
            continue;
        }
        $copyable[] = $su;
    }

    if (empty($copyable)) {
        \core\notification::error(get_string('bulk_delete_none_selected', 'auth_devicelock'));
        redirect($cancelurl);
    }

    echo $OUTPUT->header();
    echo '<div class="card border-info shadow mx-auto my-4" style="max-width: 860px; border-radius: 12px; overflow: hidden;">';
    echo '  <div class="card-header bg-info text-white py-3"><h5 class="mb-0 text-white"><i class="fa fa-graduation-cap mr-2"></i> ' . get_string('bulk_change_course_title', 'auth_devicelock') . '</h5></div>';
    echo '  <div class="card-body p-4">';
    echo '    <div class="alert alert-warning">' . get_string('bulk_change_course_intro', 'auth_devicelock', count($copyable)) . '</div>';
    if (!empty($skipped)) {
        echo '    <div class="alert alert-secondary"><strong><i class="fa fa-shield-alt"></i> ' . get_string('bulk_delete_skipped_label', 'auth_devicelock') . '</strong><br>' . implode(', ', array_map(function ($s) { return s(fullname($s) . ' (@' . $s->username . ')'); }, $skipped)) . '</div>';
    }

    $allcourses = $DB->get_records_sql("
        SELECT c.id, c.fullname, c.shortname, c.visible, cc.name AS catname
          FROM {course} c
          JOIN {course_categories} cc ON cc.id = c.category
         WHERE c.id > 1
      ORDER BY cc.sortorder, c.sortorder");
    $allroles = $DB->get_records('role', null, 'sortorder ASC', 'id, name, shortname');
    $studentrole = $DB->get_record('role', ['shortname' => 'student'], 'id', IGNORE_MISSING);
    $defaultroleid = $studentrole ? (int)$studentrole->id : 0;

    $formurl = new moodle_url('/auth/devicelock/admin_devices.php');
    echo '    <form method="post" action="' . $formurl . '" id="lg-bulkchangecourse-form">';
    echo '      <input type="hidden" name="action" value="bulkchangecourse">';
    echo '      <input type="hidden" name="confirm" value="1">';
    echo '      <input type="hidden" name="sesskey" value="' . sesskey() . '">';
    echo '      <input type="hidden" name="tab" value="users">';
    echo '      <input type="hidden" name="user_search" value="' . s($user_search) . '">';
    echo '      <input type="hidden" name="userpage" value="' . (int)$userpage . '">';
    foreach ($copyable as $su) {
        echo '      <input type="hidden" name="selected_users[]" value="' . (int)$su->id . '">';
    }

    // Role used for every enrolment (default: Student).
    echo '      <div class="form-group">';
    echo '        <label class="font-weight-bold" for="bc2_role">' . get_string('change_course_role', 'auth_devicelock') . '</label>';
    echo '        <select name="bc2_role" id="bc2_role" class="form-control" style="max-width:320px;">';
    foreach ($allroles as $role) {
        $rname = !empty($role->name) ? $role->name : ucfirst($role->shortname);
        $sel = ((int)$role->id === $defaultroleid) ? ' selected' : '';
        echo '          <option value="' . (int)$role->id . '"' . $sel . '>' . s($rname) . ' (' . s($role->shortname) . ')</option>';
    }
    echo '        </select>';
    echo '        <small class="form-text text-muted">' . get_string('change_course_role_hint', 'auth_devicelock') . '</small>';
    echo '      </div>';

    // Course list: ALL UNCHECKED, per-course days.
    echo '      <div class="form-group mt-2">';
    echo '        <label class="font-weight-bold">' . get_string('enrol_courses_label', 'auth_devicelock') . '</label>';
    echo '        <div class="small text-muted mb-1">' . get_string('change_course_days_hint', 'auth_devicelock') . '</div>';
    if (!empty($allcourses)) {
        echo '        <input type="text" class="form-control form-control-sm mb-2" placeholder="' . s(get_string('enrol_search_courses', 'auth_devicelock')) . '" onkeyup="lgFilterBc2CourseList(this.value)">';
        echo '        <div class="form-check mb-2"><label class="form-check-label"><input type="checkbox" class="form-check-input mr-2" onclick="lgToggleBc2Courses(this.checked)"> <span class="font-weight-bold">' . s(get_string('enrol_select_all', 'auth_devicelock')) . '</span></label></div>';
        echo '        <div id="bc2-course-list" class="border rounded p-2 mb-2" style="max-height:320px; overflow-y:auto;">';
        // Column header row (Course / Days).
        echo '          <div class="d-flex small text-muted font-weight-bold border-bottom pb-1 mb-1">';
        echo '            <div class="flex-grow-1">' . s(get_string('change_course_course_col', 'auth_devicelock')) . '</div>';
        echo '            <div style="min-width:140px; text-align:right;">' . s(get_string('change_course_days_col', 'auth_devicelock')) . '</div>';
        echo '          </div>';
        foreach ($allcourses as $course) {
            $cid = (int)$course->id;
            $csearch = s($course->fullname . ' ' . $course->shortname . ' ' . $course->catname);
            echo '          <div class="d-flex align-items-center py-1" data-search="' . $csearch . '">';
            echo '            <div class="form-check mb-0 flex-grow-1">';
            echo '              <label class="form-check-label">';
            echo '                <input type="checkbox" name="bc2_courses[]" value="' . $cid . '" class="form-check-input mr-2"> '
                . format_string($course->fullname) . ' <small class="text-muted">(' . s($course->shortname) . ')</small>'
                . ($course->visible ? '' : ' <span class="badge badge-warning">' . s(get_string('enrol_course_hidden', 'auth_devicelock')) . '</span>');
            echo '              </label>';
            echo '            </div>';
            echo '            <div class="d-flex align-items-center">';
            echo '              <input type="number" name="bc2_days[' . $cid . ']" value="0" min="0" max="3650" class="form-control form-control-sm" style="max-width:110px;" title="' . s(get_string('change_course_days_hint', 'auth_devicelock')) . '">';
            echo '              <small class="text-muted ml-1">' . s(get_string('change_course_days_col', 'auth_devicelock')) . '</small>';
            echo '            </div>';
            echo '          </div>';
        }
        echo '        </div>';
    } else {
        echo '        <div class="alert alert-secondary small mb-0">' . s(get_string('change_course_none', 'auth_devicelock')) . '</div>';
    }
    echo '      </div>';
    echo '      <div class="d-flex justify-content-between">';
    echo '        <a href="' . $cancelurl . '" class="btn btn-secondary px-4"><i class="fa fa-times"></i> ' . get_string('cancel', 'moodle') . '</a>';
    echo '        <button type="submit" class="btn btn-info px-4"><i class="fa fa-graduation-cap"></i> ' . get_string('bulk_change_course_save', 'auth_devicelock', count($copyable)) . '</button>';
    echo '      </div>';
    echo '    </form>';
    echo '  </div>';
    echo '</div>';
    // Self-contained copies of the course-list helpers (scoped to this
    // page's list id, so this form never depends on another page's script).
    echo '<script>' . "\n";
    echo <<<'EOJS'
function lgFilterBc2CourseList(query) {
    var list = document.getElementById('bc2-course-list');
    if (!list) { return; }
    query = (query || '').toLowerCase();
    var items = list.querySelectorAll('[data-search]');
    for (var k = 0; k < items.length; k++) {
        var hay = items[k].getAttribute('data-search') || '';
        items[k].style.display = (hay.toLowerCase().indexOf(query) !== -1) ? '' : 'none';
    }
}
function lgToggleBc2Courses(checked) {
    var list = document.getElementById('bc2-course-list');
    if (!list) { return; }
    var boxes = list.querySelectorAll('input[type="checkbox"]');
    for (var k = 0; k < boxes.length; k++) { boxes[k].checked = checked; }
}
EOJS;
    echo '</script>';
    echo $OUTPUT->footer();
    exit;
}

// ============================================================
// Bulk Change Role form (confirm=0): pick the REPLACEMENT set of
// site-level roles for every selected user. All roles start
// UNCHECKED - whatever gets checked overrides ALL system roles for
// ALL selected users (guest/user assignments are never touched).
// ============================================================
if ($action === 'bulkchangeroleform' && !$confirm) {
    require_sesskey();
    $selected = optional_param_array('selected_users', [], PARAM_INT);
    $selected = array_values(array_unique(array_filter(array_map('intval', $selected), function ($x) { return $x > 2; })));
    $cancelurl = new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'userpage' => $userpage]);
    if (empty($selected)) {
        \core\notification::error(get_string('bulk_delete_none_selected', 'auth_devicelock'));
        redirect($cancelurl);
    }

    // Partition: processable vs skipped-for-safety (self / guest / siteadmin).
    $copyable = [];
    $skipped = [];
    foreach ($selected as $sid) {
        $su = $DB->get_record('user', ['id' => $sid], 'id,firstname,lastname,username,email,auth', IGNORE_MISSING);
        if (!$su || $su->deleted) {
            continue;
        }
        if (is_siteadmin($sid) || $sid == $USER->id || isguestuser($sid)) {
            $skipped[] = $su;
            continue;
        }
        $copyable[] = $su;
    }

    if (empty($copyable)) {
        \core\notification::error(get_string('bulk_delete_none_selected', 'auth_devicelock'));
        redirect($cancelurl);
    }

    $allroles = $DB->get_records('role', null, 'sortorder ASC', 'id, name, shortname');
    // Manageable role universe (guest/user are never manageable).
    $manageableroles = [];
    foreach ($allroles as $role) {
        if ($role->shortname === 'guest' || $role->shortname === 'user') {
            continue;
        }
        $manageableroles[] = $role;
    }

    echo $OUTPUT->header();
    echo '<div class="card border-primary shadow mx-auto my-4" style="max-width: 720px; border-radius: 12px; overflow: hidden;">';
    echo '  <div class="card-header bg-primary text-white py-3"><h5 class="mb-0 text-white"><i class="fa fa-user-tag mr-2"></i> ' . get_string('bulk_change_role_title', 'auth_devicelock') . '</h5></div>';
    echo '  <div class="card-body p-4">';
    echo '    <div class="alert alert-warning">' . get_string('bulk_change_role_intro', 'auth_devicelock', count($copyable)) . '</div>';
    if (!empty($skipped)) {
        echo '    <div class="alert alert-secondary"><strong><i class="fa fa-shield-alt"></i> ' . get_string('bulk_delete_skipped_label', 'auth_devicelock') . '</strong><br>' . implode(', ', array_map(function ($s) { return s(fullname($s) . ' (@' . $s->username . ')'); }, $skipped)) . '</div>';
    }

    $formurl = new moodle_url('/auth/devicelock/admin_devices.php');
    echo '    <form method="post" action="' . $formurl . '">';
    echo '      <input type="hidden" name="action" value="bulkchangerole">';
    echo '      <input type="hidden" name="confirm" value="1">';
    echo '      <input type="hidden" name="sesskey" value="' . sesskey() . '">';
    echo '      <input type="hidden" name="tab" value="users">';
    echo '      <input type="hidden" name="user_search" value="' . s($user_search) . '">';
    echo '      <input type="hidden" name="userpage" value="' . (int)$userpage . '">';
    foreach ($copyable as $su) {
        echo '      <input type="hidden" name="selected_users[]" value="' . (int)$su->id . '">';
    }

    if (!empty($manageableroles)) {
        echo '      <div class="form-group">';
        echo '        <label class="font-weight-bold">' . get_string('change_role', 'auth_devicelock') . '</label>';
        echo '        <div class="border rounded p-2" style="max-height:300px; overflow-y:auto;">';
        foreach ($manageableroles as $role) {
            $rname = !empty($role->name) ? $role->name : ucfirst($role->shortname);
            echo '          <div class="form-check">';
            echo '            <label class="form-check-label"><input type="checkbox" name="br2_roles[]" value="' . (int)$role->id . '" class="form-check-input mr-2"> ' . s($rname) . ' <small class="text-muted">(' . s($role->shortname) . ')</small></label>';
            echo '          </div>';
        }
        echo '        </div>';
        echo '      </div>';
    } else {
        echo '      <div class="alert alert-secondary small mb-0">' . s(get_string('change_role_none', 'auth_devicelock')) . '</div>';
    }
    echo '      <div class="d-flex justify-content-between">';
    echo '        <a href="' . $cancelurl . '" class="btn btn-secondary px-4"><i class="fa fa-times"></i> ' . get_string('cancel', 'moodle') . '</a>';
    echo '        <button type="submit" class="btn btn-primary px-4"><i class="fa fa-user-tag"></i> ' . get_string('bulk_change_role_save', 'auth_devicelock', count($copyable)) . '</button>';
    echo '      </div>';
    echo '    </form>';
    echo '  </div>';
    echo '</div>';
    echo $OUTPUT->footer();
    exit;
}

// ============================================================
// Quick Create User form.
// ============================================================
if ($action === 'quickcreateuserform') {
    echo $OUTPUT->header();
    echo '<div class="card border-info shadow mx-auto my-4" style="max-width: 620px; border-radius: 12px; overflow: hidden;">';
    echo '  <div class="card-header bg-info text-white py-3"><h5 class="mb-0 text-white"><i class="fa fa-user-plus mr-2"></i> ' . get_string('quick_create_title', 'auth_devicelock') . '</h5></div>';
    echo '  <div class="card-body p-4">';
    echo '    <div class="alert alert-info small">' . get_string('quick_create_intro', 'auth_devicelock') . '</div>';
    $formurl = new moodle_url('/auth/devicelock/admin_devices.php');
    echo '    <form method="post" action="' . $formurl . '" id="lg-quickcreate-form">';
    echo '      <input type="hidden" name="action" value="quickcreateuser">';
    echo '      <input type="hidden" name="sesskey" value="' . sesskey() . '">';
    // Username.
    echo '      <div class="form-group row align-items-center">';
    echo '        <label class="col-sm-3 col-form-label font-weight-bold">' . get_string('quick_create_username', 'auth_devicelock') . '</label>';
    echo '        <div class="col-sm-6"><input type="text" name="qc_username" class="form-control" placeholder="username" maxlength="100" required aria-required="true"></div>';
    echo '        <div class="col-sm-3"><label class="form-check-label"><input type="checkbox" name="qc_autogen_user" value="1" class="form-check-input mr-1"> ' . get_string('quick_create_autogen', 'auth_devicelock') . '</label></div>';
    echo '      </div>';
    // v3.4.4: First name + Last name (one shared Auto-generate checkbox on
    // the Last name row fills a random realistic name pair).
    echo '      <div class="form-group row align-items-center">';
    echo '        <label class="col-sm-3 col-form-label font-weight-bold">' . get_string('quick_create_firstname', 'auth_devicelock') . '</label>';
    echo '        <div class="col-sm-6"><input type="text" name="qc_firstname" class="form-control" placeholder="John" maxlength="100" required aria-required="true"></div>';
    echo '        <div class="col-sm-3"></div>';
    echo '      </div>';
    echo '      <div class="form-group row align-items-center">';
    echo '        <label class="col-sm-3 col-form-label font-weight-bold">' . get_string('quick_create_lastname', 'auth_devicelock') . '</label>';
    echo '        <div class="col-sm-6"><input type="text" name="qc_lastname" class="form-control" placeholder="Doe" maxlength="100" required aria-required="true"></div>';
    echo '        <div class="col-sm-3"><label class="form-check-label"><input type="checkbox" name="qc_autogen_name" value="1" class="form-check-input mr-1"> ' . get_string('quick_create_autogen', 'auth_devicelock') . '</label></div>';
    echo '      </div>';
    // Email.
    echo '      <div class="form-group row align-items-center">';
    echo '        <label class="col-sm-3 col-form-label font-weight-bold">' . get_string('quick_create_email', 'auth_devicelock') . '</label>';
    echo '        <div class="col-sm-6"><input type="email" name="qc_email" class="form-control" placeholder="user@example.com" maxlength="100" required aria-required="true"></div>';
    echo '        <div class="col-sm-3"><label class="form-check-label"><input type="checkbox" name="qc_autogen_email" value="1" class="form-check-input mr-1"> ' . get_string('quick_create_autogen', 'auth_devicelock') . '</label></div>';
    echo '      </div>';
    // Password.
    echo '      <div class="form-group row align-items-center">';
    echo '        <label class="col-sm-3 col-form-label font-weight-bold">' . get_string('quick_create_password', 'auth_devicelock') . '</label>';
    echo '        <div class="col-sm-6"><input type="text" name="qc_password" class="form-control" placeholder="password" maxlength="255" required aria-required="true"></div>';
    echo '        <div class="col-sm-3"><label class="form-check-label"><input type="checkbox" name="qc_autogen_pass" value="1" class="form-check-input mr-1"> ' . get_string('quick_create_autogen', 'auth_devicelock') . '</label></div>';
    echo '      </div>';
    // Role selection.
    $allroles = $DB->get_records('role', null, 'sortorder ASC', 'id, name, shortname');
    echo '      <div class="form-group mt-2">';
    echo '        <label class="font-weight-bold">' . get_string('bulk_create_roles', 'auth_devicelock') . '</label>';
    echo '        <div class="border rounded p-2 mb-2" style="max-height:200px; overflow-y:auto;">';
    foreach ($allroles as $role) {
        $rname = !empty($role->name) ? $role->name : ucfirst($role->shortname);
        echo '          <div class="form-check"><label class="form-check-label"><input type="checkbox" name="qc_roles[]" value="' . (int)$role->id . '" class="form-check-input mr-2"> ' . s($rname) . ' <small class="text-muted">(' . s($role->shortname) . ')</small></label></div>';
    }
    echo '        </div>';
    echo '        <input type="text" name="qc_custom_role" class="form-control" placeholder="' . s(get_string('bulk_create_custom_role', 'auth_devicelock')) . '">';
    echo '      </div>';
    // Optional: enrol the new user into existing courses.
    $allcourses = $DB->get_records_sql("
        SELECT c.id, c.fullname, c.shortname, c.visible, cc.name AS catname
          FROM {course} c
          JOIN {course_categories} cc ON cc.id = c.category
         WHERE c.id > 1
      ORDER BY cc.sortorder, c.sortorder");
    $studentrole = $DB->get_record('role', ['shortname' => 'student'], 'id', IGNORE_MISSING);
    $defaultroleid = $studentrole ? (int)$studentrole->id : 0;
    echo '      <div class="form-group mt-2">';
    echo '        <label class="font-weight-bold">' . get_string('enrol_courses_label', 'auth_devicelock') . '</label>';
    echo '        <div class="small text-muted mb-1">' . get_string('enrol_courses_hint', 'auth_devicelock') . '</div>';
    if (!empty($allcourses)) {
        echo '        <input type="text" class="form-control form-control-sm mb-2" placeholder="' . s(get_string('enrol_search_courses', 'auth_devicelock')) . '" onkeyup="lgFilterCourseList(\'qc-course-list\', this.value)">';
        echo '        <div class="form-check mb-2"><label class="form-check-label"><input type="checkbox" class="form-check-input mr-2" onclick="lgToggleAllCourses(\'qc-course-list\', this.checked)"> <span class="font-weight-bold">' . s(get_string('enrol_select_all', 'auth_devicelock')) . '</span></label></div>';
        echo '        <div id="qc-course-list" class="border rounded p-2 mb-2" style="max-height:220px; overflow-y:auto;">';
        foreach ($allcourses as $course) {
            $csearch = s($course->fullname . ' ' . $course->shortname . ' ' . $course->catname);
            echo '          <div class="form-check" data-search="' . $csearch . '">';
            echo '            <label class="form-check-label"><input type="checkbox" name="qc_courses[]" value="' . (int)$course->id . '" class="form-check-input mr-2"> ' . format_string($course->fullname) . ' <small class="text-muted">(' . s($course->shortname) . ')</small>' . ($course->visible ? '' : ' <span class="badge badge-warning">' . s(get_string('enrol_course_hidden', 'auth_devicelock')) . '</span>') . '</label>';
            echo '          </div>';
        }
        echo '        </div>';
        echo '        <div class="row">';
        echo '          <div class="col-sm-6">';
        echo '            <label class="font-weight-bold" for="qc_enrol_role">' . get_string('enrol_role_label', 'auth_devicelock') . '</label>';
        echo '            <select name="qc_enrol_role" id="qc_enrol_role" class="form-control">';
        foreach ($allroles as $role) {
            $rname = !empty($role->name) ? $role->name : ucfirst($role->shortname);
            $sel = ((int)$role->id === $defaultroleid) ? ' selected' : '';
            echo '              <option value="' . (int)$role->id . '"' . $sel . '>' . s($rname) . ' (' . s($role->shortname) . ')</option>';
        }
        echo '            </select>';
        echo '          </div>';
        echo '          <div class="col-sm-6">';
        echo '            <label class="font-weight-bold" for="qc_enrol_duration">' . get_string('enrol_duration_label', 'auth_devicelock') . '</label>';
        echo '            <input type="number" name="qc_enrol_duration" id="qc_enrol_duration" class="form-control" value="0" min="0" max="3650">';
        echo '            <small class="form-text text-muted">' . get_string('enrol_duration_hint', 'auth_devicelock') . '</small>';
        echo '          </div>';
        echo '        </div>';
    } else {
        echo '        <div class="alert alert-secondary small mb-0">' . s(get_string('enrol_no_courses', 'auth_devicelock')) . '</div>';
    }
    echo '      </div>';
    echo '      <div class="d-flex justify-content-between mt-3">';
    echo '        <a href="' . new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']) . '" class="btn btn-secondary px-4"><i class="fa fa-times"></i> Cancel</a>';
    echo '        <button type="submit" class="btn btn-info px-4"><i class="fa fa-user-plus"></i> ' . get_string('quick_create_submit', 'auth_devicelock') . '</button>';
    echo '      </div>';
    echo '    </form>';
    echo '  </div>';
    echo '</div>';
    // Client-side guard: a field may only be left empty when its
    // "Auto-generate" checkbox is ticked. Ticking the checkbox disables the
    // input (so the browser skips its required check); unticking re-enables it.
    echo '<script>' . "\n";
    echo 'var LG_REQUIRED_MSG = ' . json_encode(get_string('createuser_required_js', 'auth_devicelock')) . ";\n";
    echo <<<'EOJS'
function lgBindAutogenToggles(formid, pairs) {
    var form = document.getElementById(formid);
    if (!form) { return; }
    function apply() {
        pairs.forEach(function(p) {
            var cb = form.querySelector('[name="' + p.cb + '"]');
            p.inputs.forEach(function(iname) {
                var input = form.querySelector('[name="' + iname + '"]');
                if (!cb || !input) { return; }
                if (cb.checked) {
                    input.removeAttribute('required');
                    input.removeAttribute('aria-required');
                    input.disabled = true;
                    input.classList.add('bg-light');
                    input.classList.remove('is-invalid');
                } else {
                    input.disabled = false;
                    input.setAttribute('required', 'required');
                    input.setAttribute('aria-required', 'true');
                    input.classList.remove('bg-light');
                }
            });
        });
    }
    pairs.forEach(function(p) {
        var cb = form.querySelector('[name="' + p.cb + '"]');
        if (cb) { cb.addEventListener('change', apply); }
    });
    form.addEventListener('submit', function(ev) {
        var firstbad = null;
        pairs.forEach(function(p) {
            var cb = form.querySelector('[name="' + p.cb + '"]');
            p.inputs.forEach(function(iname) {
                var input = form.querySelector('[name="' + iname + '"]');
                if (!cb || !input || cb.checked) { return; }
                if (input.value.replace(/^\s+|\s+$/g, '') === '') {
                    input.classList.add('is-invalid');
                    if (!firstbad) { firstbad = input; }
                } else {
                    input.classList.remove('is-invalid');
                }
            });
        });
        if (firstbad) {
            ev.preventDefault();
            ev.stopPropagation();
            firstbad.focus();
            alert(LG_REQUIRED_MSG);
        }
    });
    apply();
}
function lgFilterCourseList(listid, query) {
    var list = document.getElementById(listid);
    if (!list) { return; }
    query = (query || '').toLowerCase();
    var items = list.querySelectorAll('[data-search]');
    for (var k = 0; k < items.length; k++) {
        var hay = items[k].getAttribute('data-search') || '';
        items[k].style.display = (hay.toLowerCase().indexOf(query) !== -1) ? '' : 'none';
    }
}
function lgToggleAllCourses(listid, checked) {
    var list = document.getElementById(listid);
    if (!list) { return; }
    var boxes = list.querySelectorAll('input[type="checkbox"]');
    for (var k = 0; k < boxes.length; k++) { boxes[k].checked = checked; }
}
EOJS;
    echo "lgBindAutogenToggles('lg-quickcreate-form', [" .
        "{cb: 'qc_autogen_user', inputs: ['qc_username']}, " .
        "{cb: 'qc_autogen_name', inputs: ['qc_firstname', 'qc_lastname']}, " .
        "{cb: 'qc_autogen_email', inputs: ['qc_email']}, " .
        "{cb: 'qc_autogen_pass', inputs: ['qc_password']}]);\n";
    echo '</script>';
    echo $OUTPUT->footer();
    exit;
}

// ============================================================
// Bulk Create Users form.
// ============================================================
if ($action === 'bulkcreateusersform') {
    echo $OUTPUT->header();
    // Fetch existing roles for the role-selection table.
    $allroles = $DB->get_records('role', null, 'sortorder ASC', 'id, name, shortname');
    $studentrole = $DB->get_record('role', ['shortname' => 'student'], 'id', IGNORE_MISSING);
    $defaultroleid = $studentrole ? (int)$studentrole->id : 0;
    echo '<div class="card border-info shadow mx-auto my-4" style="max-width: 820px; border-radius: 12px; overflow: hidden;">';
    echo '  <div class="card-header bg-info text-white py-3"><h5 class="mb-0 text-white"><i class="fa fa-users mr-2"></i> ' . get_string('bulk_create_title', 'auth_devicelock') . '</h5></div>';
    echo '  <div class="card-body p-4">';
    echo '    <div class="alert alert-info small">' . get_string('bulk_create_intro', 'auth_devicelock') . '</div>';
    $formurl = new moodle_url('/auth/devicelock/admin_devices.php');
    echo '    <form method="post" action="' . $formurl . '" id="lg-bulkcreate-form">';
    echo '      <input type="hidden" name="action" value="bulkcreateusers">';
    echo '      <input type="hidden" name="sesskey" value="' . sesskey() . '">';
    // Count.
    echo '      <div class="form-group row align-items-center">';
    echo '        <label class="col-sm-4 col-form-label font-weight-bold">' . get_string('bulk_create_count', 'auth_devicelock') . '</label>';
    echo '        <div class="col-sm-3"><input type="number" name="bc_count" value="5" min="1" max="200" class="form-control" required aria-required="true"></div>';
    echo '      </div>';
    // Username base.
    echo '      <div class="form-group row align-items-center">';
    echo '        <label class="col-sm-4 col-form-label font-weight-bold">' . get_string('bulk_create_username_base', 'auth_devicelock') . '</label>';
    echo '        <div class="col-sm-5"><input type="text" name="bc_user_base" class="form-control" placeholder="user" maxlength="100" required aria-required="true"></div>';
    echo '        <div class="col-sm-3"><label class="form-check-label"><input type="checkbox" name="bc_autogen_user" value="1" class="form-check-input mr-1"> ' . get_string('quick_create_autogen', 'auth_devicelock') . '</label></div>';
    echo '      </div>';
    // v3.4.4: First name base + Last name base. One shared Auto-generate
    // checkbox (on the Last name row) gives every user in the batch a
    // different random realistic name pair.
    echo '      <div class="form-group row align-items-center">';
    echo '        <label class="col-sm-4 col-form-label font-weight-bold">' . get_string('bulk_create_firstname_base', 'auth_devicelock') . '</label>';
    echo '        <div class="col-sm-5"><input type="text" name="bc_firstname" class="form-control" placeholder="Bulk" maxlength="100" required aria-required="true"></div>';
    echo '        <div class="col-sm-3"></div>';
    echo '      </div>';
    echo '      <div class="form-group row align-items-center">';
    echo '        <label class="col-sm-4 col-form-label font-weight-bold">' . get_string('bulk_create_lastname_base', 'auth_devicelock') . '</label>';
    echo '        <div class="col-sm-5"><input type="text" name="bc_lastname" class="form-control" placeholder="User" maxlength="100" required aria-required="true"></div>';
    echo '        <div class="col-sm-3"><label class="form-check-label"><input type="checkbox" name="bc_autogen_name" value="1" class="form-check-input mr-1"> ' . get_string('quick_create_autogen', 'auth_devicelock') . '</label></div>';
    echo '      </div>';
    // Email base + domain.
    echo '      <div class="form-group row align-items-center">';
    echo '        <label class="col-sm-4 col-form-label font-weight-bold">' . get_string('bulk_create_email_base', 'auth_devicelock') . '</label>';
    echo '        <div class="col-sm-4"><input type="text" name="bc_email_base" class="form-control" placeholder="user" maxlength="100" required aria-required="true"></div>';
    echo '        <div class="col-auto text-center pt-2">@</div>';
    echo '        <div class="col-sm-3"><input type="text" name="bc_email_domain" class="form-control" placeholder="example.com" maxlength="100" required aria-required="true"></div>';
    echo '      </div>';
    echo '      <div class="form-group row align-items-center">';
    echo '        <label class="col-sm-4"></label>';
    echo '        <div class="col-sm-8"><label class="form-check-label"><input type="checkbox" name="bc_autogen_email" value="1" class="form-check-input mr-1"> ' . get_string('quick_create_autogen', 'auth_devicelock') . '</label></div>';
    echo '      </div>';
    // Password base.
    echo '      <div class="form-group row align-items-center">';
    echo '        <label class="col-sm-4 col-form-label font-weight-bold">' . get_string('bulk_create_password_base', 'auth_devicelock') . '</label>';
    echo '        <div class="col-sm-5"><input type="text" name="bc_pass_base" class="form-control" placeholder="TempPass" maxlength="255" required aria-required="true"></div>';
    echo '        <div class="col-sm-3"><label class="form-check-label"><input type="checkbox" name="bc_autogen_pass" value="1" class="form-check-input mr-1"> ' . get_string('quick_create_autogen', 'auth_devicelock') . '</label></div>';
    echo '      </div>';
    echo '      <div class="alert alert-secondary small">' . get_string('bulk_create_numbering_hint', 'auth_devicelock') . '</div>';
    // Role selection table.
    echo '      <div class="form-group">';
    echo '        <label class="font-weight-bold">' . get_string('bulk_create_roles', 'auth_devicelock') . '</label>';
    echo '        <div class="border rounded p-2 mb-2" style="max-height:200px; overflow-y:auto;">';
    foreach ($allroles as $role) {
        $rname = !empty($role->name) ? $role->name : ucfirst($role->shortname);
        echo '          <div class="form-check"><label class="form-check-label"><input type="checkbox" name="bc_roles[]" value="' . (int)$role->id . '" class="form-check-input mr-2"> ' . s($rname) . ' <small class="text-muted">(' . s($role->shortname) . ')</small></label></div>';
    }
    echo '        </div>';
    echo '        <input type="text" name="bc_custom_role" class="form-control" placeholder="' . s(get_string('bulk_create_custom_role', 'auth_devicelock')) . '">';
    echo '      </div>';
    // Optional: enrol every created user into existing courses.
    $allcourses = $DB->get_records_sql("
        SELECT c.id, c.fullname, c.shortname, c.visible, cc.name AS catname
          FROM {course} c
          JOIN {course_categories} cc ON cc.id = c.category
         WHERE c.id > 1
      ORDER BY cc.sortorder, c.sortorder");
    echo '      <div class="form-group mt-2">';
    echo '        <label class="font-weight-bold">' . get_string('enrol_courses_label', 'auth_devicelock') . '</label>';
    echo '        <div class="small text-muted mb-1">' . get_string('enrol_courses_hint', 'auth_devicelock') . '</div>';
    if (!empty($allcourses)) {
        echo '        <input type="text" class="form-control form-control-sm mb-2" placeholder="' . s(get_string('enrol_search_courses', 'auth_devicelock')) . '" onkeyup="lgFilterCourseList(\'bc-course-list\', this.value)">';
        echo '        <div class="form-check mb-2"><label class="form-check-label"><input type="checkbox" class="form-check-input mr-2" onclick="lgToggleAllCourses(\'bc-course-list\', this.checked)"> <span class="font-weight-bold">' . s(get_string('enrol_select_all', 'auth_devicelock')) . '</span></label></div>';
        echo '        <div id="bc-course-list" class="border rounded p-2 mb-2" style="max-height:220px; overflow-y:auto;">';
        foreach ($allcourses as $course) {
            $csearch = s($course->fullname . ' ' . $course->shortname . ' ' . $course->catname);
            echo '          <div class="form-check" data-search="' . $csearch . '">';
            echo '            <label class="form-check-label"><input type="checkbox" name="bc_courses[]" value="' . (int)$course->id . '" class="form-check-input mr-2"> ' . format_string($course->fullname) . ' <small class="text-muted">(' . s($course->shortname) . ')</small>' . ($course->visible ? '' : ' <span class="badge badge-warning">' . s(get_string('enrol_course_hidden', 'auth_devicelock')) . '</span>') . '</label>';
            echo '          </div>';
        }
        echo '        </div>';
        echo '        <div class="row">';
        echo '          <div class="col-sm-6">';
        echo '            <label class="font-weight-bold" for="bc_enrol_role">' . get_string('enrol_role_label', 'auth_devicelock') . '</label>';
        echo '            <select name="bc_enrol_role" id="bc_enrol_role" class="form-control">';
        foreach ($allroles as $role) {
            $rname = !empty($role->name) ? $role->name : ucfirst($role->shortname);
            $sel = ((int)$role->id === $defaultroleid) ? ' selected' : '';
            echo '              <option value="' . (int)$role->id . '"' . $sel . '>' . s($rname) . ' (' . s($role->shortname) . ')</option>';
        }
        echo '            </select>';
        echo '          </div>';
        echo '          <div class="col-sm-6">';
        echo '            <label class="font-weight-bold" for="bc_enrol_duration">' . get_string('enrol_duration_label', 'auth_devicelock') . '</label>';
        echo '            <input type="number" name="bc_enrol_duration" id="bc_enrol_duration" class="form-control" value="0" min="0" max="3650">';
        echo '            <small class="form-text text-muted">' . get_string('enrol_duration_hint', 'auth_devicelock') . '</small>';
        echo '          </div>';
        echo '        </div>';
    } else {
        echo '        <div class="alert alert-secondary small mb-0">' . s(get_string('enrol_no_courses', 'auth_devicelock')) . '</div>';
    }
    echo '      </div>';
    echo '      <div class="d-flex justify-content-between mt-3">';
    echo '        <a href="' . new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']) . '" class="btn btn-secondary px-4"><i class="fa fa-times"></i> Cancel</a>';
    echo '        <button type="submit" class="btn btn-info px-4"><i class="fa fa-users"></i> ' . get_string('bulk_create_submit', 'auth_devicelock') . '</button>';
    echo '      </div>';
    echo '    </form>';
    echo '  </div>';
    echo '</div>';
    // Client-side guard: a base field may only be left empty when its
    // "Auto-generate" checkbox is ticked (the email checkbox covers both the
    // local part and the domain).
    echo '<script>' . "\n";
    echo 'var LG_REQUIRED_MSG = ' . json_encode(get_string('createuser_required_js', 'auth_devicelock')) . ";\n";
    echo <<<'EOJS'
function lgBindAutogenToggles(formid, pairs) {
    var form = document.getElementById(formid);
    if (!form) { return; }
    function apply() {
        pairs.forEach(function(p) {
            var cb = form.querySelector('[name="' + p.cb + '"]');
            p.inputs.forEach(function(iname) {
                var input = form.querySelector('[name="' + iname + '"]');
                if (!cb || !input) { return; }
                if (cb.checked) {
                    input.removeAttribute('required');
                    input.removeAttribute('aria-required');
                    input.disabled = true;
                    input.classList.add('bg-light');
                    input.classList.remove('is-invalid');
                } else {
                    input.disabled = false;
                    input.setAttribute('required', 'required');
                    input.setAttribute('aria-required', 'true');
                    input.classList.remove('bg-light');
                }
            });
        });
    }
    pairs.forEach(function(p) {
        var cb = form.querySelector('[name="' + p.cb + '"]');
        if (cb) { cb.addEventListener('change', apply); }
    });
    form.addEventListener('submit', function(ev) {
        var firstbad = null;
        pairs.forEach(function(p) {
            var cb = form.querySelector('[name="' + p.cb + '"]');
            p.inputs.forEach(function(iname) {
                var input = form.querySelector('[name="' + iname + '"]');
                if (!cb || !input || cb.checked) { return; }
                if (input.value.replace(/^\s+|\s+$/g, '') === '') {
                    input.classList.add('is-invalid');
                    if (!firstbad) { firstbad = input; }
                } else {
                    input.classList.remove('is-invalid');
                }
            });
        });
        if (firstbad) {
            ev.preventDefault();
            ev.stopPropagation();
            firstbad.focus();
            alert(LG_REQUIRED_MSG);
        }
    });
    apply();
}
function lgFilterCourseList(listid, query) {
    var list = document.getElementById(listid);
    if (!list) { return; }
    query = (query || '').toLowerCase();
    var items = list.querySelectorAll('[data-search]');
    for (var k = 0; k < items.length; k++) {
        var hay = items[k].getAttribute('data-search') || '';
        items[k].style.display = (hay.toLowerCase().indexOf(query) !== -1) ? '' : 'none';
    }
}
function lgToggleAllCourses(listid, checked) {
    var list = document.getElementById(listid);
    if (!list) { return; }
    var boxes = list.querySelectorAll('input[type="checkbox"]');
    for (var k = 0; k < boxes.length; k++) { boxes[k].checked = checked; }
}
EOJS;
    echo "lgBindAutogenToggles('lg-bulkcreate-form', [" .
        "{cb: 'bc_autogen_user', inputs: ['bc_user_base']}, " .
        "{cb: 'bc_autogen_name', inputs: ['bc_firstname', 'bc_lastname']}, " .
        "{cb: 'bc_autogen_email', inputs: ['bc_email_base', 'bc_email_domain']}, " .
        "{cb: 'bc_autogen_pass', inputs: ['bc_pass_base']}]);\n";
    echo '</script>';
    echo $OUTPUT->footer();
    exit;
}

// ============================================================
// Data Fetching for KPIs (Top Statistics)
// ============================================================
// v3.10.0: count with the same visibility rules as the User Directory
// (guest always hidden, admins per the includeadmins setting) so the KPI
// number matches what the directory actually lists.
$kpi_totalusers = $DB->count_records_sql(
    "SELECT COUNT(u.id) FROM {user} u WHERE u.deleted = 0 AND u.id > 1" . auth_devicelock_admin_exclude_sql('u'), []);
$kpi_total   = $DB->count_records('auth_devicelock_devices');
$kpi_blocked = $DB->count_records('auth_devicelock_devices', ['status' => 'blocked']);
$kpi_24h     = $DB->count_records_select('auth_devicelock_devices', 'created_at > ?', [time() - 86400]);

// Calculate Users Exceeding Limit conservatively
$globallimit = (int)(get_config('auth_devicelock', 'maxdevices') ?: 1);
$user_device_counts = $DB->get_records_sql("
    SELECT userid, count(id) as c 
    FROM {auth_devicelock_devices} 
    WHERE status = 'active' 
    GROUP BY userid 
    HAVING count(id) > ?
", [max(1, $globallimit - 1)]); // Use a lower threshold initially to catch anyone near/over global limit

$kpi_overlimit = 0;
foreach ($user_device_counts as $row) {
    if ((int)$row->c > auth_devicelock_get_user_device_limit($row->userid)) {
        $kpi_overlimit++;
    }
}

// ============================================================
// Page Render Begins
// ============================================================
echo $OUTPUT->header();

// Global JS helper for the typed-confirmation-phrase guard. If the form
// contains a #confirm_phrase input (only rendered for batches > 50 users),
// block submission until the admin types DELETE.
echo '<script>
window.lgConfirmPhraseCheck = function(form) {
    var inp = form ? form.querySelector("#confirm_phrase") : null;
    if (!inp) { return true; }
    if (inp.value.trim().toUpperCase() !== "DELETE") {
        alert("' . s(get_string('confirm_phrase_mismatch', 'auth_devicelock')) . '");
        inp.focus();
        inp.select();
        return false;
    }
    return true;
};
</script>';

// Header with Migration & Reset buttons
echo '<div class="d-flex justify-content-between align-items-center mb-4">';
echo '<h2><i class="fa fa-desktop text-primary"></i> Device Management Hub</h2>';
echo '<div class="btn-group">';

// Settings button
$settingsurl = new moodle_url('/admin/settings.php', ['section' => 'authsettingdevicelock']);
echo '<a href="' . $settingsurl . '" class="btn btn-secondary"><i class="fa fa-cog"></i> Settings</a>';

// NOTE: The "Import Users (CSV)", "Quick Create User" and "Bulk Create
// Users" buttons no longer live on this global toolbar. The CSV import
// option has been removed from the UI completely (the import handlers are
// kept but are no longer reachable), and the two user-creation buttons now
// live in the User Directory card header on the "users" tab, next to the
// website-user-count badge.

// Security Snapshot (in-browser digest + send-test-email button).
// v3.4.3: solid button so it matches the other buttons on the toolbar.
$snapshoturl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewsnapshot', 'tab' => $tab]);
echo '<a href="' . $snapshoturl . '" class="btn btn-primary"><i class="fa fa-envelope"></i> ' . get_string('snapshot_page', 'auth_devicelock') . '</a>';

// Reset All button
$resetallurl = new moodle_url($baseurl, ['action' => 'resetall', 'sesskey' => sesskey()]);
echo '<a href="' . $resetallurl . '" class="btn btn-danger" onclick="return confirm(\'Are you sure you want to reset ALL users\\\' devices and sessions? This will log everyone out.\')"><i class="fa fa-refresh"></i> Reset All Users Devices</a>';

// Migrate All button
$migrateurl = new moodle_url($baseurl, ['action' => 'migrateall', 'confirm' => 1, 'sesskey' => sesskey()]);
echo '<a href="' . $migrateurl . '" class="btn btn-success" onclick="return confirm(\'Are you sure you want to enforce Device Lock for all non-admin users? This logs them out.\')"><i class="fa fa-users"></i> Migrate All to Plugin</a>';

// Change Auth (All) button
$changeauthallurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'changeauthall']);
echo '<a href="' . $changeauthallurl . '" class="btn btn-warning text-white"><i class="fa fa-random"></i> Change Auth Method (All)</a>';

// Send email to All users button
$sendemailallurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'sendemailall']);
echo '<a href="' . $sendemailallurl . '" class="btn btn-info text-white"><i class="fa fa-envelope"></i> Send email to All users</a>';

// Refresh button
$refreshurl = new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => $tab, 'search' => $search, 'filter' => $filter, 'user_search' => $user_search, 'log_search' => $log_search]);
echo '<a href="' . $refreshurl . '" class="btn btn-primary"><i class="fa fa-refresh"></i> Refresh</a>';

echo '</div>';
echo '</div>';

// Current Settings Configuration Overview Card
$config_enabled = get_config('auth_devicelock', 'enabled');
$config_maxdevices = get_config('auth_devicelock', 'maxdevices') ?: 1;
// v3.8.0: one summary of the excluded-roles multi-select.
$config_excludedroles_raw = (string)get_config('auth_devicelock', 'excludedroles');
$config_excludedroles_parts = [];
$config_excludedroles_count = 0;
if ($config_excludedroles_raw !== '') {
    $config_excludedroles_selected = array_filter(array_map('trim', explode(',', $config_excludedroles_raw)), function ($v) {
        return $v !== '';
    });
    if (in_array('admin', $config_excludedroles_selected, true)) {
        $config_excludedroles_parts[] = 'Admins';
    }
    $config_excludedroles_count = count(array_filter($config_excludedroles_selected, function ($v) {
        return ctype_digit($v) && (int)$v > 0;
    }));
    if ($config_excludedroles_count > 0) {
        $config_excludedroles_parts[] = $config_excludedroles_count . ' role' . ($config_excludedroles_count > 1 ? 's' : '');
    }
}
$config_excludedroles_summary = !empty($config_excludedroles_parts) ? implode(' + ', $config_excludedroles_parts) : 'None';
$config_autoregister = get_config('auth_devicelock', 'autoregister');
$config_automigrate = get_config('auth_devicelock', 'automigrate');

echo '<div class="card mb-4 border-info shadow-sm">';
echo '  <div class="card-header bg-info text-white d-flex justify-content-between align-items-center py-2">';
echo '    <h5 class="mb-0 text-white"><i class="fa fa-gears"></i> Current Settings Configuration</h5>';
echo '  </div>';
echo '  <div class="card-body py-3">';
echo '    <div class="row text-center">';
echo '      <div class="col border-right">';
echo '        <span class="text-muted small text-uppercase font-weight-bold d-block">Status</span>';
echo '        <strong>' . ($config_enabled ? '<span class="text-success"><i class="fa fa-check-circle"></i> Enabled</span>' : '<span class="text-danger"><i class="fa fa-times-circle"></i> Disabled</span>') . '</strong>';
echo '      </div>';
echo '      <div class="col border-right">';
echo '        <span class="text-muted small text-uppercase font-weight-bold d-block">Max Devices</span>';
echo '        <strong>' . s($config_maxdevices) . '</strong>';
echo '      </div>';
echo '      <div class="col border-right">';
echo '        <span class="text-muted small text-uppercase font-weight-bold d-block">Excluded Roles</span>';
echo '        <strong>' . ($config_excludedroles_summary !== 'None' ? '<span class="text-success">' . s($config_excludedroles_summary) . '</span>' : '<span class="text-muted">None</span>') . '</strong>';
echo '      </div>';
echo '      <div class="col border-right">';
echo '        <span class="text-muted small text-uppercase font-weight-bold d-block">Auto-Register</span>';
echo '        <strong>' . ($config_autoregister ? '<span class="text-success">Yes</span>' : '<span class="text-muted">No</span>') . '</strong>';
echo '      </div>';
echo '      <div class="col">';
echo '        <span class="text-muted small text-uppercase font-weight-bold d-block">Auto-Migrate</span>';
echo '        <strong>' . ($config_automigrate ? '<span class="text-success">Yes</span>' : '<span class="text-muted">No</span>') . '</strong>';
echo '      </div>';
echo '    </div>';
echo '  </div>';
echo '</div>';

// 2. Top KPI Statistics Cards
echo '<div class="row mb-4">';
// Total Users
echo '<div class="col">';
echo '<div class="card text-center border-info h-100">';
echo '<div class="card-body p-3">';
echo '<div class="text-info"><i class="fa fa-users fa-2x mb-2"></i></div>';
echo '<h3 class="mb-0">' . $kpi_totalusers . '</h3>';
echo '<p class="text-muted mb-0 small text-uppercase font-weight-bold">Total Users</p>';
echo '</div></div></div>';
// Total Devices
echo '<div class="col">';
echo '<div class="card text-center border-primary h-100">';
echo '<div class="card-body p-3">';
echo '<div class="text-primary"><i class="fa fa-cubes fa-2x mb-2"></i></div>';
echo '<h3 class="mb-0">' . $kpi_total . '</h3>';
echo '<p class="text-muted mb-0 small text-uppercase font-weight-bold">Total Devices</p>';
echo '</div></div></div>';
// Blocked Devices
echo '<div class="col">';
echo '<div class="card text-center border-danger h-100">';
echo '<div class="card-body p-3">';
echo '<div class="text-danger"><i class="fa fa-ban fa-2x mb-2"></i></div>';
echo '<h3 class="mb-0">' . $kpi_blocked . '</h3>';
echo '<p class="text-muted mb-0 small text-uppercase font-weight-bold">Blocked Devices</p>';
echo '</div></div></div>';
// Users Over Limit
echo '<div class="col">';
echo '<div class="card text-center border-warning h-100">';
echo '<div class="card-body p-3">';
echo '<div class="text-warning"><i class="fa fa-exclamation-triangle fa-2x mb-2"></i></div>';
echo '<h3 class="mb-0">' . $kpi_overlimit . '</h3>';
echo '<p class="text-muted mb-0 small text-uppercase font-weight-bold">Exceeding Limits</p>';
echo '</div></div></div>';
// New in 24h
echo '<div class="col">';
echo '<div class="card text-center border-success h-100">';
echo '<div class="card-body p-3">';
echo '<div class="text-success"><i class="fa fa-clock fa-2x mb-2"></i></div>';
echo '<h3 class="mb-0">' . $kpi_24h . '</h3>';
echo '<p class="text-muted mb-0 small text-uppercase font-weight-bold">Registered (24h)</p>';
echo '</div></div></div>';
echo '</div>';

// ============================================================
// 2b. Security Score Distribution mini-chart (persistent scores histogram)
// ============================================================
// Read every stored security score and bucket by band. This is a single
// SELECT on the plugin's own score table, so it's cheap. Every user gets a
// score row (created lazily at 100%), so the chart is always populated.
$scoredist = ['high' => 0, 'good' => 0, 'fair' => 0, 'poor' => 0, 'critical' => 0];
$scoredist_total = 0;
if ($DB->get_manager()->table_exists('auth_devicelock_user_scores')) {
    $sdrows = $DB->get_records('auth_devicelock_user_scores', null, '', 'userid, score');
    foreach ($sdrows as $sdr) {
        $bl = auth_devicelock_security_score_band((int)$sdr->score);
        $scoredist[$bl['band']] = ($scoredist[$bl['band']] ?? 0) + 1;
        $scoredist_total++;
    }
}
$sd_bands = [
    'high'     => ['color' => '#16a34a', 'label' => get_string('security_score_high', 'auth_devicelock'),     'icon' => 'fa-shield'],
    'good'     => ['color' => '#2563eb', 'label' => get_string('security_score_good', 'auth_devicelock'),     'icon' => 'fa-thumbs-up'],
    'fair'     => ['color' => '#f59e0b', 'label' => get_string('security_score_fair', 'auth_devicelock'),     'icon' => 'fa-exclamation-circle'],
    'poor'     => ['color' => '#dc2626', 'label' => get_string('security_score_poor', 'auth_devicelock'),     'icon' => 'fa-exclamation-triangle'],
    'critical' => ['color' => '#1f2937', 'label' => get_string('security_score_critical', 'auth_devicelock'), 'icon' => 'fa-skull-crossbones'],
];
$sd_max = max(1, max(array_values($scoredist)));

// Recalculate-all-scores action (sesskey-protected, JS confirm).
$recalcurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'recalculatescores', 'sesskey' => sesskey(), 'tab' => $tab]);

echo '<div class="card mb-4 shadow-sm">';
echo '<div class="card-header bg-white d-flex justify-content-between align-items-center">';
echo '  <strong class="text-dark"><i class="fa fa-chart-bar text-primary"></i> ' . get_string('score_distribution', 'auth_devicelock') . '</strong>';
echo '  <span>';
echo '    <span class="badge badge-primary badge-pill mr-2">' . get_string('score_distribution_total', 'auth_devicelock', $scoredist_total) . '</span>';
echo '    <a href="' . $recalcurl . '" class="btn btn-sm btn-outline-secondary" onclick="return confirm(\'' . s(get_string('recalculate_scores_confirm', 'auth_devicelock')) . '\');"><i class="fa fa-sync"></i> ' . get_string('recalculate_scores_btn', 'auth_devicelock') . '</a>';
echo '  </span>';
echo '</div>';
echo '<div class="card-body">';
echo '  <p class="text-muted small mb-3">' . get_string('score_distribution_desc', 'auth_devicelock') . '</p>';

if ($scoredist_total === 0) {
    echo '<div class="text-center text-muted py-3"><i class="fa fa-inbox fa-2x mb-2 d-block"></i>' . get_string('score_distribution_empty', 'auth_devicelock') . '</div>';
} else {
    echo '<div class="row">';
    foreach ($sd_bands as $band => $meta) {
        $count = $scoredist[$band] ?? 0;
        $pct = $scoredist_total > 0 ? round(($count / $scoredist_total) * 100) : 0;
        $bar_h = max(4, (int)round(($count / $sd_max) * 120));
        // Click-to-filter: jump to the Users directory filtered by this band.
        $bandfilter_url = new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'score_band' => $band]);
        $clickable = $count > 0 ? 'cursor:pointer; text-decoration:none;' : 'opacity:0.55; pointer-events:none;';
        echo '<div class="col mb-3 text-center">';
        echo '  <a href="' . $bandfilter_url . '" style="display:block; color:inherit; ' . $clickable . '" title="' . s(get_string('score_band_filter_hint', 'auth_devicelock')) . '">';
        echo '    <div class="d-flex align-items-end justify-content-center mb-1" style="height:130px;">';
        echo '      <div style="width:60%; height:' . $bar_h . 'px; background:' . $meta['color'] . '; border-radius:6px 6px 0 0; opacity:0.9;" title="' . s($meta['label']) . ': ' . $count . ' user(s)"></div>';
        echo '    </div>';
        echo '    <div class="font-weight-bold" style="color:' . $meta['color'] . ';">' . $count . '</div>';
        echo '    <div class="small text-muted"><i class="fa ' . $meta['icon'] . '"></i> ' . s($meta['label']) . '</div>';
        echo '    <div class="badge badge-light badge-pill small mt-1">' . $pct . '%</div>';
        echo '  </a>';
        echo '</div>';
    }
    echo '</div>';
}
echo '</div>'; // card-body
echo '</div>'; // card

// ============================================================
// 3. Tab Navigation & Content rendering
// ============================================================
echo '<ul class="nav nav-tabs mb-4" id="dashboardTabs" role="tablist">';
echo '  <li class="nav-item">';
echo '    <a class="nav-link ' . ($tab === 'users' ? 'active' : '') . '" href="' . new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search]) . '"><i class="fa fa-users"></i> User Directory</a>';
echo '  </li>';
echo '  <li class="nav-item">';
echo '    <a class="nav-link ' . ($tab === 'nonplugin' ? 'active' : '') . '" href="' . new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'nonplugin', 'user_search' => $user_search]) . '"><i class="fa fa-user-times"></i> Users Not Using Plugin</a>';
echo '  </li>';
echo '  <li class="nav-item">';
echo '    <a class="nav-link ' . ($tab === 'devices' ? 'active' : '') . '" href="' . new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'devices', 'search' => $search, 'filter' => $filter]) . '"><i class="fa fa-desktop"></i> Device Inventory</a>';
echo '  </li>';
echo '  <li class="nav-item">';
echo '    <a class="nav-link ' . ($tab === 'logs' ? 'active' : '') . '" href="' . new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'logs', 'log_search' => $log_search, 'log_action_filter' => $log_action_filter]) . '"><i class="fa fa-clipboard-list"></i> Activity & Security Logs</a>';
echo '  </li>';
echo '</ul>';

if ($tab === 'devices') {
    // ------------------------------------------------------------
    // TAB 1: DEVICE INVENTORY
    // ------------------------------------------------------------
    
    // Search & Filtering Bar (specific to devices).
    // v3.4.3: the magnifier is a submit button attached INSIDE the search bar
    // (click it — or press Enter — to search), the × lives inside the bar too,
    // and the status dropdown applies immediately. This markup uses buttons
    // as direct children of .input-group, which is the only structure that
    // attaches correctly on BOTH Bootstrap 4 (Moodle 4.x) and Bootstrap 5
    // (Moodle 5.x, where .input-group-prepend/-append no longer exist).
    $devclearurl = new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'devices']);
    echo '<div class="card mb-4 bg-light">';
    echo '<div class="card-body p-3">';
    echo '<form method="get" action="' . new moodle_url('/auth/devicelock/admin_devices.php') . '" class="row align-items-center">';
    echo '<input type="hidden" name="tab" value="devices">';
    echo '<div class="col-sm-8 my-1">';
    echo '<label class="sr-only" for="search">Search</label>';
    echo '<div class="input-group lg-searchbar">';
    echo '<button type="submit" class="btn btn-primary px-3" title="Search" aria-label="Search"><i class="fa fa-search" aria-hidden="true"></i></button>';
    echo '<input type="text" class="form-control" id="search" name="search" value="' . s($search) . '" placeholder="Search username, email, IP, fingerprint..." autocomplete="off">';
    echo '<button type="button" class="btn btn-outline-secondary bg-white text-muted" id="device_search_clear" title="Clear search" aria-label="Clear search"' . (($search === '' && $filter === 'all') ? ' style="display:none;"' : '') . '><i class="fa fa-times" aria-hidden="true"></i></button>';
    echo '</div></div>';
    echo '<div class="col-sm-4 my-1">';
    echo '<select class="form-control" name="filter" onchange="this.form.submit();">';
    echo '<option value="all" ' . ($filter === 'all' ? 'selected' : '') . '>All Devices</option>';
    echo '<option value="active" ' . ($filter === 'active' ? 'selected' : '') . '>Active Only</option>';
    echo '<option value="blocked" ' . ($filter === 'blocked' ? 'selected' : '') . '>Blocked Only</option>';
    echo '</select></div>';
    echo '</form>';
    echo '</div></div>';
    echo '<script>
(function() {
    var inp = document.getElementById("search");
    var clr = document.getElementById("device_search_clear");
    var sel = document.getElementsByName("filter")[0];
    var active = ' . (($search !== '' || $filter !== 'all') ? 'true' : 'false') . ';
    var clearurl = ' . json_encode($devclearurl->out(false)) . ';
    function toggle() {
        if (!clr || !inp || !sel) { return; }
        clr.style.display = (inp.value || sel.selectedIndex > 0 || active) ? "" : "none";
    }
    if (inp) { inp.addEventListener("input", toggle); }
    if (sel) { sel.addEventListener("change", toggle); }
    toggle();
    if (clr) {
        clr.addEventListener("click", function() {
            if (inp && inp.value) { inp.value = ""; }
            if (sel && sel.selectedIndex > 0) { sel.selectedIndex = 0; }
            if (active) { window.location.href = clearurl; return; }
            toggle();
            if (inp) { inp.focus(); }
        });
    }
})();
</script>';
    
    // Main Data Table Preparation
    $params = [];
    $where = "1=1";
    if ($filter === 'active') {
        $where .= " AND d.status = 'active'";
    } elseif ($filter === 'blocked') {
        $where .= " AND d.status = 'blocked'";
    }
    if ($search) {
        $user_search_where = auth_devicelock_build_user_search_where($search, 'u', $params, 'ds_usr_');
        $where .= " AND ($user_search_where OR d.ip_address LIKE :ds_ip OR d.device_fingerprint LIKE :ds_fp)";
        $params['ds_ip'] = "%" . $DB->sql_like_escape($search) . "%";
        $params['ds_fp'] = "%" . $DB->sql_like_escape($search) . "%";
    }
    
    $sql = "SELECT d.id, d.id as deviceid, d.userid, d.device_fingerprint, d.device_info, d.status, d.last_login, d.created_at, d.user_agent, d.screen_resolution, d.platform, d.browser_language, d.ip_address, u.firstname, u.lastname, u.email, u.idnumber, u.phone1, u.picture, u.imagealt
            FROM {auth_devicelock_devices} d
            JOIN {user} u ON d.userid = u.id
            WHERE $where
            ORDER BY d.last_login DESC, d.created_at DESC";
            
    $totalcount = $DB->count_records_sql("SELECT count(d.id) FROM {auth_devicelock_devices} d JOIN {user} u ON d.userid = u.id WHERE $where", $params);
    $devices = $DB->get_records_sql($sql, $params, $page * $perpage, $perpage);
    
    // Pre-fetch custom profile fields (Uni_ID and Phone_Number) for users on this page
    $device_uids = [];
    foreach ($devices as $d) {
        if (!empty($d->userid)) {
            $device_uids[] = (int)$d->userid;
        }
    }
    $device_custom_identifiers = !empty($device_uids) ? auth_devicelock_get_custom_profile_identifiers($device_uids) : [];
    
    echo '<div class="card mb-4">';
    echo '<div class="card-header"><strong>Device Inventory</strong> (' . $totalcount . ' results)</div>';
    echo '<div class="card-body p-0 table-responsive">';
    
    if (empty($devices)) {
        echo '<div class="p-4 text-center text-muted">No devices found matching your criteria.</div>';
    } else {
        $table = new html_table();
        $table->head = ['User', 'Device OS / Browser', 'IP & Details', 'Last Accessed', 'Status', 'Limits', 'Actions'];
        $table->attributes['class'] = 'table table-hover table-striped mb-0 align-middle';
        
        foreach ($devices as $d) {
            $userobj = new stdClass();
            $userobj->id = $d->userid;
            $userobj->picture = $d->picture;
            $userobj->firstname = $d->firstname;
            $userobj->lastname = $d->lastname;
            $userobj->imagealt = $d->imagealt;
            $userobj->email = $d->email;
            $pic = $OUTPUT->user_picture($userobj, ['size' => 35, 'class' => 'mr-2 rounded-circle']);
            
            $c_info = $device_custom_identifiers[$d->userid] ?? ['uni_id' => '', 'phone' => ''];
            $uni_id = !empty($c_info['uni_id']) ? $c_info['uni_id'] : (!empty($d->idnumber) ? $d->idnumber : '');
            $phone  = !empty($c_info['phone']) ? $c_info['phone'] : (!empty($d->phone1) ? $d->phone1 : '');

            $extrainfo = [];
            if (!empty($uni_id)) {
                $extrainfo[] = '<span class="badge badge-light border text-dark" title="Your University ID"><i class="fa fa-id-card text-primary"></i> ' . s($uni_id) . '</span>';
            }
            if (!empty($phone)) {
                $extrainfo[] = '<span class="badge badge-light border text-dark" title="Phone Number"><i class="fa fa-phone text-success"></i> ' . s($phone) . '</span>';
            }
            $extrastr = !empty($extrainfo) ? '<div class="mt-1">' . implode(' ', $extrainfo) . '</div>' : '';
            $usercell = '<div class="d-flex align-items-center">' . $pic . '<div><strong>' . fullname($userobj) . '</strong><br><small class="text-muted">' . $userobj->email . '</small>' . $extrastr . '</div></div>';
            
            $devicename = auth_devicelock_format_device_info($d);
            $browser_badges = auth_devicelock_format_browsers_used($d);
            $devicecell = '<div>' . $devicename . '</div>';
            if ($browser_badges) {
                $devicecell .= '<div class="mt-1">' . $browser_badges . '</div>';
            }
            $devicecell .= '<span class="d-block mt-1" title="Fingerprint">' . auth_devicelock_fingerprint_span($d->device_fingerprint) . '</span>';
            $ipcell = '<code>' . $d->ip_address . '</code>';
            $datecell = $d->last_login ? device_manager::format_gmt2_date($d->last_login, 'd M Y, H:i') : '-';
            $statuscell = auth_devicelock_get_status_badge($d->status);
            
            $limit = auth_devicelock_get_user_device_limit($d->userid);
            $globallimit = (int)(get_config('auth_devicelock', 'maxdevices') ?: 1);
            $hascustom = (get_user_preferences('auth_devicelock_userlimit', null, $d->userid) !== null) && ($limit !== $globallimit);
            $limitcell = $limit;
            if ($hascustom) {
                $limitcell .= ' <span class="badge badge-primary" title="Per-user limit override">Custom</span>';
            }
            
            $device_baseurl = new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'devices', 'search' => $search, 'filter' => $filter, 'page' => $page]);
            
            $toggleurl = new moodle_url($device_baseurl, ['action' => 'toggleblock', 'deviceid' => $d->deviceid, 'sesskey' => sesskey()]);
            $purgeurl  = new moodle_url($device_baseurl, ['action' => 'purgeuser', 'userid' => $d->userid, 'sesskey' => sesskey()]);
            $limiturl  = new moodle_url($device_baseurl, ['action' => 'setlimit', 'userid' => $d->userid]);
            $emailurl  = new moodle_url($device_baseurl, ['action' => 'sendemail', 'userid' => $d->userid]);
            
            $toggleicon = $d->status === 'active' ? 'fa-ban text-danger' : 'fa-check-circle text-success';
            $toggletext = $d->status === 'active' ? 'Block Device' : 'Unblock Device';
            
            $menu = new action_menu();
            $menu->set_menu_trigger(get_string('actions'));
            $menu->attributes['class'] .= ' d-inline-block';
            
            // Device actions
            $menu->add(new action_menu_link_secondary(
                $toggleurl,
                new pix_icon($d->status === 'active' ? 't/block' : 't/approve', '', 'moodle', ['class' => 'mr-1 ' . ($d->status === 'active' ? 'text-danger' : 'text-success')]),
                $toggletext,
                ['class' => ($d->status === 'active' ? 'text-danger' : 'text-success')]
            ));

            // Reset browsers for this specific device
            $resetdevbrowsersurl = new moodle_url($device_baseurl, [
                'action' => 'resetdevicebrowsers',
                'deviceid' => $d->deviceid,
                'sesskey' => sesskey()
            ]);
            $menu->add(new action_menu_link_secondary(
                $resetdevbrowsersurl,
                new pix_icon('t/restore', '', 'moodle', ['class' => 'mr-1 text-warning']),
                get_string('reset_device_browsers', 'auth_devicelock'),
                ['class' => 'text-warning', 'onclick' => "return confirm('" . addslashes_js(get_string('reset_device_browsers_confirm', 'auth_devicelock')) . "');"]
            ));
            
            // View user details action
            $viewuserurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $d->userid, 'tab' => 'devices']);
            $menu->add(new action_menu_link_secondary(
                $viewuserurl,
                new pix_icon('i/info', '', 'moodle', ['class' => 'mr-1 text-primary']),
                'View User Details / Devices',
                ['class' => 'text-primary']
            ));

            // Per-device audit timeline (filterable + exportable security history for this device).
            if (!empty($d->device_fingerprint)) {
                $devauditurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewdeviceaudit', 'devicefp' => $d->device_fingerprint, 'tab' => 'devices']);
                $menu->add(new action_menu_link_secondary(
                    $devauditurl,
                    new pix_icon('t/calc', '', 'moodle', ['class' => 'mr-1 text-info']),
                    get_string('device_audit_timeline', 'auth_devicelock'),
                    ['class' => 'text-info']
                ));
            }

            // User actions
            $changeauthurl = new moodle_url($device_baseurl, ['action' => 'changeauth', 'userid' => $d->userid]);
            $menu->add(new action_menu_link_secondary(
                $changeauthurl,
                new pix_icon('i/menu', '', 'moodle', ['class' => 'mr-1 text-warning']),
                'Change Auth Method',
                ['class' => 'text-warning']
            ));
            
            $menu->add(new action_menu_link_secondary(
                $purgeurl,
                new pix_icon('t/delete', '', 'moodle', ['class' => 'mr-1 text-danger']),
                'Purge All Devices',
                ['class' => 'text-danger']
            ));
            $menu->add(new action_menu_link_secondary(
                $limiturl,
                new pix_icon('i/settings', '', 'moodle', ['class' => 'mr-1 text-info']),
                'Set Custom Limit',
                ['class' => 'text-info']
            ));
            $menu->add(new action_menu_link_secondary(
                $emailurl,
                new pix_icon('t/email', '', 'moodle', ['class' => 'mr-1 text-primary']),
                'Send Custom Email',
                ['class' => 'text-primary']
            ));

            // Copy User Details (copies username + a fresh temp password)
            $copydetailsurl = new moodle_url($device_baseurl, ['action' => 'copyuserdetailsform', 'userid' => $d->userid, 'sesskey' => sesskey()]);
            $menu->add(new action_menu_link_secondary(
                $copydetailsurl,
                new pix_icon('t/copy', '', 'moodle', ['class' => 'mr-1 text-success']),
                get_string('copy_user_details', 'auth_devicelock'),
                ['class' => 'text-success', 'title' => get_string('copy_user_details', 'auth_devicelock')]
            ));

            // Delete User Account (permanently removes the Moodle user + all info)
            $deleteuserurl = new moodle_url($device_baseurl, ['action' => 'deleteuser', 'userid' => $d->userid, 'sesskey' => sesskey()]);
            $menu->add(new action_menu_link_secondary(
                $deleteuserurl,
                new pix_icon('t/delete', '', 'moodle', ['class' => 'mr-1 text-danger']),
                get_string('delete_user_account', 'auth_devicelock'),
                ['class' => 'text-danger font-weight-bold', 'title' => get_string('delete_user_account', 'auth_devicelock')]
            ));

            $actionmenu = $OUTPUT->render($menu);
            
            $table->data[] = [$usercell, $devicecell, $ipcell, $datecell, $statuscell, $limitcell, $actionmenu];
        }
        echo html_writer::table($table);
    }
    echo '</div>'; // End table card body
    
    // Pagination
    if ($totalcount > $perpage) {
        echo '<div class="mt-3 p-3">';
        echo $OUTPUT->render(new \paging_bar($totalcount, $page, $perpage, new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'devices', 'search' => $search, 'filter' => $filter]), 'page'));
        echo '</div>';
    }
    echo '</div>'; // End card outer wrapper
    
} else if ($tab === 'users') {
    // ------------------------------------------------------------
    // TAB 2: USER DIRECTORY
    // ------------------------------------------------------------

    // NOTE: The collapsible "Import Users (CSV)" upload card that used to
    // sit here has been removed from the UI. Use "Quick Create User" or
    // "Bulk Create Users" in the User Directory card header below instead
    // (the importuserscsv/importuserstemplate action handlers are kept in
    // this file but are no longer linked from anywhere).

    // ----------------------------------------------------------------
    // v3.4.3 — One-time "created accounts" card. After a quick/bulk
    // create, the handler flashed the created usernames + passwords
    // through $SESSION; show them ONCE here so the admin can copy or
    // download them (Moodle stores passwords hashed — this is the only
    // moment the plaintext values are ever available).
    // ----------------------------------------------------------------
    if (optional_param('created', 0, PARAM_BOOL) && !empty($SESSION->auth_devicelock_created_accounts)) {
        $createdaccounts = $SESSION->auth_devicelock_created_accounts;
        unset($SESSION->auth_devicelock_created_accounts);

        // Client-side CSV (UTF-8 BOM so Excel opens it correctly).
        // v3.4.4: includes the account name; fields are quoted so commas
        // in names survive the round-trip.
        $cscsv = "name,username,email,password\n";
        foreach ($createdaccounts as $ca) {
            $caname = isset($ca['name']) ? $ca['name'] : '';
            $cscsv .= '"' . str_replace('"', '""', $caname) . '",'
                . '"' . str_replace('"', '""', $ca['username']) . '",'
                . '"' . str_replace('"', '""', $ca['email']) . '",'
                . '"' . str_replace('"', '""', $ca['password']) . "\n";
        }
        $csdatauri = 'data:text/csv;base64,' . base64_encode("\xEF\xBB\xBF" . $cscsv);

        echo '<div class="card mb-4 border-success shadow-sm" id="lg-created-card">';
        echo '<div class="card-header bg-success text-white"><strong><i class="fa fa-user-check mr-2" aria-hidden="true"></i> ' . get_string('created_accounts_title', 'auth_devicelock') . ' (' . count($createdaccounts) . ')</strong></div>';
        echo '<div class="card-body">';
        echo '<div class="alert alert-warning mb-3"><i class="fa fa-exclamation-triangle mr-1" aria-hidden="true"></i> ' . get_string('created_accounts_intro', 'auth_devicelock') . '</div>';
        echo '<div class="table-responsive">';
        echo '<table class="table table-sm table-bordered mb-3" id="lg-created-accounts">';
        echo '<thead><tr>';
        echo '<th scope="col">#</th>';
        echo '<th scope="col">' . s(get_string('created_col_name', 'auth_devicelock')) . '</th>';
        echo '<th scope="col">' . s(get_string('created_col_username', 'auth_devicelock')) . '</th>';
        echo '<th scope="col">' . s(get_string('created_col_email', 'auth_devicelock')) . '</th>';
        echo '<th scope="col">' . s(get_string('created_col_password', 'auth_devicelock')) . '</th>';
        echo '<th scope="col"><span class="sr-only">' . s(get_string('created_copy_row', 'auth_devicelock')) . '</span></th>';
        echo '</tr></thead><tbody>';
        $can = 0;
        foreach ($createdaccounts as $ca) {
            $can++;
            $caname = isset($ca['name']) ? $ca['name'] : '';
            echo '<tr>';
            echo '<td>' . $can . '</td>';
            echo '<td>' . s($caname) . '</td>';
            echo '<td><code>' . s($ca['username']) . '</code></td>';
            echo '<td>' . s($ca['email']) . '</td>';
            echo '<td><code>' . s($ca['password']) . '</code></td>';
            echo '<td class="text-nowrap"><button type="button" class="btn btn-sm btn-outline-secondary lg-copy-btn" data-copy="' . s($ca['username'] . ' | ' . $ca['password']) . '" title="' . s(get_string('created_copy_row', 'auth_devicelock')) . '" aria-label="' . s(get_string('created_copy_row', 'auth_devicelock')) . '"><i class="fa fa-clipboard" aria-hidden="true"></i></button></td>';
            echo '</tr>';
        }
        echo '</tbody></table></div>';
        echo '<div class="d-flex flex-wrap align-items-center">';
        echo '<a href="' . $csdatauri . '" download="created_accounts.csv" class="btn btn-sm btn-success mr-2 mb-1"><i class="fa fa-download mr-1" aria-hidden="true"></i> ' . get_string('created_download_csv', 'auth_devicelock') . '</a>';
        echo '<button type="button" class="btn btn-sm btn-outline-secondary mb-1" id="lg_copy_all"><i class="fa fa-clipboard mr-1" aria-hidden="true"></i> ' . get_string('created_copy_all', 'auth_devicelock') . '</button>';
        echo '</div>';
        echo '</div></div>';
        echo '<script>
(function() {
    function fallbackCopy(t) {
        var ta = document.createElement("textarea");
        ta.value = t;
        ta.setAttribute("readonly", "");
        ta.style.position = "fixed";
        ta.style.top = "-1000px";
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand("copy"); } catch (e) {}
        document.body.removeChild(ta);
    }
    function copyText(t, btn) {
        var fin = function() {
            if (!btn) { return; }
            var old = btn.innerHTML;
            btn.innerHTML = \'<i class="fa fa-check text-success" aria-hidden="true"></i>\';
            btn.disabled = true;
            setTimeout(function() { btn.innerHTML = old; btn.disabled = false; }, 1200);
        };
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(t).then(fin, function() { fallbackCopy(t); fin(); });
        } else {
            fallbackCopy(t);
            fin();
        }
    }
    var card = document.getElementById("lg-created-card");
    if (card) {
        card.querySelectorAll(".lg-copy-btn").forEach(function(b) {
            b.addEventListener("click", function() { copyText(b.getAttribute("data-copy") || "", b); });
        });
        var allbtn = document.getElementById("lg_copy_all");
        if (allbtn) {
            allbtn.addEventListener("click", function() {
                var lines = [];
                document.querySelectorAll("#lg-created-accounts tbody tr").forEach(function(tr) {
                    var n = tr.cells[1] ? tr.cells[1].textContent.trim() : "";
                    var u = tr.cells[2] ? tr.cells[2].textContent.trim() : "";
                    var e = tr.cells[3] ? tr.cells[3].textContent.trim() : "";
                    var p = tr.cells[4] ? tr.cells[4].textContent.trim() : "";
                    lines.push(\'"\' + n + \'","\' + u + \'","\' + e + \'","\' + p + \'"\');
                });
                copyText(lines.join("\\n"), allbtn);
            });
        }
    }
})();
</script>';
    }

    // ----------------------------------------------------------------
    // Search Bar + quick type filter — the magnifier button submits the
    // search, the in-bar × clears it, and the chips below filter the
    // directory by user type (All / Banned / Unbanned / Blocked / Active).
    // v3.4.3: buttons are direct children of .input-group so they attach
    // correctly on both Bootstrap 4 (Moodle 4.x) and Bootstrap 5
    // (Moodle 5.x).
    // ----------------------------------------------------------------
    $userclearurl = new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']);
    // Whitelist the type filter.
    $ufilter = in_array($ufilter, ['banned', 'unbanned', 'suspended', 'active'], true) ? $ufilter : '';
    $bans_table_exists = $DB->get_manager()->table_exists('auth_devicelock_bans');

    echo '<div class="card mb-4 bg-light">';
    echo '<div class="card-body p-3">';
    echo '<form method="get" action="' . new moodle_url('/auth/devicelock/admin_devices.php') . '" class="m-0">';
    echo '<input type="hidden" name="tab" value="users">';
    if ($ufilter !== '') {
        echo '<input type="hidden" name="ufilter" value="' . s($ufilter) . '">';
    }
    echo '<label class="sr-only" for="user_search">Search Users</label>';
    echo '<div class="input-group lg-searchbar">';
    echo '<button type="submit" class="btn btn-primary px-3" title="Search Users" aria-label="Search Users"><i class="fa fa-search" aria-hidden="true"></i></button>';
    echo '<input type="text" class="form-control" id="user_search" name="user_search" value="' . s($user_search) . '" placeholder="' . s(get_string('usersearch_placeholder', 'auth_devicelock')) . '" autocomplete="off">';
    echo '<button type="button" class="btn btn-outline-secondary bg-white text-muted" id="user_search_clear" title="Clear search" aria-label="Clear search"' . (empty($user_search) ? ' style="display:none;"' : '') . '><i class="fa fa-times" aria-hidden="true"></i></button>';
    echo '</div>';
    echo '</form>';

    // Quick type filter chips (counts respect the current search text but
    // not the chips themselves, so the admin always sees every option's size).
    // v3.9.0: the fuzzy typo retry is decided ONCE here (before the chips,
    // the list, the pagination count and Select All) so every count on the
    // page agrees on the same result set.
    // v3.10.0: u.id > 1 - hide only guest; admins follow the includeadmins
    // setting (auth_devicelock_admin_exclude_sql), so the primary admin
    // (user id 2) finally appears in the directory when the setting is on.
    $userbase_where = "u.deleted = 0 AND u.id > 1" . auth_devicelock_admin_exclude_sql('u');
    $user_typo_retry = $user_search ? auth_devicelock_fuzzy_typo_retry($user_search, $userbase_where) : false;
    $chipbase_where = $userbase_where;
    $chip_params = [];
    if ($user_search) {
        $chipbase_where .= " AND " . auth_devicelock_build_user_search_where($user_search, 'u', $chip_params, 'chip_srch_', $user_typo_retry);
    }
    $chip_total = (int)$DB->count_records_sql("SELECT COUNT(DISTINCT u.id) FROM {user} u WHERE $chipbase_where", $chip_params);
    $chip_banned = 0;
    if ($bans_table_exists) {
        $chip_banned = (int)$DB->count_records_sql(
            "SELECT COUNT(DISTINCT u.id) FROM {user} u WHERE $chipbase_where AND u.id IN (SELECT userid FROM {auth_devicelock_bans} WHERE status = 'active')",
            $chip_params);
    }
    $chip_suspended = (int)$DB->count_records_sql(
        "SELECT COUNT(DISTINCT u.id) FROM {user} u WHERE $chipbase_where AND u.suspended = 1", $chip_params);
    $chip_options = [
        ''          => [get_string('ufilter_all', 'auth_devicelock'), $chip_total],
        'banned'    => [get_string('ufilter_banned', 'auth_devicelock'), $chip_banned],
        'unbanned'  => [get_string('ufilter_unbanned', 'auth_devicelock'), max(0, $chip_total - $chip_banned)],
        'suspended' => [get_string('ufilter_suspended', 'auth_devicelock'), $chip_suspended],
        'active'    => [get_string('ufilter_active', 'auth_devicelock'), max(0, $chip_total - $chip_suspended)],
    ];
    $chip_band = optional_param('score_band', '', PARAM_ALPHA);
    // v3.4.4: restyled filter chips. The old "btn rounded-pill + nested
    // badge" combo looked clunky and rendered differently on Bootstrap 4
    // vs 5 — these custom .lg-chip styles (styles.css) give a modern,
    // version-independent look: icon + label + live count pill, with a
    // per-type accent colour when active.
    $chip_meta = [
        ''          => ['fa-users',        'lg-ico-all',      'lg-chip-all'],
        'banned'    => ['fa-ban',          'lg-ico-banned',   'lg-chip-banned'],
        'unbanned'  => ['fa-check-circle', 'lg-ico-unbanned', 'lg-chip-unbanned'],
        'suspended' => ['fa-user-times',   'lg-ico-blocked',  'lg-chip-blocked'],
        'active'    => ['fa-user-check',   'lg-ico-active',   'lg-chip-active'],
    ];
    echo '<div class="lg-chipbar" role="group" aria-label="' . s(get_string('ufilter_label', 'auth_devicelock')) . '">';
    echo '<span class="lg-chipbar-label"><i class="fa fa-filter" aria-hidden="true"></i> ' . s(get_string('ufilter_label', 'auth_devicelock')) . '</span>';
    foreach ($chip_options as $chipval => $chipdata) {
        $chipurl = new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search]);
        if ($chipval !== '') {
            $chipurl->param('ufilter', $chipval);
        }
        if ($chip_band !== '' && in_array($chip_band, ['high', 'good', 'fair', 'poor', 'critical'], true)) {
            $chipurl->param('score_band', $chip_band);
        }
        $chipactive = ($ufilter === $chipval);
        $chipm = isset($chip_meta[$chipval]) ? $chip_meta[$chipval] : ['fa-tag', '', ''];
        echo '<a href="' . $chipurl . '" class="lg-chip ' . $chipm[2] . ($chipactive ? ' is-active' : '') . '" aria-pressed="' . ($chipactive ? 'true' : 'false') . '">'
            . '<i class="fa ' . $chipm[0] . ' lg-chip-icon ' . $chipm[1] . '" aria-hidden="true"></i>'
            . '<span class="lg-chip-text">' . s($chipdata[0]) . '</span>'
            . '<span class="lg-chip-count">' . (int)$chipdata[1] . '</span>'
            . '</a>';
    }
    echo '</div>';
    echo '</div></div>';
    echo '<script>
(function() {
    var inp = document.getElementById("user_search");
    var clr = document.getElementById("user_search_clear");
    var active = ' . (empty($user_search) ? 'false' : 'true') . ';
    var clearurl = ' . json_encode($userclearurl->out(false)) . ';
    function toggle() {
        if (clr && inp) { clr.style.display = inp.value ? "" : "none"; }
    }
    if (inp) { inp.addEventListener("input", toggle); toggle(); }
    if (clr) {
        clr.addEventListener("click", function() {
            if (inp && inp.value) { inp.value = ""; }
            if (active) { window.location.href = clearurl; return; }
            toggle();
            if (inp) { inp.focus(); }
        });
    }
})();
</script>';
    
    // User Query
    $user_params = [];
    // v3.10.0: u.id > 1 - hide only guest; admins follow the includeadmins
    // setting (the old id > 2 always hid the primary admin, user id 2).
    $user_where = "u.deleted = 0 AND u.id > 1" . auth_devicelock_admin_exclude_sql('u');
    if ($user_search) {
        // v3.9.0: $user_typo_retry was decided before the chips; the list,
        // the pagination count and Select All below all reuse this WHERE.
        $user_where .= " AND " . auth_devicelock_build_user_search_where($user_search, 'u', $user_params, 'usr_srch_', $user_typo_retry);
    }
    // v3.4.3: quick type filter (chips under the search bar).
    if ($ufilter === 'banned') {
        if ($bans_table_exists) {
            $user_where .= " AND u.id IN (SELECT userid FROM {auth_devicelock_bans} WHERE status = 'active')";
        } else {
            $user_where .= " AND 1=0";
        }
    } else if ($ufilter === 'unbanned') {
        if ($bans_table_exists) {
            $user_where .= " AND u.id NOT IN (SELECT userid FROM {auth_devicelock_bans} WHERE status = 'active')";
        }
    } else if ($ufilter === 'suspended') {
        $user_where .= " AND u.suspended = 1";
    } else if ($ufilter === 'active') {
        $user_where .= " AND u.suspended = 0";
    }

    // Click-to-filter: when score_band is set, restrict to users whose stored
    // security score falls in that band. We resolve the matching userids via
    // the plugin's own score table, then add an IN clause to the main query.
    $score_band_filter = optional_param('score_band', '', PARAM_ALPHA);
    $band_active = in_array($score_band_filter, ['high', 'good', 'fair', 'poor', 'critical'], true);
    $band_userids = [];
    if ($band_active && $DB->get_manager()->table_exists('auth_devicelock_user_scores')) {
        // Band score ranges (must match auth_devicelock_security_score_band).
        $band_ranges = [
            'high'     => [85, 100],
            'good'     => [70, 84],
            'fair'     => [50, 69],
            'poor'     => [25, 49],
            'critical' => [0, 24],
        ];
        $r = $band_ranges[$score_band_filter];
        $bprows = $DB->get_records_select('auth_devicelock_user_scores', 'score >= :lo AND score <= :hi', ['lo' => $r[0], 'hi' => $r[1]], '', 'userid');
        foreach ($bprows as $bp) {
            $band_userids[] = (int)$bp->userid;
        }
        if (empty($band_userids)) {
            // No users in this band — force an empty result set.
            $user_where .= " AND 1=0";
        } else {
            list($binsql, $binparams) = $DB->get_in_or_equal($band_userids, SQL_PARAMS_NAMED, 'band_');
            $user_where .= " AND u.id $binsql";
            $user_params = array_merge($user_params, $binparams);
        }
    }

    $users_sql = "SELECT u.id, u.username, u.firstname, u.lastname, u.email, u.idnumber, u.phone1, u.institution, u.department, u.auth, u.picture, u.imagealt, u.suspended, u.confirmed,
                         COUNT(DISTINCT d.id) as device_count
                  FROM {user} u
                  LEFT JOIN {auth_devicelock_devices} d ON u.id = d.userid AND d.status = 'active'
                  WHERE $user_where
                  GROUP BY u.id, u.username, u.firstname, u.lastname, u.email, u.idnumber, u.phone1, u.institution, u.department, u.auth, u.picture, u.imagealt, u.suspended, u.confirmed
                  ORDER BY u.lastname ASC, u.firstname ASC";

    $totaluserscount = $DB->count_records_sql("SELECT count(DISTINCT u.id) FROM {user} u WHERE $user_where", $user_params);
    $users = $DB->get_records_sql($users_sql, $user_params, $userpage * $userperpage, $userperpage);

    // v3.7.0: every userid matching the current search / type filter /
    // score band (not just this page). Injected into the page as JSON so
    // the "Select All" bulk button can tick the WHOLE result set - users
    // on other pages are submitted as hidden checkbox inputs.
    $alluserids = array_map('intval', $DB->get_fieldset_sql(
        "SELECT DISTINCT u.id FROM {user} u WHERE $user_where ORDER BY u.id ASC", $user_params));
    
    // Pre-fetch custom profile fields (Uni_ID and Phone_Number) for users on this page
    $user_custom_identifiers = !empty($users) ? auth_devicelock_get_custom_profile_identifiers(array_keys($users)) : [];
    
    // Fetch the latest administrative log for each of the users on this page in a single query
    $latest_logs = [];
    if (!empty($users)) {
        $userids = array_keys($users);
        list($insql, $inparams) = $DB->get_in_or_equal($userids);
        $log_sql = "SELECT l.userid, l.id, l.action, l.timestamp, l.details
                      FROM {auth_devicelock_logs} l
                      JOIN (
                          SELECT userid, MAX(id) as maxid
                            FROM {auth_devicelock_logs}
                           WHERE userid $insql
                        GROUP BY userid
                      ) lm ON l.id = lm.maxid";
        $latest_logs = $DB->get_records_sql($log_sql, $inparams);
    }

    // Batch-fetch ban status for users on this page.
    $banned_users = [];
    if ($DB->get_manager()->table_exists('auth_devicelock_bans') && !empty($users)) {
        $banuids = array_keys($users);
        list($binsql, $binparams) = $DB->get_in_or_equal($banuids, SQL_PARAMS_NAMED, 'banuid_');
        $banrows = $DB->get_records_select('auth_devicelock_bans', "status = 'active' AND userid $binsql", $binparams, '', 'DISTINCT userid');
        foreach ($banrows as $br) {
            $banned_users[(int)$br->userid] = true;
        }
    }
    
    // Export-CSV link (uses the SAME filter as the table below).
    $exportusersurl = new moodle_url('/auth/devicelock/admin_devices.php', [
        'action' => 'exportuserscsv', 'sesskey' => sesskey(), 'tab' => 'users', 'user_search' => $user_search,
        'ufilter' => $ufilter,
    ]);
    $bulkformurl = new moodle_url('/auth/devicelock/admin_devices.php');
    // v3.7.0: base URL for the temporary users-per-page control (keeps the
    // current search + type filter, always restarts on the first page).
    $pagesizeurl = new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'ufilter' => $ufilter]);

    echo '<div class="card mb-4 shadow-sm">';
    echo '<div class="card-header d-flex flex-wrap justify-content-between align-items-center">';
    echo '  <strong><i class="fa fa-address-book text-primary mr-1"></i> User Directory</strong>';
    echo '  <span class="d-inline-flex flex-wrap align-items-center">';
    // Show the active band filter as a dismissible badge.
    if ($band_active) {
        $band_labels = [
            'high' => get_string('security_score_high', 'auth_devicelock'),
            'good' => get_string('security_score_good', 'auth_devicelock'),
            'fair' => get_string('security_score_fair', 'auth_devicelock'),
            'poor' => get_string('security_score_poor', 'auth_devicelock'),
            'critical' => get_string('security_score_critical', 'auth_devicelock'),
        ];
        $clearband_url = new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'ufilter' => $ufilter]);
        echo '    <span class="badge badge-info badge-pill mr-2"><i class="fa fa-filter"></i> ' . s($band_labels[$score_band_filter]) . ' <a href="' . $clearband_url . '" class="text-white ml-1" title="' . s(get_string('clear', 'moodle')) . '"><i class="fa fa-times"></i></a></span>';
    }
    // Quick Create User + Bulk Create Users buttons (moved here from the
    // global toolbar at the top of the page, so user creation lives right
    // where the user list is).
    $quickcreateurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'quickcreateuserform', 'tab' => 'users']);
    $bulkcreateurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'bulkcreateusersform', 'tab' => 'users']);
    echo '    <a href="' . $quickcreateurl . '" class="btn btn-sm btn-outline-success mr-2" title="' . s(get_string('quick_create_user', 'auth_devicelock')) . '"><i class="fa fa-user-plus"></i> ' . get_string('quick_create_user', 'auth_devicelock') . '</a>';
    echo '    <a href="' . $bulkcreateurl . '" class="btn btn-sm btn-outline-info mr-2" title="' . s(get_string('bulk_create_users', 'auth_devicelock')) . '"><i class="fa fa-users"></i> ' . get_string('bulk_create_users', 'auth_devicelock') . '</a>';
    echo '    <span class="badge badge-primary badge-pill">' . $totaluserscount . ' users</span>';
    echo '  </span>';
    echo '</div>';
    echo '<div class="card-body p-0">';

    if (empty($users)) {
        echo '<div class="p-4 text-center text-muted">No users found.</div>';
    } else {
        // Bulk-action form wraps the toolbar + table so the Delete button can
        // POST selected_users[] straight to the bulkdeleteusers confirmation.
        echo '<form method="post" action="' . $bulkformurl . '" id="bulk_users_form">';
        echo '  <input type="hidden" name="action" value="bulkdeleteusers">';
        echo '  <input type="hidden" name="sesskey" value="' . sesskey() . '">';
        echo '  <input type="hidden" name="tab" value="users">';
        echo '  <input type="hidden" name="user_search" value="' . s($user_search) . '">';
        echo '  <input type="hidden" name="ufilter" value="' . s($ufilter) . '">';
        echo '  <input type="hidden" name="userpage" value="' . (int)$userpage . '">';

        // Bulk-action + export toolbar.
        echo '  <div class="p-2 bg-light border-bottom d-flex flex-wrap align-items-center">';
        echo '    <span class="font-weight-bold mr-3"><i class="fa fa-tasks text-secondary"></i> ' . get_string('bulk_actions', 'auth_devicelock') . '</span>';
        echo '    <div class="btn-group btn-group-sm mr-2">';
        echo '      <button type="button" class="btn btn-outline-secondary" id="bulk_select_all_btn" title="' . s(get_string('bulk_select_all_hint', 'auth_devicelock')) . '"><i class="fa fa-check-double"></i> ' . get_string('bulk_select_all', 'auth_devicelock') . '</button>';
        echo '      <button type="button" class="btn btn-outline-secondary" id="bulk_select_visible_btn" title="' . s(get_string('bulk_select_visible_hint', 'auth_devicelock')) . '"><i class="fa fa-check"></i> ' . get_string('bulk_select_visible', 'auth_devicelock') . '</button>';
        echo '      <button type="button" class="btn btn-outline-secondary" id="bulk_clear_btn"><i class="fa fa-times"></i> ' . get_string('bulk_clear_selection', 'auth_devicelock') . '</button>';
        echo '    </div>';
        echo '    <span class="badge badge-info badge-pill mr-3" id="bulk_count_badge" data-count-format="' . s(get_string('bulk_selected_count', 'auth_devicelock', '__N__')) . '">' . get_string('bulk_selected_count', 'auth_devicelock', 0) . '</span>';
        echo '    <a href="' . $exportusersurl . '" class="btn btn-sm btn-outline-success mr-2"><i class="fa fa-file-csv"></i> ' . get_string('export_users_csv', 'auth_devicelock') . '</a>';
        echo '    <button type="submit" onclick="return lgBulkSetAction(\'bulkcopydetails\', \'' . s(get_string('bulk_copy_details_warning', 'auth_devicelock')) . '\');" class="btn btn-sm btn-outline-primary mr-1"><i class="fa fa-clone"></i> ' . get_string('bulk_copy_details', 'auth_devicelock') . '</button>';
        echo '    <button type="submit" name="action" value="bulkbanusers" class="btn btn-sm btn-outline-warning mr-1"><i class="fa fa-ban"></i> ' . get_string('bulk_ban_selected', 'auth_devicelock') . '</button>';
        echo '    <button type="submit" name="action" value="bulkunbanusers" class="btn btn-sm btn-outline-success mr-1"><i class="fa fa-check-circle"></i> ' . get_string('bulk_unban_selected', 'auth_devicelock') . '</button>';
        echo '    <button type="submit" name="action" value="bulkresetscores" class="btn btn-sm btn-outline-primary mr-1" title="' . s(get_string('bulk_reset_score_hint', 'auth_devicelock')) . '"><i class="fa fa-battery-full"></i> ' . get_string('bulk_reset_score', 'auth_devicelock') . '</button>';
        echo '    <button type="submit" name="action" value="bulkchangecourseform" class="btn btn-sm btn-outline-info mr-1" title="' . s(get_string('change_course_hint', 'auth_devicelock')) . '"><i class="fa fa-graduation-cap"></i> ' . get_string('bulk_change_course', 'auth_devicelock') . '</button>';
        echo '    <button type="submit" name="action" value="bulkchangeroleform" class="btn btn-sm btn-outline-secondary mr-1" title="' . s(get_string('change_role_hint', 'auth_devicelock')) . '"><i class="fa fa-user-tag"></i> ' . get_string('bulk_change_role', 'auth_devicelock') . '</button>';
        echo '    <button type="submit" name="action" value="bulkdeleteusers" class="btn btn-sm btn-outline-danger"><i class="fa fa-trash"></i> ' . get_string('bulk_delete_selected', 'auth_devicelock') . '</button>';
        echo '  </div>';

        echo '  <div class="table-responsive">';
        $table = new html_table();
        $table->id = 'lg-userdirectory';
        $selectallhead = '<input type="checkbox" id="select_all_users" title="' . s(get_string('bulk_select_all', 'auth_devicelock')) . '" style="transform: scale(1.25);">';
        $table->head = [$selectallhead, 'Full Name', 'Email / Identifiers', 'Auth Method', 'Devices', 'Type', 'Score', 'Max Devices', 'Log', 'Actions'];
        $table->attributes['class'] = 'table table-hover table-striped mb-0 align-middle';

        // PERFORMANCE: batch-compute the security score for every user on this
        // page in ONE query (with a 1-hour user_preference cache) instead of N
        // per-row GROUP-BY queries.
        $page_score_cache = auth_devicelock_compute_security_scores_batch(array_keys($users));

        foreach ($users as $u) {
            $userobj = new stdClass();
            $userobj->id = $u->id;
            $userobj->picture = $u->picture;
            $userobj->firstname = $u->firstname;
            $userobj->lastname = $u->lastname;
            $userobj->imagealt = $u->imagealt;
            $userobj->email = $u->email;
            
            // Full Name cell
            $pic = $OUTPUT->user_picture($userobj, ['size' => 35, 'class' => 'mr-2 rounded-circle']);
            // v3.4.3: the Banned badge gets its own spacing class — inside the
            // flex container the leading space of the old markup collapsed to
            // nothing, so the badge hugged the user's name.
            $ban_badge = isset($banned_users[$u->id]) ? '<span class="badge badge-danger lg-ban-badge">' . get_string('ban_status_banned', 'auth_devicelock') . '</span>' : '';
            $row_class = isset($banned_users[$u->id]) ? 'text-danger' : '';
            $fullnamecell = '<div class="d-flex align-items-center ' . $row_class . '">' . $pic . '<strong>' . fullname($userobj) . '</strong>' . $ban_badge . '</div>';
            
            // Email & Identifiers cell (University ID / Phone)
            $c_info = $user_custom_identifiers[$u->id] ?? ['uni_id' => '', 'phone' => ''];
            $uni_id = !empty($c_info['uni_id']) ? $c_info['uni_id'] : (!empty($u->idnumber) ? $u->idnumber : '');
            $phone  = !empty($c_info['phone']) ? $c_info['phone'] : (!empty($u->phone1) ? $u->phone1 : (!empty($u->phone2) ? $u->phone2 : ''));

            $extrainfo = [];
            if (!empty($uni_id)) {
                $extrainfo[] = '<span class="badge badge-light border text-dark" title="Your University ID"><i class="fa fa-id-card text-primary"></i> ' . s($uni_id) . '</span>';
            }
            if (!empty($phone)) {
                $extrainfo[] = '<span class="badge badge-light border text-dark" title="Phone Number"><i class="fa fa-phone text-success"></i> ' . s($phone) . '</span>';
            }
            $extrastr = !empty($extrainfo) ? '<div class="mt-1">' . implode(' ', $extrainfo) . '</div>' : '';
            $emailcell = '<code>' . s($u->email) . '</code>' . $extrastr;
            
            // Auth method cell
            if ($u->auth === 'devicelock') {
                $authcell = '<span class="badge badge-success"><i class="fa fa-lock"></i> Single Device Lock</span>';
            } else {
                $authcell = '<span class="badge badge-secondary">' . s($u->auth) . '</span>';
            }
            
            // Devices cell
            $devicecell = '<strong>' . $u->device_count . '</strong> active';
            
            // User Type cell (Admin, Teacher, Student)
            $usertype = 'Student / User';
            $usertypebadge = 'badge-light';
            if (is_siteadmin($u->id)) {
                $usertype = 'Site Admin';
                $usertypebadge = 'badge-danger';
            } else {
                // Check if teacher/manager
                $roles = $DB->get_records_sql("
                    SELECT DISTINCT r.shortname 
                    FROM {role_assignments} ra 
                    JOIN {role} r ON ra.roleid = r.id 
                    WHERE ra.userid = ?
                ", [$u->id]);
                foreach ($roles as $role) {
                    if (in_array($role->shortname, ['teacher', 'editingteacher', 'manager'])) {
                        $usertype = 'Teacher / Manager';
                        $usertypebadge = 'badge-warning';
                        break;
                    }
                }
            }
            $typecell = '<span class="badge ' . $usertypebadge . '">' . $usertype . '</span>';
            
            // Max Devices cell
            $limit = auth_devicelock_get_user_device_limit($u->id);
            $globallimit = (int)(get_config('auth_devicelock', 'maxdevices') ?: 1);
            $hascustom = (get_user_preferences('auth_devicelock_userlimit', null, $u->id) !== null) && ($limit !== $globallimit);
            $maxdevicescell = '<strong>' . $limit . '</strong>';
            if ($hascustom) {
                $maxdevicescell .= ' <span class="badge badge-primary" title="Per-user limit override">Custom</span>';
            }
            
            $user_baseurl = new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'ufilter' => $ufilter, 'userpage' => $userpage]);
            
            $migrateurl = new moodle_url($user_baseurl, ['action' => 'migrateuser', 'userid' => $u->id, 'sesskey' => sesskey()]);
            $purgeurl  = new moodle_url($user_baseurl, ['action' => 'purgeuser', 'userid' => $u->id, 'sesskey' => sesskey()]);
            $limiturl  = new moodle_url($user_baseurl, ['action' => 'setlimit', 'userid' => $u->id]);
            $emailurl  = new moodle_url($user_baseurl, ['action' => 'sendemail', 'userid' => $u->id]);
            
            $menu = new action_menu();
            $menu->set_menu_trigger(get_string('actions'));
            $menu->attributes['class'] .= ' d-inline-block';
            
            // View user details action
            $viewuserurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $u->id, 'tab' => 'users']);
            $menu->add(new action_menu_link_secondary(
                $viewuserurl,
                new pix_icon('i/info', '', 'moodle', ['class' => 'mr-1 text-primary']),
                'View User Details / Devices',
                ['class' => 'text-primary']
            ));

            // Per-user Audit Timeline (filterable + exportable security history)
            $auditurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuseraudit', 'userid' => $u->id, 'tab' => 'users']);
            $menu->add(new action_menu_link_secondary(
                $auditurl,
                new pix_icon('t/calc', '', 'moodle', ['class' => 'mr-1 text-info']),
                get_string('audit_timeline', 'auth_devicelock'),
                ['class' => 'text-info']
            ));

            if ($u->auth !== 'devicelock') {
                $menu->add(new action_menu_link_secondary(
                    $migrateurl,
                    new pix_icon('t/locked', '', 'moodle', ['class' => 'mr-1 text-success']),
                    'Migrate to Plugin',
                    ['class' => 'text-success']
                ));
            }
            
            // Change auth method action
            $changeauthurl = new moodle_url($user_baseurl, ['action' => 'changeauth', 'userid' => $u->id]);
            $menu->add(new action_menu_link_secondary(
                $changeauthurl,
                new pix_icon('i/menu', '', 'moodle', ['class' => 'mr-1 text-warning']),
                'Change Auth Method',
                ['class' => 'text-warning']
            ));
            
            // Purge all devices action
            $menu->add(new action_menu_link_secondary(
                $purgeurl,
                new pix_icon('t/delete', '', 'moodle', ['class' => 'mr-1 text-danger']),
                'Purge All Devices',
                ['class' => 'text-danger']
            ));

            // Reset All Browsers (Retain devices, reset browser data and logout)
            $resetuserbrowsersurl = new moodle_url($user_baseurl, ['action' => 'resetuserbrowsers', 'userid' => $u->id, 'sesskey' => sesskey()]);
            $menu->add(new action_menu_link_secondary(
                $resetuserbrowsersurl,
                new pix_icon('i/reload', '', 'moodle', ['class' => 'mr-1 text-primary']),
                get_string('reset_all_browsers', 'auth_devicelock'),
                ['class' => 'text-primary', 'onclick' => "return confirm('" . addslashes_js(get_string('confirm_reset_user_browsers', 'auth_devicelock')) . "');"]
            ));
            
            // Set custom limit override
            $menu->add(new action_menu_link_secondary(
                $limiturl,
                new pix_icon('i/settings', '', 'moodle', ['class' => 'mr-1 text-info']),
                'Set Custom Limit',
                ['class' => 'text-info']
            ));
            
            // Send email to user
            $menu->add(new action_menu_link_secondary(
                $emailurl,
                new pix_icon('t/email', '', 'moodle', ['class' => 'mr-1 text-primary']),
                'Send Custom Email',
                ['class' => 'text-primary']
            ));
            
            // Send Reset Password link
            $resetpwdurl = new moodle_url($user_baseurl, ['action' => 'sendresetpassword', 'userid' => $u->id, 'sesskey' => sesskey()]);
            $menu->add(new action_menu_link_secondary(
                $resetpwdurl,
                new pix_icon('t/email', '', 'moodle', ['class' => 'mr-1 text-warning']),
                'Send Reset Password',
                ['class' => 'text-warning']
            ));

            // Generate Temporary Password
            $temppassurl = new moodle_url($user_baseurl, ['action' => 'generatetemppasswordform', 'userid' => $u->id]);
            $menu->add(new action_menu_link_secondary(
                $temppassurl,
                // v3.4.3: i/key is excluded from Moodle's FontAwesome map (it
                // renders as an old raster GIF that visually clashes with the
                // other menu glyphs). i/grading maps to fa-wand-magic-sparkles.
                new pix_icon('i/grading', '', 'moodle', ['class' => 'mr-1 text-info']),
                get_string('generate_temp_password', 'auth_devicelock'),
                ['class' => 'text-info']
            ));

            // Change Password (permanent, no forced change prompt)
            $changepasswordurl = new moodle_url($user_baseurl, ['action' => 'changepasswordform', 'userid' => $u->id]);
            $menu->add(new action_menu_link_secondary(
                $changepasswordurl,
                // v3.4.3: t/unlocked maps to fa-lock-open (vector glyph,
                // matches the rest of the menu icons).
                new pix_icon('t/unlocked', '', 'moodle', ['class' => 'mr-1 text-success']),
                'Change Password',
                ['class' => 'text-success']
            ));

            // Block / Restore Site Access (Moodle account suspension toggle)
            $suspendurl = new moodle_url($user_baseurl, ['action' => 'togglesuspend', 'userid' => $u->id, 'sesskey' => sesskey()]);
            if ($u->suspended) {
                $menu->add(new action_menu_link_secondary(
                    $suspendurl,
                    new pix_icon('t/go', '', 'moodle', ['class' => 'mr-1 text-success']),
                    'Restore Site Access',
                    ['class' => 'text-success']
                ));
            } else {
                $menu->add(new action_menu_link_secondary(
                    $suspendurl,
                    new pix_icon('t/block', '', 'moodle', ['class' => 'mr-1 text-danger']),
                    'Block Site Access',
                    ['class' => 'text-danger']
                ));
            }

            // Confirm Account (shown only if not already confirmed)
            if (!$u->confirmed) {
                $confirmuserurl = new moodle_url($user_baseurl, ['action' => 'confirmuser', 'userid' => $u->id, 'sesskey' => sesskey()]);
                $menu->add(new action_menu_link_secondary(
                    $confirmuserurl,
                    new pix_icon('i/valid', '', 'moodle', ['class' => 'mr-1 text-success']),
                    'Confirm Account',
                    ['class' => 'text-success']
                ));
            }

            // Edit Profile Info (Redirect to Moodle's advance user editor in new tab)
            $editurl = new moodle_url('/user/editadvanced.php', ['id' => $u->id]);
            $menu->add(new action_menu_link_secondary(
                $editurl,
                new pix_icon('t/edit', '', 'moodle', ['class' => 'mr-1 text-info']),
                'Edit Profile Info',
                ['class' => 'text-info', 'target' => '_blank']
            ));

            // Copy User Details (copies username + a freshly-generated temp password)
            $copydetailsurl = new moodle_url($user_baseurl, ['action' => 'copyuserdetailsform', 'userid' => $u->id, 'sesskey' => sesskey()]);
            $menu->add(new action_menu_link_secondary(
                $copydetailsurl,
                new pix_icon('t/copy', '', 'moodle', ['class' => 'mr-1 text-success']),
                get_string('copy_user_details', 'auth_devicelock'),
                ['class' => 'text-success', 'title' => get_string('copy_user_details', 'auth_devicelock')]
            ));

            // Delete User Account (permanently removes the Moodle user + all info)
            $deleteuserurl = new moodle_url($user_baseurl, ['action' => 'deleteuser', 'userid' => $u->id, 'sesskey' => sesskey()]);
            $menu->add(new action_menu_link_secondary(
                $deleteuserurl,
                new pix_icon('t/delete', '', 'moodle', ['class' => 'mr-1 text-danger']),
                get_string('delete_user_account', 'auth_devicelock'),
                ['class' => 'text-danger font-weight-bold', 'title' => get_string('delete_user_account', 'auth_devicelock')]
            ));

            // Change Score (increase / decrease / set / reset + custom regain)
            $changescoremenuurl = new moodle_url($user_baseurl, ['action' => 'changescoreform', 'userid' => $u->id]);
            $menu->add(new action_menu_link_secondary(
                $changescoremenuurl,
                new pix_icon('i/scales', '', 'moodle', ['class' => 'mr-1 text-primary']),
                get_string('score_change', 'auth_devicelock'),
                ['class' => 'text-primary']
            ));

            // Change Course (enrol / un-enroll from courses)
            $changecourseurl = new moodle_url($user_baseurl, ['action' => 'changecourseform', 'userid' => $u->id]);
            $menu->add(new action_menu_link_secondary(
                $changecourseurl,
                new pix_icon('i/course', '', 'moodle', ['class' => 'mr-1 text-info']),
                get_string('change_course', 'auth_devicelock'),
                ['class' => 'text-info', 'title' => get_string('change_course_hint', 'auth_devicelock')]
            ));

            // Change Role (site-level roles)
            $changeroleurl = new moodle_url($user_baseurl, ['action' => 'changeroleform', 'userid' => $u->id]);
            $menu->add(new action_menu_link_secondary(
                $changeroleurl,
                new pix_icon('i/assignroles', '', 'moodle', ['class' => 'mr-1 text-primary']),
                get_string('change_role', 'auth_devicelock'),
                ['class' => 'text-primary', 'title' => get_string('change_role_hint', 'auth_devicelock')]
            ));

            // Ban / Unban User
            $is_banned = false;
            if ($DB->get_manager()->table_exists('auth_devicelock_bans')) {
                $is_banned = $DB->record_exists('auth_devicelock_bans', ['userid' => $u->id, 'status' => 'active']);
            }
            if ($is_banned) {
                $unbanurl = new moodle_url($user_baseurl, ['action' => 'unbanuser', 'userid' => $u->id, 'sesskey' => sesskey()]);
                $menu->add(new action_menu_link_secondary(
                    $unbanurl,
                    new pix_icon('t/go', '', 'moodle', ['class' => 'mr-1 text-success']),
                    get_string('unban_user', 'auth_devicelock'),
                    ['class' => 'text-success']
                ));
            } else {
                $banurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'banuserform', 'userid' => $u->id, 'sesskey' => sesskey(), 'tab' => 'users']);
                $menu->add(new action_menu_link_secondary(
                    $banurl,
                    new pix_icon('t/block', '', 'moodle', ['class' => 'mr-1 text-danger']),
                    get_string('ban_user', 'auth_devicelock'),
                    ['class' => 'text-danger']
                ));
            }

            // Log cell containing status/action icon representing the last admin action
            $logcell = '<span class="text-muted">-</span>';
            if (isset($latest_logs[$u->id])) {
                $userlog = $latest_logs[$u->id];
                $logdate = date('d M Y, H:i:s', $userlog->timestamp);
                $logdetails = @json_decode($userlog->details, true) ?: [];
                
                switch ($userlog->action) {
                    case 'send_reset_password':
                        $logcell = '<a href="' . $resetpwdurl . '" class="btn-link" onclick="return confirm(\'Are you sure you want to resend the reset password link?\')"><i class="fa fa-refresh text-warning" title="Password Reset Sent on ' . $logdate . ' (Click to Resend)" style="font-size: 1.2rem;"></i></a>';
                        break;
                    case 'toggle_suspend':
                        $is_suspended = $logdetails['suspended'] ?? 1;
                        if ($is_suspended) {
                            $logcell = '<i class="fa fa-lock text-danger" title="Blocked by Admin on ' . $logdate . '" style="font-size: 1.2rem; cursor: help;"></i>';
                        } else {
                            $logcell = '<i class="fa fa-lock text-success" title="Restored by Admin on ' . $logdate . '" style="font-size: 1.2rem; cursor: help;"></i>';
                        }
                        break;
                    case 'confirm_user':
                        $logcell = '<i class="fa fa-lock text-success" title="Confirmed by Admin on ' . $logdate . '" style="font-size: 1.2rem; cursor: help;"></i>';
                        break;
                    case 'reset_all_devices':
                    case 'purge_user_devices':
                        $logcell = '<i class="fa fa-lock text-danger" title="Devices Purged on ' . $logdate . '" style="font-size: 1.2rem; cursor: help;"></i>';
                        break;
                    case 'device_blocked':
                    case 'device_status_blocked':
                        $logcell = '<i class="fa fa-lock text-danger" title="Device Blocked on ' . $logdate . '" style="font-size: 1.2rem; cursor: help;"></i>';
                        break;
                    case 'device_status_active':
                        $logcell = '<i class="fa fa-lock text-success" title="Device Activated on ' . $logdate . '" style="font-size: 1.2rem; cursor: help;"></i>';
                        break;
                    case 'save_user_limit':
                        $lim = $logdetails['userlimit'] ?? ($logdetails['limit'] ?? '');
                        $logcell = '<i class="fa fa-lock text-info" title="Limit Override Set (' . $lim . ') on ' . $logdate . '" style="font-size: 1.2rem; cursor: help;"></i>';
                        break;
                    case 'send_custom_email':
                        $logcell = '<i class="fa fa-lock text-info" title="Email Sent on ' . $logdate . '" style="font-size: 1.2rem; cursor: help;"></i>';
                        break;
                    case 'auth_method_changed':
                        $to_a = $logdetails['to_auth'] ?? '';
                        $logcell = '<i class="fa fa-lock text-info" title="Auth Method Changed (' . $to_a . ') on ' . $logdate . '" style="font-size: 1.2rem; cursor: help;"></i>';
                        break;
                    case 'auth_method_migrated':
                        $logcell = '<i class="fa fa-lock text-success" title="Migrated to Plugin on ' . $logdate . '" style="font-size: 1.2rem; cursor: help;"></i>';
                        break;
                    case 'generate_temporary_password':
                        $logcell = '<i class="fa fa-key text-info" title="Temporary Password Generated on ' . $logdate . '" style="font-size: 1.2rem; cursor: help;"></i>';
                        break;
                    case 'change_password_direct':
                        $logcell = '<i class="fa fa-key text-success" title="Password Changed by Admin on ' . $logdate . '" style="font-size: 1.2rem; cursor: help;"></i>';
                        break;
                    case 'copy_user_details':
                    case 'bulk_copy_user_details':
                        $logcell = '<i class="fa fa-clone text-success" title="Login Details Copied on ' . $logdate . '" style="font-size: 1.2rem; cursor: help;"></i>';
                        break;
                    case 'delete_user_account':
                    case 'bulk_delete_user_account':
                        $logcell = '<i class="fa fa-trash text-danger" title="Account Deleted on ' . $logdate . '" style="font-size: 1.2rem; cursor: help;"></i>';
                        break;
                    case 'clear_all_logs':
                        $logcell = '<i class="fa fa-eraser text-secondary" title="All Logs Cleared on ' . $logdate . '" style="font-size: 1.2rem; cursor: help;"></i>';
                        break;
                    case 'bulk_import_users':
                        $logcell = '<i class="fa fa-users text-info" title="Bulk User Import on ' . $logdate . '" style="font-size: 1.2rem; cursor: help;"></i>';
                        break;
                    default:
                        // v3.4.5: every action that has no hand-written case
                        // above (quick_create_user, ban_user, the App Guard
                        // family, ...) now gets a proper human-readable
                        // tooltip + a semantic icon/colour from the shared
                        // action map instead of the raw "some_action" name.
                        $ainfo = auth_devicelock_action_info($userlog->action);
                        $textclass = 'text-secondary';
                        if (preg_match('/badge-([a-z]+)/', $ainfo[0], $mm)) {
                            $textclass = $mm[1] === 'light' ? 'text-secondary' : 'text-' . $mm[1];
                        }
                        $logcell = '<i class="fa ' . $ainfo[1] . ' ' . $textclass . '" title="'
                            . auth_devicelock_action_label($userlog->action) . ' on ' . $logdate
                            . '" style="font-size: 1.2rem; cursor: help;"></i>';
                }
            }
            
            $actionmenu = $OUTPUT->render($menu);

            $checkboxcell = '<input type="checkbox" name="selected_users[]" value="' . (int)$u->id . '" class="user-select-checkbox" style="transform: scale(1.25);">';
            // Per-user security score (pulled from the page-level batched cache).
            $uscoreset = $page_score_cache[$u->id] ?? ['score' => 100, 'band' => 'high', 'label' => get_string('security_score_high', 'auth_devicelock'), 'breakdown' => []];
            $scorecell = auth_devicelock_render_security_score_badge($uscoreset);
            $tablerow = [$checkboxcell, $fullnamecell, $emailcell, $authcell, $devicecell, $typecell, $scorecell, $maxdevicescell, $logcell, $actionmenu];
            // v3.4.3: banned users get ONE solid red-tinted row (styled in
            // styles.css). The old approach injected a background onto every
            // <div> inside the cells, which produced a patchy overlay over
            // the name/buttons instead of tinting the whole row.
            $userrow = new html_table_row($tablerow);
            if (isset($banned_users[$u->id])) {
                $userrow->attributes['class'] = 'lg-row-banned';
            }
            $table->data[] = $userrow;
        }
        echo html_writer::table($table);
        echo '  </div>'; // end table-responsive
        echo '</form>'; // close bulk-action form
        // Live selection + selected-count behaviour (v3.7.0: "Select All"
        // now covers EVERY user matching the current filter - not just the
        // current page - by submitting hidden checkbox inputs for the users
        // on other pages; "Select Visible" keeps the old per-page behaviour).
        echo '<script>
        // Swap the bulk-form action input so the "Copy Details (CSV)" button
        // can reuse the same checkbox form as the "Delete Selected" button.
        window.lgBulkSetAction = function(act, warn) {
            var f = document.getElementById("bulk_users_form");
            if (!f) { return true; }
            var inp = f.querySelector("input[name=action]");
            if (inp) { inp.value = act; }
            if (act === "bulkcopydetails" && warn && !window.confirm(warn)) {
                return false;
            }
            return true;
        };
        // Every userid matching the current search / filters (injected
        // server-side) - the pool "Select All" draws from.
        window.lgAllUserIds = ' . json_encode($alluserids) . ';
        document.addEventListener("DOMContentLoaded", function() {
            var form = document.getElementById("bulk_users_form");
            var selectAll = document.getElementById("select_all_users");
            var boxes = document.querySelectorAll(".user-select-checkbox");
            var badge = document.getElementById("bulk_count_badge");
            function hiddenInputs() {
                if (!form) { return []; }
                return Array.prototype.slice.call(form.querySelectorAll(\'input[name="selected_users[]"][data-lg-hidden-select="1"]\'));
            }
            function removeHidden() {
                hiddenInputs().forEach(function(h) { if (h.parentNode) { h.parentNode.removeChild(h); } });
            }
            function updateBadge() {
                if (!badge || !form) { return; }
                var n = form.querySelectorAll(\'input[name="selected_users[]"]:checked\').length;
                // v3.7.0: localised count text (the "__N__" placeholder comes
                // from the badge\'s data-count-format attribute server-side).
                var fmt = badge.getAttribute("data-count-format");
                badge.textContent = fmt ? String(fmt).replace("__N__", n) : (n + " selected");
            }
            function setVisible(on) {
                boxes.forEach(function(b){ b.checked = on; });
                if (selectAll) { selectAll.checked = on; }
            }
            // Select All = the WHOLE filtered result set. Users rendered on
            // this page are ticked normally; everyone else is submitted as a
            // hidden checked checkbox appended to the bulk form.
            function selectEverything() {
                setVisible(true);
                removeHidden();
                if (form && window.lgAllUserIds && window.lgAllUserIds.length) {
                    var present = {};
                    boxes.forEach(function(b) { present[String(b.value)] = true; });
                    window.lgAllUserIds.forEach(function(uid) {
                        uid = String(uid);
                        if (present[uid]) { return; }
                        var inp = document.createElement("input");
                        inp.type = "checkbox";
                        inp.name = "selected_users[]";
                        inp.value = uid;
                        inp.checked = true;
                        inp.style.display = "none";
                        inp.setAttribute("data-lg-hidden-select", "1");
                        form.appendChild(inp);
                    });
                }
                updateBadge();
            }
            if (selectAll) {
                selectAll.addEventListener("change", function(){
                    boxes.forEach(function(b){ b.checked = selectAll.checked; });
                    // Unchecking the header box also drops the invisible
                    // "other pages" selections - never leave hidden users
                    // selected behind the admin\'s back.
                    if (!selectAll.checked) { removeHidden(); }
                    updateBadge();
                });
            }
            boxes.forEach(function(b){ b.addEventListener("change", updateBadge); });
            var sa = document.getElementById("bulk_select_all_btn");
            if (sa) { sa.addEventListener("click", selectEverything); }
            var sv = document.getElementById("bulk_select_visible_btn");
            if (sv) { sv.addEventListener("click", function(){ removeHidden(); setVisible(true); updateBadge(); }); }
            var cl = document.getElementById("bulk_clear_btn");
            if (cl) { cl.addEventListener("click", function(){ removeHidden(); setVisible(false); updateBadge(); }); }
            updateBadge();

            // v3.7.0: the page-size choice (?uperpage=) is temporary - strip
            // it from the address bar right after render, so a plain refresh
            // (or any page / search / filter link) returns to the default.
            if (window.history && window.history.replaceState && window.URL) {
                var cleanurl = new URL(window.location.href);
                if (cleanurl.searchParams.has("uperpage")) {
                    cleanurl.searchParams.delete("uperpage");
                    window.history.replaceState(null, "", cleanurl.toString());
                }
            }
            var ppsel = document.getElementById("lg_users_per_page");
            var ppbtn = document.getElementById("lg_show_all_btn");
            var ppbase = ' . json_encode($pagesizeurl->out(false)) . ';
            function goPerPage(val) {
                window.location.href = ppbase + (ppbase.indexOf("?") === -1 ? "?" : "&") + "uperpage=" + encodeURIComponent(val);
            }
            if (ppsel) { ppsel.addEventListener("change", function(){ goPerPage(ppsel.value); }); }
            if (ppbtn) { ppbtn.addEventListener("click", function(){ goPerPage("all"); }); }
        });
        </script>';
    }
    echo '</div>'; // End table card body
    
    // Pagination + temporary page-size control (v3.7.0).
    if ($totaluserscount > 0) {
        $showallactive = ($userperpage >= 1000000);
        echo '<div class="mt-3 p-3 d-flex flex-wrap justify-content-between align-items-center">';
        // Users-per-page selector + Show All. The choice is temporary: the
        // ?uperpage= parameter never enters the pagination/search/filter
        // links and is stripped from the address bar after render, so a
        // refresh or a page change returns to the default of 20.
        echo '<div class="d-inline-flex align-items-center">';
        echo '<label class="mr-2 mb-0 text-nowrap" for="lg_users_per_page"><i class="fa fa-list-ul text-secondary mr-1"></i> ' . s(get_string('users_per_page', 'auth_devicelock')) . '</label>';
        echo '<select id="lg_users_per_page" class="form-control form-control-sm" style="width:auto;" aria-label="' . s(get_string('users_per_page', 'auth_devicelock')) . '">';
        foreach ([10, 20, 50, 100, 250] as $ppopt) {
            $ppsel = (!$showallactive && (int)$userperpage === $ppopt) ? ' selected' : '';
            echo '<option value="' . $ppopt . '"' . $ppsel . '>' . $ppopt . '</option>';
        }
        if ($showallactive) {
            echo '<option value="all" selected>' . s(get_string('show_all_users', 'auth_devicelock')) . '</option>';
        }
        echo '</select>';
        echo '<button type="button" id="lg_show_all_btn" class="btn btn-sm btn-outline-secondary ml-2"' . ($showallactive ? ' disabled' : '') . ' title="' . s(get_string('show_all_users_hint', 'auth_devicelock')) . '"><i class="fa fa-expand"></i> ' . s(get_string('show_all_users', 'auth_devicelock')) . '</button>';
        echo '</div>';
        if ($totaluserscount > $userperpage) {
            echo '<div class="mt-2 mt-md-0">';
            echo $OUTPUT->render(new \paging_bar($totaluserscount, $userpage, $userperpage, new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users', 'user_search' => $user_search, 'ufilter' => $ufilter]), 'userpage'));
            echo '</div>';
        }
        echo '</div>';
    }
    echo '</div>'; // End card outer wrapper
    
} else if ($tab === 'nonplugin') {
    // ------------------------------------------------------------
    // TAB: USERS NOT USING PLUGIN
    // ------------------------------------------------------------
    
    // Search Bar — the magnifier button submits the search, the in-bar × clears it.
    // v3.4.3: buttons are direct children of .input-group so they attach on
    // both Bootstrap 4 (Moodle 4.x) and Bootstrap 5 (Moodle 5.x).
    $npclearurl = new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'nonplugin']);
    echo '<div class="card mb-4 bg-light">';
    echo '<div class="card-body p-3">';
    echo '<form method="get" action="' . new moodle_url('/auth/devicelock/admin_devices.php') . '" class="m-0">';
    echo '<input type="hidden" name="tab" value="nonplugin">';
    echo '<label class="sr-only" for="user_search">Search Users</label>';
    echo '<div class="input-group lg-searchbar">';
    echo '<button type="submit" class="btn btn-primary px-3" title="Search Users" aria-label="Search Users"><i class="fa fa-search" aria-hidden="true"></i></button>';
    echo '<input type="text" class="form-control" id="user_search" name="user_search" value="' . s($user_search) . '" placeholder="' . s(get_string('usersearch_placeholder', 'auth_devicelock')) . '" autocomplete="off">';
    echo '<button type="button" class="btn btn-outline-secondary bg-white text-muted" id="user_search_clear" title="Clear search" aria-label="Clear search"' . (empty($user_search) ? ' style="display:none;"' : '') . '><i class="fa fa-times" aria-hidden="true"></i></button>';
    echo '</div>';
    echo '</form>';
    echo '</div></div>';
    echo '<script>
(function() {
    var inp = document.getElementById("user_search");
    var clr = document.getElementById("user_search_clear");
    var active = ' . (empty($user_search) ? 'false' : 'true') . ';
    var clearurl = ' . json_encode($npclearurl->out(false)) . ';
    function toggle() {
        if (clr && inp) { clr.style.display = inp.value ? "" : "none"; }
    }
    if (inp) { inp.addEventListener("input", toggle); toggle(); }
    if (clr) {
        clr.addEventListener("click", function() {
            if (inp && inp.value) { inp.value = ""; }
            if (active) { window.location.href = clearurl; return; }
            toggle();
            if (inp) { inp.focus(); }
        });
    }
})();
</script>';
    
    // Form for bulk conversion / bulk delete (multiple submit buttons drive action).
    $bulkformurl = new moodle_url('/auth/devicelock/admin_devices.php', ['sesskey' => sesskey()]);
    $exportnpurl = new moodle_url('/auth/devicelock/admin_devices.php', [
        'action' => 'exportuserscsv', 'scope' => 'nonplugin', 'sesskey' => sesskey(), 'tab' => 'nonplugin', 'user_search' => $user_search,
    ]);
    echo '<form method="post" action="' . $bulkformurl . '" id="bulk_convert_form">';
    echo '<input type="hidden" name="tab" value="nonplugin">';
    echo '<input type="hidden" name="user_search" value="' . s($user_search) . '">';
    echo '<input type="hidden" name="userpage" value="' . (int)$userpage . '">';
    echo '<input type="hidden" name="sesskey" value="' . sesskey() . '">';

    // User Query
    $user_params = [];
    // v3.10.0: u.id > 1 - hide only guest; admins follow the includeadmins setting.
    $npbase_where = "u.deleted = 0 AND u.auth != 'devicelock' AND u.id > 1" . auth_devicelock_admin_exclude_sql('u');
    // v3.9.0: same fuzzy typo-retry semantics as the main User Directory.
    $np_typo_retry = $user_search ? auth_devicelock_fuzzy_typo_retry($user_search, $npbase_where) : false;
    $user_where = $npbase_where;
    if ($user_search) {
        $user_where .= " AND " . auth_devicelock_build_user_search_where($user_search, 'u', $user_params, 'np_srch_', $np_typo_retry);
    }

    // Click-to-filter: when score_band is set, restrict to users whose cached
    // security score falls in that band (mirrors the main users-tab logic).
    $np_score_band_filter = optional_param('score_band', '', PARAM_ALPHA);
    $np_band_active = in_array($np_score_band_filter, ['high', 'good', 'fair', 'poor', 'critical'], true);
    if ($np_band_active && $DB->get_manager()->table_exists('auth_devicelock_user_scores')) {
        $band_ranges = [
            'high'     => [85, 100],
            'good'     => [70, 84],
            'fair'     => [50, 69],
            'poor'     => [25, 49],
            'critical' => [0, 24],
        ];
        $npr = $band_ranges[$np_score_band_filter];
        $bprows = $DB->get_records_select('auth_devicelock_user_scores', 'score >= :lo AND score <= :hi', ['lo' => $npr[0], 'hi' => $npr[1]], '', 'userid');
        $np_band_userids = [];
        foreach ($bprows as $bp) {
            $np_band_userids[] = (int)$bp->userid;
        }
        if (empty($np_band_userids)) {
            $user_where .= " AND 1=0";
        } else {
            list($binsql, $binparams) = $DB->get_in_or_equal($np_band_userids, SQL_PARAMS_NAMED, 'npband_');
            $user_where .= " AND u.id $binsql";
            $user_params = array_merge($user_params, $binparams);
        }
    }

    $users_sql = "SELECT u.id, u.username, u.firstname, u.lastname, u.email, u.idnumber, u.phone1, u.auth, u.picture, u.imagealt, u.suspended
                  FROM {user} u
                  WHERE $user_where
                  ORDER BY u.lastname ASC, u.firstname ASC";

    $totalnonpluginusers = $DB->count_records_sql("SELECT count(DISTINCT u.id) FROM {user} u WHERE $user_where", $user_params);
    $users = $DB->get_records_sql($users_sql, $user_params, $userpage * $perpage, $perpage);

    // Pre-fetch custom profile fields (Uni_ID and Phone_Number) for users on this page
    $nonplugin_custom_identifiers = !empty($users) ? auth_devicelock_get_custom_profile_identifiers(array_keys($users)) : [];

    echo '<div class="card mb-4 shadow-sm">';
    echo '<div class="card-header d-flex flex-wrap justify-content-between align-items-center">';
    echo '  <span><strong><i class="fa fa-user-times text-warning mr-1"></i> Users Not Using Plugin</strong> <span class="badge badge-warning badge-pill ml-1">' . $totalnonpluginusers . '</span></span>';
    echo '  <span>';
    // Show the active band filter as a dismissible badge (mirrors main users tab).
    if ($np_band_active) {
        $np_band_labels = [
            'high' => get_string('security_score_high', 'auth_devicelock'),
            'good' => get_string('security_score_good', 'auth_devicelock'),
            'fair' => get_string('security_score_fair', 'auth_devicelock'),
            'poor' => get_string('security_score_poor', 'auth_devicelock'),
            'critical' => get_string('security_score_critical', 'auth_devicelock'),
        ];
        $np_clearband_url = new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'nonplugin', 'user_search' => $user_search]);
        echo '    <span class="badge badge-info badge-pill mr-2"><i class="fa fa-filter"></i> ' . s($np_band_labels[$np_score_band_filter]) . ' <a href="' . $np_clearband_url . '" class="text-white ml-1" title="' . s(get_string('clear', 'moodle')) . '"><i class="fa fa-times"></i></a></span>';
    }
    echo '    <a href="' . $exportnpurl . '" class="btn btn-sm btn-outline-success mr-1"><i class="fa fa-file-csv"></i> ' . get_string('export_users_csv', 'auth_devicelock') . '</a>';
    echo '    <button type="submit" name="action" value="bulkconvert" class="btn btn-sm btn-success"><i class="fa fa-lock"></i> Convert to Plugin</button>';
    echo '    <button type="submit" name="action" value="bulkcopydetails" class="btn btn-sm btn-outline-primary ml-1" onclick="return confirm(\'' . s(get_string('bulk_copy_details_warning', 'auth_devicelock')) . '\');"><i class="fa fa-clone"></i> ' . get_string('bulk_copy_details', 'auth_devicelock') . '</button>';
    echo '    <button type="submit" name="action" value="bulkdeleteusers" class="btn btn-sm btn-outline-danger ml-1"><i class="fa fa-trash"></i> ' . get_string('bulk_delete_selected', 'auth_devicelock') . '</button>';
    echo '  </span>';
    echo '</div>';
    echo '<div class="card-body p-0 table-responsive">';
    
    if (empty($users)) {
        echo '<div class="p-4 text-center text-muted">All active users are currently using the plugin, or no matching users found.</div>';
    } else {
        $table = new html_table();
        $selectallcheckbox = '<input type="checkbox" id="select_all_users" class="mr-2" style="transform: scale(1.2);">';
        $table->head = [$selectallcheckbox, 'Full Name', 'Email / Identifiers', 'Current Auth Method', 'User Type', 'Score', 'Actions'];
        $table->attributes['class'] = 'table table-hover table-striped mb-0 align-middle';

        // Batch-compute the security score for every user on this page.
        $np_score_cache = auth_devicelock_compute_security_scores_batch(array_keys($users));

        foreach ($users as $u) {
            $userobj = new stdClass();
            $userobj->id = $u->id;
            $userobj->picture = $u->picture;
            $userobj->firstname = $u->firstname;
            $userobj->lastname = $u->lastname;
            $userobj->imagealt = $u->imagealt;
            $userobj->email = $u->email;
            
            // Checkbox cell
            $checkboxcell = '<input type="checkbox" name="selected_users[]" value="' . $u->id . '" class="user-select-checkbox" style="transform: scale(1.2);">';
            
            // Full Name cell
            $pic = $OUTPUT->user_picture($userobj, ['size' => 35, 'class' => 'mr-2 rounded-circle']);
            $fullnamecell = '<div class="d-flex align-items-center">' . $pic . '<strong>' . fullname($userobj) . '</strong></div>';
            
            // Email & Identifiers cell
            $c_info = $nonplugin_custom_identifiers[$u->id] ?? ['uni_id' => '', 'phone' => ''];
            $uni_id = !empty($c_info['uni_id']) ? $c_info['uni_id'] : (!empty($u->idnumber) ? $u->idnumber : '');
            $phone  = !empty($c_info['phone']) ? $c_info['phone'] : (!empty($u->phone1) ? $u->phone1 : (!empty($u->phone2) ? $u->phone2 : ''));

            $extrainfo = [];
            if (!empty($uni_id)) {
                $extrainfo[] = '<span class="badge badge-light border text-dark" title="Your University ID"><i class="fa fa-id-card text-primary"></i> ' . s($uni_id) . '</span>';
            }
            if (!empty($phone)) {
                $extrainfo[] = '<span class="badge badge-light border text-dark" title="Phone Number"><i class="fa fa-phone text-success"></i> ' . s($phone) . '</span>';
            }
            $extrastr = !empty($extrainfo) ? '<div class="mt-1">' . implode(' ', $extrainfo) . '</div>' : '';
            $emailcell = '<code>' . s($u->email) . '</code>' . $extrastr;
            
            // Auth method cell
            $authcell = '<span class="badge badge-secondary">' . s($u->auth) . '</span>';
            
            // User Type cell (Admin, Teacher, Student)
            $usertype = 'Student / User';
            $usertypebadge = 'badge-light';
            if (is_siteadmin($u->id)) {
                $usertype = 'Site Admin';
                $usertypebadge = 'badge-danger';
            } else {
                $roles = $DB->get_records_sql("
                    SELECT DISTINCT r.shortname 
                    FROM {role_assignments} ra 
                    JOIN {role} r ON ra.roleid = r.id 
                    WHERE ra.userid = ?
                ", [$u->id]);
                foreach ($roles as $role) {
                    if (in_array($role->shortname, ['teacher', 'editingteacher', 'manager'])) {
                        $usertype = 'Teacher / Manager';
                        $usertypebadge = 'badge-warning';
                        break;
                    }
                }
            }
            $typecell = '<span class="badge ' . $usertypebadge . '">' . $usertype . '</span>';
            
            $user_baseurl = new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'nonplugin', 'user_search' => $user_search, 'userpage' => $userpage]);
            
            $migrateurl = new moodle_url($user_baseurl, ['action' => 'migrateuser', 'userid' => $u->id, 'sesskey' => sesskey()]);
            
            $menu = new action_menu();
            $menu->set_menu_trigger(get_string('actions'));
            $menu->attributes['class'] .= ' d-inline-block';
            
            // View user details action
            $viewuserurl = new moodle_url('/auth/devicelock/admin_devices.php', ['action' => 'viewuser', 'userid' => $u->id, 'tab' => 'nonplugin']);
            $menu->add(new action_menu_link_secondary(
                $viewuserurl,
                new pix_icon('i/info', '', 'moodle', ['class' => 'mr-1 text-primary']),
                'View User Details / Devices',
                ['class' => 'text-primary']
            ));
            
            // Migrate to plugin action
            $menu->add(new action_menu_link_secondary(
                $migrateurl,
                new pix_icon('t/locked', '', 'moodle', ['class' => 'mr-1 text-success']),
                'Migrate to Plugin',
                ['class' => 'text-success']
            ));

            // Copy User Details (copies username + a fresh temp password)
            $copydetailsurl = new moodle_url($user_baseurl, ['action' => 'copyuserdetailsform', 'userid' => $u->id, 'sesskey' => sesskey()]);
            $menu->add(new action_menu_link_secondary(
                $copydetailsurl,
                new pix_icon('t/copy', '', 'moodle', ['class' => 'mr-1 text-success']),
                get_string('copy_user_details', 'auth_devicelock'),
                ['class' => 'text-success', 'title' => get_string('copy_user_details', 'auth_devicelock')]
            ));

            // Delete User Account (permanently removes the Moodle user + all info)
            $deleteuserurl = new moodle_url($user_baseurl, ['action' => 'deleteuser', 'userid' => $u->id, 'sesskey' => sesskey()]);
            $menu->add(new action_menu_link_secondary(
                $deleteuserurl,
                new pix_icon('t/delete', '', 'moodle', ['class' => 'mr-1 text-danger']),
                get_string('delete_user_account', 'auth_devicelock'),
                ['class' => 'text-danger font-weight-bold', 'title' => get_string('delete_user_account', 'auth_devicelock')]
            ));

            $actionmenu = $OUTPUT->render($menu);

            // Per-user security score (pulled from the page-level batched cache).
            $np_scoreset = $np_score_cache[$u->id] ?? ['score' => 100, 'band' => 'high', 'label' => get_string('security_score_high', 'auth_devicelock'), 'breakdown' => []];
            $np_scorecell = auth_devicelock_render_security_score_badge($np_scoreset);
            $table->data[] = [$checkboxcell, $fullnamecell, $emailcell, $authcell, $typecell, $np_scorecell, $actionmenu];
        }
        echo html_writer::table($table);
    }
    echo '</div>'; // End table card body
    
    // Pagination
    if ($totalnonpluginusers > $perpage) {
        echo '<div class="mt-3 p-3">';
        echo $OUTPUT->render(new \paging_bar($totalnonpluginusers, $userpage, $perpage, new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'nonplugin', 'user_search' => $user_search]), 'userpage'));
        echo '</div>';
    }
    echo '</div>'; // End card outer wrapper
    echo '</form>';
    
    // Inline Script for Select All toggling
    echo '
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        var selectAll = document.getElementById("select_all_users");
        if (selectAll) {
            selectAll.addEventListener("change", function() {
                var checkboxes = document.querySelectorAll(".user-select-checkbox");
                checkboxes.forEach(function(cb) {
                    cb.checked = selectAll.checked;
                });
            });
        }
    });
    </script>';
    
} else if ($tab === 'logs') {
    // ------------------------------------------------------------
    // TAB 3: SECURITY & ERROR LOGS
    // ------------------------------------------------------------
    
    // Event type choices for the dropdown filter, grouped for readability.
    $log_action_groups = [
        'User Activity' => [
            'activity_all'          => 'All User Activity',
            'activity_page'         => 'Page Viewed',
            'activity_course'       => 'Course Viewed',
            'activity_section'      => 'Section Viewed',
            'activity_module'       => 'Activity Viewed',
            'activity_dashboard'    => 'Dashboard Viewed',
            'activity_mycourses'    => 'My Courses Viewed',
            'activity_profile'      => 'Profile Viewed',
            'activity_participants' => 'Participants Viewed',
            'activity_grades'       => 'Grades Viewed',
            'activity_catalog'      => 'Course Catalog Viewed',
            'activity_download'     => 'File Accessed',
            'activity_link'         => 'External Link Opened',
            'activity_click'        => 'Button Clicked',
            'activity_tour'         => 'User Tour',
        ],
        'Device & account' => [
            'login_prevented'              => 'Blocked Login',
            'device_limit_reached'         => 'Limit Blocked',
            'unexpected_device_login'      => 'Unexpected Login',
            'device_status_blocked'        => 'Device Blocked',
            'device_status_active'         => 'Device Unblocked',
            'new_browser_on_device'        => 'New Browser',
            'browser_login'                => 'Browser Login',
            'device_registered'            => 'Registered',
            'device_login'                 => 'Device Login',
            'user_logout'                  => 'User Logout',
            'auth_method_migrated'         => 'Migrated',
            'reset_all_devices'            => 'Reset User Devices',
            'reset_device_browsers'        => 'Browsers Reset',
            'browser_limit_reached'        => 'Browser Limit',
            'reset_all_users_devices'      => 'Reset All Users',
            'save_user_limit'              => 'Limit Changed',
            'send_custom_email'            => 'Email Sent',
            'auth_method_changed'          => 'Auth Changed',
            'send_reset_password'          => 'Pwd Reset Sent',
            'generate_temporary_password'  => 'Temp Pwd Created',
            'change_password_direct'       => 'Password Changed',
            'toggle_suspend'               => 'Suspend Toggled',
            'confirm_user'                 => 'User Confirmed',
            'copy_user_details'            => 'Details Copied',
            'delete_user_account'          => 'Account Deleted',
            'bulk_delete_user_account'     => 'Bulk Deletion',
            'clear_all_logs'               => 'Logs Cleared',
            'bulk_copy_user_details'       => 'Bulk Details Copied',
            'bulk_import_users'            => 'Bulk User Import',
            'quick_create_user'            => 'Quick User Created',
            'bulk_create_users'            => 'Bulk Users Created',
            'password_changed'             => 'Password Changed',
            'password_reset_completed'     => 'Password Reset Completed',
            'user_migrated'                => 'User Migrated',
            'user_migrated_bulk'           => 'Users Migrated (Bulk)',
            'auth_method_changed_bulk'     => 'Auth Changed (Bulk)',
            'send_custom_email_bulk'       => 'Email Sent (Bulk)',
            'reset_user_browsers'          => 'User Browsers Reset',
            'ban_user'                     => 'User Banned',
            'unban_user'                   => 'User Unbanned',
            'bulk_ban_users'               => 'Bulk Ban',
            'bulk_unban_users'             => 'Bulk Unban',
            'change_course'                => 'Courses Changed',
            'bulk_change_course'           => 'Bulk Course Change',
            'change_role'                  => 'Roles Changed',
            'bulk_change_role'             => 'Bulk Role Change',
        ],
        'App Guard' => [
            'web_browser_sign_in_blocked'    => 'App Guard: Sign-in Blocked',
            'web_browser_session_terminated' => 'App Guard: Session Terminated',
            'emulator_detected'              => 'App Guard: Emulator Detected',
            'dev_options_detected'           => 'App Guard: Developer Options',
            'usb_debugging_detected'         => 'App Guard: USB Debugging',
            'wireless_debugging_detected'    => 'App Guard: Wireless Debugging',
            'screenshot_attempt'             => 'App Guard: Screenshot',
            'screen_recording_detected'      => 'App Guard: Screen Recording',
            'audio_capture_detected'         => 'App Guard: Audio Capture',
            'mic_guard_unavailable'          => 'App Guard: Mic Guard Unavailable',
            'mic_contended'                  => 'App Guard: Mic Contended',
            'vm_detected' => 'App Guard: Virtual machine detected',
            'debugger_detected' => 'App Guard: Debugger detected',
            'dev_mode_detected' => 'App Guard: Developer mode detected',
            'test_signing_detected' => 'App Guard: Test signing detected',
            'remote_session_detected' => 'App Guard: Remote session detected',
            'virtual_display_detected' => 'App Guard: Virtual display detected',
            'capture_tool_detected' => 'App Guard: Capture / remote tool detected',
            'recorder_suspected' => 'App Guard: Recorder suspected (report only)',
        ],
    ];

    // Search Bar — the magnifier button submits the search, the in-bar × clears it.
    // v3.4.3: buttons are direct children of .input-group so they attach on
    // both Bootstrap 4 (Moodle 4.x) and Bootstrap 5 (Moodle 5.x).
    $logsclearurl = new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'logs']);
    echo '<div class="card mb-4 bg-light">';
    echo '<div class="card-body p-3">';
    echo '<form method="get" action="' . new moodle_url('/auth/devicelock/admin_devices.php') . '" class="row align-items-center">';
    echo '<input type="hidden" name="tab" value="logs">';
    echo '<div class="col-lg-7 my-1">';
    echo '<label class="sr-only" for="log_search">Search Logs</label>';
    echo '<div class="input-group lg-searchbar">';
    echo '<button type="submit" class="btn btn-primary px-3" title="Search Logs" aria-label="Search Logs"><i class="fa fa-search" aria-hidden="true"></i></button>';
    echo '<input type="text" class="form-control" id="log_search" name="log_search" value="' . s($log_search) . '" placeholder="Search logs by user, action, IP, university ID, phone, or details..." autocomplete="off">';
    echo '<button type="button" class="btn btn-outline-secondary bg-white text-muted" id="log_search_clear" title="Clear search &amp; filter" aria-label="Clear search and filter"' . (empty($log_search) && empty($log_action_filter) ? ' style="display:none;"' : '') . '><i class="fa fa-times" aria-hidden="true"></i></button>';
    echo '</div></div>';
    echo '<div class="col-lg-5 my-1">';
    echo '<label class="sr-only" for="log_action_filter">Filter by event type</label>';
    echo '<select name="log_action_filter" id="log_action_filter" class="form-control" onchange="this.form.submit();">';
    echo '<option value="">All Event Types</option>';
    foreach ($log_action_groups as $grouplabel => $choices) {
        echo '<optgroup label="' . s($grouplabel) . '">';
        foreach ($choices as $value => $label) {
            $selected = ($log_action_filter === $value) ? ' selected' : '';
            echo '<option value="' . s($value) . '"' . $selected . '>' . s($label) . '</option>';
        }
        echo '</optgroup>';
    }
    echo '</select>';
    echo '</div>';
    echo '</form>';
    echo '</div></div>';
    echo '<script>
(function() {
    var inp = document.getElementById("log_search");
    var clr = document.getElementById("log_search_clear");
    var sel = document.getElementById("log_action_filter");
    var filteractive = ' . ($log_action_filter !== '' ? 'true' : 'false') . ';
    var clearurl = ' . json_encode($logsclearurl->out(false)) . ';
    function toggle() {
        if (!clr) { return; }
        var hastext = inp && inp.value;
        var selfilter = sel && sel.selectedIndex > 0;
        clr.style.display = (hastext || selfilter || filteractive) ? "" : "none";
    }
    if (inp) { inp.addEventListener("input", toggle); }
    if (sel) { sel.addEventListener("change", toggle); }
    toggle();
    if (clr) {
        clr.addEventListener("click", function() {
            if (inp && inp.value) { inp.value = ""; }
            if (sel && sel.selectedIndex > 0) { sel.selectedIndex = 0; }
            if (filteractive) { window.location.href = clearurl; return; }
            toggle();
            if (inp) { inp.focus(); }
        });
    }
})();
</script>';
    
    // Logs Query
    $log_params = [];
    $log_where = "1=1";
    if ($log_search) {
        $usr_search_where = auth_devicelock_build_user_search_where($log_search, 'u', $log_params, 'lg_usr_');
        $log_where .= " AND ($usr_search_where OR l.action LIKE :lg_act OR l.ip_address LIKE :lg_ip OR l.details LIKE :lg_det)";
        $log_params['lg_act'] = "%" . $DB->sql_like_escape($log_search) . "%";
        $log_params['lg_ip'] = "%" . $DB->sql_like_escape($log_search) . "%";
        $log_params['lg_det'] = "%" . $DB->sql_like_escape($log_search) . "%";
    }
    if ($log_action_filter) {
        if ($log_action_filter === 'activity_all') {
            // Pseudo-filter: every user-activity event type at once.
            $log_where .= " AND " . $DB->sql_like('l.action', ':lg_actlike', true, true, false);
            $log_params['lg_actlike'] = 'activity%';
        } else {
            $log_where .= " AND l.action = :lg_action_filter";
            $log_params['lg_action_filter'] = $log_action_filter;
        }
    }
    
    $log_sql = "SELECT l.id, l.userid, l.device_fingerprint, l.action, l.ip_address, l.user_agent, l.timestamp, l.details,
                       u.firstname, u.lastname, u.email, u.picture, u.imagealt
                FROM {auth_devicelock_logs} l
                LEFT JOIN {user} u ON l.userid = u.id
                WHERE $log_where
                ORDER BY l.timestamp DESC";
                
    $totallogscount = $DB->count_records_sql("SELECT count(l.id) FROM {auth_devicelock_logs} l LEFT JOIN {user} u ON l.userid = u.id WHERE $log_where", $log_params);
    $logs = $DB->get_records_sql($log_sql, $log_params, $logpage * $perpage, $perpage);
    
    // Pre-fetch custom profile fields (Uni_ID and Phone_Number) for users on this page
    $log_uids = [];
    foreach ($logs as $l) {
        if (!empty($l->userid)) {
            $log_uids[] = (int)$l->userid;
        }
    }
    $log_custom_identifiers = !empty($log_uids) ? auth_devicelock_get_custom_profile_identifiers($log_uids) : [];
    
    $exportlogsurl = new moodle_url('/auth/devicelock/admin_devices.php', [
        'action' => 'exportlogscsv', 'sesskey' => sesskey(), 'tab' => 'logs',
        'log_search' => $log_search, 'log_action_filter' => $log_action_filter,
    ]);
    $clearlogsurl = new moodle_url('/auth/devicelock/admin_devices.php', [
        'action' => 'clearlogs', 'sesskey' => sesskey(), 'tab' => 'logs',
        'log_search' => $log_search, 'log_action_filter' => $log_action_filter, 'logpage' => $logpage,
    ]);

    echo '<div class="card mb-4 shadow-sm">';
    echo '<div class="card-header d-flex flex-wrap justify-content-between align-items-center">';
    echo '  <strong><i class="fa fa-clipboard-list"></i> Activity &amp; Security Logs</strong> <span class="badge badge-secondary badge-pill ml-1">' . $totallogscount . ' events</span>';
    echo '  <span>';
    echo '    <a href="' . $exportlogsurl . '" class="btn btn-sm btn-outline-success mr-1"><i class="fa fa-file-csv"></i> ' . get_string('export_logs_csv', 'auth_devicelock') . '</a>';
    echo '    <a href="' . $clearlogsurl . '" class="btn btn-sm btn-outline-danger" onclick="return confirm(\'' . s(get_string('clear_logs_confirm', 'auth_devicelock')) . '\');"><i class="fa fa-eraser"></i> ' . get_string('clear_logs', 'auth_devicelock') . '</a>';
    echo '  </span>';
    echo '</div>';
    echo '<div class="card-body p-0 table-responsive">';
    
    if (empty($logs)) {
        echo '<div class="p-4 text-center text-muted">No events logged yet.</div>';
    } else {
        $table = new html_table();
        $table->head = ['Time', 'User', 'Event / Action', 'IP Address', 'Fingerprint', 'Details'];
        $table->attributes['class'] = 'table table-hover table-striped mb-0 align-middle';
        
        foreach ($logs as $l) {
            // Time
            $timecell = '<span class="lg-log-time">' . device_manager::format_gmt2_date($l->timestamp, 'd M Y, H:i:s') . '</span>';
            
            // User formatting
            if ($l->userid > 0 && !empty($l->email)) {
                $userobj = new stdClass();
                $userobj->id = $l->userid;
                $userobj->picture = $l->picture;
                $userobj->firstname = $l->firstname;
                $userobj->lastname = $l->lastname;
                $userobj->imagealt = $l->imagealt;
                $userobj->email = $l->email;
                $pic = $OUTPUT->user_picture($userobj, ['size' => 30, 'class' => 'mr-2 rounded-circle']);

                $c_info = $log_custom_identifiers[$l->userid] ?? ['uni_id' => '', 'phone' => ''];
                $uni_id = !empty($c_info['uni_id']) ? $c_info['uni_id'] : '';
                $phone  = !empty($c_info['phone']) ? $c_info['phone'] : '';

                $extrainfo = [];
                if (!empty($uni_id)) {
                    $extrainfo[] = '<span class="badge badge-light border text-dark" title="Your University ID"><i class="fa fa-id-card text-primary"></i> ' . s($uni_id) . '</span>';
                }
                if (!empty($phone)) {
                    $extrainfo[] = '<span class="badge badge-light border text-dark" title="Phone Number"><i class="fa fa-phone text-success"></i> ' . s($phone) . '</span>';
                }
                $extrastr = !empty($extrainfo) ? '<div class="mt-1">' . implode(' ', $extrainfo) . '</div>' : '';

                $usercell = '<div class="d-flex align-items-center">' . $pic . '<div><strong>' . fullname($userobj) . '</strong>' . $extrastr . '</div></div>';
            } else if ($l->userid > 0) {
                $usercell = 'User ID: ' . $l->userid;
            } else {
                $usercell = '<span class="lg-dimtext"><i class="fa fa-gears"></i> System</span>';
            }
            
            // Action highlight and humanized badges (shared helper).
            $actioncell = auth_devicelock_action_badge($l->action);
            
            // IP
            $ipcell = '<code>' . s($l->ip_address) . '</code>';
            
            // Fingerprint
            $fpcell = auth_devicelock_fingerprint_span($l->device_fingerprint);
            
            // Details description (styled chips, shared helper).
            $detailscell = auth_devicelock_log_details_cell($l->details);
            
            $table->data[] = [$timecell, $usercell, $actioncell, $ipcell, $fpcell, $detailscell];
        }
        echo html_writer::table($table);
        // v3.4.4: click-to-expand behaviour for the event rows.
        auth_devicelock_print_log_expand_js();
    }
    echo '</div>'; // End table card body
    
    // Pagination
    if ($totallogscount > $perpage) {
        echo '<div class="mt-3 p-3">';
        echo $OUTPUT->render(new \paging_bar($totallogscount, $logpage, $perpage, new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'logs', 'log_search' => $log_search, 'log_action_filter' => $log_action_filter]), 'logpage'));
        echo '</div>';
    }
    echo '</div>'; // End card outer wrapper
}

echo $OUTPUT->footer();