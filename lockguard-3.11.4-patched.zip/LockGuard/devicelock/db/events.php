<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Event observers for Lock Guard plugin
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$observers = [
    [
        'eventname' => '\core\event\user_loggedin',
        'callback' => '\auth_devicelock\observer::user_loggedin',
        'internal' => false,
        'priority' => 1000,
    ],
    [
        // v3.5.0: seed the persistent security-score row (100%) when a new
        // account is created.
        'eventname' => '\core\event\user_created',
        'callback' => '\auth_devicelock\observer::user_created',
        'internal' => false,
        'priority' => 1000,
    ],
    // v3.8.0: user-activity observers. These are the SAME core events
    // that Moodle's standard Logs report reads, so the plugin's
    // Activity & Security Logs now record course, activity-module,
    // profile, participants, category and grades views plus user
    // tours reliably on Moodle 5.0/5.1 - the v3.6.0 output-hook
    // page logger did not record any of them there. Observing the
    // abstract base classes also catches every module-specific
    // subclass (\mod_page\event\course_module_viewed etc.).
    [
        'eventname' => '\core\event\course_viewed',
        'callback' => '\auth_devicelock\observer::activity_course_viewed',
        'internal' => false,
        'priority' => 1000,
    ],
    [
        'eventname' => '\core\event\course_module_viewed',
        'callback' => '\auth_devicelock\observer::activity_course_module_viewed',
        'internal' => false,
        'priority' => 1000,
    ],
    [
        'eventname' => '\core\event\user_profile_viewed',
        'callback' => '\auth_devicelock\observer::activity_profile_viewed',
        'internal' => false,
        'priority' => 1000,
    ],
    [
        'eventname' => '\core\event\user_list_viewed',
        'callback' => '\auth_devicelock\observer::activity_participants_viewed',
        'internal' => false,
        'priority' => 1000,
    ],
    [
        'eventname' => '\core\event\course_category_viewed',
        'callback' => '\auth_devicelock\observer::activity_category_viewed',
        'internal' => false,
        'priority' => 1000,
    ],
    [
        'eventname' => '\core\event\grade_report_viewed',
        'callback' => '\auth_devicelock\observer::activity_grades_viewed',
        'internal' => false,
        'priority' => 1000,
    ],
    [
        'eventname' => '\tool_usertours\event\tour_started',
        'callback' => '\auth_devicelock\observer::activity_tour_started',
        'internal' => false,
        'priority' => 1000,
    ],
    [
        'eventname' => '\tool_usertours\event\tour_ended',
        'callback' => '\auth_devicelock\observer::activity_tour_ended',
        'internal' => false,
        'priority' => 1000,
    ],
    // v3.10.0: the events the admin found missing compared to Moodle's
    // standard Logs report - logouts, the Dashboard, the My courses page
    // and single-section pages now all appear in the plugin's log too.
    [
        'eventname' => '\core\event\user_loggedout',
        'callback' => '\auth_devicelock\observer::user_loggedout',
        'internal' => false,
        'priority' => 1000,
    ],
    [
        'eventname' => '\core\event\dashboard_viewed',
        'callback' => '\auth_devicelock\observer::activity_dashboard_viewed',
        'internal' => false,
        'priority' => 1000,
    ],
    [
        'eventname' => '\core\event\mycourses_viewed',
        'callback' => '\auth_devicelock\observer::activity_mycourses_viewed',
        'internal' => false,
        'priority' => 1000,
    ],
    [
        'eventname' => '\core\event\section_viewed',
        'callback' => '\auth_devicelock\observer::activity_section_viewed',
        'internal' => false,
        'priority' => 1000,
    ],
    // v3.10.0: catch-all for every OTHER *::..._viewed event from any
    // component (calendar, blog, messages, notifications, search results,
    // badges, glossary entries, book chapters, wiki/lesson pages ...).
    // Moodle maps '*' to \core\event\base, the parent of every event,
    // so this observer receives them all and logs the *_viewed ones the
    // dedicated observers above do not cover.
    [
        'eventname' => '*',
        'callback' => '\auth_devicelock\observer::activity_wildcard_viewed',
        'internal' => false,
        'priority' => 500,
    ],
];