<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Upgrade script for Lock Guard plugin
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Upgrade the plugin
 *
 * @param int $oldversion The old version of the plugin
 * @return bool Always true
 */
function xmldb_auth_devicelock_upgrade($oldversion) {
    global $DB;
    
    $dbman = $DB->get_manager();
    
    if ($oldversion < 2024010101) {
        // Initial installation - Version 1
        upgrade_plugin_savepoint(true, 2024010101, 'auth', 'devicelock');
    }
    
    if ($oldversion < 2024010102) {
        // Version 2 - Add device_info field if missing
        $table = new xmldb_table('auth_devicelock_devices');
        
        // Check if device_info field exists
        if (!$dbman->field_exists($table, 'device_info')) {
            // Add device_info field
            $field = new xmldb_field('device_info', XMLDB_TYPE_TEXT, null, null, null, null, null, 'device_fingerprint');
            $dbman->add_field($table, $field);
        }
        
        upgrade_plugin_savepoint(true, 2024010102, 'auth', 'devicelock');
    }
    
    if ($oldversion < 2024010103) {
        // Version 3 - Add session tracking table
        $table = new xmldb_table('auth_devicelock_session_tracking');
        
        if (!$dbman->table_exists($table)) {
            
            // Add fields
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $table->add_field('device_fingerprint', XMLDB_TYPE_CHAR, '64', null, XMLDB_NOTNULL, null, null);
            $table->add_field('session_id', XMLDB_TYPE_CHAR, '128', null, XMLDB_NOTNULL, null, null);
            $table->add_field('created_at', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('ip_address', XMLDB_TYPE_CHAR, '45', null, null, null, null);
            $table->add_field('user_agent', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('last_access', XMLDB_TYPE_INTEGER, '10', null, null, null, '0');
            
            // Add keys
            $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
            $table->add_key('fk_tracking_userid', XMLDB_KEY_FOREIGN, array('userid'), 'user', array('id'));
            
            // Add indexes
            $table->add_index('userid_fingerprint', XMLDB_INDEX_UNIQUE, array('userid', 'device_fingerprint'));
            $table->add_index('session_id', XMLDB_INDEX_UNIQUE, array('session_id'));
            $table->add_index('created_at', XMLDB_INDEX_NOTUNIQUE, array('created_at'));
            $table->add_index('ip_address', XMLDB_INDEX_NOTUNIQUE, array('ip_address'));
            $table->add_index('last_access', XMLDB_INDEX_NOTUNIQUE, array('last_access'));
            
            // Create the table
            $dbman->create_table($table);
        }
        
        upgrade_plugin_savepoint(true, 2024010103, 'auth', 'devicelock');
    }
    
    if ($oldversion < 2024010104) {
        // Version 4 - Clean up any duplicate session tracking and add cleanup index
        $table = new xmldb_table('auth_devicelock_session_tracking');
        
        if ($dbman->table_exists($table)) {
            
            // Add last_access field if it doesn't exist
            if (!$dbman->field_exists($table, 'last_access')) {
                $field = new xmldb_field('last_access', XMLDB_TYPE_INTEGER, '10', null, null, null, '0', 'user_agent');
                $dbman->add_field($table, $field);
            }
            
            // Clean up any potential duplicate entries portably
            $sql = "SELECT MIN(id) as id, userid, device_fingerprint 
                      FROM {auth_devicelock_session_tracking} 
                  GROUP BY userid, device_fingerprint";
            if ($records = $DB->get_records_sql($sql)) {
                $keepids = array_keys($records);
                if (!empty($keepids)) {
                    list($insql, $inparams) = $DB->get_in_or_equal($keepids, SQL_PARAMS_NAMED, 'param', false);
                    $DB->delete_records_select('auth_devicelock_session_tracking', "id $insql", $inparams);
                }
            }
            
            // Also delete any orphaned session tracking
            $sql = "DELETE FROM {auth_devicelock_session_tracking} 
                    WHERE userid NOT IN (SELECT id FROM {user})";
            $DB->execute($sql);
        }
        
        upgrade_plugin_savepoint(true, 2024010104, 'auth', 'devicelock');
    }
    
    if ($oldversion < 2024010105) {
        // Version 5 - Update to ensure session tracking is properly set up
        $table = new xmldb_table('auth_devicelock_session_tracking');
        
        if ($dbman->table_exists($table)) {
            // Ensure indexes exist
            $indexes = [
                'userid_fingerprint' => ['userid', 'device_fingerprint'],
                'session_id' => ['session_id'],
                'created_at' => ['created_at'],
                'ip_address' => ['ip_address'],
                'last_access' => ['last_access']
            ];
            
            foreach ($indexes as $name => $fields) {
                $index = new xmldb_index($name, XMLDB_INDEX_NOTUNIQUE, $fields);
                if (!$dbman->index_exists($table, $index)) {
                    $dbman->add_index($table, $index);
                }
            }
        }
        
        upgrade_plugin_savepoint(true, 2024010105, 'auth', 'devicelock');
    }
    
    if ($oldversion < 2024010106) {
        // Version 6 - Ensure plugin is registered in Moodle enabled auth plugins
        require_once(__DIR__ . '/../lib.php');
        if (function_exists('auth_devicelock_ensure_enabled')) {
            auth_devicelock_ensure_enabled();
        }
        upgrade_plugin_savepoint(true, 2024010106, 'auth', 'devicelock');
    }
    
    if ($oldversion < 2024010107) {
        // Version 7 - Ensure plugin registration and clear any stale flags
        require_once(__DIR__ . '/../lib.php');
        if (function_exists('auth_devicelock_ensure_enabled')) {
            auth_devicelock_ensure_enabled();
        }
        upgrade_plugin_savepoint(true, 2024010107, 'auth', 'devicelock');
    }

    if ($oldversion < 2024010108) {
        // Version 8 - Admin action audit logging with admin email & danger zone relocation
        require_once(__DIR__ . '/../lib.php');
        if (function_exists('auth_devicelock_ensure_enabled')) {
            auth_devicelock_ensure_enabled();
        }
        upgrade_plugin_savepoint(true, 2024010108, 'auth', 'devicelock');
    }

    if ($oldversion < 2024010109) {
        // Version 9 - Browser limit per device configuration and Danger Zone native button
        require_once(__DIR__ . '/../lib.php');
        if (function_exists('auth_devicelock_ensure_enabled')) {
            auth_devicelock_ensure_enabled();
        }
        upgrade_plugin_savepoint(true, 2024010109, 'auth', 'devicelock');
    }

    if ($oldversion < 2024010110) {
        // Version 10 - Multi-factor hardware device matching & seamless multi-browser/update linking
        require_once(__DIR__ . '/../lib.php');
        if (function_exists('auth_devicelock_ensure_enabled')) {
            auth_devicelock_ensure_enabled();
        }
        upgrade_plugin_savepoint(true, 2024010110, 'auth', 'devicelock');
    }
    
    if ($oldversion < 2024010111) {
        // Version 11 - Reset all browsers for user and isolated browser reset for specific device
        require_once(__DIR__ . '/../lib.php');
        if (function_exists('auth_devicelock_ensure_enabled')) {
            auth_devicelock_ensure_enabled();
        }
        upgrade_plugin_savepoint(true, 2024010111, 'auth', 'devicelock');
    }
    
    if ($oldversion < 2024010112) {
        // Version 12 - Admin-generated temporary password feature
        require_once(__DIR__ . '/../lib.php');
        if (function_exists('auth_devicelock_ensure_enabled')) {
            auth_devicelock_ensure_enabled();
        }
        upgrade_plugin_savepoint(true, 2024010112, 'auth', 'devicelock');
    }
    
    if ($oldversion < 2024010113) {
        // Version 13 - Use Moodle core addslashes_js and add esc_js polyfill
        require_once(__DIR__ . '/../lib.php');
        if (function_exists('auth_devicelock_ensure_enabled')) {
            auth_devicelock_ensure_enabled();
        }
        upgrade_plugin_savepoint(true, 2024010113, 'auth', 'devicelock');
    }

    if ($oldversion < 2024010114) {
        // Version 14 - Clean up any lingering logout flags and update browser reset handlers
        global $CFG;
        $logoutdir = $CFG->dataroot . '/devicelock_logout_flags';
        if (is_dir($logoutdir)) {
            $flags = glob($logoutdir . '/*.flag');
            if ($flags) {
                foreach ($flags as $flag) {
                    @unlink($flag);
                }
            }
        }
        require_once(__DIR__ . '/../lib.php');
        if (function_exists('auth_devicelock_ensure_enabled')) {
            auth_devicelock_ensure_enabled();
        }
        upgrade_plugin_savepoint(true, 2024010114, 'auth', 'devicelock');
    }

    if ($oldversion < 2024010115) {
        // Version 15 - Add index on auth_devicelock_logs for userid, timestamp for faster audit lookups
        $table = new xmldb_table('auth_devicelock_logs');
        if ($dbman->table_exists($table)) {
            $index = new xmldb_index('userid_timestamp', XMLDB_INDEX_NOTUNIQUE, ['userid', 'timestamp']);
            if (!$dbman->index_exists($table, $index)) {
                $dbman->add_index($table, $index);
            }
        }
        upgrade_plugin_savepoint(true, 2024010115, 'auth', 'devicelock');
    }

    if ($oldversion < 2024010116) {
        // Version 16 - Performance optimizations for high user volume and purge uninstallation support
        upgrade_plugin_savepoint(true, 2024010116, 'auth', 'devicelock');
    }
    
    if ($oldversion < 2026100511) {
        // Version 3.3.1 - Add auth_devicelock_score_history table for per-user
        // security-score trend sparklines on the viewuser page.
        $table = new xmldb_table('auth_devicelock_score_history');
        if (!$dbman->table_exists($table)) {
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $table->add_field('score', XMLDB_TYPE_INTEGER, '3', null, XMLDB_NOTNULL, null, '100');
            $table->add_field('band', XMLDB_TYPE_CHAR, '10', null, XMLDB_NOTNULL, null, 'high');
            $table->add_field('timestamp', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
            $table->add_key('fk_scorehist_userid', XMLDB_KEY_FOREIGN, array('userid'), 'user', array('id'));
            $table->add_index('userid_timestamp', XMLDB_INDEX_NOTUNIQUE, array('userid', 'timestamp'));
            $table->add_index('timestamp', XMLDB_INDEX_NOTUNIQUE, array('timestamp'));
            $dbman->create_table($table);
        }
        upgrade_plugin_savepoint(true, 2026100511, 'auth', 'devicelock');
    }

    if ($oldversion < 2026100512) {
        // Version 3.3.2 - Add auth_devicelock_bans table for the new user-ban
        // feature. An admin can ban a user from signing in; the auth plugin
        // checks this table in user_authenticated_hook and refuses login for
        // any user with an active (status='active') ban row.
        $table = new xmldb_table('auth_devicelock_bans');
        if (!$dbman->table_exists($table)) {
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $table->add_field('reason', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('banned_by', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $table->add_field('banned_at', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('ip_address', XMLDB_TYPE_CHAR, '45', null, null, null, '');
            $table->add_field('device_fingerprint', XMLDB_TYPE_CHAR, '64', null, null, null, '');
            $table->add_field('status', XMLDB_TYPE_CHAR, '10', null, XMLDB_NOTNULL, null, 'active');

            $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
            $table->add_key('fk_ban_userid', XMLDB_KEY_FOREIGN, array('userid'), 'user', array('id'));

            $table->add_index('userid_status', XMLDB_INDEX_NOTUNIQUE, array('userid', 'status'));
            $table->add_index('status', XMLDB_INDEX_NOTUNIQUE, array('status'));
            $table->add_index('banned_at', XMLDB_INDEX_NOTUNIQUE, array('banned_at'));

            $dbman->create_table($table);
        }
        upgrade_plugin_savepoint(true, 2026100512, 'auth', 'devicelock');
    }

    if ($oldversion < 2026101300) {
        // Version 3.5.0 - Persistent security score system.
        // New table auth_devicelock_user_scores stores the live score per
        // user (starts at 100 when the account is created, lowered by each
        // violation, slowly regained over time). Every existing user is
        // seeded with a clean 100 - the new score model begins NOW, past
        // log activity is no longer re-computed into the score.
        $table = new xmldb_table('auth_devicelock_user_scores');
        if (!$dbman->table_exists($table)) {
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $table->add_field('score', XMLDB_TYPE_INTEGER, '3', null, XMLDB_NOTNULL, null, '100');
            $table->add_field('violation_count', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('last_violation', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('last_regain', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('custom_regain', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('regain_amount', XMLDB_TYPE_INTEGER, '3', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('regain_interval', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('updated_at', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');

            $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
            // A foreign-unique key already generates the UNIQUE index on
            // userid (plus the FK constraint). Moodle 5.x rejects a separate
            // index covering exactly the same fields as a key with a coding
            // exception, so no extra userid index is defined here.
            $table->add_key('fk_userscore_userid', XMLDB_KEY_FOREIGN_UNIQUE, array('userid'), 'user', array('id'));

            $table->add_index('score', XMLDB_INDEX_NOTUNIQUE, array('score'));

            $dbman->create_table($table);
        }

        // Seed a row for every existing (non-deleted) user at 100%.
        $now = time();
        $existing = $DB->get_recordset_sql("SELECT u.id FROM {user} u WHERE u.deleted = 0 AND u.id > 1", null);
        foreach ($existing as $eu) {
            $rec = new stdClass();
            $rec->userid = (int)$eu->id;
            $rec->score = 100;
            $rec->violation_count = 0;
            $rec->last_violation = 0;
            $rec->last_regain = 0;
            $rec->custom_regain = 0;
            $rec->regain_amount = 0;
            $rec->regain_interval = 0;
            $rec->updated_at = $now;
            try {
                $DB->insert_record('auth_devicelock_user_scores', $rec, false);
            } catch (\dml_write_exception $e) {
                // Row already exists (unique userid key) - keep it as is.
            }
        }
        $existing->close();

        // Purge the legacy computed-score cache preferences - the score now
        // lives in its own table and this cache is never read again.
        try {
            $DB->delete_records_select('user_preferences', "name = 'auth_devicelock_secscore_cache'");
        } catch (\Exception $e) {
            debugging('Could not purge legacy score cache: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }

        upgrade_plugin_savepoint(true, 2026101300, 'auth', 'devicelock');
    }

    if ($oldversion < 2026101304) {
        // Version 3.8.0 - Migrate the old "Exclude administrators" /
        // "Exclude teachers" checkboxes to the new excluded-roles
        // multi-select: pseudo-entry 'admin' plus the ids of the
        // teacher / editingteacher / manager roles.
        $excluded = get_config('auth_devicelock', 'excludedroles');
        if ($excluded === false || $excluded === null) {
            $list = [];
            if (!empty(get_config('auth_devicelock', 'excludeadmins'))) {
                $list[] = 'admin';
            }
            if (!empty(get_config('auth_devicelock', 'excludeteachers'))) {
                $teacherish = $DB->get_records_list('role', 'shortname',
                    ['teacher', 'editingteacher', 'manager'], 'sortorder ASC', 'id');
                foreach ($teacherish as $tr) {
                    $list[] = (string)(int)$tr->id;
                }
            }
            set_config('excludedroles', implode(',', $list), 'auth_devicelock');
        }
        // The old checkboxes are gone from the settings page.
        unset_config('excludeadmins', 'auth_devicelock');
        unset_config('excludeteachers', 'auth_devicelock');

        upgrade_plugin_savepoint(true, 2026101304, 'auth', 'devicelock');
    }

    if ($oldversion < 2026101402) {
        $table = new xmldb_table('auth_devicelock_ios_state');
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('kind', XMLDB_TYPE_CHAR, '12', null, XMLDB_NOTNULL, null, null);
        $table->add_field('lookuphash', XMLDB_TYPE_CHAR, '64', null, XMLDB_NOTNULL, null, null);
        $table->add_field('fingerprint', XMLDB_TYPE_CHAR, '64', null, XMLDB_NOTNULL, null, '');
        $table->add_field('payload', XMLDB_TYPE_TEXT, null, null, XMLDB_NOTNULL, null, null);
        $table->add_field('created', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('expires', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
        $table->add_index('kind_lookup', XMLDB_INDEX_UNIQUE, ['kind', 'lookuphash']);
        $table->add_index('fingerprint', XMLDB_INDEX_NOTUNIQUE, ['fingerprint']);
        $table->add_index('expiry', XMLDB_INDEX_NOTUNIQUE, ['expires']);
        if (!$dbman->table_exists($table)) { $dbman->create_table($table); }
        upgrade_plugin_savepoint(true, 2026101402, 'auth', 'devicelock');
    }

    if ($oldversion < 2026101403) {
        // Capture policy is fail closed; old session payloads have no OS/build approval.
        $DB->delete_records('auth_devicelock_ios_state', ['kind' => 'session']);
        upgrade_plugin_savepoint(true, 2026101403, 'auth', 'devicelock');
    }

    if ($oldversion < 2026101404) {
        // Capture reporting now revokes only the reporting native bearer.
        upgrade_plugin_savepoint(true, 2026101404, 'auth', 'devicelock');
    }

    if ($oldversion < 2026101405) {
        // Native Mac identity and signed-extension validation share the Apple table.
        // Force existing short-lived sessions to prove their current app again.
        $DB->delete_records('auth_devicelock_ios_state', ['kind' => 'session']);
        upgrade_plugin_savepoint(true, 2026101405, 'auth', 'devicelock');
    }

    if ($oldversion < 2026101406) {
        // The Xcode 26 Mac build uses automatic key possession, not admin grants.
        $DB->delete_records('auth_devicelock_ios_state', ['kind' => 'session']);
        $DB->delete_records('auth_devicelock_ios_state', ['kind' => 'challenge']);
        upgrade_plugin_savepoint(true, 2026101406, 'auth', 'devicelock');
    }

    if ($oldversion < 2026101407) {
        upgrade_plugin_savepoint(true, 2026101407, 'auth', 'devicelock');
    }

    if ($oldversion < 2026101408) {
        $DB->delete_records('auth_devicelock_ios_state', ['kind' => 'session']);
        $DB->delete_records('auth_devicelock_ios_state', ['kind' => 'challenge']);
        upgrade_plugin_savepoint(true, 2026101408, 'auth', 'devicelock');
    }

    if ($oldversion < 2026101500) {
        // The longest current action name filled the 30-character limit exactly.
        // Widen it so future event types are not truncated (MySQL) or rejected.
        $table = new xmldb_table('auth_devicelock_logs');
        $field = new xmldb_field('action', XMLDB_TYPE_CHAR, '40', null, XMLDB_NOTNULL, null, null, 'device_fingerprint');
        $dbman->change_field_precision($table, $field);
        upgrade_plugin_savepoint(true, 2026101500, 'auth', 'devicelock');
    }

    // Always purge caches after upgrade
    purge_all_caches();
    
    return true;
}
