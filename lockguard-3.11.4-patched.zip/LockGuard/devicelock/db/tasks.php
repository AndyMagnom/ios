<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Task definitions for Lock Guard plugin
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$tasks = [
    [
        'classname' => 'auth_devicelock\task\cleanup_logs_task',
        'blocking' => 0,
        'minute' => '15',
        'hour' => '2',
        'day' => '*',
        'dayofweek' => '*',
        'month' => '*',
    ],
    [
        'classname' => 'auth_devicelock\task\revoke_appguard_tokens',
        'blocking' => 0,
        'minute' => '*',
        'hour' => '*',
        'day' => '*',
        'dayofweek' => '*',
        'month' => '*',
    ],
    [
        // Every minute - apply due security-score regains (v3.5.0). Users
        // regain points after the regain timer expires; each regain is
        // logged so the Security & Error Logs show the recovery too.
        'classname' => 'auth_devicelock\task\score_regain_task',
        'blocking' => 0,
        'minute' => '*',
        'hour' => '*',
        'day' => '*',
        'dayofweek' => '*',
        'month' => '*',
    ],
    [
        // Daily at 03:30 — prune device + session-tracking rows whose owning
        // user no longer exists in mdl_user (catches users deleted via Moodle's
        // own UI or a DB restore that bypasses the plugin's delete hook).
        'classname' => 'auth_devicelock\task\prune_orphans_task',
        'blocking' => 0,
        'minute' => '30',
        'hour' => '3',
        'day' => '*',
        'dayofweek' => '*',
        'month' => '*',
    ],
    [
        // Weekly on Monday at 06:00 — email every site admin a security
        // snapshot (7-day trends, score distribution, top-5 at-risk users).
        'classname' => 'auth_devicelock\task\weekly_snapshot_task',
        'blocking' => 0,
        'minute' => '0',
        'hour' => '6',
        'day' => '*',
        'dayofweek' => '1',
        'month' => '*',
    ],
];
