<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Custom uninstallation cleanup for auth_devicelock.
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Custom uninstallation callback.
 * Executed by Moodle core before tables are dropped and plugin configs removed.
 *
 * @return bool True on success
 */
function xmldb_auth_devicelock_uninstall() {
    global $DB, $CFG;

    // 1. Revert any user whose auth is 'devicelock' back to 'manual' so they are not locked out
    try {
        $DB->set_field('user', 'auth', 'manual', ['auth' => 'devicelock']);
    } catch (\Exception $e) {
        debugging('Error reverting auth_devicelock users to manual: ' . $e->getMessage(), DEBUG_DEVELOPER);
    }

    // 2. Remove all user preferences related to the plugin
    try {
        $DB->delete_records_select('user_preferences', "name LIKE 'auth_devicelock_%'");
    } catch (\Exception $e) {
        debugging('Error cleaning up auth_devicelock user preferences: ' . $e->getMessage(), DEBUG_DEVELOPER);
    }

    // 3. Clean up all flag and cache directories on disk
    $dirs = [
        $CFG->dataroot . '/devicelock_logout_flags',
        $CFG->dataroot . '/devicelock_resets',
        $CFG->dataroot . '/devicelock_wipe_flags'
    ];

    foreach ($dirs as $dir) {
        if (is_dir($dir)) {
            $files = glob($dir . '/*');
            if ($files) {
                foreach ($files as $f) {
                    if (is_file($f)) {
                        @unlink($f);
                    }
                }
            }
            @rmdir($dir);
        }
    }

    return true;
}
