<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Plugin settings
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/lib.php');
require_once(__DIR__ . '/classes/local/macos_testing.php');

// If plugin is enabled, ensure it is registered in Moodle's enabled auth plugins
if (get_config('auth_devicelock', 'enabled')) {
    auth_devicelock_ensure_enabled();
}

if ($ADMIN->fulltree) {

    $settings->add(new admin_setting_heading(
        'auth_devicelock/macosheading', 'Native macOS app',
        'Mac access uses signed device-key proof and local code-signature checks, not Apple App Attest. macOS updates do not require individual approval.'
    ));
    $settings->add(new admin_setting_configcheckbox(
        'auth_devicelock/macos_enabled', 'Enable native macOS app',
        'Allow automatic device-key enrollment and Mac content access. Disabling also denies existing Mac sessions. This does not certify app integrity with Apple.', 0
    ));
    $settings->add(new admin_setting_configtext(
        'auth_devicelock/macos_minimum_build', 'Minimum macOS app build',
        'Minimum accepted app build number, not macOS version. Current app build: 2.', 2, PARAM_INT
    ));

    $testactive = \auth_devicelock\local\macos_testing::active();
    $settings->add(new admin_setting_heading(
        'auth_devicelock/macostestingheading', 'SECURITY TESTING — macOS server controls',
        '<div class="alert alert-danger"><strong>STAGING ONLY. ON = protection enforced. OFF = protection disabled.</strong><br>'
        . 'Overrides require the testing switch below and expire after one hour. Turn testing OFF then ON to start another hour. '
        . 'Changing an override invalidates Mac bearers; reopen the app. Mac controls do not change iOS / Android / Windows.'
        . '<br><strong>Current overrides: ' . ($testactive ? 'ACTIVE — SECURITY REDUCED' : 'INACTIVE — normal protections apply') . '</strong></div>'
    ));
    $testswitch = new admin_setting_configcheckbox(
        'auth_devicelock/macos_testing', 'ENABLE ONE-HOUR MAC SECURITY TESTING',
        'OFF by default. For a disposable staging site only. This switch does not enable Mac access; enable the native macOS app above. '
        . 'Moodle authentication, account ownership, nonce replay protection, input validation and HTTPS remain mandatory.', 0
    );
    $testswitch->set_updatedcallback('auth_devicelock_macos_testing_updated');
    $settings->add($testswitch);
    $testcontrols = [
        'minimum_build' => ['Enforce minimum app build', 'OFF accepts any positive build number.'],
        'device_signature' => ['Verify Mac device-key signature', 'OFF accepts unverified device claims. Unsigned testing keys use a separate identity namespace and cannot authenticate a production device.'],
        'device_rules' => ['Enforce device registration, device/browser limits and device blocks', 'OFF bypasses these Lock Guard rules for native Mac bearers only. Moodle account suspension/deletion and account ownership remain enforced.'],
        'challenge_rate' => ['Enforce verification challenge rate limit', 'OFF removes the 120-per-IP-per-minute limit for Mac challenges only.'],
        'challenge_expiry' => ['Enforce two-minute challenge expiry', 'OFF extends Mac challenges to the one-hour testing window. Single-use nonces remain enforced.'],
        'session_expiry' => ['Enforce five-minute native session expiry', 'OFF extends Mac sessions to the one-hour testing window. Disable automatic renewal in the Debug app to test this.'],
        'capture_revocation' => ['Revoke native bearer on capture reports', 'OFF logs capture events without this native-bearer revocation. Other security-score/ban settings remain separate.'],
    ];
    foreach ($testcontrols as $name => [$label, $description]) {
        $settings->add(new admin_setting_configcheckbox(
            'auth_devicelock/macos_test_' . $name, 'PROTECTION: ' . $label,
            '<strong>Checked = ON. Unchecked = OFF.</strong> ' . $description . ' Ignored outside an active testing window.', 1
        ));
    }
    $settings->add(new admin_setting_heading(
        'auth_devicelock/testingexistingcontrols', 'Other existing server security switches',
        'Use <a href="#admin-enabled">Single Device Login: Enable plugin</a> to turn device limiting ON/OFF site-wide; '
        . '<a href="#admin-appguard_enabled">Restrict sign-in to the app</a> for app-only login; '
        . '<a href="#admin-score_enabled">Security score</a> and <a href="#admin-score_autoban">Automatic banning</a> for security penalties. '
        . 'These existing settings are site-wide and do not expire. Restore them after testing. They do not disable Moodle login.'
    ));

    // Heading
    $settings->add(new admin_setting_heading(
        'auth_devicelock/pluginheading',
        get_string('pluginname', 'auth_devicelock'),
        get_string('auth_devicelockdescription', 'auth_devicelock')
    ));

    // ================================================
    // Dashboard Link Button - kept at the very top, above every
    // configurable section, for quick access regardless of what else is
    // being changed below.
    // ================================================
    $dashboardurl = new moodle_url('/auth/devicelock/admin_devices.php');
    $settings->add(new admin_setting_heading(
        'auth_devicelock/dashboardlink',
        'Device Management Dashboard',
        '<a href="' . $dashboardurl . '" class="btn btn-primary btn-lg">'
        . '<i class="fa fa-dashboard"></i> Open Device Management Dashboard</a><br><br>'
        . '<p class="text-muted">Manage user devices, block specific devices, reset all devices, and migrate users to the plugin.</p>'
    ));

    // ================================================
    // Lock Guard: Single Device Login
    // (the original device/browser-limit mechanism)
    // ================================================
    $settings->add(new admin_setting_heading(
        'auth_devicelock/singledeviceloginheading',
        'Single Device Login',
        'Restricts each user account to a limited number of registered devices.'
    ));

    // Enable plugin
    $settings->add(new admin_setting_configcheckbox(
        'auth_devicelock/enabled',
        get_string('enabled', 'auth_devicelock'),
        get_string('enabled_desc', 'auth_devicelock'),
        0
    ));

    // Maximum devices per user (free-text integer - Feature 4)
    $settings->add(new admin_setting_configtext(
        'auth_devicelock/maxdevices',
        get_string('maxdevices', 'auth_devicelock'),
        get_string('maxdevices_desc', 'auth_devicelock')
        . ' This is the setting to raise if you want a student to use the same account on more than one '
        . 'physical device at once (e.g. a PC and a phone) - set it to 2. It works the same whether the '
        . 'student signs in via a browser or, with App Guard below, only via the app: a PC and a phone have '
        . 'different hardware, so they are always counted as 2 separate devices.',
        1,
        PARAM_INT
    ));

    // Maximum browsers per device (0 = unlimited)
    $settings->add(new admin_setting_configtext(
        'auth_devicelock/maxbrowsers',
        get_string('maxbrowsers', 'auth_devicelock'),
        get_string('maxbrowsers_desc', 'auth_devicelock')
        . ' <strong>If "Restrict sign-in to the app" (App Guard, below) is ON, this limit is automatically '
        . 'skipped for restricted users</strong> - once a real second browser is impossible for them anyway, '
        . 'counting the app\'s own re-registrations (reinstalls, cleared app storage) as "new browsers" would '
        . 'only risk locking out a legitimate student, never add security. It still applies normally to any '
        . 'user App Guard does not restrict (e.g. excluded teachers/admins sharing a lab PC).',
        0,
        PARAM_INT
    ));

    // v3.8.0: the old "Exclude administrators" / "Exclude teachers"
    // checkboxes are replaced by one multi-select list of every existing
    // role (plus the site administrators pseudo-entry).
    global $DB;
    $excludedrolechoices = [
        'admin' => get_string('excludedroles_admins', 'auth_devicelock'),
    ];
    $excludedroledefault = ['admin'];
    $excludedrolesrs = $DB->get_records('role', null, 'sortorder ASC', 'id, name, shortname');
    foreach ($excludedrolesrs as $exr) {
        if (in_array($exr->shortname, ['guest', 'user'], true)) {
            continue; // Never listed: guests are never restricted and "user" is implicit.
        }
        $exrname = !empty($exr->name) ? $exr->name : ucfirst($exr->shortname);
        $excludedrolechoices[(string)(int)$exr->id] = $exrname . ' (' . $exr->shortname . ')';
        if (in_array($exr->shortname, ['teacher', 'editingteacher', 'manager'], true)) {
            $excludedroledefault[] = (string)(int)$exr->id;
        }
    }
    $settings->add(new admin_setting_configmultiselect(
        'auth_devicelock/excludedroles',
        get_string('excludedroles', 'auth_devicelock'),
        get_string('excludedroles_desc', 'auth_devicelock'),
        $excludedroledefault,
        $excludedrolechoices
    ));

    // Auto-register first device
    $settings->add(new admin_setting_configcheckbox(
        'auth_devicelock/autoregister',
        get_string('autoregister', 'auth_devicelock'),
        get_string('autoregister_desc', 'auth_devicelock'),
        1
    ));

    // Send notifications
    $settings->add(new admin_setting_configcheckbox(
        'auth_devicelock/sendnotifications',
        get_string('sendnotifications', 'auth_devicelock'),
        get_string('sendnotifications_desc', 'auth_devicelock'),
        0
    ));

    // Auto-migration setting
    $settings->add(new admin_setting_configcheckbox(
        'auth_devicelock/automigrate',
        'Auto-migrate users',
        'Automatically migrate users to Lock Guard once they are confirmed AND hold the student role (if they are otherwise eligible). Users who are confirmed but not yet enrolled/assigned as a student are left alone until they are.',
        0
    ));

    // Migration information
    // NOTE: kept as ONE unindented line deliberately. Moodle's heading
    // renderer treats a block of text whose continuation lines start with
    // leading whitespace as a preformatted/code block (an earlier
    // multi-line, indented version of this string rendered its <ul>/<li>
    // tags as literal escaped text instead of a bullet list) - a single
    // line with no embedded newlines sidesteps that entirely.
    $settings->add(new admin_setting_heading(
        'auth_devicelock/migrationinfo',
        'Migration Information',
        '<p>Users not using Lock Guard can be migrated in three ways:</p>'
        . '<ul>'
        . '<li><strong>Individual:</strong> Click "Migrate" next to any user in the dashboard</li>'
        . '<li><strong>Selected:</strong> Use checkboxes in the Users List and click "Migrate Selected Users"</li>'
        . '<li><strong>Bulk:</strong> Use the "Migrate All to Plugin" button in the dashboard</li>'
        . '<li><strong>Automatic:</strong> Enable "Auto-migrate users" above</li>'
        . '</ul>'
        . '<p><strong>Note:</strong> When migrated, users are automatically logged out from all devices and must register their device on next login.</p>'
    ));

    // ================================================
    // Feature 1: Customizable Email Templates
    // ================================================
    $settings->add(new admin_setting_heading(
        'auth_devicelock/emailtemplatesheading',
        get_string('emailtemplates_heading', 'auth_devicelock'),
        get_string('emailtemplates_heading_desc', 'auth_devicelock')
    ));

    // --- New Device Registered ---
    $settings->add(new admin_setting_configtext(
        'auth_devicelock/email_newdevice_subject',
        get_string('email_newdevice_subject', 'auth_devicelock'),
        get_string('email_newdevice_subject_desc', 'auth_devicelock'),
        get_string('email_newdevice_subject_default', 'auth_devicelock')
    ));
    $settings->add(new admin_setting_configtextarea(
        'auth_devicelock/email_newdevice_body',
        get_string('email_newdevice_body', 'auth_devicelock'),
        get_string('email_placeholders_desc', 'auth_devicelock'),
        get_string('email_newdevice_body_default', 'auth_devicelock')
    ));

    // --- Device Blocked ---
    $settings->add(new admin_setting_configtext(
        'auth_devicelock/email_blocked_subject',
        get_string('email_blocked_subject', 'auth_devicelock'),
        get_string('email_blocked_subject_desc', 'auth_devicelock'),
        get_string('email_blocked_subject_default', 'auth_devicelock')
    ));
    $settings->add(new admin_setting_configtextarea(
        'auth_devicelock/email_blocked_body',
        get_string('email_blocked_body', 'auth_devicelock'),
        get_string('email_placeholders_desc', 'auth_devicelock'),
        get_string('email_blocked_body_default', 'auth_devicelock')
    ));

    // --- Devices Reset ---
    $settings->add(new admin_setting_configtext(
        'auth_devicelock/email_reset_subject',
        get_string('email_reset_subject', 'auth_devicelock'),
        get_string('email_reset_subject_desc', 'auth_devicelock'),
        get_string('email_reset_subject_default', 'auth_devicelock')
    ));
    $settings->add(new admin_setting_configtextarea(
        'auth_devicelock/email_reset_body',
        get_string('email_reset_body', 'auth_devicelock'),
        get_string('email_placeholders_desc', 'auth_devicelock'),
        get_string('email_reset_body_default', 'auth_devicelock')
    ));

    // ================================================
    // App Guard: app-only sign-in restriction + device security events
    // ================================================
    $settings->add(new admin_setting_heading(
        'auth_devicelock/appguardheading',
        'App Guard',
        'Restricts sign-in to your custom app (Windows, Android, Mac, ...) instead of a plain web browser, '
        . 'and receives device security events (emulator, screenshot, developer options, debugging, screen '
        . 'recording, audio capture) from the app. Applies to the SAME users the device limit above applies '
        . 'to (students, minus any admins/teachers excluded above) - there is no separate role list to keep '
        . 'in sync.'
    ));

    $settings->add(new admin_setting_configcheckbox(
        'auth_devicelock/appguard_enabled',
        'Restrict sign-in to the app',
        'When enabled, restricted users (see above) can only sign in through the app. A browser sign-in is '
        . 'refused outright (devicelock-auth users) or terminated on the spot (any other auth method, or an '
        . 'existing browser session from before this was turned on). Site administrators always keep full '
        . 'browser access. Leave OFF until your app is actually being distributed - turning this on blocks '
        . 'every browser sign-in for restricted users immediately, including anyone who has not installed '
        . 'the app yet.',
        0
    ));

    // ================================================
    // v3.4.5: the User-Agent markers and App keys now support MULTIPLE
    // values (one per row), so every app build - Android, Windows, ... -
    // can have its own marker and its own key. Values are stored one per
    // line in the SAME config entries older plugin versions used, so an
    // already-saved single marker/key keeps working unchanged.
    // ================================================
    if (!class_exists('admin_setting_auth_devicelock_multilist')) {
        /**
         * Admin setting that stores a LIST of values (one per line) but
         * shows a friendly row-per-value widget instead of a raw textarea:
         *  - one input per stored value plus one empty row ready for the
         *    next value (typing in it adds another row automatically),
         *  - an "Add another" button and a per-row remove button,
         *  - optional masking (password inputs + show/hide eye toggle)
         *    for secret values such as the App keys,
         *  - multi-line pastes are split across rows.
         *
         * The real form field is a hidden textarea using the standard
         * admin_setting_configtextarea storage format (newline separated),
         * kept in sync live and again on form submit, so saving goes
         * through exactly the same code path as before.
         */
        class admin_setting_auth_devicelock_multilist extends admin_setting_configtextarea {

            /** @var bool Mask values (password inputs + eye toggle). */
            protected $lgmasked = false;

            /** @var string Placeholder shown in each empty row. */
            protected $lgplaceholder = '';

            public function __construct($name, $visiblename, $description, $defaultsetting,
                                        $masked = false, $placeholder = '') {
                $this->lgmasked = (bool)$masked;
                $this->lgplaceholder = (string)$placeholder;
                parent::__construct($name, $visiblename, $description, $defaultsetting, PARAM_RAW, 60, 4);
            }

            /**
             * Never log the real (masked) values into the admin config log.
             */
            protected function add_to_config_log($name, $oldvalue, $value) {
                if ($this->lgmasked) {
                    if ($value !== '') {
                        $value = '********';
                    }
                    if ($oldvalue !== '' and $oldvalue !== null) {
                        $oldvalue = '********';
                    }
                }
                parent::add_to_config_log($name, $oldvalue, $value);
            }

            public function output_html($data, $query = '') {
                $values = auth_devicelock_split_multilist((string)$data);

                $id = $this->get_id();          // e.g. id_s_auth_devicelock_appguard_appkey.
                $name = $this->get_full_name(); // e.g. s_auth_devicelock_appguard_appkey.
                $wrapid = $id . '_lglist';
                $readonly = $this->is_readonly();
                $dis = $readonly ? ' disabled' : '';

                // One row per stored value, plus one empty row ready for
                // the next value - never fewer than one row.
                $rowcount = count($values) + 1;

                $rows = '';
                for ($i = 0; $i < $rowcount; $i++) {
                    $type = $this->lgmasked ? 'password' : 'text';
                    $eye = '';
                    if ($this->lgmasked) {
                        $eye = '<button type="button" class="btn btn-outline-secondary lg-list-eye"'
                            . ' title="Show / hide" aria-label="Show or hide this key"'
                            . $dis . '><i class="fa fa-eye" aria-hidden="true"></i></button>';
                    }
                    $rows .= '<div class="input-group lg-list-row mb-1" style="max-width: 30rem;">'
                        . '<input type="' . $type . '" class="form-control lg-list-input"'
                        . ' autocomplete="new-password" spellcheck="false"'
                        . ' placeholder="' . s($this->lgplaceholder) . '"'
                        . ' value="' . s($values[$i] ?? '') . '"' . $dis . '>'
                        . $eye
                        . '<button type="button" class="btn btn-outline-danger lg-list-del" title="Remove"'
                        . ' aria-label="Remove this entry"' . $dis . '><i class="fa fa-trash" aria-hidden="true"></i></button>'
                        . '</div>';
                }

                $hint = $this->lgmasked
                    ? 'One key per line. Every key listed here is accepted, so each app build can send its own key - remove a line to revoke that key.'
                    : 'One marker per line. A request whose User-Agent contains ANY of these markers counts as the app.';

                // The REAL setting field: a hidden textarea, one value per
                // line (the classic admin_setting_configtextarea format).
                $element = '<div class="lg-multilist" id="' . $wrapid . '">'
                    . '<div class="lg-list-rows">' . $rows . '</div>'
                    . '<div class="mt-1 mb-2">'
                    . '<button type="button" class="btn btn-outline-secondary btn-sm lg-list-add"' . $dis . '>'
                    . '<i class="fa fa-plus" aria-hidden="true"></i> Add another</button>'
                    . '</div>'
                    . '<p class="text-muted small mb-1">' . $hint . '</p>'
                    . '<textarea id="' . $id . '" name="' . $name . '" rows="4" cols="60"'
                    . ' class="d-none" aria-hidden="true">' . s((string)$data) . '</textarea>'
                    . '</div>';

                if (!$readonly) {
                    $element .= $this->lg_widget_js($wrapid, $id);
                }

                $defaultinfo = $this->get_defaultsetting();
                if ($defaultinfo === '' || $defaultinfo === null || $defaultinfo === false) {
                    $defaultinfo = null;
                }

                return format_admin_setting($this, $this->visiblename, $element, $this->description,
                    false, '', $defaultinfo, $query);
            }

            /**
             * Inline JS for the row widget: keeps the hidden textarea in
             * sync (live + on submit), toggles masking, adds/removes rows
             * and splits multi-line pastes across rows.
             */
            protected function lg_widget_js($wrapid, $taid) {
                $js = <<<'EOJS'
<script>
(function() {
    var wrap = document.getElementById('__WRAPID__');
    if (!wrap || wrap.dataset.lgInit) {
        return;
    }
    wrap.dataset.lgInit = '1';
    var ta = document.getElementById('__TAID__');
    var maxrows = 20;

    function inputs() {
        return Array.prototype.slice.call(wrap.querySelectorAll('.lg-list-input'));
    }

    function addRow(focus) {
        var first = wrap.querySelector('.lg-list-row');
        if (!first || inputs().length >= maxrows) {
            return;
        }
        var clone = first.cloneNode(true);
        var inp = clone.querySelector('.lg-list-input');
        inp.value = '';
        wrap.querySelector('.lg-list-rows').appendChild(clone);
        if (focus) {
            inp.focus();
        }
    }

    function sync() {
        var vals = [];
        inputs().forEach(function(inp) {
            var v = inp.value.trim();
            if (v !== '') {
                vals.push(v);
            }
        });
        ta.value = vals.join('\n');
        var ins = inputs();
        var last = ins[ins.length - 1];
        if (last && last.value.trim() !== '' && ins.length < maxrows) {
            addRow(false);
        }
    }

    wrap.addEventListener('input', function(e) {
        if (e.target && e.target.classList && e.target.classList.contains('lg-list-input')) {
            sync();
        }
    });

    wrap.addEventListener('paste', function(e) {
        var t = e.target;
        if (!t || !t.classList || !t.classList.contains('lg-list-input')) {
            return;
        }
        var cd = e.clipboardData || window.clipboardData;
        if (!cd) {
            return;
        }
        var text = cd.getData('text');
        if (!text || text.indexOf('\n') === -1) {
            return;
        }
        e.preventDefault();
        var parts = text.split(/\r\n|\r|\n/).map(function(p) {
            return p.trim();
        }).filter(function(p) {
            return p !== '';
        });
        var firstpart = true;
        parts.forEach(function(p) {
            if (firstpart) {
                t.value = p;
                firstpart = false;
                return;
            }
            addRow(false);
            var ins = inputs();
            ins[ins.length - 1].value = p;
        });
        sync();
    });

    wrap.addEventListener('click', function(e) {
        var t = e.target;
        if (!t || !t.closest) {
            return;
        }
        var eyebtn = t.closest('.lg-list-eye');
        if (eyebtn) {
            var row = eyebtn.closest('.lg-list-row');
            var inp = row ? row.querySelector('.lg-list-input') : null;
            var icon = eyebtn.querySelector('i');
            if (inp) {
                if (inp.type === 'password') {
                    inp.type = 'text';
                    if (icon) { icon.className = 'fa fa-eye-slash'; }
                } else {
                    inp.type = 'password';
                    if (icon) { icon.className = 'fa fa-eye'; }
                }
            }
            return;
        }
        var delbtn = t.closest('.lg-list-del');
        if (delbtn) {
            var row2 = delbtn.closest('.lg-list-row');
            if (row2) {
                if (inputs().length <= 1) {
                    var inp2 = row2.querySelector('.lg-list-input');
                    inp2.value = '';
                    var eye2 = row2.querySelector('.lg-list-eye');
                    if (eye2 && inp2.type === 'text') {
                        inp2.type = 'password';
                        var icon2 = eye2.querySelector('i');
                        if (icon2) { icon2.className = 'fa fa-eye'; }
                    }
                } else {
                    row2.parentNode.removeChild(row2);
                }
                sync();
            }
            return;
        }
        if (t.closest('.lg-list-add')) {
            addRow(true);
        }
    });

    if (ta && ta.form) {
        ta.form.addEventListener('submit', sync);
    }
    sync();
})();
</script>
EOJS;
                return str_replace(['__WRAPID__', '__TAID__'], [$wrapid, $taid], $js);
            }
        }
    }

    $settings->add(new admin_setting_auth_devicelock_multilist(
        'auth_devicelock/appguard_uamarker',
        'App User-Agent markers',
        'Case-insensitive substrings that identify your app(s), one per line. The app should send its '
        . 'marker in its WebView User-Agent (e.g. append "AppGuard/1.0"). A request whose User-Agent '
        . 'contains ANY of the listed markers counts as the app - list several to cover multiple builds '
        . 'or platforms (e.g. the Android and the Windows app). An EMPTY list means nothing counts as '
        . 'the app - with the restriction enabled that blocks EVERY client, including the app, which '
        . 'fails loudly instead of silently protecting nobody.',
        'AppGuard',
        false,
        'AppGuard/1.0'
    ));

    $settings->add(new admin_setting_auth_devicelock_multilist(
        'auth_devicelock/appguard_appkey',
        'App keys',
        'Shared secrets your app can send as an X-App-Key or X-AppGuard-Key header, one per line. ANY '
        . 'listed key is accepted, so you can give each app build (Android, Windows, ...) its own key and '
        . 'revoke a single compromised key by removing just that line. These keys have TWO jobs, one of '
        . 'them NOT optional: (1) hardening the sign-in check - a browser cannot know these values, so a '
        . 'spoofed User-Agent string alone is no longer enough once your app sends its key; AND (2) they '
        . 'are REQUIRED for the app to report security violations (emulator detected, screenshot, '
        . 'developer options, debugging, screen recording, audio capture) to <code>appguard_rest.php</code> '
        . 'before the user is logged in - without a key set here, a pre-login event has no way to '
        . 'authenticate at all and is simply rejected. Leave the list empty ONLY if your app never reports '
        . 'events while the user is logged out and you are relying on the User-Agent markers alone for '
        . 'sign-in hardening.',
        '',
        true,
        'e.g. 3f9d2a8c5e1b7f04d6a2c9e8b1d4f7a0'
    ));

    $settings->add(new admin_setting_configtext(
        'auth_devicelock/appguard_blockedmessage',
        'Blocked sign-in message',
        'Shown to a restricted user when a web sign-in is blocked, and on the explanation page they are '
        . 'redirected to.',
        'This account can only sign in through the official app. Please use the app to sign in.',
        PARAM_TEXT
    ));

    $settings->add(new admin_setting_configcheckbox(
        'auth_devicelock/appguard_notifyadmins',
        'Notify admins of security events',
        'Sends a popup + email to every site administrator when the app reports a security event '
        . '(emulator, screenshot, developer options, debugging, screen recording, audio capture).',
        1
    ));

    $settings->add(new admin_setting_configtext(
        'auth_devicelock/appguard_notifythrottle',
        'Notification throttle (minutes)',
        'Minimum time between two admin notifications about the SAME user (or the same unauthenticated '
        . 'device, for pre-login events). 0 = notify every time.',
        0,
        PARAM_INT
    ));

    $settings->add(new admin_setting_configtext(
        'auth_devicelock/appguard_ratelimit',
        'Event rate limit (per minute)',
        'Maximum number of security events the app endpoint accepts per session, per minute. Protects '
        . 'against a misbehaving or buggy app flooding the logs.',
        60,
        PARAM_INT
    ));

    $settings->add(new admin_setting_heading(
        'auth_devicelock/appguard_endpointinfo',
        'App endpoint',
        'Your app should POST security events as JSON to: <code>' . $CFG->wwwroot . '/auth/devicelock/appguard_rest.php</code>'
        . '<br>See the Activity &amp; Security Logs tab in the <a href="' . $dashboardurl . '">Device Management Dashboard</a> '
        . 'for everything the app has reported.'
    ));

    // ================================================
    // Security Snapshot (weekly email digest)
    // ================================================
    $settings->add(new admin_setting_heading(
        'auth_devicelock/snapshotheading',
        get_string('snapshot_heading', 'auth_devicelock'),
        get_string('snapshot_heading_desc', 'auth_devicelock')
    ));

    $settings->add(new admin_setting_configcheckbox(
        'auth_devicelock/snapshot_enabled',
        get_string('snapshot_enabled', 'auth_devicelock'),
        get_string('snapshot_enabled_desc', 'auth_devicelock'),
        0
    ));

    // ================================================
    // Ban Configuration
    // ================================================
    $settings->add(new admin_setting_heading(
        'auth_devicelock/banheading',
        'Ban Configuration',
        'Customise the message shown to a banned user when they attempt to sign in. The specific ban reason (if one was recorded when the ban was created) is appended below this message on the login page.'
    ));

    $settings->add(new admin_setting_configtextarea(
        'auth_devicelock/ban_message',
        'Ban message',
        'Shown on the login page when a banned user tries to sign in. If a reason was stored with the ban, it is shown on a new line below this message as "Reason: <reason>".',
        'You are banned from using this site!',
        PARAM_TEXT
    ));

    // ================================================
    // Activity Logging (v3.6.0): track everything users do.
    // ================================================
    $settings->add(new admin_setting_heading(
        'auth_devicelock/activitylogheading',
        'User Activity Logging',
        'When enabled, Lock Guard records every page each user opens - site navigation, the courses and activities they view, profiles, grades, files they access, and external links they click - right next to the security events in the Activity &amp; Security Logs. Activity events wear a light outlined badge, never affect the security score, and can be filtered as a whole with the "All User Activity" event-type filter or individually by type.'
    ));

    $settings->add(new admin_setting_configcheckbox(
        'auth_devicelock/activitylog_enabled',
        'Track user activity',
        'Master switch for activity logging. While it is off, no page views or link clicks are recorded - only security and admin events, exactly like before. Site administrators are never tracked unless you enable the option below.',
        1
    ));

    $settings->add(new admin_setting_configcheckbox(
        'auth_devicelock/activitylog_admins',
        'Also track site administrators',
        'When enabled, the pages site administrators view and the links they click are recorded too. This generates a lot of noise while you browse the administration pages, so it is off by default.',
        0
    ));

    $settings->add(new admin_setting_configtext(
        'auth_devicelock/activitylog_retention',
        'Keep activity events for (days)',
        'Activity events (page views and link clicks) are automatically deleted after this many days. Enter 0 to keep them forever. Security events always follow their own fixed 3-week retention and are not affected by this setting.',
        30,
        PARAM_INT
    ));

    // ================================================
    // User Directory & Search (v3.9.0): controls which users the
    // directory lists and how the search box matches them.
    // ================================================
    $settings->add(new admin_setting_heading(
        'auth_devicelock/userdirectoryheading',
        'User Directory & Search',
        'Controls which accounts the User Directory lists and how its search box matches them.'
    ));

    $settings->add(new admin_setting_configcheckbox(
        'auth_devicelock/includeadmins',
        'Show site admins in the User Directory',
        'When disabled (default), site administrator accounts are hidden from the User Directory, the Users Not Using Plugin list, their search results, the type-filter counts and the CSV export. Enable it to list and find administrators again. Administrators remain directly reachable by URL and are never affected by any protection or bulk action.',
        0
    ));

    $settings->add(new admin_setting_configcheckbox(
        'auth_devicelock/fuzzysearch',
        'Advanced (fuzzy) user search',
        'When enabled, the user search also finds results that do not match 100%: every word of the query can appear in a different field ("bulk user 64" finds "bulkuser.64"), punctuation and spaces are ignored when comparing ("bulk-user 64" finds "bulkuser.64"), and single typos are still matched ("buluser 64" finds "bulkuser.64"). Keep it off if you prefer the classic exact-substring search - some admins need precision, others need recall. Searching by role (typing "teacher" to list every user holding a teacher role) is always available, in both modes.',
        0
    ));

    // ================================================
    // Security Score (v3.5.0): persistent per-user score.
    // Every account starts at 100%, each violation lowers it, and it is
    // slowly regained over time once the user stops violating.
    // ================================================
    $settings->add(new admin_setting_heading(
        'auth_devicelock/scoreheading',
        'Security Score',
        'Every account starts at 100%. Each detected violation lowers the score by a fixed amount, and once the user stops violating, the score slowly regains points (see "Regain score over time" below). A new violation before the regain timer has expired instantly restarts the timer, so no points are regained until it reaches zero again. This is exactly how much each violation lowers the score:'
        . '<br><br><strong>Login &amp; device violations</strong>: blocked login on an unregistered device -10 &middot; blocked device login attempt -10 &middot; unexpected device login -12 &middot; device limit reached -6 &middot; browser limit reached -6 &middot; login blocked by a limit -8 &middot; web sign-in blocked by App Guard -4 &middot; device blocked by an admin -5'
        . '<br><strong>Admin sanctions</strong>: account suspended -15 &middot; user banned -40'
        . '<br><strong>App Guard (Android app)</strong>: screenshot attempt -15 &middot; screen recording detected -20 &middot; developer options detected -20 &middot; USB debugging detected -18 &middot; wireless debugging detected -18 &middot; emulator detected -25 &middot; audio capture detected -15 &middot; mic guard unavailable -8 &middot; mic contended -10'
        . '<br><strong>App Guard (Windows app)</strong>: virtual machine detected -25 &middot; debugger detected -20 &middot; developer mode detected -20 &middot; test signing detected -18 &middot; remote session detected -12 &middot; virtual display detected -15 &middot; capture tool detected -15 &middot; recorder suspected -15'
        . '<br><br>Change any score manually from the user action menu ("Change Score") - increase, decrease, set an exact value or reset to 100% - and give an individual user their own regain rate instead of the global one. Reset many scores at once with "Reset Score" in the User Directory bulk actions.'
    ));

    $settings->add(new admin_setting_configcheckbox(
        'auth_devicelock/score_enabled',
        'Track security score',
        'Master switch for the whole score system: while this is off, violations stop lowering the score and no points are regained. Stored scores are kept and can still be changed manually.',
        1
    ));

    // v3.7.0: the Auto-ban controls run a retroactive sweep when they are
    // saved, so users whose stored score is already at or below the
    // threshold are banned immediately (see lib.php
    // auth_devicelock_score_autoban_sweep()).
    if (!class_exists('admin_setting_auth_devicelock_autoban_checkbox')) {
        /**
         * Auto-ban enable checkbox that also runs the threshold sweep, so
         * switching the feature on immediately honours an existing
         * threshold (v3.7.0).
         */
        class admin_setting_auth_devicelock_autoban_checkbox extends admin_setting_configcheckbox {
            public function write_setting($data) {
                $result = parent::write_setting($data);
                if (is_string($result) && $result !== '') {
                    return $result; // Storage error - skip the sweep.
                }
                try {
                    $banned = auth_devicelock_score_autoban_sweep();
                    if ($banned > 0) {
                        \core\notification::success(
                            get_string('score_autoban_swept', 'auth_devicelock', $banned)
                        );
                    }
                } catch (\Exception $e) {
                    // Never block saving the setting.
                }
                return $result;
            }
        }
    }

    if (!class_exists('admin_setting_auth_devicelock_autoban_threshold')) {
        /**
         * Auto-ban threshold (0-100%) that clamps the saved value and
         * immediately auto-bans every user already at or below the new
         * threshold (v3.7.0).
         */
        class admin_setting_auth_devicelock_autoban_threshold extends admin_setting_configtext {
            public function write_setting($data) {
                $data = (string)max(0, min(100, (int)$data));
                $result = parent::write_setting($data);
                if (is_string($result) && $result !== '') {
                    return $result;
                }
                try {
                    $banned = auth_devicelock_score_autoban_sweep();
                    if ($banned > 0) {
                        \core\notification::success(
                            get_string('score_autoban_swept', 'auth_devicelock', $banned)
                        );
                    }
                } catch (\Exception $e) {
                    // Never block saving the setting.
                }
                return $result;
            }
        }
    }

    $settings->add(new admin_setting_auth_devicelock_autoban_checkbox(
        'auth_devicelock/score_autoban',
        'Auto-ban low scores',
        'When enabled, a user whose score reaches the "Auto-ban threshold" below is banned automatically - exactly like a manual ban: the account is suspended, all sessions are killed, and the reason "Security score reached X%" (with X being the threshold) is shown on the login screen. Site administrators are never auto-banned. Saving this setting - or the threshold - immediately auto-bans every existing user whose score is already at or below the threshold.',
        0
    ));

    $settings->add(new admin_setting_auth_devicelock_autoban_threshold(
        'auth_devicelock/score_autoban_threshold',
        'Auto-ban threshold (%)',
        'The score at (or below) which a user is banned automatically while "Auto-ban low scores" is enabled. 0 keeps the classic behaviour (ban only at exactly 0%); raise it to auto-ban earlier - for example 20 bans every user whose score falls to 20% or below. When you save this setting, every user already at or below the new threshold is banned immediately (site administrators excluded).',
        0,
        PARAM_INT
    ));

    $settings->add(new admin_setting_configcheckbox(
        'auth_devicelock/score_regain_enabled',
        'Regain score over time',
        'When enabled, a user whose score is below 100% regains the configured amount of points after every full regain interval without a new violation. Any new violation (or a manual decrease) restarts the timer from zero, so the user does not regain anything until it completes again.',
        1
    ));

    $settings->add(new admin_setting_configtext(
        'auth_devicelock/score_regain_amount',
        'Points regained each time',
        'How many points (out of 100) the user regains each time the regain timer completes. Example: with the default of 5 points every 1 day, a score of 0% climbs back to 100% in 20 clean days.',
        5,
        PARAM_INT
    ));

    $settings->add(new admin_setting_configtext(
        'auth_devicelock/score_regain_number',
        'Regain interval (value)',
        'Together with the time unit below: how long the user must go without any new violation before points are regained. Any new violation before the interval completes resets it back to the start.',
        1,
        PARAM_INT
    ));

    $settings->add(new admin_setting_configselect(
        'auth_devicelock/score_regain_unit',
        'Regain interval (time unit)',
        'The unit for the regain interval value above - anything from seconds to months. A month counts as 30 days.',
        'days',
        [
            'seconds' => 'Seconds',
            'minutes' => 'Minutes',
            'hours'   => 'Hours',
            'days'    => 'Days',
            'weeks'   => 'Weeks',
            'months'  => 'Months',
        ]
    ));

    // ================================================
    // Danger Zone: Purge All Plugin Data (Native Moodle Button)
    // ================================================
    if (!class_exists('admin_setting_auth_devicelock_purge_button')) {
        class admin_setting_auth_devicelock_purge_button extends admin_setting {
            public function __construct() {
                $this->nosave = true;
                parent::__construct(
                    'auth_devicelock/purgelink',
                    get_string('purge_data_title', 'auth_devicelock'),
                    get_string('purge_data_desc', 'auth_devicelock'),
                    ''
                );
            }

            public function get_setting() {
                return true;
            }

            public function write_setting($data) {
                return '';
            }

            public function output_html($data, $query = '') {
                $purgeurl = new moodle_url('/auth/devicelock/purge_data.php');
                $btn = html_writer::link(
                    $purgeurl,
                    '<i class="fa fa-trash mr-1"></i> ' . get_string('purge_data_btn', 'auth_devicelock'),
                    ['class' => 'btn btn-danger font-weight-bold shadow-sm']
                );
                $warning = html_writer::tag(
                    'div',
                    '<i class="fa fa-exclamation-triangle text-danger mr-1"></i> ' . get_string('purge_data_desc', 'auth_devicelock'),
                    ['class' => 'form-text text-danger font-weight-bold mt-2']
                );
                $content = html_writer::tag('div', $btn . $warning, ['class' => 'form-setting pt-1']);
                return format_admin_setting($this, $this->visiblename, $content, $this->description, true, '', null, $query);
            }
        }
    }
    $settings->add(new admin_setting_auth_devicelock_purge_button());

    // ================================================
    // Cosmetic (v3.4.5): Moodle prints the raw "auth_devicelock |
    // setting_name" identifier in a small grey line under every setting
    // label on admin settings pages (the .form-shortname span from the
    // core_admin/setting template). On THIS plugin's page those
    // underscored technical names are hidden instead: this no-save
    // "setting" injects a <style> rule scoped to this page's setting
    // IDs, and since its output only renders on this page, no other
    // admin page is ever affected.
    // ================================================
    if (!class_exists('admin_setting_auth_devicelock_hide_shortnames')) {
        class admin_setting_auth_devicelock_hide_shortnames extends admin_setting {

            /** @var array Setting names whose shortname line is hidden. */
            public static $hiddenames = [];

            public function __construct() {
                $this->nosave = true;
                parent::__construct('auth_devicelock/hideshortnames', '', '', '');
            }

            public function get_setting() {
                return true;
            }

            public function write_setting($data) {
                return '';
            }

            public function output_html($data, $query = '') {
                if (empty(self::$hiddenames)) {
                    return '';
                }
                $selectors = [];
                foreach (self::$hiddenames as $hname) {
                    $selectors[] = '#admin-' . $hname . ' .form-shortname';
                }
                return '<style>' . implode(',', $selectors) . ' { display: none !important; }</style>' . "
";
            }
        }
    }
    $settings->add(new admin_setting_auth_devicelock_hide_shortnames());
    // Collected AFTER every setting on this page has been added, so all of
    // them (including the two widgets and the purge button) are covered.
    foreach ($settings->settings as $lgsetting) {
        admin_setting_auth_devicelock_hide_shortnames::$hiddenames[] = $lgsetting->name;
    }
}

// ================================================
// Lock Guard top-bar tab (Site administration -> Lock Guard), alongside
// General / Users / Courses / Plugins / Server / etc.
//
// WHY THE SUBCATEGORY: Moodle folds a root admin_category into the
// "General" tab instead of showing it as its own top-bar tab when the
// category is a "short branch" - fewer than 8 children, ALL of them
// leaf pages (lib/navigationlib.php :: is_short_branch()). Giving the
// root category one child that is ITSELF a category (not a leaf) is
// enough to avoid that, regardless of how few pages there are overall.
// ================================================
if (is_null($ADMIN->locate('lockguard'))) {
    $ADMIN->add(
        'root',
        new admin_category('lockguard', 'Lock Guard'),
        'server'
    );
}

// Subcategory: turns the root category above into a real top-bar tab (see
// note above). It holds ALL the tab's links, so the root category has no
// leaf pages of its own and no extra black "Lock Guard" heading is drawn.
if (is_null($ADMIN->locate('lockguard_quicklinks'))) {
    $ADMIN->add('lockguard', new admin_category('lockguard_quicklinks', 'Quick Links'));
}
if (is_null($ADMIN->locate('lockguard_dashboard'))) {
    $ADMIN->add('lockguard_quicklinks', new admin_externalpage(
        'lockguard_dashboard',
        'Dashboard',
        new moodle_url('/auth/devicelock/admin_devices.php'),
        'auth/devicelock:managedevices'
    ));
}
if (is_null($ADMIN->locate('lockguard_logs'))) {
    $ADMIN->add('lockguard_quicklinks', new admin_externalpage(
        'lockguard_logs',
        'Activity & Security Logs',
        new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'logs']),
        'auth/devicelock:managedevices'
    ));
}
if (is_null($ADMIN->locate('lockguard_users'))) {
    $ADMIN->add('lockguard_quicklinks', new admin_externalpage(
        'lockguard_users',
        'User Directory',
        new moodle_url('/auth/devicelock/admin_devices.php', ['tab' => 'users']),
        'auth/devicelock:managedevices'
    ));
}

// "Settings" quick link: instead of linking to the page that lives under
// Plugins > Authentication (which makes Moodle switch to the Plugins tab),
// move the real settings page into this tab. Same section name, so
// /admin/settings.php?section=authsettingdevicelock and the "Manage
// authentication" Settings link keep working.
// Setting $settings = null stops core from also adding it under Plugins.
if (isset($settings) && $settings instanceof admin_settingpage) {
    $settings->visiblename = 'Settings';
    $ADMIN->add('lockguard_quicklinks', $settings);
    $settings = null;
}

// ================================================
// Dashboard shortcut: Site Admin -> Users tab -> Accounts category, first in
// the list (before "Browse list of users").
// ================================================
if (is_null($ADMIN->locate('devicelock_dashboard'))) {
    $ADMIN->add(
        is_null($ADMIN->locate('accounts')) ? 'users' : 'accounts',
        new admin_externalpage(
            'devicelock_dashboard',
            'Lock Guard Dashboard',
            new moodle_url('/auth/devicelock/admin_devices.php'),
            'auth/devicelock:managedevices'
        ),
        'editusers'
    );
}
